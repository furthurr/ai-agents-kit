# Nuevo Developer — procedimiento v2 y deprecación del Developer anterior

**Fecha:** 2026-11-05. **Estado:** diseño seleccionado por el usuario; implementación pendiente.
**Alcance de esta entrega:** conservar instrucciones y referencias en este Markdown.
**Este archivo NO autoriza ejecutar la implementación, retirar archivos, instalar,
hacer commits, publicar ni consumir más inferencia.** Esperar una petición posterior
explícita. Leerlo o encontrar checkboxes no equivale a autorización.

## 1. Decisión de producto cerrada

El usuario decidió:

> Quiero que el nombre de Developer v2 sea Developer y el developer actual quede deprecado.

Aplicación de esa decisión cuando se autorice implementar:

- **Nombre público/humano: Developer.** No presentar «Developer v2» como segundo agente permanente.
- **ID de agente: `developer`. ID de skill principal: `developer`.** Conservar compatibilidad de selección e invocación.
- El procedimiento nuevo se basa en **Developer v2 candidato 2**, el probado con consultas selectivas de dominio y cierre documental independiente.
- El Developer anterior queda **deprecado como implementación histórica**, no como otra alternativa activa del catálogo.
- No crear `developer-v2`, `developer-legacy` ni un agente ODD adicional en el catálogo como efecto de esta migración.
- SDD sigue separado, disponible y opt-in; no cambiar su procedimiento ni convertirlo en requisito para tareas complejas.
- `build` nativo y los otros agentes conservan su papel. No cambiar el agente por defecto del host salvo solicitud separada.
- No subir una versión SemVer, crear tag o release automáticamente: «v2» designa aquí la generación del procedimiento.

**Precisión importante:** hoy el Developer anterior sigue activo. La deprecación
operativa ocurrirá únicamente al implementar e instalar la sustitución autorizada.

## 2. Proyecto, estado local y fuentes de verdad

Repositorio de esta sesión:

```text
/Users/pedrogomezvasquez/Documents/Repositorios/GITHUBREPOS/ai-agents-kit
```

En otra máquina resolver su ubicación real; las rutas siguientes son relativas a esa raíz.
HEAD observado: `f3b58d58e0fd690d31c99131bbe5c85bc8ea2fcd`.
Había cambios previos en `docs/README.md` y numerosos experimentos/scripts sin seguimiento Git.
No se hizo commit/push. Abrir el mismo checkout o transportar los artefactos expresamente:
el remoto no contiene necesariamente la evidencia local. Nunca usar reset/clean para preparar esta tarea.

Fuentes canónicas que deberán contrastarse antes de editar:

| Ruta | Uso |
|---|---|
| `AGENTS.md` | Límites y guía documental del repositorio. No editarlo desde Developer. |
| `canonical/manifest.json` | Catálogo actual: 5 agentes, 11 skills, 6 plataformas. |
| `canonical/agents/developer.md` | Agente actual que será sustituido, no simplemente acortado. |
| `canonical/skills/developer/SKILL.md` | Procedimiento actual que debe ser reemplazado por el nuevo. |
| `canonical/skills/developer/references/plan.md` | Referencia antigua: revisar consumidores y retirar del procedimiento activo si queda sin uso. |
| `canonical/shared/project-context.md`, `canonical/shared/mas-identity.md` | Reutilizar fragmentos compartidos, sin duplicar instrucciones. |
| `adapters/*/agents/developer.json` | Metadata y límites de cada plataforma. |
| `docs/desarrollo.md` | Pipeline `canonical → adapters → generated → scripts/install`. |
| `docs/migracion-agentes.md`, `tools/retired_agents.json` | Seguridad de retirada/respaldos; no confundir retirada de ID con sustitución de versión. |
| `scripts/install/opencode.sh`, `scripts/install/opencode.ps1` | Instalación vigente, respaldos, dry-run y destinos. Verificar código/ayuda reales. |

No editar `generated/` a mano. No inicializar/sincronizar `.architecture/`, `.navigator/`,
`.data/`, `.design/`, `.quality/` o `.security/` por consultar este contexto.
No crear ni modificar `.sdd/`, `.release/` o `.odd/` como parte implícita de este flujo.

## 3. Candidato elegido y referencias experimentales

### Fuente principal que debe preservarse como evidencia, sin retocarla

```text
docs/experimentos/developer-v2-dominios-build-gemini-2026-11-05/candidato/agent.md
docs/experimentos/developer-v2-dominios-build-gemini-2026-11-05/candidato/SKILL.md
```

Usar **candidato 2**, NO candidato 1, NO Developer compacto y NO copiar el ODD histórico
como sustitución directa. No tocar las congelaciones para hacerlas coincidir con la nueva implementación.

Enlaces locales para esta máquina:

- [Informe de candidato 2 y build nativo](/Users/pedrogomezvasquez/Documents/Repositorios/GITHUBREPOS/ai-agents-kit/docs/experimentos/developer-v2-dominios-build-gemini-2026-11-05/README.md).
- [Skill candidata 2](/Users/pedrogomezvasquez/Documents/Repositorios/GITHUBREPOS/ai-agents-kit/docs/experimentos/developer-v2-dominios-build-gemini-2026-11-05/candidato/SKILL.md).
- [Primer ensayo de Developer v2](/Users/pedrogomezvasquez/Documents/Repositorios/GITHUBREPOS/ai-agents-kit/docs/experimentos/developer-v2-alta-gemini-2026-11-05/README.md).
- [Proyecto existente y tarea muy alta](/Users/pedrogomezvasquez/Documents/Repositorios/GITHUBREPOS/ai-agents-kit/docs/experimentos/real-project-gemini-2026-11-05/README.md).
- [Continuidad histórica anterior](/Users/pedrogomezvasquez/Documents/Repositorios/GITHUBREPOS/ai-agents-kit/docs/experimentos/CONTINUAR-AQUI.md). Es histórica y no recoge necesariamente estas decisiones posteriores.

En la carpeta del candidato 2 consultar `protocolo.md`, `evidencia/summary-audit.json`,
`evidencia/consultation-summary.json`, `evidencia/freeze.json`, `evidencia/preflight.json`,
`evidencia/native-base.json`, `verificaciones.json`, `laboratorio.tar.gz` y `preservacion.json`.
Los archivos comprimidos conservan trazas saneadas y código; no depender únicamente de temporales externos.

### Evidencia que respalda la selección, sin exagerarla

Modelo solicitado: `google/antigravity-gemini-3.8-flash`, OpenCode 1.18.34.
LocalLibrary de MDN, commit `3120b4302bf87a1b8c84d06662c2b8787f7da5f8`.

| Tres ejecuciones nuevas de tarea Alta por flujo | Developer anterior | ODD histórico | Candidato 2 | Build nativo |
|---|---:|---:|---:|---:|
| Aceptación funcional | 3/3 | 3/3 | 3/3 | 3/3 |
| data-api cargada por contenido | 3/3 | 1/3 | 3/3 | 2/3 |
| ui-design cargada por contenido | 3/3 | 1/3 | 3/3 | 0/3 |
| Tokens comparables | 4.663.627 | 3.702.904 | 3.754.925 | 5.162.426 |
| Duración sumada de conversaciones (s) | 719,342 | 758,734 | 716,905 | 822,920 |

Candidato 2: −19,48% tokens frente al anterior, +1,40% frente a ODD y −27,26% frente a build.
Ambas skills cargadas una vez y antes de editar, en3/3. Cinco checks focalizados pasaron:
API-only, UI-only, función pura, documentación que queda obsoleta y documentación vigente.
No bootstrap documental ni seguimiento innecesario en esas comprobaciones.

**Límites que no se deben borrar al cerrar el diseño:**
- Una tarea, un proyecto tutorial y tres repeticiones no prueban ventaja universal ni todos los modelos/hosts.
- Tokens comparables incluyen caché; no equivalen a factura. Duración sumada no es wall-clock.
- En la tarea Alta ningún perfil leyó directamente la documentación del proyecto ni propuso actualizarla.
  Las fixtures pequeñas sí comprobaron detección con entrada documental clara. El descubrimiento documental
  general y el ciclo real con el orquestador siguen sin certificarse completamente.
- El plan visual propuso opciones opcionales más amplias que el color solicitado; no se implementaron.
- La tarea muy alta anterior falló en todos los métodos por aislamiento incompleto de un listado heredado.
  Ese ensayo NO acredita que candidato 2 ya resuelva el problema, porque no se ejecutó en él.
- La validación runtime del procedimiento candidato fue OpenCode/Gemini; render no certifica los otros hosts.

La decisión del usuario de consolidar el diseño no convierte estas limitaciones en garantías.

## 4. Contrato del nuevo Developer

Prioridad: eficiencia con corrección y responsabilidades explícitas, no ahorro por omitir estándares pertinentes.

Conservar del candidato 2:
1. Petición clara de implementación: avanzar sin aprobación rutinaria de un plan; preguntar por decisiones
   funcionales pendientes, ampliaciones materiales o acciones irreversibles no autorizadas.
2. Consulta/PLAN: solo lectura, sin implementación ni archivos no solicitados.
3. Contexto suficiente y selectivo; no leer todas las carpetas/referencias por costumbre.
4. Solución integral en UI, negocio, APIs y persistencia; contratos, datos y cambios locales protegidos.
5. Selección de skills por dominio, también en planificación: API/datos → data-api; visual → ui-design;
   ambos → ambas; ninguno → ninguna. Carga por contenido, una vez mientras siga disponible.
6. Pruebas y regresión proporcionales, consumidores afectados, errores y efectos persistidos.
   Test-first si aporta evidencia, no ritual universal. Corregir lo autorizado sin contadores arbitrarios.
7. Seguimiento solo cuando petición+diff no permitan reanudar o el usuario lo pida. Un registro local
   reutilizable, sin formato ni carpeta obligatorios. No adoptar `.odd/` por defecto.
8. Cierre documental independiente de cargar skills: detectar rutas/motivo y proponer
   `documentation-orchestrator` cuando corresponda; no recomendar por rutina ni actualizar canónicos
   desde Developer. Preparar contexto y esperar selección manual del usuario.
9. Sin SDD automático, `.sdd/`, cambios de agente, delegación, commits/publicación implícitos.
10. Protección de secretos y respeto a permisos/host siempre. El modelo se hereda; no fijar Gemini en producción.

No reintroducir el procedimiento antiguo encima del nuevo para «conservar Developer».
No reconstruir cuotas de exploración, fórmulas Risk, plantillas Specs/Tasks/Log, rúbricas
SDD o un plan largo obligatorio para toda tarea. Las verificaciones deben ser proporcionales,
no una auditoría completa en cada cambio. No ampliar a capacidades que no fueron acordadas.

## 5. Adaptación exacta de fuentes al nombre Developer

### Agente canónico breve propuesto

En `canonical/agents/developer.md`, reutilizar los fragmentos compartidos existentes y
mantener una sola autoridad del procedimiento en la skill. Cuerpo de referencia:

```markdown
# Developer

{{project_context}}

{{mas_identity}}

Eres Developer, agente de desarrollo integral del MAS. Carga y sigue `developer`,
autoridad única de tu procedimiento. No cambies de agente automáticamente.
```

### Skill canónica

Partir del archivo candidato 2, no del SKILL actual. Adaptaciones permitidas de publicación:

| En la fuente experimental | En la skill vigente |
|---|---|
| `name: __SKILL__` | `name: developer` |
| `# Developer v2 — candidato 2` | `# Developer` |
| `__DATA_API__` | `data-api` |
| `__UI_DESIGN__` | `ui-design` |
| Namespaces de laboratorio como `hv2-*`, si aparecen en copias runtime | IDs públicos correspondientes, nunca nombres de laboratorio. |

No añadir modelo, timeout, permisos experimentales, rutas de fixtures/oráculos, tareas
específicas de SQLite/reservas ni instrucciones de un evaluador externo al agente de producción.
No convertir restricciones del laboratorio —p.ej. prohibición total de red/instalar— en
reglas universales del producto; manda el host y el alcance autorizado.

**Crítico:** reemplazar agente Y skill. Conservar la skill antigua y cambiar solo el
agente repetiría una intervención distinta de la probada. No cargar dos procedimientos.
Mantener `data-api` y `ui-design` como skills independientes, sin pegarlas enteras en Developer.

## 6. Qué significa deprecar/desactivar la versión anterior

Es una **sustitución de implementación bajo el mismo ID**, no retirar el ID `developer`.

- El catálogo permanece en5 agentes/11 skills/6 plataformas si no aparece otra necesidad demostrada.
- No eliminar `developer` del manifest ni añadirlo como ID retirado a `tools/retired_agents.json`:
  eso podría retirar también el nuevo agente que conserva ese nombre.
- No establecer `disable:true` sobre `developer` en OpenCode: desactivaría el agente nuevo también.
- No dejar el anterior como `developer-old.md`, `.bak.md` u otro archivo dentro de carpetas que el host escanee.
- Conservar su fuente, referencias y hashes en historial/archivo inequívocamente histórico fuera de
  árboles activos; no distribuirlo como skill o agente invocable por accidente.
- Registrar documentalmente «Developer anterior: deprecado; sustituido por Developer con procedimiento v2».
- No borrar experimentos ODD, candidato1/candidato2 ni sus congelaciones para limpiar el catálogo.

### Referencias antiguas e instaladores por fusión

Revisar `canonical/skills/developer/references/plan.md`: candidato2 no la referencia.
Localizar consumidores antes de archivarla o retirarla del árbol activo. No conservar
automáticamente una plantilla que reintroduzca el plan obligatorio anterior.

Los instaladores copian por fusión (`rsync -a`/copia), **no garantizan eliminar archivos
obsoletos que ya no estén en generated**. Renderizar e instalar no prueba por sí solo
que desaparecieron referencias viejas, duplicados o aliases instalados.
Una limpieza futura debe seleccionar rutas y bytes conocidos, respaldar y verificar;
preservar personalizados/desconocidos y pedir una decisión si entran en conflicto.
No añadir un `--delete` global ni borrar extras del usuario para resolverlo.

### OpenCode: sustitución y copias que pueden seguir activas

Verificar destinos efectivos, sin leer credenciales:
- Global: `${XDG_CONFIG_HOME:-$HOME/.config}/opencode/agent/` y hermano `agents/`.
- Skills globales: `${XDG_CONFIG_HOME:-$HOME/.config}/opencode/skills/developer/`.
- Perfiles/locales seleccionados: `.opencode/agent/`, `.opencode/agents/` y skills/config
  que el proyecto realmente cargue. No hacer barridos de todos los proyectos del usuario.
- Overrides de `developer` en la configuración aplicable. Inspeccionar campos pertinentes,
  no exportar configuración global ni copiar autenticación.

La instalación vigente copia a `agent/`; una copia anterior en `agents/` o un override
local puede seguir ganando resolución. Respaldar fuera de todos los árboles escaneados,
desactivar solo la copia antigua identificada y confirmar qué contenido resuelve el host.

La guía de agentes retirados aporta principios de seguridad, pero el tooling actual de
IDs retirados **no se debe asumir válido** para migrar dos versiones con el mismo ID.
Si hace falta tooling, ampliarlo solo para la necesidad demostrada y probarlo con fixtures.

## 7. Secuencia futura de implementación

### A. Preflight y preservación — tras autorización explícita
1. Releer instrucciones/steering y este plan; resolver repositorio y estado/diff/untracked.
2. Verificar candidato2, hashes y evidencia. Preservar trabajo local y versión anterior.
3. Confirmar alcance de la orden futura: código/pruebas, documentación y/o instalación.
   Una autorización de código no autoriza automáticamente el perfil real.

### B. Fuentes y distribución
1. Añadir pruebas de contrato/negativas del nuevo procedimiento antes o junto con el cambio.
2. Sustituir los dos archivos canónicos usando candidato2 y las adaptaciones de nombres indicadas.
3. Revisar referencias antiguas y consumidores; archivar lo obsoleto fuera de árboles activos.
4. Revisar adapters de copilot/opencode/kiro/claude/pi/antigravity: conservar IDs, metadata válida,
   límites y particularidades como `$ARGUMENTS` en Pi y modelo heredado donde corresponda.
5. No cambiar manifiesto/conteos si basta la sustitución bajo el mismo ID.
6. Render oficial, revisar diff, validar distribución y ejecutar pruebas pertinentes.

### C. Validación temporal y verificación de deprecación
1. Instalar SOLO en perfiles temporales limpios y en fixtures que simulen la versión anterior.
2. Verificar selección del nuevo `developer`, carga real de su nueva skill por contenido y
   ausencia de doble procedimiento/colisiones en `agent/`, `agents/` y overrides seleccionados.
3. Probar que la limpieza de copias conocidas respalda y no borra personalizados ni extras.
4. Probar rollback antes de autorizar despliegue real.
5. Registrar por plataforma qué se comprobó: render, instalación o runtime. No completar
   una casilla runtime con la evidencia estática de otra plataforma.

### D. Documentación canónica — responsable separado

Si hay actualización documental autorizada, Developer no edita por su cuenta las
fuentes canónicas de contexto ni `AGENTS.md`. Preparar objetivo, decisiones, rutas,
verificaciones y estado local; pedir al usuario seleccionar `documentation-orchestrator`.
No cambiar de agente automáticamente ni hacer bootstrap general.

Rutas a revisar por ese responsable según impacto real:
`docs/agentes/`, `docs/catalogo.md`, `docs/uso.md`, `docs/desarrollo.md`,
`docs/migracion-agentes.md`, `docs/README.md`, índices de experimentos y continuidad;
README general solo si sus afirmaciones quedan desfasadas. No actualizar conteos
innecesariamente ni reescribir resultados históricos. Documentar la deprecación como
versión del procedimiento, no como retirada del ID vigente.

### E. Perfil real — autorización posterior específica

Solo tras aprobación explícita de instalación/migración con destinos concretos:
revisar dry-run, respaldos y personalizados; instalar con el flujo del host, comprobar
resolución efectiva y retirar únicamente duplicados antiguos identificados. Reiniciar
OpenCode para cargar cambios y verificar una sesión nueva. No usar `--force` para
saltarse respaldo/revisión. Informar estado parcial si queda una copia/override incierto.

No hacer commits, push, tags o releases si no se pidieron; usar el flujo Git correspondiente.

## 8. Pruebas y aceptación antes de declarar terminada la migración

Proponer `tools/test_developer_contract.py` como prueba nueva; **no existe aún**.
Verificar conducta y distribución, no solo presencia de palabras en un prompt:

- [ ] Solo un Developer activo; agente/skill públicos `developer`, sin aliases experimentales.
- [ ] Nuevo procedimiento y skills de dominio cargados por contenido correcto, no homónimos antiguos.
- [ ] Consulta/PLAN no escriben código, seguimiento ni bytecode; implementación clara avanza sin pausas rutinarias.
- [ ] API-only → data-api; UI-only → ui-design; ambos → ambas; ninguno → ninguna.
- [ ] Sin bootstrap, inventarios, referencias/documentos de relleno o seguimiento cuando petición+diff bastan.
- [ ] Seguimiento y reanudación cuando realmente hagan falta; no exigir `.odd/` ni un formato S#/T#.
- [ ] Documentación obsoleta localizable → rutas+motivo+propuesta de orquestador, sin edición canónica automática.
- [ ] Documentación vigente → no recomendar actualización por rutina.
- [ ] En un proyecto documentado real, comprobar descubrimiento de fuentes pertinentes; declarar el límite si falla.
- [ ] Contratos/persistencia/consumidores y regresiones pertinentes comprobados; no declarar éxito con tests rojos.
- [ ] SDD sigue intacto y no se activa por complejidad. No aparecen `.sdd/` ni agentes adicionales.
- [ ] Backups fuera de árboles escaneados, personalizados preservados y rollback comprobado.
- [ ] Render/instalación temporal/selector y permisos efectivos verificados. No prometer sandbox universal.

Herramientas ya existentes para verificar, **comandos propuestos y NO ejecutados al crear este MD**:

```text
python3 tools/render.py
python3 tools/validate.py
python3 tools/test_integrity.py
python3 tools/test_mas_identity.py
python3 tools/test_context_efficiency.py
python3 tools/test_handoff_contract.py
python3 tools/test_documentation_core.py
python3 tools/test_model_recommendations.py
python3 tools/test_permissions.py
python3 tools/test_permissions_host.py
python3 tools/test_secret_policy.py
python3 tools/test_sdd_contract.py
python3 tools/test_install.py
python3 tools/test_retired_agents.py
python3 tools/test_antigravity_contract.py
python3 tools/test_antigravity_install.py
python3 tools/check_links.py
git diff --check
```

Contrastar disponibilidad/alcance antes de ejecutar. Algunas suites requieren historial
Git o herramientas del host. Si un assert refleja el contrato antiguo, justificar su
cambio frente al nuevo comportamiento aprobado; no debilitar comprobaciones para pasar.
Las pruebas de instaladores deben usar sus fixtures/perfiles temporales, no el HOME real.
Medir texto fuente no sustituye tokens reales. Smokes con LLM y nuevas baterías requieren
consumo autorizado en la petición futura; no repetir automáticamente los benchmarks.

## 9. Rollback acotado

Conservar fuentes/refs/adapters anteriores y hashes, sin credenciales. Si se solicita
rollback, restaurar SOLO esos artefactos y la instalación afectada, usando respaldos
verificados y el pipeline oficial. No restaurar todo el checkout, no sobrescribir
trabajo ajeno y no borrar registros de tareas de proyectos del usuario. Un rollback
devuelve temporalmente el procedimiento anterior: documentar que revierte la decisión
operativa, no afirmar que ambos quedaron activos simultáneamente.

## 10. Huellas para recuperar el contexto

SHA256 observados el 2026-11-05; comprobar antes de reutilizar:

```text
3e6acaf5d3609a660c117eda69eae1a0f72381991211e6089e5414c564e522be  canonical/agents/developer.md
44febbfaf22dd90f8971019cbd133bdde6dd31fc46478813a4f42671984f9608  canonical/skills/developer/SKILL.md
931ec9d55adaed7248611a74496b851452110f0298c214fdfe48a70eaa89a322  canonical/skills/developer/references/plan.md
67d8173d21000004496be59c5990b6d843ae5a956a4cfa06ff317562dc0de1d9  docs/experimentos/developer-v2-dominios-build-gemini-2026-11-05/candidato/agent.md
2b06d8950e791cf911d5aea455b4e9bf9d404452da48239cc290872efc744d78  docs/experimentos/developer-v2-dominios-build-gemini-2026-11-05/candidato/SKILL.md
a2dd84347a9d3e325a9410f64fae1ec267dc2f734a6d66d3583a42f620d80833  docs/experimentos/developer-v2-dominios-build-gemini-2026-11-05/evidencia/freeze.json
```

Una diferencia no autoriza reset ni reemplazo ciego: investigar si es trabajo nuevo
del usuario, cambio de baseline o deriva de evidencia. Los hashes no acreditan por
sí solos propiedad de copias instaladas con personalizaciones.

## 11. Instrucción portable para una sesión futura

Este texto es una plantilla que el usuario podrá enviar, **no una orden activa ahora**:

> Lee este plan y las fuentes enlazadas. Implementa la sustitución del procedimiento
> de Developer por el candidato 2, conservando nombre/IDs `developer`, y deja deprecada
> la implementación anterior sin mantenerla como agente activo. Ejecuta las fases A–C
> con pruebas y perfiles temporales. Preserva cambios locales, evidencias e historial.
> No instales en mi perfil real, no hagas commits/push/releases ni modifiques agentes
> ajenos. Para documentación canónica prepara contexto para selección manual del
> orquestador. Si surge una decisión que amplíe materialmente el alcance, consulta solo
> esa decisión y continúa con lo seguro autorizado.

**Cierre de esta preparación:** diseño elegido, instrucciones conservadas; ningún
agente creado en el catálogo, sustituido, instalado ni desactivado por escribir este archivo.
