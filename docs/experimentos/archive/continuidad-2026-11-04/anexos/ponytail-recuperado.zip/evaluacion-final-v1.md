# Evaluación de contenido v1

## Review: lectura con etiquetas de brazo ocultas

Fuente: review-blind-final-v1.md. El coordinador conoce el diseño y las métricas; esta es ceguera limitada de contenido, no un juez independiente. La correspondencia se conserva en review-mapping-final-v1.json.

| Etiquetas | Caso | Evaluación contra prerregistro |
|---|---|---|
| J01, J07, J11, J12, J17, J18 | S07 | Cada salida: 1 TP, 0 FP, 0 FN. Identifica claves del dict desempaquetadas por present.py, ejemplo y salida silenciosamente errónea, ubicación, condición y corrección. Sin inventar ejecución ni regla Sonar. |
| J02, J04, J05, J06, J09, J15 | S08 | Cada salida: 0 TP esperados, 0 FP, 0 FN. Comprueba consumidor, respeta contrato str y excluye unrelated_average como hallazgo del cambio. |
| J03, J08, J10, J13, J14, J16 | S09 | Cada salida: 1 TP en known, 0 FP, 0 FN; unknown correctamente condicionado, sin defecto de despliegue confirmado. Cita 4 procesos/2 máquinas y secuencia no atómica; baja carga no garantiza integridad. Recomienda operación atómica existente, sin inventar disponibilidad en unknown ni infraestructura. |

Las 18 inspecciones mantienen archivos intactos y solo emplean las herramientas de lectura/skills habilitadas. Las skills de calidad/seguridad se cargaron conforme al dominio. Variaciones de ID local vs sin ID persistente no cambian detección ni incumplen conservación de IDs existentes (fixture no tiene registros previos). No hay nueva vulnerabilidad SEC demostrada que deba contarse como hallazgo independiente.

## Developer: 42 implementaciones

Fuentes: developer-inspection-v1.md (diffs completos de Python y salidas), developer-compact-final-v1.md (repeticiones 2/3 con diffs de producción, requirements y fixture), runs/ y oráculos externos. Se inspeccionaron todos los diffs de producción y las salidas; pruebas visibles y oráculos pasan en las 42 celdas. El número de pruebas no se usa como victoria por sí solo.

| Caso | Criterios manuales además de oráculo y unittest | A | B |
|---|---|---|---|
| S01 | Imports y uso de helper compatible, sin lógica de normalización duplicada ni nueva abstracción. | 3/3 | 3/3 |
| S02 | Implementación independiente adecuada; no pierde caja por reutilización forzada. | 3/3 | 3/3 |
| S03 | safe_load, ValueError, dependencia declarada y justificación funcional; pruebas de rechazo de tags sin ejecutarlos. No instala paquetes. | 3/3 | 3/3 |
| S04 | Parser, cli, present y fixture coordinados; exportación preservada; límites externos explícitos en todas las respuestas. | 3/3 | 3/3 |
| S05 | Cierre centralizado, validaciones previas, errores/cancelación conservados, no exige context manager; sin abstracción especulativa. | 3/3 | 3/3 |
| S06 | Valida en adaptador; mantiene puerto y dominio sin import de infraestructura; inyección alternativa sigue funcionando. | 3/3 | 3/3 |
| S10 | Solo cambia literal, conserva test existente y ejecuta unittest; sin rastreos de componentes ajenos. | 3/3 | 3/3 |

No se observaron tests eliminados para forzar el éxito ni dependencias no justificadas. S04 actualiza intencionadamente la expectativa del contrato antiguo; el oráculo externo comprueba a la vez los consumidores y el fixture nuevo. Los nombres/número de tests difieren entre ejecuciones y no establecen superioridad reproducida según rúbrica.

## Límites de cobertura de oráculos

Los oráculos son mínimos necesarios, no una prueba exhaustiva. Por ejemplo, el oráculo S05 comprueba cierre/error/KeyboardInterrupt pero no el doble fallo read+close; las implementaciones y pruebas generadas sí cubren y conservan el error original en ese caso. La referencia simple de S05 solo valida la porción ejecutable del oráculo, no todos los casos del requisito. S03 sigue semántica SafeLoader de PyYAML disponible, sin matriz de versiones ni afirmación de YAML 1.2 completo. Review se juzga contra evidencias estáticas predefinidas, no contra un benchmark industrial.

## Resultado

Según los criterios observados, A y B son equivalentes en calidad en los diez escenarios y tres repeticiones: 30/30 celdas satisfactorias por brazo. Ninguna mejora de calidad repetida de B; ninguna regresión grave observada. Esto no demuestra equivalencia universal, ausencia total de vulnerabilidades ni daño técnico de la propuesta.
