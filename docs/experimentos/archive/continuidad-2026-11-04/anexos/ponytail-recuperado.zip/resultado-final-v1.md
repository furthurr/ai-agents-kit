# Ponytail — comparación completada; no promover B

**Decisión: inconcluso respecto al beneficio incremental, conservar A.** Se completó la comparación planificada de **60/60 celdas** (10 escenarios × 2 brazos × 3 repeticiones), tras pasar el filtro inicial de 20. Ambos brazos cumplieron los requisitos de la muestra; B no demostró mejora de calidad ni el ahorro repetido prerregistrado. No se trata de un bloqueo de permisos, falta de runner o comparación pendiente, ni de un rechazo técnico por daño demostrado.

Este informe es el cierre autocontenido de la continuación del 2026-11-04. El archivo veredicto.md conserva el historial previo y sus correcciones; sus afirmaciones antiguas de cero celdas o imposibilidad de continuar no describen este resultado.

## Variante, protocolo y entorno

- Control A: commit **f3b58d58e0fd690d31c99131bbe5c85bc8ea2fcd**, repo limpio antes y después.
- B exacta: **variante-b.patch**, aplicada solo sobre snapshot externo; fuentes Developer D1–D3 y Code Review R1–R3, test textual y render oficial en seis plataformas. No se retocó B tras observar resultados.
- Prerregistro: protocolo-v1.md y preregistro-v1.json, congelado **2026-11-04T06:08:32.877144+00:00**, 162 hashes de protocolo/harness/casos/oráculos/instrucciones. Sin cambios durante la comparación.
- Modelo solicitado y usado para las celdas: **openai/gpt-6.1-sol**, proveedor OpenAI ya disponible en el host, OpenCode **1.18.34**, `--pure run --format json --agent ... --model ... --dir ...`.
- MAS completo disponible en ambos brazos: cinco agentes, once skills con referencias; prompts íntegros. Carga de skills de rol y dominio verificada en las 60 trazas; texto experimental de Developer comprobado en todas las celdas B y ausente en A. No se comparó una skill suelta contra el sistema completo.
- Configuración temporal separada por XDG_CONFIG_HOME, sin skills externas/Claude/plugins externos; políticas globales no sensibles idénticas, fixtures y sesiones nuevas. Overrides finales simétricos por rol. Inspect tiene bash/edit/write/task/webfetch deshabilitados en el host; las 18 sesiones reales solo leen y no alteran archivos.
- Auditoría de **408 llamadas read/glob/grep**: todas dentro del fixture de su celda o configuración de su brazo; ninguna lectura de otro brazo, oráculos o contexto exterior por esas herramientas. No es una prueba de sandbox de sistema operativo.

## Ejecuciones y calidad por escenario

| Caso | A | B | Evidencia de calidad |
|---|---:|---:|---|
| S01 — helper adecuado | 3/3 | 3/3 | Reutiliza helper, espacios/vacíos/Unicode correctos. |
| S02 — helper incompatible | 3/3 | 3/3 | Conserva caja sin reutilización lossy. |
| S03 — dependencia justificada | 3/3 | 3/3 | PyYAML declarada; estructuras, alias, multilínea, mapa raíz y rechazo seguro. |
| S04 — contrato y consumidores | 3/3 | 3/3 | Parser, consumidores, fixture y exportación coherentes; límites externos declarados. |
| S05 — recursos y errores | 3/3 | 3/3 | Cierre, autorización, errores y cancelación conservados. |
| S06 — frontera arquitectónica | 3/3 | 3/3 | Puerto y separación de dominio preservados. |
| S07 — regresión conectada en review | 3/3 | 3/3 | Cada revisión: 1 TP, 0 FP, 0 FN; claves de dict en consumidor. |
| S08 — defecto independiente | 3/3 | 3/3 | Cada revisión: 0 FP, no amplía auditoría. |
| S09 — topología conocida/desconocida | 3/3 | 3/3 | Cada revisión: 1 TP known, unknown condicionado; sin topología inventada. |
| S10 — cambio trivial | 3/3 | 3/3 | Literal y prueba localizada, exploración proporcional. |
| **Total** | **30/30** | **30/30** | Sin diferencia de calidad según rúbrica. |

**42 implementaciones** pasan sus suites unittest y oráculos externos; **18 inspecciones** pasan la revisión de contenido y controles de alcance. No hubo timeout del agente, reintentos de celdas ni errores de herramientas. En cada brazo: seis TP agregados de Review (tres S07 y tres known S09), cero FP/FN; tres S08 sin hallazgos y tres unknown S09 condicionados. No contar estos últimos como defectos confirmados.

Detalle manual y límites: evaluacion-final-v1.md; respuestas de Review con brazo oculto: review-blind-final-v1.md. La ceguera es limitada: el coordinador conoce el diseño y métricas, no es un evaluador independiente. Los oráculos son necesarios pero no exhaustivos.

## Métricas observadas y coste

Suma de contadores step_finish, no estimaciones desde caracteres. Entrada nueva, caché y salida se publican separadamente; el total siguiente también incluye los contadores de razonamiento, **sin conservar su contenido**.

| Métrica, 30 celdas por brazo | A | B |
|---|---:|---:|
| Entrada no cacheada reportada | 509.613 | 479.235 |
| Lectura de caché reportada | 1.693.696 | 1.785.216 |
| Salida reportada | 40.852 | 41.013 |
| Contador de razonamiento | 873 | 1.056 |
| **Tokens observados totales** | **2.245.034** | **2.306.520** |
| Llamadas a herramientas | 304 | 305 |
| Pasos/turnos con step_finish | 208 | 213 |
| cost reportado por el host | 0 | 0 |

B: **+61.486 tokens (+2,74 %)** en el total observado. La entrada no cacheada por sí sola disminuye; ignorar la mayor caché produciría una lectura engañosa. Caché del proveedor no reiniciable ni completamente controlada, sin tarifa conocida: estos contadores no son una factura ni demuestran sobrecoste monetario.

Para tiempo homogéneo se usan las **40 celdas no interrumpidas de repeticiones 2 y 3**: A **868,158 s**, B **878,783 s**, diferencia **+1,22 %** para B. Son sumas de duración de celdas concurrentes, no tiempo de reloj del lote. En ese mismo subconjunto, tokens observados A **1.476.864**, B **1.542.043** (**+4,41 %**). Las duraciones de las cuatro sesiones recuperadas de r1 excluyen arranque CLI y se conservan identificadas, sin mezclarlas para aceptar por eficiencia.

**Coste monetario real: no observable.** El host informa cost=0 en las celdas y pruebas de preflight; no se acredita gratuidad ni precio marginal. Se reutilizó autenticación del proveedor existente sin leer/copiar credenciales y se enviaron solo tareas sintéticas e instrucciones MAS del alcance. Operaciones auxiliares del host (por ejemplo titulado de sesiones) no quedan íntegramente atribuidas en step_finish y no se presenta su coste como medido.

Límite efectivamente respetado: 60 celdas, máximo 22 pasos/180 s por celda, cuatro procesos concurrentes; sin reintentos A/B. Hubo dos pruebas reales de preflight separadas, no contadas como celdas. No hubo ejecución ilimitada.

## Incidentes y correcciones

1. La herramienta de delegación rechazó crear otro subagente por profundidad máxima 1. El coordinador ejecutó directamente el experimento; no se cambió la configuración del host.
2. El primer supervisor bash tenía timeout 120 s y se interrumpió durante el filtro. Cuatro sesiones originales (S04-A-r1, S05-A-r1, S05-B-r1, S06-B-r1) terminaron normalmente y se recuperaron por sus IDs exactos desde el host: estado stop, sin repetir modelo. Sus retornos de proceso no se conocen y sus duraciones son timestamps de sesión. Sesiones conservadas en *-recovered.json, sin bloques de razonamiento.
3. debug skill/export masivos por pipe se truncaban alrededor de 64 KiB; inventario completo contrastado con manifiestos, permisos resueltos y cargas reales. PTY permitió export completo de las cuatro sesiones recuperadas, filtrado en memoria antes de guardar.
4. El check de enlaces B falló inicialmente por seis destinos existentes en A no copiados al snapshot (MAS.png y cinco referencias históricas .sdd). Se corrigió el montaje del evaluador con overlay **solo de existencia**, sin copiar ni modificar .sdd ni fuentes: los 94 Markdown de B pasan. Se conserva el intento fallido en checks-estaticos-final-v1.json y el cierre correcto en checks-cierre-v1.json.
5. measure_context rechazó rutas absolutas externas por su contrato. Se reejecutó con rutas relativas `generated/opencode/...` desde cada snapshot, idénticas al contenido cargado. Resultado en context-flows-v1.json. No se confundió volumen estático con tokens.

## Checks estáticos y distribución

| Comprobación | A | B externo |
|---|---|---|
| `python3 tools/validate.py` | 11 skills / 5 agentes / 6 plataformas correcto | Ídem, correcto |
| `python3 tools/check_links.py` | 94 Markdown correctos | 94 correctos con overlay de existencia explícito descrito arriba |
| `python3 tools/test_context_efficiency.py` | 12 pruebas correctas | 13 correctas, incluye contrato textual experimental |
| `python3 tools/test_code_review_contract.py` | 7 pruebas correctas | 7 correctas |
| Render oficial | Control reproducible verificado por validate | `python3 tools/render.py` ejecutado en snapshot B, reproducibilidad verificada |

Medición de las dos fuentes candidatas: A 12.189 bytes, B 13.632; **+1.443 bytes / +174 palabras / +18 líneas**. Los flujos de agentes+skills realmente cargados se midieron aparte con rutas explícitas (context-flows-v1.json); tampoco incluyen todo el prompt dinámico, catálogo de herramientas o caché. La evidencia conductual y los contadores reales son independientes de estos contratos estáticos.

## Aplicación del veredicto y estado final

El prerregistro exige mejora repetida de calidad sin degradación y sin intercambio económico no acordado, o calidad equivalente con ahorro >=10 % de tokens y tiempo suficientemente repetido. **No se cumple ninguna vía**: calidad equivalente en esta muestra y ausencia de ahorro agregado. No se selecciona el escenario favorable S03 o S08 para promover una variante parcial sin reevaluación.

Por tanto: **no promover D1–D3/R1–R3**, preservar A. B no se declara perjudicial por estos datos; no se justifica una integración por beneficio demostrado. No se ajustó ni aceptó una variante parcial.

- **Archivos modificados del repositorio: ninguno.** Fuentes y generated permanecen A; B y su test solo existen en artefactos externos.
- `git diff --check`: correcto; `git status --short`: vacío; HEAD permanece f3b58d58e0fd690d31c99131bbe5c85bc8ea2fcd.
- `git apply --check variante-b.patch`: correcto sobre A, conservado para reproducción o retirada/selectividad futura.
- Sin commits, instalación global, Ponytail producto, SDD ni modificación persistente de permisos. Configuraciones aisladas conservadas como fixtures inertes para reproducibilidad; solo se seleccionaban por variables de los procesos hijos, sin activación habitual ni cambio pendiente de reinicio.
- Informe, harness, fixtures, hashes, variantes y registros externos preservados. No se requiere actualización documental canónica: no se integró el cambio.

## Evidencia y reproducción

Directorio base: `/var/folders/d7/z7388kp51w532q4c0rj7hqqh0000gn/T/opencode/mas-ponytail-evaluacion-20261103/`.

- `protocolo-v1.md`, `preregistro-v1.json`: criterios y hashes previos.
- `preflight.py`, `probe_runner.py`, `runner.py`: preparación, controles y ejecutor acotado. `freeze.py` congela antes de celdas; no se puede reejecutar sobre resultados existentes.
- `build_cases.py`, `casos-v1/`, `oracles-v1/`, `oracle-validation.json`: diez tareas y oráculos comprobados contra referencias.
- `snapshots/A/`, `snapshots/B/`, `isolated/`: fuentes y distribución exactas; reglas de carga y permisos en `isolation-resolved.json` y prueba real en `isolation-runtime-probe.json`.
- `ejecuciones-v1.jsonl`: **60 filas únicas**, todas las celdas/intentos incluidos. `evidencias-v1/`: eventos saneados y resumen por celda; `runs/`: resultados de archivos y tests.
- `recover_runner.py`, `resume_v1.py`, `filtro-v1.md`: recuperación sin reintento y decisión de pasar filtro.
- `audit_results.py`, `compact_evidence.py`, `evaluacion-final-v1.md`, `access-audit-v1.json`: inspección de resultados y contexto.
- `final_metrics.py`, `metricas-final-v1.json`: agregación verificable de tokens, herramientas y duración.
- `static_checks_v1.py`, `close_checks_v1.py`, `checks-estaticos-final-v1.json`, `checks-cierre-v1.json`, `context-flows-v1.json`: verificaciones y correcciones ambientales.

Para reproducir desde cero usar un directorio externo nuevo, conservar versiones/hashes, verificar de nuevo proveedor y controles y ejecutar el mismo protocolo; los scripts evitan sobreescribir celdas existentes. La disponibilidad del modelo y el estado de caché pueden cambiar. Esta muestra sintética pequeña y un único modelo/host no permiten generalizar a todos los proyectos ni hosts del MAS; las seis plataformas solo se verificaron estáticamente.

**Pendiente de esta comparación: nada esencial.** El beneficio universal y el coste de facturación siguen sin demostrarse, como límites del resultado, no como celdas pendientes.
