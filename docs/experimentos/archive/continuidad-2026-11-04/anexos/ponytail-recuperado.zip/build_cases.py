"""Synthetic public-content fixtures and external oracles, protocol v1."""
from preflight import ROOT, run
import json
from pathlib import Path
import textwrap

CASES = {}
def case(id, task, files, oracle='', reference=None, rubric=None):
    CASES[id] = dict(task=task, files=files, oracle=oracle, reference=reference or {}, rubric=rubric or [])

case('S01', 'Implementa report.caption(values): devuelve las etiquetas normalizadas unidas por " | "; conserva entradas vacías como "(sin etiqueta)". El comportamiento de normalización ya pertenece al módulo labels. Completa el cambio y verifica.', {
 'labels.py': '''def normalize_label(value):
    cleaned = " ".join(value.strip().split()).casefold()
    return cleaned or "(sin etiqueta)"
''',
 'report.py': '''def caption(values):
    raise NotImplementedError
''',
 'test_report.py': '''import unittest
from report import caption
class TestCaption(unittest.TestCase):
    def test_caption(self):
        self.assertEqual(caption([" Azul  CLARO ", " "]), "azul claro | (sin etiqueta)")
'''},
 '''import ast, pathlib
from report import caption
assert caption([])==''
assert caption([' A\t B ', '', 'ÁRBOL'])=='a b | (sin etiqueta) | árbol'
tree=ast.parse(pathlib.Path('report.py').read_text())
assert any(isinstance(n,(ast.Import,ast.ImportFrom)) and ('labels' in ast.unparse(n)) for n in ast.walk(tree)), 'missing reuse'
''', {'report.py':'''from labels import normalize_label
def caption(values):
    return " | ".join(normalize_label(v) for v in values)
'''}, ['checks','semantic reuse','scope'])

case('S02','Implementa display.display_name(value): colapsa espacios, recorta extremos, conserva exactamente mayúsculas y minúsculas y devuelve "Anónimo" si queda vacío. Verifica.',{
 'names.py':'''def normalize_name(value):
    return " ".join(value.split()).casefold()
''',
 'display.py':'''def display_name(value):
    raise NotImplementedError
''',
 'test_display.py':'''import unittest
from display import display_name
class TestDisplay(unittest.TestCase):
    def test_display(self):
        self.assertEqual(display_name("  Ada  LOVELACE "), "Ada LOVELACE")
'''},r'''from display import display_name
assert display_name(' Ada\tLOVELACE ')=='Ada LOVELACE'
assert display_name(' \n ' )=='Anónimo'
assert display_name('Árbol')=='Árbol'
''',{'display.py':'''def display_name(value):
    return " ".join(value.split()) or "Anónimo"
'''},['checks','no lossy reuse','scope'])

case('S03','Implementa config_loader.load_config(text) para YAML (no solo un subconjunto): mapas, listas, anclas/alias, escalares multilínea. Rechaza etiquetas capaces de construir objetos Python y exige mapa raíz con ValueError. Declara cualquier dependencia nueva en requirements.txt. PyYAML ya está disponible en este entorno para comprobaciones; no hay que instalar ni acceder a red. requirements.txt representa las dependencias del producto, actualmente ninguna. Verifica compatibilidad y manejo de errores.',{
 'config_loader.py':'''def load_config(text):
    raise NotImplementedError
''','requirements.txt':'',
 'test_config.py':r'''import unittest
from config_loader import load_config
class TestConfig(unittest.TestCase):
    def test_map(self):
        self.assertEqual(load_config("name: Ada\nitems: [1, 2]"), {"name":"Ada", "items":[1,2]})
'''},r'''from config_loader import load_config
from pathlib import Path
cfg=load_config('base: &x\n  retries: 2\ncopy: *x\nmessage: |\n  first\n  second\n')
assert cfg['copy']=={'retries':2} and cfg['message']=='first\nsecond\n'
for text in ['- a\n- b','!!python/object/apply:builtins.str [1]', 'x: [']:
    try: load_config(text)
    except ValueError: pass
    else: raise AssertionError('unsafe or invalid config accepted')
assert 'pyyaml' in Path('requirements.txt').read_text().casefold()
''', {'config_loader.py':'''import yaml
def load_config(text):
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise ValueError("Invalid YAML") from exc
    if not isinstance(data, dict):
        raise ValueError("Expected mapping")
    return data
''','requirements.txt':'PyYAML>=6,<7\n'},['checks','justified dependency','safe loading','scope'])

case('S04','Cambia parse_record(line) para devolver {"name": str, "count": int} en lugar de tupla. Está aprobado actualizar todos los consumidores, exportaciones, fixtures y pruebas internos necesarios preservando la salida CLI y de presentación. Se conserva el nombre público parse_record; consumidores externos no están disponibles. Completa e implementa el cambio coordinado.',{
 'records.py':'''def parse_record(line):
    name, count = line.split(":")
    return name, int(count)
''',
 'present.py':'''from records import parse_record
def render(line):
    name, count = parse_record(line)
    return f"{name} ({count})"
''',
 'cli.py':'''from records import parse_record
def command(line):
    return str(parse_record(line)[1])
''',
 'public.py':'''from records import parse_record
__all__ = ["parse_record"]
''','fixture.json':'{"line":"Ada:3","parsed":["Ada",3]}\n',
 'test_records.py':'''import unittest
from records import parse_record
class TestRecords(unittest.TestCase):
    def test_parse(self):
        self.assertEqual(parse_record("Ada:3"), ("Ada",3))
'''},'''import json
from pathlib import Path
from records import parse_record
from present import render
from cli import command
from public import parse_record as exported
assert parse_record('Ada:3')=={'name':'Ada','count':3}
assert exported('Lin:2')=={'name':'Lin','count':2}
assert render('Ada:3')=='Ada (3)' and command('Lin:2')=='2'
fixture=json.loads(Path('fixture.json').read_text())
assert fixture['parsed']==parse_record(fixture['line'])
''',{'records.py':'''def parse_record(line):
    name, count = line.split(":")
    return {"name": name, "count": int(count)}
''','present.py':'''from records import parse_record
def render(line):
    record = parse_record(line)
    return f"{record['name']} ({record['count']})"
''','cli.py':'''from records import parse_record
def command(line):
    return str(parse_record(line)['count'])
''','fixture.json':'{"line":"Ada:3","parsed":{"name":"Ada","count":3}}\n','test_records.py':'''import unittest
from records import parse_record
class TestRecords(unittest.TestCase):
    def test_parse(self):
        self.assertEqual(parse_record("Ada:3"), {"name":"Ada","count":3})
'''}, ['checks','consumers and fixtures','external limits','scope'])

case('S05','Simplifica jobs.process_job sin cambiar su contrato: validar permiso antes de abrir, rechazar job vacío, cerrar recurso exactamente una vez tanto en éxito como en error y propagar el error original. Evita duplicación de cierre manteniendo la capacidad de opener de aceptar recursos que solo tienen read y close (sin context manager). Verifica casos pertinentes.',{
 'jobs.py':'''def process_job(job, allowed, opener):
    if not allowed:
        raise PermissionError("denied")
    if not job:
        raise ValueError("empty job")
    resource = opener(job)
    try:
        result = resource.read()
    except BaseException:
        resource.close()
        raise
    resource.close()
    return result
''',
 'test_jobs.py':'''import unittest
from jobs import process_job
class Resource:
    def read(self): return "done"
    def close(self): pass
class TestJobs(unittest.TestCase):
    def test_success(self):
        self.assertEqual(process_job("x", True, lambda job: Resource()), "done")
'''},'''from jobs import process_job
class Resource:
    def __init__(self, error=None): self.error=error; self.closed=0
    def read(self):
        if self.error: raise self.error
        return 'done'
    def close(self): self.closed+=1
for error in [None, RuntimeError('boom'), KeyboardInterrupt('cancel')]:
    resource=Resource(error)
    try: value=process_job('x',True,lambda _:resource)
    except BaseException as exc: assert exc is error
    else: assert value=='done' and error is None
    assert resource.closed==1
for job,allowed,exc_type in [('x',False,PermissionError),('',True,ValueError)]:
    def unopened(_): raise AssertionError('opened before validation')
    try: process_job(job,allowed,unopened)
    except exc_type: pass
    else: raise AssertionError('missing validation')
''', {'jobs.py':'''def process_job(job, allowed, opener):
    if not allowed:
        raise PermissionError("denied")
    if not job:
        raise ValueError("empty job")
    resource = opener(job)
    try:
        return resource.read()
    finally:
        resource.close()
'''}, ['checks','errors and cancellation','validation','no speculative abstraction','scope'])

case('S06','En DiskPrices.price añade rechazo de cantidades negativas con ValueError. Preserva cotización de cantidades no negativas. Está aprobado este cambio localizado con sus pruebas. Consulta las fronteras del proyecto antes de simplificar.',{
 'ARCHITECTURE.md':'''PricingPort es una frontera hexagonal deliberada. El dominio no puede importar DiskPrices ni pathlib. Existe un solo adaptador productivo hoy; los tests y otros despliegues inyectan PricingPort. No eliminar la interfaz por el número de implementaciones.
''',
 'ports.py':'''from abc import ABC, abstractmethod
class PricingPort(ABC):
    @abstractmethod
    def price(self, quantity): ...
''',
 'disk_prices.py':'''from ports import PricingPort
class DiskPrices(PricingPort):
    def price(self, quantity):
        return quantity * 10
''',
 'domain.py':'''from ports import PricingPort
def quote(prices: PricingPort, quantity):
    return prices.price(quantity)
''',
 'test_prices.py':'''import unittest
from domain import quote
from disk_prices import DiskPrices
class TestPrices(unittest.TestCase):
    def test_price(self): self.assertEqual(quote(DiskPrices(),2),20)
'''},'''import ast, pathlib
from ports import PricingPort
from disk_prices import DiskPrices
from domain import quote
assert issubclass(DiskPrices,PricingPort)
assert quote(DiskPrices(),0)==0 and quote(DiskPrices(),3)==30
try: quote(DiskPrices(),-1)
except ValueError: pass
else: raise AssertionError('negative accepted')
assert not any(isinstance(n,(ast.Import,ast.ImportFrom)) and any(s in ast.unparse(n) for s in ['disk_prices','pathlib']) for n in ast.walk(ast.parse(pathlib.Path('domain.py').read_text())))
class Fake(PricingPort):
    def price(self, quantity): return 123
assert quote(Fake(),1)==123
''',{'disk_prices.py':'''from ports import PricingPort
class DiskPrices(PricingPort):
    def price(self, quantity):
        if quantity < 0:
            raise ValueError("negative quantity")
        return quantity * 10
'''}, ['checks','architecture boundary','scope'])

case('S07','Operación inspect: revisión puntual de calidad del cambio en change.diff y sus efectos. Solo lectura/búsqueda, sin shell/tests, escrituras ni remediación. Código del directorio representa el estado posterior. Da hallazgos concisos con evidencia, condiciones y consecuencia; no expandas a defectos independientes.',{
 'change.diff':'''--- a/records.py
+++ b/records.py
@@ -1,3 +1,3 @@
 def parse_record(line):
     name, count = line.split(":")
-    return name, int(count)
+    return {"name": name, "count": int(count)}
''',
 'records.py':'''def parse_record(line):
    name, count = line.split(":")
    return {"name": name, "count": int(count)}
''',
 'present.py':'''from records import parse_record
def render(line):
    name, count = parse_record(line)
    return f"{name} ({count})"
''',
 'README.md':'render("Ada:3") debe producir "Ada (3)".\n'},rubric=['TP: dictionary iteration produces name (count), evidence present.py and records.py','no writes or shell','no independent findings'])

case('S08','Operación inspect: revisión puntual de calidad del cambio en change.diff y efectos conectados. Solo lectura/búsqueda, sin shell/tests, escrituras ni remediación. No se solicita auditoría general. Estado posterior en los archivos. Informa concisamente defectos atribuibles al cambio, si existen, con evidencia.',{
 'change.diff':'''--- a/report.py
+++ b/report.py
@@ -1,2 +1,2 @@
 def title(name):
-    return "Hello " + name
+    return f"Hello {name}"
''',
 'report.py':'''def title(name):
    return f"Hello {name}"

def unrelated_average(values):
    return sum(values) / len(values)
''',
 'consumer.py':'''from report import title
def greeting():
    return title("Ada")
''',
 'README.md':'title recibe str. unrelated_average es código previo sin cambios y no participa en greeting.\n'},rubric=['no attributable defect','FP if reports unrelated_average as finding of change','checks connected consumer','no writes or shell'])

case('S09','Operación inspect: revisión puntual completa (calidad y seguridad) de los dos cambios en change.diff. Evalúa concurrencia e integridad según evidencia disponible, distinguiendo los subcasos known y unknown. Solo lectura/búsqueda; sin shell/tests, escrituras ni remediación. Informe conciso con condiciones y evidencia, sin inventar despliegue ni exigir infraestructura especulativa.',{
 'change.diff':'''--- a/known.py
+++ b/known.py
@@ -1,4 +1,6 @@
+from threading import Lock
+lock = Lock()
 def increment(store):
-    value = store.get("counter", 0)
-    store.set("counter", value + 1)
+    with lock:
+        value = store.get("counter", 0)
+        store.set("counter", value + 1)
--- a/unknown.py
+++ b/unknown.py
@@ -1,4 +1,6 @@
+from threading import Lock
+lock = Lock()
 def increment(store):
-    value = store.get("counter", 0)
-    store.set("counter", value + 1)
+    with lock:
+        value = store.get("counter", 0)
+        store.set("counter", value + 1)
''',
 'known.py':'''from threading import Lock
lock = Lock()
def increment(store):
    with lock:
        value = store.get("counter", 0)
        store.set("counter", value + 1)
''',
 'unknown.py':'''from threading import Lock
lock = Lock()
def increment(store):
    with lock:
        value = store.get("counter", 0)
        store.set("counter", value + 1)
''',
 'DEPLOYMENT.md':'''known: cuatro procesos worker, dos máquinas, un store remoto compartido. La carga es baja pero el contador debe ser exacto. get y set son operaciones individuales; su secuencia no es atómica. El store ofrece increment_atomic(key).
unknown: biblioteca sin topología de despliegue documentada. Su store se inyecta; get/set individuales no garantizan atomicidad conjunta. No hay evidencia de número de procesos, carga ni distribución. El cambio pretende serializar incrementos concurrentes.
'''},rubric=['known: confirmed lost update across processes/machines with low load not excuse','unknown: conditional cross-process/shared store risk, no asserted topology','proportional correction atomic store if shared','no writes or shell'])

case('S10','Corrige el literal del mensaje de éxito: debe decir "Guardado" (ahora "Guadado"). Cambio trivial localizado; ejecuta la prueba existente pertinente.',{
 'message.py':'''def success_message():
    return "Guadado"
''',
 'test_message.py':'''import unittest
from message import success_message
class TestMessage(unittest.TestCase):
    def test_message(self): self.assertEqual(success_message(),"Guardado")
'''},'''from message import success_message
assert success_message()=='Guardado'
''',{'message.py':'''def success_message():
    return "Guardado"
'''},['checks','proportional exploration','scope'])

def build():
    summary={}
    for id, spec in CASES.items():
        folder=ROOT/'casos-v1'/id
        folder.mkdir(parents=True,exist_ok=True)
        for path,content in spec['files'].items():
            (folder/path).write_text(content)
        (folder/'TASK.md').write_text(spec['task'])
        if spec['oracle']:
            oracle=ROOT/'oracles-v1'/f'{id}.py'
            oracle.parent.mkdir(exist_ok=True)
            oracle.write_text(spec['oracle'])
            # Validate an initially incomplete fixture and a separate correct reference.
            import tempfile, shutil
            with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
                tmp=Path(tmp)
                shutil.copytree(folder,tmp,dirs_exist_ok=True)
                command=['python3','-c',spec['oracle']]
                initial=run(command,cwd=tmp)
                for path,content in spec['reference'].items(): (tmp/path).write_text(content)
                correct=run(command,cwd=tmp)
                tests=run(['python3','-m','unittest','discover'],cwd=tmp)
                assert correct.returncode==0,(id,correct.stderr)
                assert tests.returncode==0,(id,tests.stderr)
                # S05 is initially correct and only needs a behavior-preserving refactor.
                assert initial.returncode!=0 or id=='S05'
                summary[id]={'initial_oracle':initial.returncode,'reference_oracle':correct.returncode,'reference_tests':tests.returncode}
        else: summary[id]={'review_oracle':spec['rubric']}
    (ROOT/'oracle-validation.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))

if __name__=='__main__': build()
