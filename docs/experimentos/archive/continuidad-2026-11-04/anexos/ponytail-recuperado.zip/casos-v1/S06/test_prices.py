import unittest
from domain import quote
from disk_prices import DiskPrices
class TestPrices(unittest.TestCase):
    def test_price(self): self.assertEqual(quote(DiskPrices(),2),20)
