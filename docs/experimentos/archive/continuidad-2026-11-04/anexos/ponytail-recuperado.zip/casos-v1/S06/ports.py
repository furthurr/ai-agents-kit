from abc import ABC, abstractmethod
class PricingPort(ABC):
    @abstractmethod
    def price(self, quantity): ...
