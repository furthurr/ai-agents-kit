from ports import PricingPort
class DiskPrices(PricingPort):
    def price(self, quantity):
        return quantity * 10
