from ports import PricingPort
def quote(prices: PricingPort, quantity):
    return prices.price(quantity)
