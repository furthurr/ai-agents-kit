from threading import Lock
lock = Lock()
def increment(store):
    with lock:
        value = store.get("counter", 0)
        store.set("counter", value + 1)
