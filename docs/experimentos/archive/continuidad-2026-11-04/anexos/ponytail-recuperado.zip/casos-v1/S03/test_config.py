import unittest
from config_loader import load_config
class TestConfig(unittest.TestCase):
    def test_map(self):
        self.assertEqual(load_config("name: Ada\nitems: [1, 2]"), {"name":"Ada", "items":[1,2]})
