import unittest
from message import success_message
class TestMessage(unittest.TestCase):
    def test_message(self): self.assertEqual(success_message(),"Guardado")
