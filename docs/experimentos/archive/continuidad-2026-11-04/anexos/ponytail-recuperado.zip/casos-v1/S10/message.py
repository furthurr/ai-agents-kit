def success_message():
    return "Guadado"
