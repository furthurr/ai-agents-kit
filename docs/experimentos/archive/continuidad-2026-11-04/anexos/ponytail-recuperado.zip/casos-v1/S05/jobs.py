def process_job(job, allowed, opener):
    if not allowed:
        raise PermissionError("denied")
    if not job:
        raise ValueError("empty job")
    resource = opener(job)
    try:
        result = resource.read()
    except BaseException:
        resource.close()
        raise
    resource.close()
    return result
