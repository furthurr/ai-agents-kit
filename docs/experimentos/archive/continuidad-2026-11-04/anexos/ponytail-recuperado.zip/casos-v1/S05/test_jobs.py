import unittest
from jobs import process_job
class Resource:
    def read(self): return "done"
    def close(self): pass
class TestJobs(unittest.TestCase):
    def test_success(self):
        self.assertEqual(process_job("x", True, lambda job: Resource()), "done")
