title recibe str. unrelated_average es código previo sin cambios y no participa en greeting.
