def title(name):
    return f"Hello {name}"

def unrelated_average(values):
    return sum(values) / len(values)
