from report import title
def greeting():
    return title("Ada")
