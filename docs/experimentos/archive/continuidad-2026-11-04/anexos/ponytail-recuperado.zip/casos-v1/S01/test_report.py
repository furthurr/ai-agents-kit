import unittest
from report import caption
class TestCaption(unittest.TestCase):
    def test_caption(self):
        self.assertEqual(caption([" Azul  CLARO ", " "]), "azul claro | (sin etiqueta)")
