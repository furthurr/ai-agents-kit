def normalize_label(value):
    cleaned = " ".join(value.strip().split()).casefold()
    return cleaned or "(sin etiqueta)"
