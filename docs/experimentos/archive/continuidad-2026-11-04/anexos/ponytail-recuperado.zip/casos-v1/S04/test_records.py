import unittest
from records import parse_record
class TestRecords(unittest.TestCase):
    def test_parse(self):
        self.assertEqual(parse_record("Ada:3"), ("Ada",3))
