from records import parse_record
__all__ = ["parse_record"]
