from records import parse_record
def render(line):
    name, count = parse_record(line)
    return f"{name} ({count})"
