def display_name(value):
    raise NotImplementedError
