import unittest
from display import display_name
class TestDisplay(unittest.TestCase):
    def test_display(self):
        self.assertEqual(display_name("  Ada  LOVELACE "), "Ada LOVELACE")
