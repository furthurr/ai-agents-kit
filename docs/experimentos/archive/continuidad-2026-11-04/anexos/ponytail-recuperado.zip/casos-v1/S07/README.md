render("Ada:3") debe producir "Ada (3)".
