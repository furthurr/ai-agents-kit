def parse_record(line):
    name, count = line.split(":")
    return {"name": name, "count": int(count)}
