from runner import hashes, ROOT, REPO, run
import json
import hashlib
import datetime

assert not (ROOT/'ejecuciones-v1.jsonl').exists(), 'Cannot preregister after cells'
files=['protocolo-v1.md','build_cases.py','runner.py','preflight.py','variante-b.patch']
manifest={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files}
for folder in ['casos-v1','oracles-v1','isolated/A/opencode','isolated/B/opencode']:
    manifest.update({folder+'/'+p:h for p,h in hashes(ROOT/folder).items()})
record={'protocol':'ponytail-v1-20261104','frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'head':run(['git','rev-parse','HEAD'],cwd=REPO).stdout.strip(),'hashes':manifest}
(ROOT/'preregistro-v1.json').write_text(json.dumps(record,indent=2))
print('Frozen',len(manifest),'files at',record['frozen_at'])
