import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/pedrogomezvasquez/Documents/Repositorios/GITHUBREPOS/ai-agents-kit')
CLI = shutil.which('opencode')

def run(args, **kw):
    return subprocess.run(args, text=True, capture_output=True, timeout=90, **kw)

def env_for(arm):
    env = dict(os.environ)
    # Remove inherited runtime overrides, retaining the host's authentication store.
    for key in list(env):
        if key.startswith('OPENCODE_CONFIG'):
            del env[key]
    env.update(XDG_CONFIG_HOME=str(ROOT / 'isolated' / arm),
               OPENCODE_DISABLE_PROJECT_CONFIG='1', OPENCODE_DISABLE_EXTERNAL_SKILLS='1',
               OPENCODE_DISABLE_CLAUDE_CODE='1', OPENCODE_DISABLE_CLAUDE_CODE_SKILLS='1',
               OPENCODE_DISABLE_CLAUDE_CODE_PROMPT='1', PYTHONDONTWRITEBYTECODE='1')
    return env

def setup():
    tracked = run(['git', 'ls-files', 'canonical', 'adapters', 'tools', 'generated'], cwd=REPO)
    assert tracked.returncode == 0
    for arm in ['A', 'B']:
        target = ROOT / 'snapshots' / arm
        target.mkdir(parents=True, exist_ok=True)
        for rel in tracked.stdout.splitlines():
            if any(p.startswith('.env') for p in Path(rel).parts) or Path(rel).suffix in {'.pem','.key','.p12','.pfx','.jks','.keystore'}:
                raise ValueError('Forbidden path in source selection')
            dest = target / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(REPO / rel, dest)
        if arm == 'B':
            p = run(['git', 'apply', str(ROOT / 'variante-b.patch')], cwd=target)
            assert p.returncode == 0, p.stderr
            p = run(['python3', 'tools/render.py'], cwd=target)
            assert p.returncode == 0, p.stderr
        configdir = ROOT / 'isolated' / arm / 'opencode'
        shutil.copytree(target / 'generated/opencode', configdir, dirs_exist_ok=True)
        # Preserve applicable global behavioral policies identically, without copying config/auth.
        shutil.copyfile(Path.home() / '.config/opencode/AGENTS.md', configdir / 'AGENTS.md')
        shutil.copyfile(Path.home() / '.config/opencode/ai-agents-kit-autonomy.md', configdir / 'autonomy.md')
        config = {'$schema':'https://opencode.ai/config.json', 'share':'disabled',
                  'autoupdate':False, 'snapshot':False, 'formatter':False, 'lsp':False,
                  'instructions':[str(configdir / 'autonomy.md')],
                  'agent':{name:{'permission':{'bash':'deny','edit':'deny','webfetch':'deny','websearch':'deny','task':'deny','question':'deny'}} for name in ['developer','code-review']}}
        (configdir / 'opencode.json').write_text(json.dumps(config, indent=2))
    probe = ROOT / 'probe'
    probe.mkdir(exist_ok=True)
    run(['git','init','--quiet',str(probe)])
    evidence = {}
    for arm in ['A','B']:
        env = env_for(arm)
        data = {}
        for cmd in [['debug','paths'], ['debug','skill'], ['debug','agent','developer'], ['debug','agent','code-review'], ['models','openai'], ['models','github-copilot']]:
            p = run([CLI,'--pure',*cmd], cwd=probe, env=env)
            data[' '.join(cmd)] = {'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
        evidence[arm] = data
    (ROOT / 'preflight-evidence.json').write_text(json.dumps(evidence, indent=2))
    print(json.dumps({arm:{cmd:{'returncode':v['returncode'],'bytes':len(v['stdout']), 'stderr':v['stderr'][:300]} for cmd,v in data.items()} for arm,data in evidence.items()},indent=2))

if __name__ == '__main__':
    setup()
