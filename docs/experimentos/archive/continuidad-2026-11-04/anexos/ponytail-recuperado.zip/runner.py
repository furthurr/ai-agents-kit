"""Bounded independent OpenCode sessions; no credentials or private reasoning read/saved."""
from preflight import *
from build_cases import CASES
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime
import time
import signal
import sys

MODEL='openai/gpt-6.1-sol'
PROTOCOL='ponytail-v1-20261104'

def runtime_env(arm, role, workspace):
    env=env_for(arm)
    configdir=(ROOT/'isolated'/arm/'opencode').resolve()
    workspace=workspace.resolve()
    permission={'bash':'deny','edit':'deny','webfetch':'deny','websearch':'deny',
                'task':'deny','question':'deny',
                'external_directory':{'*':'deny',str(configdir)+'/*':'allow'},
                'read':{'*':'allow','*.env*':'deny','*.pem':'deny','*.key':'deny',
                        '*.p12':'deny','*.pfx':'deny','*.jks':'deny','*.keystore':'deny',
                        '*/.ssh/*':'deny','*/.aws/*':'deny','*/.config/gh/*':'deny',
                        '*auth.json':'deny','*/.npmrc':'deny','*/.netrc':'deny'}}
    if role=='developer':
        permission['edit']={'*':'allow','.sdd/*':'deny','AGENTS.md':'deny','TASK.md':'deny'}
        permission['bash']={'*':'deny','python3 -m unittest*':'allow','git status*':'allow','git diff*':'allow'}
    cfg={'agent':{role:{'permission':permission,'steps':22}},
         'share':'disabled','snapshot':False,'autoupdate':False,'lsp':False,'formatter':False}
    env['OPENCODE_CONFIG_CONTENT']=json.dumps(cfg)
    return env

def clean_events(output):
    events=[]
    for line in output.splitlines():
        try: event=json.loads(line)
        except json.JSONDecodeError: continue
        if event.get('type')=='reasoning' or event.get('part',{}).get('type')=='reasoning': continue
        # No reasoning payloads or opaque provider metadata retained.
        part=event.get('part',{})
        part.pop('metadata',None)
        events.append(event)
    return events

def invoke(arm, role, workspace, prompt, timeout=180):
    started=time.time()
    env=runtime_env(arm,role,workspace)
    command=[CLI,'--pure','run','--format','json','--agent',role,'--model',MODEL,'--dir',str(workspace),prompt]
    process=subprocess.Popen(command,cwd=workspace,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    timed_out=False
    try: stdout,stderr=process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out=True
        os.killpg(process.pid,signal.SIGTERM)
        stdout,stderr=process.communicate(timeout=15)
    return {'started':datetime.datetime.fromtimestamp(started,datetime.timezone.utc).isoformat(),
            'seconds':round(time.time()-started,3),'returncode':process.returncode,'timeout':timed_out,
            'events':clean_events(stdout),'stderr':stderr[:3000]}

def hashes(folder):
    return {str(p.relative_to(folder)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(folder.rglob('*')) if p.is_file() and '.git' not in p.parts and '__pycache__' not in p.parts}

def isolate_check():
    checks={}
    for arm in ['A','B']:
        for role in ['developer','code-review']:
            env=runtime_env(arm,role,ROOT/'probe')
            result=run([CLI,'--pure','debug','agent',role],cwd=ROOT/'probe',env=env)
            assert result.returncode==0,result.stderr
            agent=json.loads(result.stdout)
            assert agent['tools']['bash']==(role=='developer')
            assert agent['tools']['edit']==(role=='developer')
            assert not agent['tools']['task'] and not agent['tools']['webfetch']
            expected=(ROOT/'isolated'/arm/'opencode/agents'/f'{role}.md').read_text().split('---',2)[2].strip()
            assert agent['prompt'].strip()==expected
            checks[arm+'-'+role]=agent
    manifests={arm:hashes(ROOT/'isolated'/arm/'opencode') for arm in ['A','B']}
    differing=[p for p in manifests['A'] if manifests['A'][p]!=manifests['B'][p]]
    assert sorted(differing)==['agents/code-review.md','opencode.json','skills/developer/SKILL.md'], differing
    # Agent rules contain identical policies and configuration differs only in arm paths.
    a=(ROOT/'isolated/A/opencode/opencode.json').read_text().replace('/A/','/ARM/')
    b=(ROOT/'isolated/B/opencode/opencode.json').read_text().replace('/B/','/ARM/')
    assert a==b
    (ROOT/'isolation-resolved.json').write_text(json.dumps({'agents':checks,'manifests':manifests,'differing':differing},indent=2))
    probe=invoke('A','code-review',ROOT/'probe',
        'Comprobación del host, no escenario A/B. Usa lectura para comprobar este directorio y enumera si tus herramientas disponibles permiten bash, edit, write, task o webfetch. No ejecutes herramientas prohibidas ni escribas. Responde brevemente.',90)
    (ROOT/'isolation-runtime-probe.json').write_text(json.dumps(probe,indent=2))
    assert not probe['timeout'] and probe['returncode']==0
    assert not any(e.get('part',{}).get('tool') in ['bash','edit','write','task','webfetch'] for e in probe['events'])
    print('Isolation resolution and runtime probe passed; see isolation-resolved.json and isolation-runtime-probe.json')

def cell(id, arm, repeat):
    label=f'{id}-{arm}-r{repeat}'
    workspace=ROOT/'runs'/label
    if workspace.exists(): raise ValueError('Cell exists; never silently overwrite: '+label)
    shutil.copytree(ROOT/'casos-v1'/id,workspace)
    run(['git','init','--quiet',str(workspace)])
    role='code-review' if id in ['S07','S08','S09'] else 'developer'
    (workspace/'AGENTS.md').write_text('Fixture sintético del experimento; no contiene secretos. El alcance está en TASK.md. No leas otros escenarios, oráculos ni resultados del experimento. No uses red. La instalación MAS completa está disponible por skills del host.\n')
    before=hashes(workspace)
    prompt=CASES[id]['task']+'\n\nEsta es una sesión independiente. Usa la skill de tu rol y las de dominio que correspondan; no uses SDD. Implementación autorizada íntegramente para el alcance indicado. No pidas aprobaciones técnicas adicionales. Trabaja solo en este directorio. '
    if role=='developer': prompt+='Para verificar tienes permitido python3 -m unittest discover (y variantes de unittest). No instales paquetes; no uses otros comandos. Entrega resumen breve con cambios, comprobaciones y límites.'
    else: prompt+='Entrega un informe breve de los hallazgos y límites; el evaluador externo se ocupa de pruebas. Los permisos efectivos deshabilitan shell, escritura, delegación y web.'
    result=invoke(arm,role,workspace,prompt)
    after=hashes(workspace)
    events=result.pop('events')
    text='\n'.join(e.get('part',{}).get('text','') for e in events if e.get('type')=='text')
    tools=[e.get('part',{}).get('tool') for e in events if e.get('type')=='tool_use']
    finish=[e['part'] for e in events if e.get('type')=='step_finish']
    metrics={'input':0,'output':0,'cache_read':0,'cache_write':0,'reasoning_count':0,'reported_cost':0}
    for step in finish:
        tok=step.get('tokens',{})
        metrics['input']+=tok.get('input',0)
        metrics['output']+=tok.get('output',0)
        metrics['reasoning_count']+=tok.get('reasoning',0)
        metrics['cache_read']+=tok.get('cache',{}).get('read',0)
        metrics['cache_write']+=tok.get('cache',{}).get('write',0)
        metrics['reported_cost']+=step.get('cost',0)
    if not finish: metrics=None
    evaluation={}
    if role=='developer':
        oracle=run(['python3','-c',CASES[id]['oracle']],cwd=workspace,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        tests=run(['python3','-m','unittest','discover'],cwd=workspace,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        evaluation={'oracle_returncode':oracle.returncode,'oracle_stdout':oracle.stdout,'oracle_stderr':oracle.stderr,
                    'tests_returncode':tests.returncode,'tests_stdout':tests.stdout,'tests_stderr':tests.stderr}
    else: evaluation={'unchanged':before==after,'forbidden_tools_called':[t for t in tools if t in ['bash','edit','write','task','webfetch']]}
    # Tool-use event type is also recorded directly to avoid assumptions about event naming.
    toolparts=[e['part'] for e in events if e.get('part',{}).get('type')=='tool']
    if toolparts: tools=[p.get('tool') for p in toolparts]
    record={'protocol':PROTOCOL,'cell':label,'scenario':id,'arm':arm,'repetition':repeat,'attempt':1,
            'model':MODEL,'host':'opencode 1.18.34 --pure','role':role,**result,'metrics':metrics,
            'tool_calls':tools,'turns':len(finish),'changed':[p for p in set(before)|set(after) if before.get(p)!=after.get(p)],
            'evaluation':evaluation,'output':text,'events_file':f'evidencias-v1/{label}.json'}
    evidence=ROOT/'evidencias-v1'
    evidence.mkdir(exist_ok=True)
    (evidence/f'{label}.json').write_text(json.dumps(events,indent=2))
    (evidence/f'{label}-summary.json').write_text(json.dumps(record,indent=2))
    return record

def batch(repeats):
    jobs=[]
    for repeat in repeats:
        for number,id in enumerate(CASES):
            order=['A','B'] if (number+repeat)%2 else ['B','A']
            jobs.extend((id,arm,repeat) for arm in order)
    records=[]
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures={pool.submit(cell,*job):job for job in jobs}
        for f in as_completed(futures):
            rec=f.result()
            records.append(rec)
            with (ROOT/'ejecuciones-v1.jsonl').open('a') as fp: fp.write(json.dumps(rec)+'\n')
            print(rec['cell'], 'timeout='+str(rec['timeout']), 'seconds='+str(rec['seconds']),
                  'oracle='+str(rec['evaluation'].get('oracle_returncode')), 'tools='+str(len(rec['tool_calls'])),flush=True)
    print('Completed',len(records),'cells')

if __name__=='__main__':
    if sys.argv[1]=='isolation': isolate_check()
    elif sys.argv[1]=='filter': batch([1])
    elif sys.argv[1]=='replicate': batch([2,3])
