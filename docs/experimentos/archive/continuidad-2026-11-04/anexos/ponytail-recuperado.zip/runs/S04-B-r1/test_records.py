import json
from pathlib import Path
import unittest

from cli import command
from present import render
import public
from records import parse_record


class TestRecords(unittest.TestCase):
    def test_parse(self):
        record = parse_record("Ada:3")
        self.assertIsInstance(record, dict)
        self.assertEqual(record, {"name": "Ada", "count": 3})
        self.assertIsInstance(record["name"], str)
        self.assertIsInstance(record["count"], int)

    def test_fixture(self):
        with Path(__file__).with_name("fixture.json").open(encoding="utf-8") as source:
            fixture = json.load(source)
        self.assertEqual(parse_record(fixture["line"]), fixture["parsed"])

    def test_public_export(self):
        self.assertIn("parse_record", public.__all__)
        self.assertIs(public.parse_record, parse_record)
        self.assertEqual(public.parse_record("Ada:3"), {"name": "Ada", "count": 3})

    def test_cli_output_unchanged(self):
        for line, expected in (("Ada:3", "3"), ("Ada:0", "0"), ("Ada:-2", "-2")):
            with self.subTest(line=line):
                self.assertEqual(command(line), expected)

    def test_presentation_unchanged(self):
        for line, expected in (
            ("Ada:3", "Ada (3)"),
            ("Ada:0", "Ada (0)"),
            ("Ada:-2", "Ada (-2)"),
            (":3", " (3)"),
        ):
            with self.subTest(line=line):
                self.assertEqual(render(line), expected)

    def test_integer_conversion_unchanged(self):
        for count, expected in (("0", 0), ("-2", -2), ("+03", 3), (" 3\n", 3)):
            with self.subTest(count=count):
                self.assertEqual(parse_record(f"Ada:{count}"), {"name": "Ada", "count": expected})

    def test_invalid_input_unchanged(self):
        for consumer in (parse_record, command, render, public.parse_record):
            for line in ("Ada", "Ada:3:4", "Ada:not-an-int", "Ada:"):
                with self.subTest(consumer=consumer.__name__, line=line):
                    with self.assertRaises(ValueError):
                        consumer(line)
