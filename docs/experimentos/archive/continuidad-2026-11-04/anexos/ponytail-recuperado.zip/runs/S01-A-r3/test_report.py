import unittest
from report import caption
class TestCaption(unittest.TestCase):
    def test_caption(self):
        self.assertEqual(caption([" Azul  CLARO ", " "]), "azul claro | (sin etiqueta)")

    def test_empty_values(self):
        self.assertEqual(caption([]), "")

    def test_preserves_empty_labels(self):
        self.assertEqual(
            caption(["", "\t\n", "Rojo", ""]),
            "(sin etiqueta) | (sin etiqueta) | rojo | (sin etiqueta)",
        )

    def test_normalizes_whitespace_and_unicode_case(self):
        self.assertEqual(caption(["  STRAẞE\t AZUL\n"]), "strasse azul")
