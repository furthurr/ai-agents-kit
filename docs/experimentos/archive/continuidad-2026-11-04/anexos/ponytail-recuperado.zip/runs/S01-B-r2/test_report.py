import unittest
from report import caption
class TestCaption(unittest.TestCase):
    def test_caption(self):
        self.assertEqual(caption([" Azul  CLARO ", " "]), "azul claro | (sin etiqueta)")

    def test_empty_collection(self):
        self.assertEqual(caption([]), "")

    def test_preserves_empty_entries(self):
        self.assertEqual(
            caption(["", " \t\n", "Rojo", ""]),
            "(sin etiqueta) | (sin etiqueta) | rojo | (sin etiqueta)",
        )

    def test_normalizes_whitespace_and_unicode(self):
        self.assertEqual(caption(["  STRAẞE\t\n AZUL  "]), "strasse azul")

    def test_preserves_order_and_duplicates(self):
        self.assertEqual(caption(["B", "A", "B"]), "b | a | b")
