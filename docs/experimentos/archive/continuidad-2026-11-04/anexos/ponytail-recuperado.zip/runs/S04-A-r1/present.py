from records import parse_record
def render(line):
    record = parse_record(line)
    return f"{record['name']} ({record['count']})"
