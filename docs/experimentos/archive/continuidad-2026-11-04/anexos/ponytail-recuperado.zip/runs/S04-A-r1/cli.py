from records import parse_record
def command(line):
    return str(parse_record(line)["count"])
