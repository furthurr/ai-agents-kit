import json
from pathlib import Path
import unittest

from cli import command
from present import render
import public
from records import parse_record


class TestRecords(unittest.TestCase):
    def test_parse(self):
        for line, name, count in (
            ("Ada:3", "Ada", 3),
            ("Grace:0", "Grace", 0),
            ("Linus:-2", "Linus", -2),
            ("Ada Lovelace:003", "Ada Lovelace", 3),
        ):
            with self.subTest(line=line):
                record = parse_record(line)
                self.assertIsInstance(record, dict)
                self.assertEqual(record, {"name": name, "count": count})
                self.assertIsInstance(record["name"], str)
                self.assertIsInstance(record["count"], int)

    def test_invalid_input_still_raises_value_error(self):
        for line in ("Ada", "Ada:3:4", "Ada:many", "Ada:"):
            with self.subTest(line=line):
                with self.assertRaises(ValueError):
                    parse_record(line)

    def test_fixture(self):
        fixture = json.loads(
            Path(__file__).with_name("fixture.json").read_text(encoding="utf-8")
        )
        self.assertEqual(parse_record(fixture["line"]), fixture["parsed"])

    def test_public_export(self):
        self.assertIn("parse_record", public.__all__)
        self.assertIs(public.parse_record, parse_record)
        self.assertEqual(public.parse_record("Ada:3"), {"name": "Ada", "count": 3})

    def test_cli_output_is_preserved(self):
        for line, expected in (("Ada:3", "3"), ("Grace:0", "0"), ("Linus:-2", "-2")):
            with self.subTest(line=line):
                self.assertEqual(command(line), expected)

    def test_presentation_output_is_preserved(self):
        for line, expected in (
            ("Ada:3", "Ada (3)"),
            ("Grace:0", "Grace (0)"),
            ("Linus:-2", "Linus (-2)"),
            ("Ada Lovelace:003", "Ada Lovelace (3)"),
        ):
            with self.subTest(line=line):
                self.assertEqual(render(line), expected)
