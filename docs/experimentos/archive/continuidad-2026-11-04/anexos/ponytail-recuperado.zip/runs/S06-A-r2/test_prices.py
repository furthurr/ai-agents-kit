import unittest
from domain import quote
from disk_prices import DiskPrices
class TestPrices(unittest.TestCase):
    def test_price(self): self.assertEqual(quote(DiskPrices(),2),20)

    def test_price_rejects_negative_quantities(self):
        for quantity in (-1, -10, -0.5):
            with self.subTest(quantity=quantity):
                with self.assertRaises(ValueError):
                    DiskPrices().price(quantity)

    def test_quote_propagates_negative_quantity_error(self):
        with self.assertRaises(ValueError):
            quote(DiskPrices(), -1)

    def test_non_negative_prices_are_preserved(self):
        for quantity, expected in ((0, 0), (1, 10), (2, 20), (0.5, 5)):
            with self.subTest(quantity=quantity):
                self.assertEqual(DiskPrices().price(quantity), expected)
                self.assertEqual(quote(DiskPrices(), quantity), expected)
