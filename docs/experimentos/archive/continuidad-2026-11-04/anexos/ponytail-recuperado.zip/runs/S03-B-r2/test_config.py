import unittest
from unittest.mock import patch

import yaml

from config_loader import load_config


class TestConfig(unittest.TestCase):
    def test_map(self):
        self.assertEqual(load_config("name: Ada\nitems: [1, 2]"), {"name":"Ada", "items":[1,2]})

    def test_nested_maps_and_lists(self):
        self.assertEqual(
            load_config("people:\n  - name: Ada\n    roles:\n      - developer\n"),
            {"people": [{"name": "Ada", "roles": ["developer"]}]},
        )

    def test_anchors_aliases_and_merge_keys(self):
        config = load_config(
            "defaults: &defaults\n"
            "  retries: 3\n"
            "  enabled: true\n"
            "alias: *defaults\n"
            "service:\n"
            "  <<: *defaults\n"
            "  retries: 5\n"
        )
        self.assertIs(config["alias"], config["defaults"])
        self.assertEqual(config["service"], {"retries": 5, "enabled": True})

    def test_multiline_scalars(self):
        self.assertEqual(
            load_config("literal: |\n  first\n  second\nfolded: >-\n  first\n  second\n"),
            {"literal": "first\nsecond\n", "folded": "first second"},
        )

    def test_scalar_types_and_quoted_values(self):
        self.assertEqual(
            load_config('enabled: true\nmissing: null\ncount: 3\nratio: 1.5\ntext: "true"'),
            {"enabled": True, "missing": None, "count": 3, "ratio": 1.5, "text": "true"},
        )

    def test_empty_mapping(self):
        self.assertEqual(load_config("{}"), {})

    def test_non_mapping_roots_raise_value_error(self):
        for text in ("", "# comment only", "null", "42", "hello", "[]", "- item", "true"):
            with self.subTest(text=text), self.assertRaisesRegex(ValueError, "root.*mapping"):
                load_config(text)

    def test_invalid_yaml_raises_value_error_with_cause(self):
        for text in ("items: [1, 2", "alias: *missing", "? [a, b]\n: value", "a: 1\n---\nb: 2"):
            with self.subTest(text=text), self.assertRaises(ValueError) as caught:
                load_config(text)
            self.assertIsInstance(caught.exception.__cause__, yaml.YAMLError)

    def test_python_tags_are_rejected_without_execution(self):
        payloads = (
            '!!python/object/apply:os.system ["not-a-real-command"]',
            'value: !!python/object/apply:os.system ["not-a-real-command"]',
            "value: !!python/object:builtins.object {}",
            "value: !!python/object/new:builtins.object []",
            "value: !!python/name:os.system ''",
        )
        with patch("os.system") as system:
            for text in payloads:
                with self.subTest(text=text), self.assertRaises(ValueError):
                    load_config(text)
            system.assert_not_called()

    def test_unknown_tags_are_rejected(self):
        with self.assertRaises(ValueError):
            load_config("value: !custom data")
