import yaml


def load_config(text):
    """Load a single YAML mapping without constructing Python objects.

    Raise ValueError for invalid YAML, unsupported tags or a non-mapping root.
    Scalar resolution follows PyYAML's SafeLoader semantics.
    """
    try:
        config = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise ValueError("Invalid YAML configuration") from exc

    if not isinstance(config, dict):
        raise ValueError("Configuration root must be a mapping")
    return config
