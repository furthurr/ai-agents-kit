import unittest
from display import display_name
class TestDisplay(unittest.TestCase):
    def test_display(self):
        self.assertEqual(display_name("  Ada  LOVELACE "), "Ada LOVELACE")

    def test_collapses_whitespace(self):
        self.assertEqual(display_name("\t Ada\n  LOVELACE\t "), "Ada LOVELACE")

    def test_preserves_case(self):
        self.assertEqual(display_name("  Áda  McDONALD  Straße "), "Áda McDONALD Straße")

    def test_empty_name(self):
        for value in ("", " ", "  \t\n\r  "):
            with self.subTest(value=value):
                self.assertEqual(display_name(value), "Anónimo")

    def test_name_without_extra_whitespace(self):
        self.assertEqual(display_name("Ada LOVELACE"), "Ada LOVELACE")
