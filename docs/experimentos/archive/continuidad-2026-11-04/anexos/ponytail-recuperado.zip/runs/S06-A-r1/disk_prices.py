from ports import PricingPort
class DiskPrices(PricingPort):
    def price(self, quantity):
        if quantity < 0:
            raise ValueError("quantity must be non-negative")
        return quantity * 10
