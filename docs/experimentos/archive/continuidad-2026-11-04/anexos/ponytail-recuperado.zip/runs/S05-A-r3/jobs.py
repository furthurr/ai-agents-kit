def process_job(job, allowed, opener):
    if not allowed:
        raise PermissionError("denied")
    if not job:
        raise ValueError("empty job")
    resource = opener(job)
    read_failed = False
    try:
        return resource.read()
    except BaseException:
        read_failed = True
        raise
    finally:
        try:
            resource.close()
        except BaseException:
            if not read_failed:
                raise
