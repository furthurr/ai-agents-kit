from labels import normalize_label


def caption(values):
    return " | ".join(normalize_label(value) for value in values)
