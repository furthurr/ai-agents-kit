import unittest
from report import caption
class TestCaption(unittest.TestCase):
    def test_caption(self):
        self.assertEqual(caption([" Azul  CLARO ", " "]), "azul claro | (sin etiqueta)")

    def test_empty_collection(self):
        self.assertEqual(caption([]), "")

    def test_preserves_empty_entries_and_order(self):
        self.assertEqual(
            caption(["", " ROJO ", "\t\n", ""]),
            "(sin etiqueta) | rojo | (sin etiqueta) | (sin etiqueta)",
        )

    def test_uses_label_normalization(self):
        self.assertEqual(caption([" STRAẞE\t AZUL\n"]), "strasse azul")
