import yaml


def load_config(text):
    """Load a single safe YAML document with a mapping at its root.

    Invalid YAML, unsupported tags and non-mapping roots raise ValueError.
    Scalar resolution follows PyYAML's SafeLoader semantics.
    """
    try:
        config = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise ValueError("Invalid or unsupported YAML configuration") from exc

    if not isinstance(config, dict):
        raise ValueError("Configuration root must be a mapping")
    return config
