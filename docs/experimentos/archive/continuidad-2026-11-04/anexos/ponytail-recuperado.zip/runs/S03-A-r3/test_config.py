import unittest
from unittest.mock import patch

from config_loader import load_config


class TestConfig(unittest.TestCase):
    def test_map(self):
        self.assertEqual(load_config("name: Ada\nitems: [1, 2]"), {"name":"Ada", "items":[1,2]})

    def test_nested_maps_and_block_lists(self):
        self.assertEqual(
            load_config("service:\n  enabled: true\n  items:\n    - name: Ada\n      score: 2.5\n    - null\n"),
            {"service": {"enabled": True, "items": [{"name": "Ada", "score": 2.5}, None]}},
        )

    def test_anchors_aliases_and_merge_keys(self):
        config = load_config(
            "defaults: &defaults\n  retries: 3\n  hosts: &hosts [alpha, beta]\n"
            "service:\n  <<: *defaults\n  retries: 5\n"
            "hosts: *hosts\ncopy: *defaults\n"
        )
        self.assertEqual(config["service"], {"retries": 5, "hosts": ["alpha", "beta"]})
        self.assertIs(config["copy"], config["defaults"])
        self.assertIs(config["hosts"], config["defaults"]["hosts"])

    def test_multiline_scalars(self):
        self.assertEqual(
            load_config("literal: |\n  first\n  second\nfolded: >-\n  first\n  second\n"),
            {"literal": "first\nsecond\n", "folded": "first second"},
        )

    def test_flow_mapping_comments_and_quoted_scalars(self):
        self.assertEqual(
            load_config('---\n{number: 42, text: "true", empty: ""} # comment\n...\n'),
            {"number": 42, "text": "true", "empty": ""},
        )

    def test_empty_mapping_is_valid(self):
        self.assertEqual(load_config("{}"), {})

    def test_non_mapping_roots_raise_value_error(self):
        for text in ("", "# comment", "null", "42", "true", "text", "[]", "- item"):
            with self.subTest(text=text):
                with self.assertRaisesRegex(ValueError, "root must be a mapping"):
                    load_config(text)

    def test_invalid_yaml_raises_value_error(self):
        for text in ("items: [1, 2", "value: *missing", "? [a, b]\n: value", "a: 1\n---\nb: 2"):
            with self.subTest(text=text):
                with self.assertRaises(ValueError) as caught:
                    load_config(text)
                self.assertIsNotNone(caught.exception.__cause__)

    def test_python_tags_are_rejected_without_constructing_objects(self):
        payloads = (
            'value: !!python/object/apply:builtins.eval ["1 + 1"]',
            'value: !!python/object/new:builtins.tuple [[1, 2]]',
            'value: !!python/object:builtins.object {}',
            'value: !!python/name:builtins.eval ""',
            '!!python/object:builtins.dict {}',
        )
        with patch("builtins.eval") as evaluate:
            for text in payloads:
                with self.subTest(text=text):
                    with self.assertRaises(ValueError):
                        load_config(text)
            evaluate.assert_not_called()

    def test_unknown_tag_is_rejected(self):
        with self.assertRaises(ValueError):
            load_config("value: !unknown data")
