import unittest
from domain import quote
from disk_prices import DiskPrices
from ports import PricingPort
class TestPrices(unittest.TestCase):
    def test_price(self): self.assertEqual(quote(DiskPrices(),2),20)

    def test_non_negative_prices(self):
        prices = DiskPrices()
        for quantity in (0, 1, 2, 100, 0.5):
            with self.subTest(quantity=quantity):
                self.assertEqual(prices.price(quantity), quantity * 10)
                self.assertEqual(quote(prices, quantity), quantity * 10)

    def test_negative_quantities_raise_value_error(self):
        prices = DiskPrices()
        for quantity in (-1, -100, -0.5):
            with self.subTest(quantity=quantity):
                with self.assertRaises(ValueError):
                    prices.price(quantity)
                with self.assertRaises(ValueError):
                    quote(prices, quantity)

    def test_quote_accepts_another_pricing_port(self):
        class FixedPrices(PricingPort):
            def price(self, quantity):
                return 42

        self.assertEqual(quote(FixedPrices(), 2), 42)
