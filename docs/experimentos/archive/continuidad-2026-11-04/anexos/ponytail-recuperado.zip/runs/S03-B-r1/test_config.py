import unittest
from unittest.mock import patch

from config_loader import load_config


class TestConfig(unittest.TestCase):
    def test_map(self):
        self.assertEqual(load_config("name: Ada\nitems: [1, 2]"), {"name":"Ada", "items":[1,2]})

    def test_nested_maps_and_block_lists(self):
        text = """
service:
  name: 'Ada: # not a comment'
  workers:
    - name: first
      ports: [8000, 8001]
    - name: second
      ports: []
"""
        self.assertEqual(load_config(text), {
            "service": {
                "name": "Ada: # not a comment",
                "workers": [
                    {"name": "first", "ports": [8000, 8001]},
                    {"name": "second", "ports": []},
                ],
            },
        })

    def test_anchors_aliases_and_merge(self):
        text = """
defaults: &defaults
  retries: 3
  ports: &ports [8000, 8001]
copy: *defaults
service:
  <<: *defaults
  retries: 5
ports: *ports
"""
        config = load_config(text)
        self.assertEqual(config["defaults"], {"retries": 3, "ports": [8000, 8001]})
        self.assertIs(config["copy"], config["defaults"])
        self.assertIs(config["ports"], config["defaults"]["ports"])
        self.assertEqual(config["service"], {"retries": 5, "ports": [8000, 8001]})

    def test_multiline_scalars(self):
        config = load_config("literal: |\n  first\n  second\nfolded: >-\n  first\n  second\n")
        self.assertEqual(config, {"literal": "first\nsecond\n", "folded": "first second"})

    def test_scalar_types_and_flow_mapping(self):
        self.assertEqual(
            load_config('{integer: 42, decimal: 1.5, enabled: true, missing: null, quoted: "true"}'),
            {"integer": 42, "decimal": 1.5, "enabled": True, "missing": None, "quoted": "true"},
        )

    def test_empty_mapping(self):
        self.assertEqual(load_config("{}"), {})

    def test_root_must_be_mapping(self):
        for text in ("", "# comment only\n", "null", "[]", "- item", "text", "42", "true"):
            with self.subTest(text=text):
                with self.assertRaisesRegex(ValueError, "root must be a mapping"):
                    load_config(text)

    def test_yaml_errors_are_value_errors(self):
        for text in (
            "items: [1, 2",
            "key: *undefined",
            "key: !unknown value",
            "? [unhashable, key]\n: value",
            "first: 1\n---\nsecond: 2",
        ):
            with self.subTest(text=text):
                with self.assertRaisesRegex(ValueError, "Invalid YAML configuration") as error:
                    load_config(text)
                self.assertIsNotNone(error.exception.__cause__)

    def test_python_tags_are_rejected_without_execution(self):
        tags = (
            "!!python/object/apply:builtins.eval ['1 + 1']",
            "!!python/object/new:builtins.object {}",
            "!!python/object:builtins.object {}",
            "!!python/name:builtins.eval ''",
        )
        with patch("builtins.eval") as evaluate:
            for tag in tags:
                for text in (tag, "payload: " + tag):
                    with self.subTest(text=text):
                        with self.assertRaises(ValueError):
                            load_config(text)
            evaluate.assert_not_called()
