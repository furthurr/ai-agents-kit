import yaml


def load_config(text):
    """Load one safe YAML document, requiring a mapping at its root.

    Invalid YAML, unsupported tags and non-mapping roots raise ValueError.
    Scalar resolution follows PyYAML's SafeLoader semantics.
    """
    try:
        config = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise ValueError(f"Invalid YAML configuration: {exc}") from exc

    if not isinstance(config, dict):
        raise ValueError("Configuration root must be a mapping")
    return config
