import unittest
from report import caption
class TestCaption(unittest.TestCase):
    def test_caption(self):
        self.assertEqual(caption([" Azul  CLARO ", " "]), "azul claro | (sin etiqueta)")

    def test_empty_values_are_preserved(self):
        self.assertEqual(
            caption(["", "\t\n", " Azul ", ""]),
            "(sin etiqueta) | (sin etiqueta) | azul | (sin etiqueta)",
        )

    def test_empty_collection(self):
        self.assertEqual(caption([]), "")

    def test_normalization_and_order(self):
        self.assertEqual(
            caption([" STRAẞE ", " Azul\t\nCLARO ", " STRAẞE "]),
            "strasse | azul claro | strasse",
        )

    def test_iterable(self):
        self.assertEqual(caption(iter([" UNO ", " DOS "])), "uno | dos")
