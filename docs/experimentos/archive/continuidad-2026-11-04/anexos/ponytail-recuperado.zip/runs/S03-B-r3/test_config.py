import unittest
from unittest.mock import patch

from config_loader import load_config


class TestConfig(unittest.TestCase):
    def test_map(self):
        self.assertEqual(load_config("name: Ada\nitems: [1, 2]"), {"name":"Ada", "items":[1,2]})

    def test_nested_maps_and_block_lists(self):
        self.assertEqual(
            load_config("service:\n  users:\n    - name: Ada\n      roles: [admin, reader]\n"),
            {"service": {"users": [{"name": "Ada", "roles": ["admin", "reader"]}]}},
        )

    def test_anchors_aliases_and_merge_keys(self):
        config = load_config(
            "defaults: &defaults\n  retries: 3\n  enabled: true\n"
            "copy: *defaults\n"
            "service:\n  <<: *defaults\n  retries: 5\n"
        )
        self.assertIs(config["defaults"], config["copy"])
        self.assertEqual(config["service"], {"retries": 5, "enabled": True})

    def test_multiline_scalars(self):
        self.assertEqual(
            load_config("literal: |\n  first\n  second\nfolded: >-\n  first\n  second\n"),
            {"literal": "first\nsecond\n", "folded": "first second"},
        )

    def test_scalar_resolution_and_quoted_strings(self):
        self.assertEqual(
            load_config('count: 3\nratio: 1.5\nenabled: true\nmissing: null\ntext: "true"\n'),
            {"count": 3, "ratio": 1.5, "enabled": True, "missing": None, "text": "true"},
        )

    def test_empty_map_and_document_markers(self):
        self.assertEqual(load_config("---\n{}\n...\n"), {})

    def test_non_mapping_roots_raise_value_error(self):
        for text in ("", "# comment\n", "null", "[]", "- item", "hello", "42", "true"):
            with self.subTest(text=text), self.assertRaises(ValueError):
                load_config(text)

    def test_invalid_yaml_raises_value_error(self):
        for text in ("items: [1,", "a: *missing", "a: {[]: value}"):
            with self.subTest(text=text), self.assertRaises(ValueError) as error:
                load_config(text)
            self.assertIsNotNone(error.exception.__cause__)

    def test_multiple_documents_are_rejected(self):
        with self.assertRaises(ValueError):
            load_config("---\na: 1\n---\nb: 2\n")

    def test_python_tags_are_rejected_without_execution(self):
        tags = (
            '!!python/object/apply:os.system ["never execute"]',
            '!!python/object/new:builtins.list []',
            '!!python/object:builtins.object {}',
            '!!python/name:os.system',
            '!!python/tuple [1, 2]',
        )
        with patch("os.system") as system:
            for tag in tags:
                for text in (tag, "nested: " + tag):
                    with self.subTest(text=text), self.assertRaises(ValueError):
                        load_config(text)
            system.assert_not_called()

    def test_unknown_tags_are_rejected(self):
        with self.assertRaises(ValueError):
            load_config("value: !custom data")
