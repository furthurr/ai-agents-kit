import yaml


def load_config(text):
    """Load a YAML mapping safely; reject invalid YAML or non-mapping roots.

    Scalar resolution follows PyYAML's SafeLoader semantics. Unsupported tags,
    including Python object tags, raise ValueError without constructing objects.
    """
    try:
        config = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise ValueError("Invalid or unsupported YAML configuration") from exc

    if not isinstance(config, dict):
        raise ValueError("Configuration root must be a mapping")
    return config
