import json
from pathlib import Path
import unittest

from cli import command
from present import render
import public
from records import parse_record


class TestRecords(unittest.TestCase):
    def test_parse(self):
        record = parse_record("Ada:3")
        self.assertIsInstance(record, dict)
        self.assertEqual(record, {"name": "Ada", "count": 3})
        self.assertIsInstance(record["name"], str)
        self.assertIsInstance(record["count"], int)

    def test_parse_counts(self):
        for count in ("0", "-2", "+4", "003"):
            with self.subTest(count=count):
                self.assertEqual(
                    parse_record(f"Ada:{count}"),
                    {"name": "Ada", "count": int(count)},
                )

    def test_invalid_input_still_raises(self):
        for line in ("Ada", "Ada:3:4", "Ada:invalid", "Ada:"):
            with self.subTest(line=line):
                with self.assertRaises(ValueError):
                    parse_record(line)

    def test_public_export(self):
        self.assertEqual(public.__all__, ["parse_record"])
        self.assertIs(public.parse_record, parse_record)
        self.assertEqual(public.parse_record("Ada:3"), {"name": "Ada", "count": 3})

    def test_fixture(self):
        with Path(__file__).with_name("fixture.json").open(encoding="utf-8") as source:
            fixture = json.load(source)
        self.assertEqual(parse_record(fixture["line"]), fixture["parsed"])

    def test_cli_output_unchanged(self):
        for line, expected in (("Ada:3", "3"), ("Ada:0", "0"), ("Ada:-2", "-2")):
            with self.subTest(line=line):
                self.assertEqual(command(line), expected)

    def test_presentation_unchanged(self):
        for line, expected in (
            ("Ada:3", "Ada (3)"),
            ("Ada:0", "Ada (0)"),
            ("Ada:-2", "Ada (-2)"),
            (" Ada :003", " Ada  (3)"),
        ):
            with self.subTest(line=line):
                self.assertEqual(render(line), expected)
