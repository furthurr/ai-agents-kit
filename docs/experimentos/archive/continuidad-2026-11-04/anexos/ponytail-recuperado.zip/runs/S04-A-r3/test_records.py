import json
from pathlib import Path
import unittest

from cli import command
from present import render
import public
from records import parse_record


class TestRecords(unittest.TestCase):
    def test_parse(self):
        record = parse_record("Ada:3")
        self.assertIsInstance(record, dict)
        self.assertEqual(record, {"name": "Ada", "count": 3})
        self.assertIsInstance(record["name"], str)
        self.assertIsInstance(record["count"], int)

    def test_fixture(self):
        fixture = json.loads(
            Path(__file__).with_name("fixture.json").read_text(encoding="utf-8")
        )
        self.assertEqual(parse_record(fixture["line"]), fixture["parsed"])

    def test_public_export(self):
        self.assertEqual(public.__all__, ["parse_record"])
        self.assertIs(public.parse_record, parse_record)
        self.assertEqual(public.parse_record("Ada:3"), {"name": "Ada", "count": 3})

    def test_outputs_unchanged(self):
        for line, expected_record, expected_cli, expected_render in [
            ("Ada:3", {"name": "Ada", "count": 3}, "3", "Ada (3)"),
            ("Bob:0", {"name": "Bob", "count": 0}, "0", "Bob (0)"),
            ("Ada:-2", {"name": "Ada", "count": -2}, "-2", "Ada (-2)"),
            (" Ada :003", {"name": " Ada ", "count": 3}, "3", " Ada  (3)"),
            (":1", {"name": "", "count": 1}, "1", " (1)"),
        ]:
            with self.subTest(line=line):
                self.assertEqual(parse_record(line), expected_record)
                self.assertEqual(command(line), expected_cli)
                self.assertEqual(render(line), expected_render)

    def test_invalid_records_still_raise_value_error(self):
        for line in ["Ada", "Ada:3:4", "Ada:many", "Ada:"]:
            for consumer in [parse_record, public.parse_record, command, render]:
                with self.subTest(line=line, consumer=consumer.__name__):
                    with self.assertRaises(ValueError):
                        consumer(line)
