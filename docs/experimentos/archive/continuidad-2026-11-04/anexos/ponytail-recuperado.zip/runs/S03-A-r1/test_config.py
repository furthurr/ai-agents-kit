import unittest
from unittest.mock import patch

from config_loader import load_config


class TestConfig(unittest.TestCase):
    def test_map(self):
        self.assertEqual(load_config("name: Ada\nitems: [1, 2]"), {"name":"Ada", "items":[1,2]})

    def test_nested_maps_and_block_lists(self):
        text = """\
service:
  enabled: true
  retries: 3
  ratio: 1.5
  optional: null
  users:
    - name: Ada
      roles: [admin, reader]
    - name: Grace
      roles: []
"""
        self.assertEqual(load_config(text), {
            "service": {
                "enabled": True, "retries": 3, "ratio": 1.5,
                "optional": None,
                "users": [
                    {"name": "Ada", "roles": ["admin", "reader"]},
                    {"name": "Grace", "roles": []},
                ],
            },
        })

    def test_anchors_aliases_and_merge(self):
        config = load_config("""\
defaults: &defaults
  retries: 3
  tags: &tags [one, two]
copy: *defaults
service:
  <<: *defaults
  retries: 5
tags: *tags
""")
        self.assertIs(config["defaults"], config["copy"])
        self.assertIs(config["tags"], config["defaults"]["tags"])
        self.assertEqual(config["service"], {"retries": 5, "tags": ["one", "two"]})

    def test_multiline_scalars(self):
        config = load_config("""\
literal: |
  first line
  second line
folded: >-
  first line
  second line
""")
        self.assertEqual(config["literal"], "first line\nsecond line\n")
        self.assertEqual(config["folded"], "first line second line")

    def test_flow_mapping_comments_quotes_and_unicode(self):
        self.assertEqual(
            load_config('---\n{name: "Áda", text: "a: b # c", flag: "true"} # comment\n...'),
            {"name": "Áda", "text": "a: b # c", "flag": "true"},
        )

    def test_empty_mapping_is_valid(self):
        self.assertEqual(load_config("{}"), {})

    def test_non_mapping_roots(self):
        for text in ("", "# comment", "null", "42", "true", "hello", "[]", "- one\n- two"):
            with self.subTest(text=text):
                with self.assertRaisesRegex(ValueError, "root must be a mapping"):
                    load_config(text)

    def test_malformed_yaml_and_multiple_documents(self):
        for text in ("items: [1, 2", "a: *missing", "? [a, b]\n: value", "a: 1\n---\nb: 2"):
            with self.subTest(text=text):
                with self.assertRaisesRegex(ValueError, "Invalid YAML configuration"):
                    load_config(text)

    def test_rejects_python_and_unknown_tags_without_execution(self):
        payloads = (
            'value: !!python/object/apply:os.system ["should-not-run"]',
            'value: !!python/object/new:builtins.object {}',
            'value: !!python/object:builtins.object {}',
            'value: !!python/name:os.system',
            'value: !!python/tuple [1, 2]',
            'value: !custom {}',
        )
        with patch("os.system") as system:
            for text in payloads:
                with self.subTest(text=text):
                    with self.assertRaises(ValueError):
                        load_config(text)
            system.assert_not_called()
