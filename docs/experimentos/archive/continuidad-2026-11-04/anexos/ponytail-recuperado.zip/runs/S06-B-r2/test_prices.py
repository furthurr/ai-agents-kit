import unittest
from domain import quote
from disk_prices import DiskPrices
from ports import PricingPort
class TestPrices(unittest.TestCase):
    def test_price(self): self.assertEqual(quote(DiskPrices(),2),20)

    def test_negative_quantities_are_rejected(self):
        for quantity in (-1, -0.5, -100):
            with self.subTest(quantity=quantity):
                with self.assertRaises(ValueError):
                    DiskPrices().price(quantity)

    def test_non_negative_quantities_keep_their_price(self):
        for quantity, expected in ((0, 0), (1, 10), (2.5, 25), (100, 1000)):
            with self.subTest(quantity=quantity):
                self.assertEqual(quote(DiskPrices(), quantity), expected)

    def test_quote_propagates_negative_quantity_error(self):
        with self.assertRaises(ValueError):
            quote(DiskPrices(), -1)

    def test_quote_uses_injected_pricing_port(self):
        class FixedPrices(PricingPort):
            def price(self, quantity):
                return 42

        self.assertEqual(quote(FixedPrices(), 2), 42)
