import unittest
from display import display_name
class TestDisplay(unittest.TestCase):
    def test_display(self):
        self.assertEqual(display_name("  Ada  LOVELACE "), "Ada LOVELACE")

    def test_empty_name(self):
        for value in ("", "   ", "\t\n\r", "\u00a0"):
            with self.subTest(value=value):
                self.assertEqual(display_name(value), "Anónimo")

    def test_collapses_whitespace(self):
        self.assertEqual(display_name("\tAda\n \tLOVELACE\r\n"), "Ada LOVELACE")
        self.assertEqual(display_name("  Ada\u00a0 LOVELACE  "), "Ada LOVELACE")

    def test_preserves_case(self):
        for value in ("aDa LoVeLaCe", "ÁNGELA Muñoz", "Straße", "ANÓNIMO"):
            with self.subTest(value=value):
                self.assertEqual(display_name(value), value)
