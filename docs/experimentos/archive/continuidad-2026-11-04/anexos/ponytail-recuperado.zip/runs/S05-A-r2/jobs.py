def process_job(job, allowed, opener):
    if not allowed:
        raise PermissionError("denied")
    if not job:
        raise ValueError("empty job")
    resource = opener(job)
    read_failed = False
    try:
        return resource.read()
    except BaseException:
        read_failed = True
        raise
    finally:
        try:
            resource.close()
        except BaseException:
            # A cleanup failure must not replace the original read failure.
            if not read_failed:
                raise
