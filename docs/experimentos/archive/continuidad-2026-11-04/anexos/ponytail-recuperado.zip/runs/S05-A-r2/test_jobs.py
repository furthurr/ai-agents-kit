import unittest
from unittest.mock import Mock

from jobs import process_job


class Resource:
    """Resource deliberately lacking the context manager protocol."""

    def __init__(self, read_error=None, close_error=None):
        self.read_error = read_error
        self.close_error = close_error
        self.close_calls = 0

    def read(self):
        if self.read_error is not None:
            raise self.read_error
        return "done"

    def close(self):
        self.close_calls += 1
        if self.close_error is not None:
            raise self.close_error


class TestJobs(unittest.TestCase):
    def test_success(self):
        resource = Resource()
        opener = Mock(return_value=resource)

        self.assertEqual(process_job("x", True, opener), "done")

        opener.assert_called_once_with("x")
        self.assertEqual(resource.close_calls, 1)

    def test_permission_is_checked_before_job_and_opening(self):
        for job in ("x", "", None):
            with self.subTest(job=job):
                opener = Mock()
                with self.assertRaisesRegex(PermissionError, "^denied$"):
                    process_job(job, False, opener)
                opener.assert_not_called()

    def test_empty_job_is_rejected_before_opening(self):
        for job in ("", None, False, 0, [], {}):
            with self.subTest(job=job):
                opener = Mock()
                with self.assertRaisesRegex(ValueError, "^empty job$"):
                    process_job(job, True, opener)
                opener.assert_not_called()

    def test_opening_error_is_propagated(self):
        error = OSError("cannot open")
        opener = Mock(side_effect=error)

        with self.assertRaises(OSError) as caught:
            process_job("x", True, opener)

        self.assertIs(caught.exception, error)
        opener.assert_called_once_with("x")

    def test_reading_error_is_propagated_and_resource_closed_once(self):
        for error in (RuntimeError("read failed"), KeyboardInterrupt()):
            with self.subTest(error=type(error).__name__):
                resource = Resource(read_error=error)

                with self.assertRaises(type(error)) as caught:
                    process_job("x", True, lambda job: resource)

                self.assertIs(caught.exception, error)
                self.assertEqual(resource.close_calls, 1)

    def test_closing_error_does_not_replace_reading_error(self):
        for close_error in (OSError("close failed"), KeyboardInterrupt()):
            with self.subTest(error=type(close_error).__name__):
                error = RuntimeError("read failed")
                resource = Resource(read_error=error, close_error=close_error)

                with self.assertRaises(RuntimeError) as caught:
                    process_job("x", True, lambda job: resource)

                self.assertIs(caught.exception, error)
                self.assertEqual(resource.close_calls, 1)

    def test_closing_error_after_successful_read_is_propagated(self):
        error = OSError("close failed")
        resource = Resource(close_error=error)

        with self.assertRaises(OSError) as caught:
            process_job("x", True, lambda job: resource)

        self.assertIs(caught.exception, error)
        self.assertEqual(resource.close_calls, 1)
