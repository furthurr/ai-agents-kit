import unittest
from display import display_name
class TestDisplay(unittest.TestCase):
    def test_display(self):
        self.assertEqual(display_name("  Ada  LOVELACE "), "Ada LOVELACE")

    def test_preserves_case(self):
        for value in ("aDa lOvElAcE", "ÁNA ñÚÑEZ", "Straße İ"):
            with self.subTest(value=value):
                self.assertEqual(display_name(value), value)

    def test_collapses_whitespace(self):
        self.assertEqual(display_name("\t Ada\n \tLOVELACE\r\n"), "Ada LOVELACE")

    def test_empty_returns_anonymous(self):
        for value in ("", "   ", "\t\n\r", "\u00a0"):
            with self.subTest(value=value):
                self.assertEqual(display_name(value), "Anónimo")
