def display_name(value):
    return " ".join(value.split()) or "Anónimo"
