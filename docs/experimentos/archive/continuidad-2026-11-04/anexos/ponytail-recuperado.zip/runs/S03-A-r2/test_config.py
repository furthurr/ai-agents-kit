import unittest
from unittest.mock import patch

from config_loader import load_config


class TestConfig(unittest.TestCase):
    def test_map(self):
        self.assertEqual(load_config("name: Ada\nitems: [1, 2]"), {"name":"Ada", "items":[1,2]})

    def test_nested_maps_and_block_lists(self):
        self.assertEqual(
            load_config("people:\n  - name: Ada\n    roles: [admin, editor]\n"),
            {"people": [{"name": "Ada", "roles": ["admin", "editor"]}]},
        )

    def test_aliases_and_merge_keys(self):
        config = load_config(
            "defaults: &defaults\n  retries: 3\n  enabled: true\n"
            "alias: *defaults\n"
            "service:\n  <<: *defaults\n  retries: 5\n"
        )
        self.assertIs(config["alias"], config["defaults"])
        self.assertEqual(config["service"], {"retries": 5, "enabled": True})

    def test_multiline_scalars(self):
        self.assertEqual(
            load_config("literal: |\n  first\n  second\nfolded: >-\n  first\n  second\n"),
            {"literal": "first\nsecond\n", "folded": "first second"},
        )

    def test_standard_scalars_and_document_markers(self):
        self.assertEqual(
            load_config(
                '---\nname: "Áda: #1" # comment\ncount: 3\n'
                'ratio: 1.5\nenabled: false\nmissing: null\nquoted: "true"\n...\n'
            ),
            {"name": "Áda: #1", "count": 3, "ratio": 1.5,
             "enabled": False, "missing": None, "quoted": "true"},
        )

    def test_empty_mapping(self):
        self.assertEqual(load_config("{}"), {})

    def test_non_mapping_roots(self):
        for text in ("", "# comment\n", "null", "42", "true", "hello", "[]", "- item"):
            with self.subTest(text=text):
                with self.assertRaisesRegex(ValueError, "root must be a mapping"):
                    load_config(text)

    def test_malformed_yaml_and_multiple_documents(self):
        for text in ("items: [1, 2", "value: *missing", "a: 1\n---\nb: 2", "? [a, b]\n: value"):
            with self.subTest(text=text):
                with self.assertRaises(ValueError) as raised:
                    load_config(text)
                self.assertIsNotNone(raised.exception.__cause__)

    def test_python_and_unknown_tags_are_rejected(self):
        tags = (
            "!!python/object:builtins.object {}",
            "!!python/object/new:builtins.object []",
            "!!python/object/apply:builtins.eval ['1 + 1']",
            "!!python/name:builtins.eval ''",
            "!!python/tuple [1, 2]",
            "!custom value",
        )
        for tag in tags:
            for text in (tag, "nested: " + tag):
                with self.subTest(text=text):
                    with self.assertRaises(ValueError):
                        load_config(text)

    def test_python_callable_is_not_executed(self):
        with patch("builtins.eval") as evaluate:
            with self.assertRaises(ValueError):
                load_config("nested: !!python/object/apply:builtins.eval ['1 + 1']")
            evaluate.assert_not_called()
