import yaml


def load_config(text):
    """Load one YAML mapping using PyYAML's safe standard-type constructors.

    Invalid YAML, unsupported tags, and non-mapping roots raise ValueError.
    Nested values retain PyYAML's standard scalar and collection semantics.
    """
    try:
        config = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise ValueError("Invalid or unsupported YAML configuration") from exc

    if not isinstance(config, dict):
        raise ValueError("Configuration root must be a mapping")
    return config
