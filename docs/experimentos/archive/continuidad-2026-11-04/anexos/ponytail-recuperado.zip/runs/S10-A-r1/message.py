def success_message():
    return "Guardado"
