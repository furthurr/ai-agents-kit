import json
from pathlib import Path
import unittest

from cli import command
from present import render
import public
from records import parse_record


class TestRecords(unittest.TestCase):
    def test_parse(self):
        record = parse_record("Ada:3")
        self.assertIsInstance(record, dict)
        self.assertEqual(record, {"name": "Ada", "count": 3})
        self.assertIsInstance(record["name"], str)
        self.assertIsInstance(record["count"], int)

    def test_fixture(self):
        path = Path(__file__).with_name("fixture.json")
        fixture = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(parse_record(fixture["line"]), fixture["parsed"])

    def test_public_export(self):
        self.assertEqual(public.__all__, ["parse_record"])
        self.assertIs(public.parse_record, parse_record)
        self.assertEqual(public.parse_record("Ada:3"), {"name": "Ada", "count": 3})

    def test_cli_and_presentation_unchanged(self):
        for line, count, presentation in (
            ("Ada:3", "3", "Ada (3)"),
            ("Ada:0", "0", "Ada (0)"),
            ("Ada:-2", "-2", "Ada (-2)"),
            ("Ada:003", "3", "Ada (3)"),
            (":3", "3", " (3)"),
        ):
            with self.subTest(line=line):
                self.assertEqual(command(line), count)
                self.assertEqual(render(line), presentation)

    def test_invalid_records_still_raise_value_error(self):
        for line in ("Ada", "Ada:3:4", "Ada:abc", "Ada:"):
            for consumer in (parse_record, public.parse_record, command, render):
                with self.subTest(line=line, consumer=consumer.__name__):
                    with self.assertRaises(ValueError):
                        consumer(line)
