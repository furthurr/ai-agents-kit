def process_job(job, allowed, opener):
    if not allowed:
        raise PermissionError("denied")
    if not job:
        raise ValueError("empty job")
    resource = opener(job)
    read_succeeded = False
    try:
        result = resource.read()
        read_succeeded = True
        return result
    finally:
        try:
            resource.close()
        except BaseException:
            # A cleanup failure must not replace the original read error.
            if read_succeeded:
                raise
