import unittest
from unittest.mock import Mock

from jobs import process_job


class Resource:
    """Resource deliberately without the context manager protocol."""

    def __init__(self, result="done", read_error=None, close_error=None):
        self.result = result
        self.read_error = read_error
        self.close_error = close_error
        self.close_calls = 0

    def read(self):
        if self.read_error is not None:
            raise self.read_error
        return self.result

    def close(self):
        self.close_calls += 1
        if self.close_error is not None:
            raise self.close_error


class TestJobs(unittest.TestCase):
    def test_success(self):
        result = object()
        resource = Resource(result=result)
        opener = Mock(return_value=resource)
        self.assertIs(process_job("x", True, opener), result)
        opener.assert_called_once_with("x")
        self.assertEqual(resource.close_calls, 1)

    def test_permission_checked_before_job_and_opening(self):
        for job in ("x", ""):
            with self.subTest(job=job):
                opener = Mock()
                with self.assertRaisesRegex(PermissionError, "^denied$"):
                    process_job(job, False, opener)
                opener.assert_not_called()

    def test_empty_job_does_not_open(self):
        for job in ("", None, False, 0):
            with self.subTest(job=job):
                opener = Mock()
                with self.assertRaisesRegex(ValueError, "^empty job$"):
                    process_job(job, True, opener)
                opener.assert_not_called()

    def test_opener_error_propagates_unchanged(self):
        error = OSError("open failed")
        opener = Mock(side_effect=error)
        with self.assertRaises(OSError) as caught:
            process_job("x", True, opener)
        self.assertIs(caught.exception, error)
        opener.assert_called_once_with("x")

    def test_read_error_is_preserved_and_resource_closed_once(self):
        for error in (RuntimeError("read failed"), KeyboardInterrupt()):
            for close_error in (None, OSError("close failed"), SystemExit()):
                with self.subTest(error=error, close_error=close_error):
                    resource = Resource(read_error=error, close_error=close_error)
                    with self.assertRaises(type(error)) as caught:
                        process_job("x", True, lambda job: resource)
                    self.assertIs(caught.exception, error)
                    self.assertEqual(resource.close_calls, 1)

    def test_close_error_after_success_propagates_without_retry(self):
        for error in (OSError("close failed"), SystemExit()):
            with self.subTest(error=error):
                resource = Resource(close_error=error)
                with self.assertRaises(type(error)) as caught:
                    process_job("x", True, lambda job: resource)
                self.assertIs(caught.exception, error)
                self.assertEqual(resource.close_calls, 1)
