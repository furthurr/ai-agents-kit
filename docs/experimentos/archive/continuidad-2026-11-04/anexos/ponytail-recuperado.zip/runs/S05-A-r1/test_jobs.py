import unittest
from unittest.mock import Mock

from jobs import process_job


class Resource:
    """A resource that deliberately does not implement a context manager."""

    def __init__(self, result="done", read_error=None, close_error=None):
        self.result = result
        self.read_error = read_error
        self.close_error = close_error
        self.read_count = 0
        self.close_count = 0

    def read(self):
        self.read_count += 1
        if self.read_error is not None:
            raise self.read_error
        return self.result

    def close(self):
        self.close_count += 1
        if self.close_error is not None:
            raise self.close_error


class TestJobs(unittest.TestCase):
    def test_success(self):
        result = object()
        resource = Resource(result=result)
        opener = Mock(return_value=resource)

        self.assertIs(process_job("x", True, opener), result)

        opener.assert_called_once_with("x")
        self.assertEqual(resource.read_count, 1)
        self.assertEqual(resource.close_count, 1)

    def test_permission_checked_before_job_validation_and_opening(self):
        for job in ("x", "", None):
            with self.subTest(job=job):
                opener = Mock()
                with self.assertRaisesRegex(PermissionError, "^denied$"):
                    process_job(job, False, opener)
                opener.assert_not_called()

    def test_empty_job_rejected_before_opening(self):
        for job in ("", None, False, 0, []):
            with self.subTest(job=job):
                opener = Mock()
                with self.assertRaisesRegex(ValueError, "^empty job$"):
                    process_job(job, True, opener)
                opener.assert_not_called()

    def test_opener_error_propagates_unchanged(self):
        error = OSError("open failed")
        opener = Mock(side_effect=error)

        with self.assertRaises(OSError) as caught:
            process_job("x", True, opener)

        self.assertIs(caught.exception, error)
        opener.assert_called_once_with("x")

    def test_read_error_propagates_and_closes_once(self):
        for error in (RuntimeError("read failed"), KeyboardInterrupt()):
            with self.subTest(error=type(error).__name__):
                resource = Resource(read_error=error)
                with self.assertRaises(type(error)) as caught:
                    process_job("x", True, lambda job: resource)
                self.assertIs(caught.exception, error)
                self.assertEqual(resource.read_count, 1)
                self.assertEqual(resource.close_count, 1)

    def test_close_error_propagates_after_successful_read(self):
        error = OSError("close failed")
        resource = Resource(close_error=error)

        with self.assertRaises(OSError) as caught:
            process_job("x", True, lambda job: resource)

        self.assertIs(caught.exception, error)
        self.assertEqual(resource.read_count, 1)
        self.assertEqual(resource.close_count, 1)

    def test_close_error_does_not_replace_read_error(self):
        for close_error in (OSError("close failed"), KeyboardInterrupt()):
            with self.subTest(close_error=type(close_error).__name__):
                error = RuntimeError("original read error")
                resource = Resource(read_error=error, close_error=close_error)
                with self.assertRaises(RuntimeError) as caught:
                    process_job("x", True, lambda job: resource)
                self.assertIs(caught.exception, error)
                self.assertEqual(resource.read_count, 1)
                self.assertEqual(resource.close_count, 1)
