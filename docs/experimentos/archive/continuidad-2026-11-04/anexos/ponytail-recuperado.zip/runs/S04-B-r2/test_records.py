import json
from pathlib import Path
import unittest

from cli import command
from present import render
import public
from records import parse_record


class TestRecords(unittest.TestCase):
    def test_parse(self):
        record = parse_record("Ada:3")
        self.assertEqual(record, {"name": "Ada", "count": 3})
        self.assertIsInstance(record["name"], str)
        self.assertIsInstance(record["count"], int)

    def test_public_export(self):
        self.assertIn("parse_record", public.__all__)
        self.assertIs(public.parse_record, parse_record)
        self.assertEqual(public.parse_record("Ada:3"), {"name": "Ada", "count": 3})

    def test_fixture(self):
        path = Path(__file__).with_name("fixture.json")
        fixture = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(parse_record(fixture["line"]), fixture["parsed"])

    def test_outputs_preserved(self):
        cases = (
            ("Ada:3", "3", "Ada (3)"),
            ("Ada:0", "0", "Ada (0)"),
            ("Ada:-2", "-2", "Ada (-2)"),
            (" Ada :003", "3", " Ada  (3)"),
            (":1", "1", " (1)"),
        )
        for line, cli_output, presentation in cases:
            with self.subTest(line=line):
                self.assertEqual(command(line), cli_output)
                self.assertEqual(render(line), presentation)

    def test_invalid_records_preserve_errors(self):
        for line in ("Ada", "Ada:3:extra", "Ada:invalid", "Ada:"):
            for consumer in (parse_record, public.parse_record, command, render):
                with self.subTest(line=line, consumer=consumer.__name__):
                    with self.assertRaises(ValueError):
                        consumer(line)
