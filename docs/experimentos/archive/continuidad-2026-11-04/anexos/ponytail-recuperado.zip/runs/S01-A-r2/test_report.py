import unittest
from report import caption
class TestCaption(unittest.TestCase):
    def test_caption(self):
        self.assertEqual(caption([" Azul  CLARO ", " "]), "azul claro | (sin etiqueta)")

    def test_empty_collection(self):
        self.assertEqual(caption([]), "")

    def test_preserves_empty_entries(self):
        self.assertEqual(
            caption(["", "Azul", " \t\n", ""]),
            "(sin etiqueta) | azul | (sin etiqueta) | (sin etiqueta)",
        )

    def test_normalizes_whitespace_and_unicode_case(self):
        self.assertEqual(caption(["  Straße\t VERDE\n", "ÁZUL"]), "strasse verde | ázul")

    def test_accepts_iterator(self):
        self.assertEqual(caption(iter([" ROJO ", "Azul"])), "rojo | azul")
