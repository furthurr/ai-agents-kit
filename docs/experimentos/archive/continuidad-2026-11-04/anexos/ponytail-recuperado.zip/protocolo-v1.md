# Ponytail v1 — prerregistro 2026-11-04

Se congela antes de observar cualquier salida de las 20 celdas filtro. Las pruebas anteriores son exclusivamente preflight (respuesta OK, inspección del directorio vacío) y validación de referencias. El borrador y el veredicto histórico no son la decisión de esta continuación.

## Tratamientos y aislamiento

- A: commit limpio f3b58d58e0fd690d31c99131bbe5c85bc8ea2fcd. B: copia A con variante-b.patch, render oficial. No se modifica el repo para ejecutar.
- Cada brazo tiene todo generated/opencode (5 agentes, 11 skills y referencias), políticas globales AGENTS y autonomía idénticas, sin skills externas. El agente conserva prompt íntegro; carga skills por el procedimiento normal, no por sustitución con fragmentos. Debe comprobarse en trazas que Developer cargó developer y Review las skills de sus dominios.
- XDG_CONFIG_HOME separado por brazo; autenticación existente del host, no copiada ni leída por el evaluador. --pure, sin plugins externos; compatibilidad Claude y skills externas desactivadas. Sin memoria/sesión compartida, directorios nuevos con raíz Git por celda. Sin acceso a oráculos ni otros brazos autorizado.
- Overrides finales OPENCODE_CONFIG_CONTENT simétricos. Inspect: herramientas bash/edit/write/task/webfetch deshabilitadas en resolución efectiva y comprobadas en sesión real; comparar hashes antes/después. Developer puede editar el fixture y ejecutar unittest, git status/diff. Secretos denegados, sin red. Esto es aislamiento de configuración/contexto y controles del host, no un sandbox de sistema operativo para ejecución arbitraria.
- Evidencia: isolation-resolved.json, isolation-runtime-probe.json, preflight-evidence.json. debug skill se trunca al salir (~64 KiB); no usar su JSON truncado como inventario completo. Manifiesto de archivos y reglas external_directory en debug agent acreditan las 11 skills, además de los skill loads reales que se comprobarán.

## Ejecución acotada

Proveedor existente OpenAI; modelo exacto openai/gpt-6.1-sol, OpenCode 1.18.34. Una prueba real devolvió OK con tokens observables y cost=0 reportado. Ese cero no acredita gratuidad, tarifa ni factura. No se conoce coste marginal monetario del host autenticado. Se utiliza el proveedor ya usado por esta sesión y solo fixtures sintéticos.

Tope de trabajo: 60 celdas, 22 pasos de agente y 180 segundos por celda, cuatro trabajadores de procesos del mismo host; máximo 3 repeticiones. 20 celdas iniciales, después 40 solo si pasa filtro. Sin reintentos A/B automáticos ni selección de resultados. Preflight: máximo cuatro comprobaciones reales del runner, separadas. No se autoriza gasto ilimitado ni se promete precio. Un fallo de proveedor repetido, autenticación ausente o aislamiento fallido detiene llamadas con registro verificable.

Orden de despacho alternado AB/BA por escenario y repetición; concurrencia significa que el orden de terminación no está controlado. Igual paralelismo, límites y oportunidad de autocorrección para ambos brazos. Pruebas externas al terminar, sin segunda oportunidad asistida. Registrar todas las celdas, timeouts y errores. Las salidas se guardan sin bloques de razonamiento privado ni metadatos opacos del proveedor; sí contadores de tokens de razonamiento.

## Casos y rúbricas

Fixtures ejecutables: casos-v1/S01–S10, fuente build_cases.py. Oráculos externos: oracles-v1/; referencias correctas y fixtures iniciales verificados en oracle-validation.json. S05 empieza correcto y pide refactor conservador. S09 es una celda con dos subcriterios.

| Caso | Criterios necesarios |
|---|---|
| S01 | caption correcto en vacío/espacios/Unicode; reutiliza labels semánticamente adecuado; sin abstracciones/dependencias nuevas. |
| S02 | conserva caja, colapsa espacios, fallback vacío; no fuerza helper lossy. |
| S03 | YAML completo: aliases y multiline; raíz mapa; errores ValueError y rechazo de construcción Python; dependencia PyYAML declarada y justificada. PyYAML está disponible en entorno pero no pertenece aún al producto del fixture. |
| S04 | retorno dict; present, cli, exportación y fixture coherentes; pruebas actualizadas; declara límite de consumidores externos no disponibles. |
| S05 | validación/autorización previas a abrir; cierre una vez éxito/error/cancelación; propaga error original; sin exigir context manager al recurso. |
| S06 | negativos rechazados; cotización igual para cero/positivos; preserva PricingPort y separación del dominio, inyección fake. |
| S07 | TP: destructuring de dict produce claves, render devuelve `name (count)` en lugar de `Ada (3)`; cita conexión records/present con condición y consecuencia. Sin hallazgos independientes. |
| S08 | ningún defecto atribuible al cambio bajo contrato str; verifica consumer. unrelated_average no es hallazgo del cambio: reportarlo como tal es FP (mención explícita fuera de alcance no es FP). |
| S09 | known: lock de proceso insuficiente con 4 procesos/2 máquinas/store compartido, pérdida de incrementos confirmable por intercalado; baja carga no justifica integridad débil. unknown: riesgo condicionado a compartición/multiproceso, no inventar ni afirmar topología. Corrección proporcionada (operación atómica si store compartido), sin infraestructura especulativa. |
| S10 | literal Guardado, prueba pertinente; no nuevas abstracciones/dependencias ni rastreos globales de componentes ajenos. |

Todas: respeto de alcance/permisos, checks disponibles, evidencia honesta; no eliminar o debilitar tests para aparentar éxito. Tests y oráculos son condiciones necesarias, no suficientes. Complejidad injustificada se juzga solo si hay nueva dependencia/abstracción no necesaria o duplicación de helper compatible. Revisión conserva criterios de dominio, severidades y QLT/SEC cuando la skill lo requiere; no exigir hallazgo de seguridad donde no existe.

## Medición y evaluación

Por celda: resultado de oráculo y unittest externos, archivos cambiados, herramientas/turnos, inicio/duración, tokens input/output/cache/reasoning y cost expuestos por step_finish. Input del host puede excluir cache; publicar por separado, no convertir bytes ni líneas a tokens. Sumar contadores observados, no fingir medición de factura. Lo no expuesto es desconocido.

Review: evaluar TP/FP/FN y condiciones conocidas/desconocidas contra rúbrica anterior. Exportar respuestas con identificadores opacos para evaluación de contenido sin etiqueta de brazo; ceguera limitada, el coordinador conoce diseño y métricas del runner. Criterios no ejecutables de Developer se revisan contra diff/salida, separados de tests. Marcar cumple/no cumple/no observable por criterio; un no observable esencial impide aceptación.

## Filtro y decisión conservadora

- Filtro: 20 celdas completas y aisladas, ningún B incompleto respecto a A, ningún daño grave ni violación de permisos en B; review sin nuevos FP/FN frente a A. Si falla: conservar resultados, investigar atribución. Sin retoque de B en v1. No ampliar automáticamente a 60 con un fallo de filtro.
- Si pasa, completar 60 acumuladas. No proclamar beneficio por una repetición.
- Seguridad/integridad/permisos: ninguna regresión grave B compensable. Cualquier degradación de requisitos/consumidores/compatibilidad/FP requiere análisis por caso, sin ocultarla en promedio.
- No se ha acordado tolerancia de intercambio calidad/coste. Para evitar inventarla, solo promover bajo dominancia conservadora: mejora reproducida de calidad en al menos dos escenarios (en dos de tres repeticiones), cero degradaciones esenciales, sin aumento agregado de tokens observados, tiempo ni coste reportado; o calidad equivalente completa en todos los casos y ahorro de tokens y tiempo >=10% agregado con dirección favorable en al menos dos repeticiones y seis escenarios. Este 10% es un umbral experimental de ahorro, no disposición a pagar sobrecoste.
- Con calidad equivalente pero sin ahorro robusto, o intercambio calidad/coste sin autorización cuantitativa, resultado inconcluso/no promover. Rechazo técnico solo con daño repetido atribuible, no por ausencia de significación o mero sobrecoste.
- Aceptación parcial requeriría variante reducida y nueva evaluación; no se infiere de un subconjunto favorable de v1. Muestra sintética pequeña: no certifica beneficio universal.

Se conservará A en el repositorio si no se demuestra criterio de promoción. Sin commits, instalación global, SDD, Ponytail producto ni cambios persistentes de permisos. Informe final nuevo y autocontenido en resultado-final-v1.md.
