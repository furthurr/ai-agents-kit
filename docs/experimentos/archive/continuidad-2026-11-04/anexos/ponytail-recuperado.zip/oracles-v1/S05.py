from jobs import process_job
class Resource:
    def __init__(self, error=None): self.error=error; self.closed=0
    def read(self):
        if self.error: raise self.error
        return 'done'
    def close(self): self.closed+=1
for error in [None, RuntimeError('boom'), KeyboardInterrupt('cancel')]:
    resource=Resource(error)
    try: value=process_job('x',True,lambda _:resource)
    except BaseException as exc: assert exc is error
    else: assert value=='done' and error is None
    assert resource.closed==1
for job,allowed,exc_type in [('x',False,PermissionError),('',True,ValueError)]:
    def unopened(_): raise AssertionError('opened before validation')
    try: process_job(job,allowed,unopened)
    except exc_type: pass
    else: raise AssertionError('missing validation')
