from message import success_message
assert success_message()=='Guardado'
