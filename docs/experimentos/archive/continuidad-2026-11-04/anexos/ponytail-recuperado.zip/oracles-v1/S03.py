from config_loader import load_config
from pathlib import Path
cfg=load_config('base: &x\n  retries: 2\ncopy: *x\nmessage: |\n  first\n  second\n')
assert cfg['copy']=={'retries':2} and cfg['message']=='first\nsecond\n'
for text in ['- a\n- b','!!python/object/apply:builtins.str [1]', 'x: [']:
    try: load_config(text)
    except ValueError: pass
    else: raise AssertionError('unsafe or invalid config accepted')
assert 'pyyaml' in Path('requirements.txt').read_text().casefold()
