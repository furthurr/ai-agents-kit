from display import display_name
assert display_name(' Ada\tLOVELACE ')=='Ada LOVELACE'
assert display_name(' \n ' )=='Anónimo'
assert display_name('Árbol')=='Árbol'
