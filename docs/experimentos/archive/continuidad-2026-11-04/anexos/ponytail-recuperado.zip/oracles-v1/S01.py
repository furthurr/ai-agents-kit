import ast, pathlib
from report import caption
assert caption([])==''
assert caption([' A	 B ', '', 'ÁRBOL'])=='a b | (sin etiqueta) | árbol'
tree=ast.parse(pathlib.Path('report.py').read_text())
assert any(isinstance(n,(ast.Import,ast.ImportFrom)) and ('labels' in ast.unparse(n)) for n in ast.walk(tree)), 'missing reuse'
