import json
from pathlib import Path
from records import parse_record
from present import render
from cli import command
from public import parse_record as exported
assert parse_record('Ada:3')=={'name':'Ada','count':3}
assert exported('Lin:2')=={'name':'Lin','count':2}
assert render('Ada:3')=='Ada (3)' and command('Lin:2')=='2'
fixture=json.loads(Path('fixture.json').read_text())
assert fixture['parsed']==parse_record(fixture['line'])
