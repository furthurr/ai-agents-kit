import ast, pathlib
from ports import PricingPort
from disk_prices import DiskPrices
from domain import quote
assert issubclass(DiskPrices,PricingPort)
assert quote(DiskPrices(),0)==0 and quote(DiskPrices(),3)==30
try: quote(DiskPrices(),-1)
except ValueError: pass
else: raise AssertionError('negative accepted')
assert not any(isinstance(n,(ast.Import,ast.ImportFrom)) and any(s in ast.unparse(n) for s in ['disk_prices','pathlib']) for n in ast.walk(ast.parse(pathlib.Path('domain.py').read_text())))
class Fake(PricingPort):
    def price(self, quantity): return 123
assert quote(Fake(),1)==123
