import unittest
class Test(unittest.TestCase):
    def test_ok(self): self.assertEqual(2+2, 4)
