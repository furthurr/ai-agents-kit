import json
from django.test import TestCase, Client
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.apps import apps
from django.urls import reverse

User = get_user_model()

class Task3Stage1OracleTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        try:
            Branch = apps.get_model('catalog', 'Branch')
            BranchMembership = apps.get_model('catalog', 'BranchMembership')
        except LookupError:
            return

        Author = apps.get_model('catalog', 'Author')
        Book = apps.get_model('catalog', 'Book')
        BookInstance = apps.get_model('catalog', 'BookInstance')

        cls.branch_central, _ = Branch.objects.get_or_create(code='CENTRAL', defaults={'name': 'Central Library', 'address': 'Main St'})
        cls.branch_north = Branch.objects.create(code='NORTH', name='North Branch', address='North Ave')
        cls.branch_south = Branch.objects.create(code='SOUTH', name='South Branch', address='South Rd')

        cls.user_legacy = User.objects.create_user(username='legacy_user', password='password123')
        cls.user_north = User.objects.create_user(username='north_user', password='password123')
        cls.superuser = User.objects.create_superuser(username='admin_user', password='password123', email='admin@test.com')

        cls.staff_north = User.objects.create_user(username='staff_north', password='password123')
        cls.staff_south = User.objects.create_user(username='staff_south', password='password123')
        perm = Permission.objects.get(codename='can_mark_returned')
        cls.staff_north.user_permissions.add(perm)
        cls.staff_south.user_permissions.add(perm)

        BranchMembership.objects.create(user=cls.user_north, branch=cls.branch_north, is_staff=False)
        BranchMembership.objects.create(user=cls.staff_north, branch=cls.branch_north, is_staff=True)
        BranchMembership.objects.create(user=cls.staff_south, branch=cls.branch_south, is_staff=True)

        cls.author = Author.objects.create(first_name='Gabriel', last_name='Garcia Marquez')
        cls.book = Book.objects.create(title='One Hundred Years of Solitude', author=cls.author, isbn='7777777777771')

        cls.inst_central = BookInstance.objects.create(book=cls.book, imprint='Ed Central', status='a', branch=cls.branch_central)
        cls.inst_north = BookInstance.objects.create(book=cls.book, imprint='Ed North', status='o', borrower=cls.user_north, branch=cls.branch_north)
        cls.inst_south = BookInstance.objects.create(book=cls.book, imprint='Ed South', status='o', borrower=cls.user_legacy, branch=cls.branch_south)

    def setUp(self):
        self.client = Client()

    def _check_models(self):
        try:
            apps.get_model('catalog', 'Branch')
            apps.get_model('catalog', 'BranchMembership')
        except LookupError:
            self.fail('Branch or BranchMembership model not found in catalog.models')

    def test_catalog_is_global_and_public(self):
        self._check_models()
        res = self.client.get('/catalog/books/')
        self.assertEqual(res.status_code, 200)
        self.assertIn(self.book.title, res.content.decode('utf-8'))

    def test_branch_selection_legacy_and_explicit_memberships(self):
        self._check_models()
        # Legacy user without memberships: defaults to CENTRAL
        self.client.force_login(self.user_legacy)
        res_sel_central = self.client.post('/catalog/branches/select/', json.dumps({'branch_code': 'CENTRAL'}), content_type='application/json')
        self.assertEqual(res_sel_central.status_code, 200)
        self.assertEqual(res_sel_central.json(), {'active_branch': 'CENTRAL'})

        # Trying unauthorized branch NORTH should return 403 and NOT mutate session
        res_unauth = self.client.post('/catalog/branches/select/', json.dumps({'branch_code': 'NORTH'}), content_type='application/json')
        self.assertEqual(res_unauth.status_code, 403)
        self.assertEqual(self.client.session.get('active_branch_code', 'CENTRAL'), 'CENTRAL')

        # User North has membership NORTH but NOT Central
        self.client.force_login(self.user_north)
        res_sel_north = self.client.post('/catalog/branches/select/', json.dumps({'branch_code': 'NORTH'}), content_type='application/json')
        self.assertEqual(res_sel_north.status_code, 200)

        # Trying CENTRAL without membership gives 403
        res_sel_cent = self.client.post('/catalog/branches/select/', json.dumps({'branch_code': 'CENTRAL'}), content_type='application/json')
        self.assertEqual(res_sel_cent.status_code, 403)

        # Superuser can select any branch
        self.client.force_login(self.superuser)
        res_su = self.client.post('/catalog/branches/select/', json.dumps({'branch_code': 'SOUTH'}), content_type='application/json')
        self.assertEqual(res_su.status_code, 200)
        self.assertEqual(res_su.json(), {'active_branch': 'SOUTH'})

    def test_inventory_api_endpoint(self):
        self._check_models()
        # Anonymous -> 401
        res_anon = self.client.get('/catalog/api/inventory/')
        self.assertEqual(res_anon.status_code, 401)

        # User North -> only North copies
        self.client.force_login(self.user_north)
        self.client.post('/catalog/branches/select/', json.dumps({'branch_code': 'NORTH'}), content_type='application/json')
        res_north = self.client.get('/catalog/api/inventory/')
        self.assertEqual(res_north.status_code, 200)
        data = res_north.json()
        self.assertEqual(data['branch'], 'NORTH')
        self.assertEqual(len(data['instances']), 1)
        self.assertEqual(data['instances'][0]['id'], str(self.inst_north.id))
        self.assertEqual(data['instances'][0]['book_title'], self.book.title)
        self.assertEqual(data['instances'][0]['status'], 'o')

    def test_cross_branch_isolation_renew_and_borrowed_lists(self):
        """Checks direct cross-branch renewal and loans listing negative tests."""
        self._check_models()
        # staff_north has can_mark_returned and membership.is_staff in NORTH, but NOT in SOUTH
        self.client.force_login(self.staff_north)

        # Attempt to access or renew South copy directly -> Forbidden 403
        renew_url_south = reverse('renew-book-librarian', args=[str(self.inst_south.id)])
        res_renew = self.client.get(renew_url_south)
        self.assertEqual(res_renew.status_code, 403, 'Cross-branch librarian renewal must be 403 Forbidden')

        res_renew_post = self.client.post(renew_url_south, {'renewal_date': '2026-12-01'})
        self.assertEqual(res_renew_post.status_code, 403, 'Cross-branch renewal POST must be 403 Forbidden')

        # Permitted renewal on North copy
        renew_url_north = reverse('renew-book-librarian', args=[str(self.inst_north.id)])
        res_renew_ok = self.client.get(renew_url_north)
        self.assertEqual(res_renew_ok.status_code, 200)

        # In borrowed all list: staff_north should see only North branch loans or forbidden from South
        res_borrowed = self.client.get(reverse('all-borrowed'))
        self.assertEqual(res_borrowed.status_code, 200)
        content = res_borrowed.content.decode('utf-8')
        self.assertIn(str(self.inst_north.id), content)
        self.assertNotIn(str(self.inst_south.id), content, 'Cross-branch loan leakage in all-borrowed list')
