import os, sys
from locallibrary.settings import *

test_db_file = os.getenv('EVAL_TEST_DB_FILE')
if test_db_file:
    DATABASES['default']['TEST'] = {
        'NAME': test_db_file,
    }
