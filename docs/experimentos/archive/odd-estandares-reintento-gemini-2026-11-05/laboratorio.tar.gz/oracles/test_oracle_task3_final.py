import json
import uuid
from django.test import TestCase, Client
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.apps import apps

User = get_user_model()

class Task3FinalOracleTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        try:
            Branch = apps.get_model('catalog', 'Branch')
            BranchMembership = apps.get_model('catalog', 'BranchMembership')
        except LookupError:
            return

        Author = apps.get_model('catalog', 'Author')
        Book = apps.get_model('catalog', 'Book')
        BookInstance = apps.get_model('catalog', 'BookInstance')

        cls.branch_central, _ = Branch.objects.get_or_create(code='CENTRAL', defaults={'name': 'Central Library', 'address': 'Main St'})
        cls.branch_north = Branch.objects.create(code='NORTH', name='North Branch', address='North Ave')
        cls.branch_south = Branch.objects.create(code='SOUTH', name='South Branch', address='South Rd')

        perm = Permission.objects.get(codename='can_mark_returned')

        # Staff with permissions in NORTH and SOUTH
        cls.staff_dual = User.objects.create_user(username='staff_dual', password='password123')
        cls.staff_dual.user_permissions.add(perm)
        BranchMembership.objects.create(user=cls.staff_dual, branch=cls.branch_north, is_staff=True)
        BranchMembership.objects.create(user=cls.staff_dual, branch=cls.branch_south, is_staff=True)

        # Staff with permission only in NORTH
        cls.staff_north_only = User.objects.create_user(username='staff_north_only', password='password123')
        cls.staff_north_only.user_permissions.add(perm)
        BranchMembership.objects.create(user=cls.staff_north_only, branch=cls.branch_north, is_staff=True)

        # Regular user
        cls.user_reg = User.objects.create_user(username='regular_user', password='password123')

        cls.author = Author.objects.create(first_name='Jorge Luis', last_name='Borges')
        cls.book = Book.objects.create(title='Ficciones', author=cls.author, isbn='7777777777772')

        cls.inst_avail = BookInstance.objects.create(
            book=cls.book,
            imprint='Sur 1944',
            status='a',
            branch=cls.branch_north,
            origin_branch=cls.branch_north
        )
        cls.inst_loaned = BookInstance.objects.create(
            book=cls.book,
            imprint='Sur 1944',
            status='o',
            borrower=cls.user_reg,
            branch=cls.branch_north,
            origin_branch=cls.branch_north
        )

    def setUp(self):
        self.client = Client()

    def _check_models(self):
        try:
            apps.get_model('catalog', 'Branch')
            apps.get_model('catalog', 'BranchMembership')
        except LookupError:
            self.fail('Branch or BranchMembership model not found in catalog.models')

    def test_transfer_requires_permissions_in_origin_and_destination(self):
        self._check_models()
        # Staff North Only trying to transfer to South -> 403 (lacks perm in South)
        self.client.force_login(self.staff_north_only)
        payload = {'instance_id': str(self.inst_avail.id), 'target_branch_code': 'SOUTH'}
        res = self.client.post('/catalog/api/branch-transfer/', json.dumps(payload), content_type='application/json')
        self.assertEqual(res.status_code, 403)
        self.assertEqual(res.json(), {'error': 'permission_denied'})

        # Verify no mutation
        self.inst_avail.refresh_from_db()
        self.assertEqual(self.inst_avail.branch.code, 'NORTH')

    def test_transfer_unavailable_copy_rejected(self):
        self._check_models()
        # Trying to transfer loaned copy -> 409 not_available
        self.client.force_login(self.staff_dual)
        payload = {'instance_id': str(self.inst_loaned.id), 'target_branch_code': 'SOUTH'}
        res = self.client.post('/catalog/api/branch-transfer/', json.dumps(payload), content_type='application/json')
        self.assertEqual(res.status_code, 409)
        self.assertEqual(res.json(), {'error': 'not_available'})

        # Verify no mutation
        self.inst_loaned.refresh_from_db()
        self.assertEqual(self.inst_loaned.branch.code, 'NORTH')

    def test_transfer_successful_immediate_custody_change(self):
        self._check_models()
        self.client.force_login(self.staff_dual)
        payload = {'instance_id': str(self.inst_avail.id), 'target_branch_code': 'SOUTH'}
        res = self.client.post('/catalog/api/branch-transfer/', json.dumps(payload), content_type='application/json')
        self.assertEqual(res.status_code, 201)
        expected = {
            'instance_id': str(self.inst_avail.id),
            'origin_branch': 'NORTH',
            'current_branch': 'SOUTH',
            'status': 'a'
        }
        self.assertEqual(res.json(), expected)

        # Check DB state: origin_branch remains NORTH, branch is now SOUTH
        self.inst_avail.refresh_from_db()
        self.assertEqual(self.inst_avail.origin_branch.code, 'NORTH')
        self.assertEqual(self.inst_avail.branch.code, 'SOUTH')
        self.assertEqual(self.inst_avail.status, 'a')

    def test_transfer_validation_errors(self):
        self._check_models()
        self.client.force_login(self.staff_dual)
        # Not found instance
        res1 = self.client.post('/catalog/api/branch-transfer/', json.dumps({'instance_id': str(uuid.uuid4()), 'target_branch_code': 'SOUTH'}), content_type='application/json')
        self.assertEqual(res1.status_code, 404)

        # Not found branch
        res2 = self.client.post('/catalog/api/branch-transfer/', json.dumps({'instance_id': str(self.inst_avail.id), 'target_branch_code': 'INVALID'}), content_type='application/json')
        self.assertEqual(res2.status_code, 404)

        # Missing fields
        res3 = self.client.post('/catalog/api/branch-transfer/', json.dumps({'target_branch_code': 'SOUTH'}), content_type='application/json')
        self.assertEqual(res3.status_code, 400)
