import os
import unittest
from django.test import TransactionTestCase
from django.db import connection
from django.db.migrations.executor import MigrationExecutor
from django.apps import apps


def _has_stage1_models(apps_registry):
    try:
        apps_registry.get_model('catalog', 'Branch')
        apps_registry.get_model('catalog', 'BranchMembership')
        BookInstance = apps_registry.get_model('catalog', 'BookInstance')
        return any(f.name == 'branch' for f in BookInstance._meta.fields)
    except LookupError:
        return False


def _get_catalog_migration_plan(graph, leaf_nodes):
    plan = []
    for leaf in leaf_nodes:
        for m in graph.forwards_plan(leaf):
            if m[0] == 'catalog' and m not in plan:
                plan.append(m)
    return plan


class Task3MigrationFreshTest(TransactionTestCase):
    """Tests backward-compatible migration from baseline state to current leaf migration.
    Re-creates real data under baseline migration 0029, migrates forward to leaf nodes,
    and asserts data preservation and Central assignment.
    """

    def test_migration_preserves_legacy_instances_and_assigns_central(self):
        executor = MigrationExecutor(connection)
        current_targets = executor.loader.graph.leaf_nodes('catalog')
        self.assertTrue(current_targets, 'No migrations found for catalog')

        # Baseline target 0029
        baseline_target = [('catalog', '0029_alter_genre_options_alter_language_options')]

        try:
            # Migrate backwards to baseline 0029
            executor.migrate(baseline_target)
            old_apps = executor.loader.project_state(baseline_target).apps

            Author_old = old_apps.get_model('catalog', 'Author')
            Book_old = old_apps.get_model('catalog', 'Book')
            BookInstance_old = old_apps.get_model('catalog', 'BookInstance')
            User_old = old_apps.get_model('auth', 'User')

            user = User_old.objects.create_user(username='mig_user', password='password123')
            author = Author_old.objects.create(first_name='Mig', last_name='Author')
            book = Book_old.objects.create(title='Legacy Book', author=author, isbn='9999999999999')

            inst = BookInstance_old.objects.create(
                book=book,
                imprint='Legacy Imprint 1900',
                status='o',
                borrower=user
            )
            legacy_id = inst.id

            # Migrate forward to current leaf migrations
            new_executor = MigrationExecutor(connection)
            new_executor.loader.build_graph()
            new_executor.migrate(current_targets)

            # Assert models and data in migrated state
            try:
                Branch = apps.get_model('catalog', 'Branch')
                BookInstance = apps.get_model('catalog', 'BookInstance')
            except LookupError:
                self.fail('Branch or BookInstance model not found after leaf migration')

            central = Branch.objects.filter(code='CENTRAL').first()
            self.assertIsNotNone(central, 'CENTRAL branch was not created by migration')
            self.assertEqual(central.name, 'Central Library')

            migrated_inst = BookInstance.objects.get(id=legacy_id)
            self.assertEqual(migrated_inst.imprint, 'Legacy Imprint 1900')
            self.assertEqual(migrated_inst.status, 'o')
            self.assertEqual(migrated_inst.borrower.username, 'mig_user')
            self.assertEqual(migrated_inst.branch, central, 'Legacy instance branch not set to CENTRAL')
            if hasattr(migrated_inst, 'origin_branch') and migrated_inst.origin_branch:
                self.assertEqual(migrated_inst.origin_branch, central)

        finally:
            # Ensure database is restored to current leaves cleanly
            final_executor = MigrationExecutor(connection)
            final_executor.loader.build_graph()
            final_executor.migrate(current_targets)

    def test_upgrade_stage1_to_final_preserves_seeded_instances(self):
        """Tests that data created in stage1 survives migration forward to final leaves."""
        executor = MigrationExecutor(connection)
        current_targets = executor.loader.graph.leaf_nodes('catalog')
        self.assertTrue(current_targets, 'No migrations found for catalog')

        plan = _get_catalog_migration_plan(executor.loader.graph, current_targets)

        # Discover migrations where Branch, BranchMembership and BookInstance.branch exist
        stage1_indices = []
        for idx, m in enumerate(plan):
            state = executor.loader.project_state(m)
            if _has_stage1_models(state.apps):
                stage1_indices.append(idx)

        if not stage1_indices:
            raise unittest.SkipTest('No stage1 migration state found containing Branch, BranchMembership, and BookInstance.branch')

        # Find the first migration index in plan that introduces changes beyond stage1
        # (e.g. introduces new models or fields beyond stage1 state)
        first_stage1_idx = stage1_indices[0]
        base_stage1_models = set(executor.loader.project_state(plan[first_stage1_idx]).apps.all_models.get('catalog', {}).keys())

        subsequent_change_idx = None
        for idx in range(first_stage1_idx + 1, len(plan)):
            st = executor.loader.project_state(plan[idx])
            current_models = set(st.apps.all_models.get('catalog', {}).keys())
            if current_models != base_stage1_models:
                subsequent_change_idx = idx
                break

        if subsequent_change_idx is None:
            raise unittest.SkipTest('No subsequent migration phase beyond stage1 detected; skipping upgrade verification')

        # Target stage1 migration immediately before first subsequent change
        stage1_target_node = plan[subsequent_change_idx - 1]
        stage1_target = [stage1_target_node]

        try:
            executor.migrate(stage1_target)
            stage1_apps = executor.loader.project_state(stage1_target).apps

            Author_s1 = stage1_apps.get_model('catalog', 'Author')
            Book_s1 = stage1_apps.get_model('catalog', 'Book')
            Branch_s1 = stage1_apps.get_model('catalog', 'Branch')
            BranchMembership_s1 = stage1_apps.get_model('catalog', 'BranchMembership')
            BookInstance_s1 = stage1_apps.get_model('catalog', 'BookInstance')
            User_s1 = stage1_apps.get_model('auth', 'User')

            north = Branch_s1.objects.create(code='NORTH_STAGE1', name='North Branch Stage1')
            user_s1 = User_s1.objects.create_user(username='staff_s1', password='pass')
            membership = BranchMembership_s1.objects.create(user=user_s1, branch=north, is_staff=True)
            membership_id = membership.id

            author_s1 = Author_s1.objects.create(first_name='Stage1', last_name='Author')
            book_s1 = Book_s1.objects.create(title='Stage1 Book', author=author_s1, isbn='8888888888888')

            # Create BookInstance ensuring origin_branch defaults or explicitly matches branch
            kwargs = {
                'book': book_s1,
                'imprint': 'Stage1 Seed Imprint',
                'status': 'a',
                'branch': north,
            }
            if any(f.name == 'origin_branch' for f in BookInstance_s1._meta.fields):
                kwargs['origin_branch'] = north

            inst = BookInstance_s1.objects.create(**kwargs)
            s1_id = inst.id

            # Migrate forward to final leaves
            new_executor = MigrationExecutor(connection)
            new_executor.loader.build_graph()
            new_executor.migrate(current_targets)

            BookInstance_final = apps.get_model('catalog', 'BookInstance')
            BranchMembership_final = apps.get_model('catalog', 'BranchMembership')

            survived = BookInstance_final.objects.get(id=s1_id)
            self.assertEqual(survived.imprint, 'Stage1 Seed Imprint')
            self.assertEqual(survived.branch.code, 'NORTH_STAGE1')
            self.assertEqual(survived.status, 'a')
            if hasattr(survived, 'origin_branch') and survived.origin_branch:
                self.assertEqual(survived.origin_branch.code, 'NORTH_STAGE1')

            survived_membership = BranchMembership_final.objects.get(id=membership_id)
            self.assertEqual(survived_membership.user.username, 'staff_s1')
            self.assertEqual(survived_membership.branch.code, 'NORTH_STAGE1')
            self.assertTrue(survived_membership.is_staff)

        finally:
            final_executor = MigrationExecutor(connection)
            final_executor.loader.build_graph()
            final_executor.migrate(current_targets)
