import json
import re
from urllib.parse import urlparse, parse_qs
from django.test import TestCase, Client
from django.apps import apps

class Task1OracleTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        Author = apps.get_model('catalog', 'Author')
        Book = apps.get_model('catalog', 'Book')
        Genre = apps.get_model('catalog', 'Genre')
        Language = apps.get_model('catalog', 'Language')
        BookInstance = apps.get_model('catalog', 'BookInstance')

        cls.author1 = Author.objects.create(first_name='Arthur', last_name='Conan Doyle')
        cls.author2 = Author.objects.create(first_name='Agatha', last_name='Christie')
        cls.genre_mys = Genre.objects.create(name='Mystery')
        cls.genre_sci = Genre.objects.create(name='Sci-Fi')
        cls.genre_adv = Genre.objects.create(name='Adventure')
        cls.lang_en = Language.objects.create(name='English')
        cls.lang_fr = Language.objects.create(name='French')

        # Book with null author
        cls.b_null_author = Book.objects.create(
            title='Anonymous Chronicles',
            author=None,
            summary='An ancient text with no credited author.',
            isbn='0000000000001',
            language=cls.lang_en
        )
        cls.b_null_author.genre.add(cls.genre_mys)

        # Book 1: Mystery & Adventure, English, Multiple copies with same and different status
        cls.b1 = Book.objects.create(
            title='A Study in Scarlet',
            author=cls.author1,
            summary='  A detective story featuring Sherlock Holmes.  ',
            isbn='1111111111111',
            language=cls.lang_en
        )
        cls.b1.genre.add(cls.genre_mys, cls.genre_adv)
        cls.b1_inst1 = BookInstance.objects.create(
            book=cls.b1,
            imprint='London 1887 (Copy 1)',
            status='a'
        )
        cls.b1_inst2 = BookInstance.objects.create(
            book=cls.b1,
            imprint='London 1887 (Copy 2)',
            status='a'
        )

        # Book 2: Mystery, French, Maintenance copy
        cls.b2 = Book.objects.create(
            title='The Hound of the Baskervilles',
            author=cls.author1,
            summary='Spectral hound terrorizing Dartmoor.',
            isbn='2222222222222',
            language=cls.lang_fr
        )
        cls.b2.genre.add(cls.genre_mys)
        cls.b2_inst = BookInstance.objects.create(
            book=cls.b2,
            imprint='Paris 1902',
            status='m'
        )

        # Book 3: Sci-Fi, English, Reserved copy
        cls.b3 = Book.objects.create(
            title='Murder on the Orient Express',
            author=cls.author2,
            summary='Hercule Poirot solves a snowbound train mystery.',
            isbn='3333333333333',
            language=cls.lang_en
        )
        cls.b3.genre.add(cls.genre_sci)
        cls.b3_inst = BookInstance.objects.create(
            book=cls.b3,
            imprint='Harper 1934',
            status='r'
        )

        # Book with identical title to test tie-breaking on (title, id)
        cls.b_tie = Book.objects.create(
            title='A Study in Scarlet',
            author=cls.author2,
            summary='A theatrical adaptation script.',
            isbn='1111111111112',
            language=cls.lang_en
        )
        cls.b_tie.genre.add(cls.genre_adv)

        # Create additional filler books for pagination test (11 filler books, total 15 books)
        for i in range(1, 13):
            b = Book.objects.create(
                title=f'Filler Book {i:02d}',
                author=cls.author2,
                summary=f'Summary description {i}',
                isbn=f'99999999999{i:02d}',
                language=cls.lang_en
            )
            b.genre.add(cls.genre_mys)

    def setUp(self):
        self.client = Client()

    def test_api_public_get_and_structure(self):
        res = self.client.get('/catalog/api/books/')
        self.assertEqual(res.status_code, 200)
        self.assertIn('application/json', res.headers.get('Content-Type', ''))
        data = res.json()
        self.assertIn('count', data)
        self.assertIn('page', data)
        self.assertIn('num_pages', data)
        self.assertIn('results', data)
        self.assertEqual(data['count'], 17)
        self.assertEqual(data['page'], 1)
        self.assertEqual(data['num_pages'], 2)
        self.assertEqual(len(data['results']), 10)

        # Verify results order ties: (title, id)
        titles_and_ids = [(r['title'], r['id']) for r in data['results']]
        self.assertEqual(titles_and_ids, sorted(titles_and_ids, key=lambda x: (x[0], x[1])))

        # Check exact schema of item
        for item in data['results']:
            self.assertIn('id', item)
            self.assertIn('title', item)
            self.assertIn('author', item)
            self.assertIn('isbn', item)
            self.assertIn('genre', item)
            self.assertIsInstance(item['genre'], list)
            # Check genres are alphabetically sorted
            self.assertEqual(item['genre'], sorted(item['genre']))

        # Check null author serialization
        null_author_item = next((r for r in data['results'] if r['id'] == self.b_null_author.id), None)
        self.assertIsNotNone(null_author_item)
        self.assertIsNone(null_author_item['author'])

    def test_api_filter_q(self):
        # Case insensitive substring on title or summary with trim
        res = self.client.get('/catalog/api/books/?q=  sherlock  ')
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data['count'], 1)
        self.assertEqual(data['results'][0]['title'], 'A Study in Scarlet')

        # Filter q on title
        res2 = self.client.get('/catalog/api/books/?q=Orient')
        self.assertEqual(res2.status_code, 200)
        data2 = res2.json()
        self.assertEqual(data2['count'], 1)
        self.assertEqual(data2['results'][0]['title'], 'Murder on the Orient Express')

        # Filter q whitespace-only should be ignored (all 15 books)
        res_blank = self.client.get('/catalog/api/books/?q=   ')
        self.assertEqual(res_blank.status_code, 200)
        self.assertEqual(res_blank.json()['count'], 17)

    def test_api_filter_genre_and_language(self):
        # Filter by genre id
        res = self.client.get(f'/catalog/api/books/?genre={self.genre_adv.id}')
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data['count'], 2)
        # Check order and distinctness
        ids = [r['id'] for r in data['results']]
        self.assertEqual(ids, sorted(ids))
        self.assertEqual(len(ids), len(set(ids)))

        # Filter by language id
        res_lang = self.client.get(f'/catalog/api/books/?language={self.lang_fr.id}')
        self.assertEqual(res_lang.status_code, 200)
        data_lang = res_lang.json()
        self.assertEqual(data_lang['count'], 1)
        self.assertEqual(data_lang['results'][0]['title'], 'The Hound of the Baskervilles')

    def test_api_filter_status(self):
        # Filter books having at least one available copy
        # b1 has 2 available copies, but must appear exactly once (distinct)
        res = self.client.get('/catalog/api/books/?status=a')
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data['count'], 1)
        self.assertEqual(data['results'][0]['title'], 'A Study in Scarlet')
        self.assertEqual(len(data['results']), 1)

    def test_api_combined_filters_and(self):
        res = self.client.get(f'/catalog/api/books/?q=hound&language={self.lang_fr.id}&status=m')
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data['count'], 1)
        self.assertEqual(data['results'][0]['title'], 'The Hound of the Baskervilles')

    def test_api_invalid_query_params(self):
        # Invalid status (invalid char or length != 1)
        res1 = self.client.get('/catalog/api/books/?status=x')
        self.assertEqual(res1.status_code, 400)
        self.assertEqual(res1.json(), {'error': 'invalid_query'})

        res1b = self.client.get('/catalog/api/books/?status=aa')
        self.assertEqual(res1b.status_code, 400)
        self.assertEqual(res1b.json(), {'error': 'invalid_query'})

        # Invalid genre (not positive integer)
        res2 = self.client.get('/catalog/api/books/?genre=-5')
        self.assertEqual(res2.status_code, 400)
        self.assertEqual(res2.json(), {'error': 'invalid_query'})

        res2b = self.client.get('/catalog/api/books/?genre=0')
        self.assertEqual(res2b.status_code, 400)
        self.assertEqual(res2b.json(), {'error': 'invalid_query'})

        # Invalid language (string)
        res3 = self.client.get('/catalog/api/books/?language=abc')
        self.assertEqual(res3.status_code, 400)
        self.assertEqual(res3.json(), {'error': 'invalid_query'})

        # Page out of range
        res4 = self.client.get('/catalog/api/books/?page=999')
        self.assertEqual(res4.status_code, 400)
        self.assertEqual(res4.json(), {'error': 'invalid_query'})

        # Page not integer
        res5 = self.client.get('/catalog/api/books/?page=zero')
        self.assertEqual(res5.status_code, 400)
        self.assertEqual(res5.json(), {'error': 'invalid_query'})

    def test_ui_book_list_form_and_pagination(self):
        res = self.client.get('/catalog/books/?q=Filler&genre=' + str(self.genre_mys.id))
        self.assertEqual(res.status_code, 200)
        content = res.content.decode('utf-8')

        # Form must be present with labeled inputs for accessibility
        self.assertTrue('<form' in content and 'method="get"' in content.lower())
        self.assertIn('name="q"', content)
        self.assertIn('name="genre"', content)
        self.assertIn('name="language"', content)
        self.assertIn('name="status"', content)

        # Accessibility checks: labels or aria-label for inputs
        self.assertTrue(
            bool(re.search(r'<label[^>]+for=[\'"][^\'"]*q[^\'"]*[\'"]', content) or 'aria-label=' in content),
            'Accessible label for q input missing'
        )

        # Check pagination links preserves query parameters via HTML URL parsing
        # Look for links containing page=
        page_links = re.findall(r'href=[\'"]([^\'"]*page=\d+[^\'"]*)[\'"]', content)
        self.assertTrue(len(page_links) > 0, 'No pagination links found preserving query')
        for link in page_links:
            # Decode HTML entities if present like &amp;
            clean_link = link.replace('&amp;', '&')
            parsed = urlparse(clean_link)
            query_dict = parse_qs(parsed.query)
            self.assertIn('page', query_dict)
            self.assertIn('q', query_dict, f'Query param q not preserved in link: {clean_link}')
            self.assertIn('genre', query_dict, f'Query param genre not preserved in link: {clean_link}')

        # Invalid query on UI should not 500, but return 200 with friendly message
        res_invalid = self.client.get('/catalog/books/?status=invalid')
        self.assertEqual(res_invalid.status_code, 200)
        self.assertNotIn('Traceback', res_invalid.content.decode('utf-8'))

        # Empty result on UI
        res_empty = self.client.get('/catalog/books/?q=NonExistentTitleXYZ')
        self.assertEqual(res_empty.status_code, 200)
