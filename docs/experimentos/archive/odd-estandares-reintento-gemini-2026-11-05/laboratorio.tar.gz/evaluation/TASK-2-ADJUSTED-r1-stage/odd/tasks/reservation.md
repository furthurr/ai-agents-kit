# Feature: Reservation System for Available BookInstances

## Specs
- S1: Definir modelo Reservation en catalog.models (user FK settings.AUTH_USER_MODEL CASCADE, instance FK BookInstance CASCADE, key CharField max 100, created_at DateTimeField auto_now_add=True, UniqueConstraint/unique_together sobre [user, key]).
- S2: API Endpoint POST /catalog/api/bookinstance/<uuid:pk>/reserve/:
  - Requiere usuario autenticado (401 Unauthorized con {'error': 'unauthorized'}).
  - Solo POST permitido (GET u otro responde 405 Method Not Allowed).
  - Header 'Idempotency-Key' obligatorio, no vacío tras strip y <= 100 caracteres. De lo contrario 400 Bad Request con {'error': 'invalid_key'}.
  - Instancia inexistente responde 404 Not Found con {'error': 'not_found'}.
  - Si status != 'a', responder 409 Conflict con {'error': 'unavailable'}.
  - Éxito (primera reserva): status='r', borrower=request.user, registra Reservation, 201 Created con {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}.
  - Replay / Idempotencia exacta: Mismo usuario, misma key, misma instancia responde 201 Created con {"instance_id": str(pk), "user_id": request.user.id, "status": "r"} sin duplicar ni alterar.
  - Conflicto de Idempotencia: Mismo usuario reutilizando key para otra instancia responde 409 Conflict con {'error': 'idempotency_conflict'}.
  - Persistencia de idempotencia entre conexiones/sesiones.
- S3: Garantía de concurrencia bajo SQLite en disco: dos solicitudes concurrentes sobre la misma copia 'a' resultan en exactamente un 201 y un 409 unavailable sin 500 'database locked' ni mutar BookInstance en peticiones fallidas.
- S4: Interfaz Web (UI):
  - En /catalog/book/<int:pk>, para cada copia con status='a', incluir botón/formulario de reserva apuntando a /catalog/book/<uuid:instance_pk>/reserve/.
  - POST a /catalog/book/<uuid:instance_pk>/reserve/ requiere auth (redirige a login si anónimo).
  - Incluye token CSRF y campo hidden con idempotency_key generada para prevenir doble envío accidental.
  - Al completarse con éxito, muestra mensaje flash de confirmación visible en la interfaz (o redirige al detalle con mensaje flash de éxito).
- S5: Suite original (43 tests) debe seguir pasando intacta. No modificar renew de bibliotecarios ni violar retrocompatibilidad.

## Tasks
- [x] T1: Crear pruebas unitarias y de integración que fallen (RED) para S1, S2, S3, S4, S5
- [x] T2: Implementar modelo Reservation y generar migraciones (S1)
- [x] T3: Implementar API endpoint POST /catalog/api/bookinstance/<uuid:pk>/reserve/ con idempotencia y concurrencia (S2, S3)
- [x] T4: Implementar UI web para reserva de ejemplares y vistas correspondientes (S4)
- [x] T5: Verificar suite completa en GREEN, verificar preservación de 43 tests existentes y concurrencia SQLite (S5)

## Log
- L1: Petición recibida: Implementar flujo de reserva de ejemplares disponibles (BookInstance con status='a') para usuarios autenticados, con persistencia de reservas, garantía de idempotencia en reintentos y tolerancia a concurrencia real bajo SQLite.
- L2: Creados tests en catalog/tests/test_reservation.py. Observado estado RED (ImportError: cannot import name 'Reservation').
- L3: Implementado modelo Reservation en catalog/models.py con UniqueConstraint [user, key] y migración catalog/migrations/0030_reservation.py. Registrado en admin.py.
- L4: Implementado endpoint API reserve_bookinstance_api y vista web reserve_bookinstance_web en catalog/views.py y catalog/urls.py con protección contra concurrencia SQLite, reintentos exponenciales y validación estricta de idempotencia.
- L5: Actualizadas plantillas catalog/templates/catalog/book_detail.html y base_generic.html para renderizar botón/formulario CSRF con clave oculta y mensajes flash.
- L6: Ejecutada la suite completa: 58 tests pasaron exitosamente (43 originales + 15 de reserva y concurrencia multihilo).
