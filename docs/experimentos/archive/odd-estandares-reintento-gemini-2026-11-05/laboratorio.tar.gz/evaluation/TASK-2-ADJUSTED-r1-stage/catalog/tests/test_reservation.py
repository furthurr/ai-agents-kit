import uuid
import datetime
from django.test import TestCase, TransactionTestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.db import IntegrityError
from catalog.models import Book, BookInstance, Author, Genre, Language, Reservation

User = get_user_model()


class ReservationModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='res_user', password='password123')
        self.author = Author.objects.create(first_name='Arthur', last_name='Conan')
        self.book = Book.objects.create(title='A Study in Scarlet', isbn='1234567890123', author=self.author)
        self.instance = BookInstance.objects.create(book=self.book, imprint='First Ed', status=BookInstance.LoanStatus.AVAILABLE)

    def test_reservation_creation(self):
        res = Reservation.objects.create(user=self.user, instance=self.instance, key='test-key-1')
        self.assertEqual(res.user, self.user)
        self.assertEqual(res.instance, self.instance)
        self.assertEqual(res.key, 'test-key-1')
        self.assertIsNotNone(res.created_at)

    def test_unique_user_key_constraint(self):
        Reservation.objects.create(user=self.user, instance=self.instance, key='key-duplicate')
        # Same user, same key should fail with IntegrityError
        with self.assertRaises(IntegrityError):
            Reservation.objects.create(user=self.user, instance=self.instance, key='key-duplicate')

    def test_different_users_can_use_same_key(self):
        user2 = User.objects.create_user(username='res_user_2', password='password123')
        instance2 = BookInstance.objects.create(book=self.book, imprint='Second Ed', status=BookInstance.LoanStatus.AVAILABLE)
        res1 = Reservation.objects.create(user=self.user, instance=self.instance, key='shared-key')
        res2 = Reservation.objects.create(user=user2, instance=instance2, key='shared-key')
        self.assertEqual(res1.key, res2.key)


class ReservationAPITest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='api_user', password='password123')
        self.user2 = User.objects.create_user(username='api_user2', password='password123')
        self.author = Author.objects.create(first_name='Arthur', last_name='Conan')
        self.book = Book.objects.create(title='Sherlock Holmes', isbn='9876543210123', author=self.author)
        self.instance_avail = BookInstance.objects.create(
            book=self.book, imprint='Standard', status=BookInstance.LoanStatus.AVAILABLE
        )
        self.instance_loan = BookInstance.objects.create(
            book=self.book, imprint='Standard', status=BookInstance.LoanStatus.ON_LOAN
        )
        self.reserve_url = f'/catalog/api/bookinstance/{self.instance_avail.id}/reserve/'

    def test_unauthenticated_returns_401(self):
        resp = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(resp.status_code, 401)
        self.assertEqual(resp.json(), {'error': 'unauthorized'})

    def test_method_not_allowed_returns_405(self):
        self.client.login(username='api_user', password='password123')
        resp = self.client.get(self.reserve_url, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(resp.status_code, 405)

    def test_missing_or_invalid_idempotency_key_returns_400(self):
        self.client.login(username='api_user', password='password123')
        
        # Missing key
        resp = self.client.post(self.reserve_url)
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.json(), {'error': 'invalid_key'})

        # Empty key after strip
        resp = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.json(), {'error': 'invalid_key'})

        # Key exceeding 100 chars
        resp = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='a' * 101)
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.json(), {'error': 'invalid_key'})

    def test_nonexistent_instance_returns_404(self):
        self.client.login(username='api_user', password='password123')
        non_id = uuid.uuid4()
        resp = self.client.post(f'/catalog/api/bookinstance/{non_id}/reserve/', HTTP_IDEMPOTENCY_KEY='valid-key')
        self.assertEqual(resp.status_code, 404)
        self.assertEqual(resp.json(), {'error': 'not_found'})

    def test_unavailable_instance_returns_409(self):
        self.client.login(username='api_user', password='password123')
        resp = self.client.post(
            f'/catalog/api/bookinstance/{self.instance_loan.id}/reserve/',
            HTTP_IDEMPOTENCY_KEY='valid-key'
        )
        self.assertEqual(resp.status_code, 409)
        self.assertEqual(resp.json(), {'error': 'unavailable'})
        # Ensure status didn't mutate
        self.instance_loan.refresh_from_db()
        self.assertEqual(self.instance_loan.status, BookInstance.LoanStatus.ON_LOAN)

    def test_successful_reservation(self):
        self.client.login(username='api_user', password='password123')
        resp = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='valid-key-1')
        self.assertEqual(resp.status_code, 201)
        self.assertEqual(resp.json(), {
            'instance_id': str(self.instance_avail.id),
            'user_id': self.user.id,
            'status': 'r'
        })

        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance_avail.borrower, self.user)
        self.assertTrue(Reservation.objects.filter(user=self.user, instance=self.instance_avail, key='valid-key-1').exists())

    def test_idempotent_replay_same_user_same_key_same_instance(self):
        self.client.login(username='api_user', password='password123')
        # First request
        resp1 = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='idem-key-replay')
        self.assertEqual(resp1.status_code, 201)

        # Second request (replay)
        resp2 = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='idem-key-replay')
        self.assertEqual(resp2.status_code, 201)
        self.assertEqual(resp2.json(), resp1.json())
        self.assertEqual(resp2.json(), {
            'instance_id': str(self.instance_avail.id),
            'user_id': self.user.id,
            'status': 'r'
        })
        self.assertEqual(Reservation.objects.filter(user=self.user, key='idem-key-replay').count(), 1)

    def test_idempotency_conflict_reusing_key_for_different_instance(self):
        self.client.login(username='api_user', password='password123')
        instance_avail2 = BookInstance.objects.create(
            book=self.book, imprint='Standard 2', status=BookInstance.LoanStatus.AVAILABLE
        )
        # First reservation
        resp1 = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='conflict-key')
        self.assertEqual(resp1.status_code, 201)

        # Attempt to reserve second instance with same key
        resp2 = self.client.post(f'/catalog/api/bookinstance/{instance_avail2.id}/reserve/', HTTP_IDEMPOTENCY_KEY='conflict-key')
        self.assertEqual(resp2.status_code, 409)
        self.assertEqual(resp2.json(), {'error': 'idempotency_conflict'})
        
        # Second instance remains available
        instance_avail2.refresh_from_db()
        self.assertEqual(instance_avail2.status, BookInstance.LoanStatus.AVAILABLE)


class ReservationUITest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='web_user', password='password123')
        self.author = Author.objects.create(first_name='Arthur', last_name='Conan')
        self.book = Book.objects.create(title='Sherlock Holmes UI', isbn='1112223334445', author=self.author)
        self.instance_avail = BookInstance.objects.create(
            book=self.book, imprint='Standard Copy', status=BookInstance.LoanStatus.AVAILABLE
        )
        self.instance_maint = BookInstance.objects.create(
            book=self.book, imprint='Maint Copy', status=BookInstance.LoanStatus.MAINTENANCE
        )

    def test_book_detail_shows_reserve_button_for_available_only(self):
        resp = self.client.get(reverse('book-detail', kwargs={'pk': self.book.pk}))
        self.assertEqual(resp.status_code, 200)
        reserve_action = f"/catalog/book/{self.instance_avail.id}/reserve/"
        self.assertContains(resp, reserve_action)
        maint_reserve_action = f"/catalog/book/{self.instance_maint.id}/reserve/"
        self.assertNotContains(resp, maint_reserve_action)

    def test_web_reserve_anonymous_redirects_to_login(self):
        resp = self.client.post(f"/catalog/book/{self.instance_avail.id}/reserve/", {'idempotency_key': 'web-key-1'})
        self.assertEqual(resp.status_code, 302)
        self.assertTrue('/accounts/login/' in resp.url or '/login/' in resp.url)

    def test_web_reserve_authenticated_success(self):
        self.client.login(username='web_user', password='password123')
        resp = self.client.post(f"/catalog/book/{self.instance_avail.id}/reserve/", {'idempotency_key': 'web-key-2'}, follow=True)
        self.assertEqual(resp.status_code, 200)
        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance_avail.borrower, self.user)
        # Check success message present in response
        messages = list(resp.context['messages'])
        self.assertTrue(any('reserve' in str(m).lower() or 'éxito' in str(m).lower() or 'success' in str(m).lower() for m in messages))


import threading
from django.db import connections


class ReservationConcurrencyTest(TransactionTestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='concurrent_user_1', password='password123')
        self.user2 = User.objects.create_user(username='concurrent_user_2', password='password123')
        self.author = Author.objects.create(first_name='Concurrent', last_name='Author')
        self.book = Book.objects.create(title='Concurrency in SQLite', isbn='9999999999999', author=self.author)
        self.instance = BookInstance.objects.create(
            book=self.book, imprint='Concurrency Ed', status=BookInstance.LoanStatus.AVAILABLE
        )
        self.reserve_url = f'/catalog/api/bookinstance/{self.instance.id}/reserve/'

    def test_concurrent_reservations_result_in_one_success_and_one_conflict(self):
        results = []
        barrier = threading.Barrier(2)

        def make_reservation(user, key):
            connections.close_all()
            from django.test import Client
            c = Client()
            c.login(username=user.username, password='password123')
            try:
                barrier.wait(timeout=5)
            except Exception:
                pass
            resp = c.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY=key)
            results.append((resp.status_code, resp.json()))
            connections.close_all()

        t1 = threading.Thread(target=make_reservation, args=(self.user1, 'key-user-1'))
        t2 = threading.Thread(target=make_reservation, args=(self.user2, 'key-user-2'))

        t1.start()
        t2.start()
        t1.join()
        t2.join()

        status_codes = [r[0] for r in results]
        self.assertCountEqual(status_codes, [201, 409])
        
        success_result = next(r[1] for r in results if r[0] == 201)
        conflict_result = next(r[1] for r in results if r[0] == 409)

        self.assertEqual(success_result['status'], 'r')
        self.assertEqual(conflict_result, {'error': 'unavailable'})

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)

