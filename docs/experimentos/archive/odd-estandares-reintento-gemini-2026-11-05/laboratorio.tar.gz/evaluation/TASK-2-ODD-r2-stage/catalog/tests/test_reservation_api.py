import concurrent.futures
import uuid
from django.test import TestCase, TransactionTestCase
from django.contrib.auth import get_user_model
from django.db import connection
from catalog.models import Book, BookInstance, Reservation

User = get_user_model()


class ReserveBookInstanceApiTest(TestCase):

    def setUp(self):
        self.user1 = User.objects.create_user(username='user1', password='password123')
        self.user2 = User.objects.create_user(username='user2', password='password123')
        self.book = Book.objects.create(title='Test Book', summary='Summary', isbn='1112223334445')
        self.instance_available = BookInstance.objects.create(
            book=self.book, imprint='Imprint 1', status='a'
        )
        self.instance_maintenance = BookInstance.objects.create(
            book=self.book, imprint='Imprint 2', status='m'
        )
        self.instance_reserved = BookInstance.objects.create(
            book=self.book, imprint='Imprint 3', status='r'
        )

    def test_unauthenticated_returns_401(self):
        url = f'/catalog/api/bookinstance/{self.instance_available.pk}/reserve/'
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_method_not_allowed(self):
        self.client.force_login(self.user1)
        url = f'/catalog/api/bookinstance/{self.instance_available.pk}/reserve/'
        for method in ['get', 'put', 'delete', 'patch']:
            client_method = getattr(self.client, method)
            response = client_method(url, HTTP_IDEMPOTENCY_KEY='key-1')
            self.assertEqual(response.status_code, 405)

    def test_missing_or_invalid_idempotency_key(self):
        self.client.force_login(self.user1)
        url = f'/catalog/api/bookinstance/{self.instance_available.pk}/reserve/'

        # Missing key
        response = self.client.post(url)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

        # Empty key
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='')
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

        # Whitespace key
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

        # Exceeds 100 chars
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='a' * 101)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

    def test_nonexistent_instance_returns_404(self):
        self.client.force_login(self.user1)
        random_uuid = uuid.uuid4()
        url = f'/catalog/api/bookinstance/{random_uuid}/reserve/'
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_unavailable_instance_returns_409(self):
        self.client.force_login(self.user1)
        url = f'/catalog/api/bookinstance/{self.instance_maintenance.pk}/reserve/'
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})

        url2 = f'/catalog/api/bookinstance/{self.instance_reserved.pk}/reserve/'
        response2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='key-2')
        self.assertEqual(response2.status_code, 409)
        self.assertEqual(response2.json(), {'error': 'unavailable'})

        # Ensure no Reservation created
        self.assertEqual(Reservation.objects.count(), 0)

    def test_successful_reservation(self):
        self.client.force_login(self.user1)
        url = f'/catalog/api/bookinstance/{self.instance_available.pk}/reserve/'
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-success-1')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), {
            'instance_id': str(self.instance_available.pk),
            'user_id': self.user1.id,
            'status': 'r'
        })

        self.instance_available.refresh_from_db()
        self.assertEqual(self.instance_available.status, 'r')
        self.assertEqual(self.instance_available.borrower, self.user1)

        res = Reservation.objects.get(user=self.user1, key='key-success-1')
        self.assertEqual(res.instance, self.instance_available)

    def test_idempotent_replay_same_user_same_key_same_instance(self):
        self.client.force_login(self.user1)
        url = f'/catalog/api/bookinstance/{self.instance_available.pk}/reserve/'

        # First request
        res1 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-replay-1')
        self.assertEqual(res1.status_code, 201)
        self.assertEqual(res1.json(), {
            'instance_id': str(self.instance_available.pk),
            'user_id': self.user1.id,
            'status': 'r'
        })

        # Replay request
        res2 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-replay-1')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), {
            'instance_id': str(self.instance_available.pk),
            'user_id': self.user1.id,
            'status': 'r'
        })

        # Reservation count still 1
        self.assertEqual(Reservation.objects.filter(user=self.user1, key='key-replay-1').count(), 1)

    def test_idempotency_conflict_same_user_same_key_different_instance(self):
        self.client.force_login(self.user1)
        instance2 = BookInstance.objects.create(
            book=self.book, imprint='Imprint 4', status='a'
        )

        url1 = f'/catalog/api/bookinstance/{self.instance_available.pk}/reserve/'
        res1 = self.client.post(url1, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(res1.status_code, 201)

        url2 = f'/catalog/api/bookinstance/{instance2.pk}/reserve/'
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})

        instance2.refresh_from_db()
        self.assertEqual(instance2.status, 'a')
        self.assertIsNone(instance2.borrower)

    def test_different_users_with_same_key(self):
        instance2 = BookInstance.objects.create(
            book=self.book, imprint='Imprint 5', status='a'
        )

        self.client.force_login(self.user1)
        res1 = self.client.post(
            f'/catalog/api/bookinstance/{self.instance_available.pk}/reserve/',
            HTTP_IDEMPOTENCY_KEY='common-key'
        )
        self.assertEqual(res1.status_code, 201)

        self.client.force_login(self.user2)
        res2 = self.client.post(
            f'/catalog/api/bookinstance/{instance2.pk}/reserve/',
            HTTP_IDEMPOTENCY_KEY='common-key'
        )
        self.assertEqual(res2.status_code, 201)


class ReserveBookInstanceConcurrencyTest(TransactionTestCase):
    """TransactionTestCase allows concurrent DB threads in SQLite."""

    def test_concurrent_reservations_same_instance(self):
        user1 = User.objects.create_user(username='c_user1', password='password123')
        user2 = User.objects.create_user(username='c_user2', password='password123')
        book = Book.objects.create(title='C Book', summary='Sum', isbn='9998887776665')
        instance = BookInstance.objects.create(book=book, imprint='C Imprint', status='a')

        url = f'/catalog/api/bookinstance/{instance.pk}/reserve/'

        from django.test import Client

        def try_reserve(user, key):
            c = Client()
            c.force_login(user)
            resp = c.post(url, HTTP_IDEMPOTENCY_KEY=key)
            return resp.status_code, resp.json()

        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            f1 = executor.submit(try_reserve, user1, 'c-key-1')
            f2 = executor.submit(try_reserve, user2, 'c-key-2')
            results = [f1.result(), f2.result()]

        statuses = [r[0] for r in results]
        self.assertIn(201, statuses)
        self.assertIn(409, statuses)

        winner = [r for r in results if r[0] == 201][0]
        loser = [r for r in results if r[0] == 409][0]
        self.assertEqual(loser[1], {'error': 'unavailable'})
        self.assertEqual(winner[1]['status'], 'r')

        instance.refresh_from_db()
        self.assertEqual(instance.status, 'r')
        self.assertEqual(Reservation.objects.count(), 1)
