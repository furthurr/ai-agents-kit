import uuid
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from catalog.models import Book, BookInstance, Reservation

User = get_user_model()


class BookReservationUITest(TestCase):

    def setUp(self):
        self.user = User.objects.create_user(username='uiuser', password='password123')
        self.book = Book.objects.create(title='UI Test Book', summary='Book summary', isbn='1122334455667')
        self.instance_available = BookInstance.objects.create(
            book=self.book, imprint='Imprint UI 1', status='a'
        )
        self.instance_reserved = BookInstance.objects.create(
            book=self.book, imprint='Imprint UI 2', status='r'
        )

    def test_book_detail_shows_reserve_form_for_available_instance(self):
        url = reverse('book-detail', kwargs={'pk': self.book.pk})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

        # Should contain reserve URL for available copy
        reserve_url = f'/catalog/book/{self.instance_available.pk}/reserve/'
        self.assertContains(response, reserve_url)
        self.assertContains(response, 'idempotency_key')
        self.assertContains(response, 'csrfmiddlewaretoken')

        # Should NOT contain reserve URL for reserved copy
        reserve_url_reserved = f'/catalog/book/{self.instance_reserved.pk}/reserve/'
        self.assertNotContains(response, reserve_url_reserved)

    def test_reserve_view_unauthenticated_redirects_to_login(self):
        url = f'/catalog/book/{self.instance_available.pk}/reserve/'
        response = self.client.post(url, {'idempotency_key': str(uuid.uuid4())})
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/'))

    def test_reserve_view_post_success(self):
        self.client.force_login(self.user)
        key = str(uuid.uuid4())
        url = f'/catalog/book/{self.instance_available.pk}/reserve/'
        response = self.client.post(url, {'idempotency_key': key}, follow=True)

        self.assertEqual(response.status_code, 200)
        self.instance_available.refresh_from_db()
        self.assertEqual(self.instance_available.status, 'r')
        self.assertEqual(self.instance_available.borrower, self.user)
        self.assertTrue(Reservation.objects.filter(user=self.user, key=key).exists())

        # Success message displayed
        self.assertContains(response, 'Book reserved successfully!')
