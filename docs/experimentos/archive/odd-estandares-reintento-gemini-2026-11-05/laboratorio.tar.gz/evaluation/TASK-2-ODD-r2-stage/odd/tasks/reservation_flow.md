# Task: Flujo de reserva de ejemplares disponibles con idempotencia y concurrencia

## Specs
S1. Modelo Reservation en catalog.models con user (ForeignKey settings.AUTH_USER_MODEL, CASCADE), instance (ForeignKey BookInstance, CASCADE), key (CharField max_length=100), created_at (DateTimeField auto_now_add=True) y restricción de unicidad [user, key].
S2. Endpoint API POST /catalog/api/bookinstance/<uuid:pk>/reserve/ requiriendo autenticación (401 {'error': 'unauthorized'} si anónimo), método POST únicamente (405 si otro), header 'Idempotency-Key' obligatorio, no vacío tras strip y <= 100 chars (400 {'error': 'invalid_key'} en caso contrario).
S3. En API: 404 {'error': 'not_found'} si pk no existe; 409 {'error': 'unavailable'} si copia status != 'a'.
S4. En API con éxito primera reserva: transicionar status a 'r', borrower=request.user, guardar Reservation con key, responder 201 Created con {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}.
S5. En API replay / idempotencia: mismo user y misma key para misma instancia retorna 201 Created con mismo JSON exacto sin duplicar reservas ni alterar estado.
S6. En API conflicto idempotencia: mismo user reutiliza key para diferente instancia responde 409 Conflict con {"error": "idempotency_conflict"}.
S7. Garantía concurrencia SQLite: solicitudes concurrentes sobre misma copia 'a' resultan en exactamente un 201 y un 409 (con {'error': 'unavailable'}), sin 500 database locked ni reservas espurias.
S8. UI Web: en /catalog/book/<int:pk>, para cada copia con status='a', incluir formulario/botón apuntando a /catalog/book/<uuid:instance_pk>/reserve/. POST requiere autenticación (redirige a login si anónimo), incluye CSRF y hidden idempotency_key generada. Tras éxito, mostrar mensaje visible en la interfaz / flash de éxito.
S9. Suite original (43 tests) intacta, sin alterar comando renew de bibliotecarios ni violar retrocompatibilidad.

## Tasks
- T1: S1 Definir modelo Reservation y migraciones [completed]
- T2: S2, S3, S4, S5, S6, S7 Implementar endpoint API de reserva con idempotencia y concurrencia [in_progress]
- T3: S8 Implementar UI flujo de reserva (views, templates, urls) [pending]
- T4: S9 Verificación completa de suite original y nuevos tests [pending]

## Log
- L1: Petición original recibida:
"Implementar flujo de reserva de ejemplares disponibles (BookInstance con status='a') para usuarios autenticados, con persistencia de reservas, garantía de idempotencia en reintentos y tolerancia a concurrencia real bajo SQLite.
CONTRATOS EXACTOS:
1. Modelo público de persistencia: Definir modelo Reservation en catalog.models...
2. API Endpoint: POST /catalog/api/bookinstance/<uuid:pk>/reserve/...
3. Garantía de concurrencia bajo SQLite en disco...
4. Interfaz Web (UI): En /catalog/book/<int:pk>, para cada copia con status='a'...
5. Suite original (43 tests) debe seguir pasando intacta..."
