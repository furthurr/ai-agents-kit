import uuid
import threading
from django.test import TestCase, TransactionTestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from catalog.models import Book, Author, BookInstance, Genre, Reservation

User = get_user_model()

class ReservationModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='password123')
        self.user2 = User.objects.create_user(username='testuser2', password='password123')
        self.author = Author.objects.create(first_name='Gabriel', last_name='Garcia')
        self.book = Book.objects.create(title='Cien Anos', author=self.author, summary='Summary', isbn='1234567890123')
        self.instance = BookInstance.objects.create(book=self.book, imprint='Imprint', status=BookInstance.LoanStatus.AVAILABLE)

    def test_reservation_creation_and_str(self):
        res = Reservation.objects.create(user=self.user, instance=self.instance, key='key-123')
        self.assertEqual(res.user, self.user)
        self.assertEqual(res.instance, self.instance)
        self.assertEqual(res.key, 'key-123')
        self.assertIn('Reservation:', str(res))

    def test_reservation_unique_constraint_per_user(self):
        Reservation.objects.create(user=self.user, instance=self.instance, key='shared-key')
        # Same key for different user is allowed
        res2 = Reservation.objects.create(user=self.user2, instance=self.instance, key='shared-key')
        self.assertIsNotNone(res2.id)

        # Same key for same user raises IntegrityError
        from django.db import IntegrityError
        with self.assertRaises(IntegrityError):
            Reservation.objects.create(user=self.user, instance=self.instance, key='shared-key')


class ReservationAPITest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='user1', password='password123')
        self.user2 = User.objects.create_user(username='user2', password='password123')
        self.author = Author.objects.create(first_name='Author', last_name='Test')
        self.book = Book.objects.create(title='Book Title', author=self.author, summary='Summ', isbn='1112223334445')
        self.instance_available = BookInstance.objects.create(
            book=self.book,
            imprint='First Edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.instance_on_loan = BookInstance.objects.create(
            book=self.book,
            imprint='Second Edition',
            status=BookInstance.LoanStatus.ON_LOAN
        )
        self.url = reverse('api-bookinstance-reserve', args=[str(self.instance_available.id)])

    def test_unauthenticated_request_returns_401(self):
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key1')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_invalid_http_method_returns_405(self):
        self.client.force_login(self.user)
        response = self.client.get(self.url, HTTP_IDEMPOTENCY_KEY='key1')
        self.assertEqual(response.status_code, 405)

    def test_missing_or_invalid_idempotency_key_returns_400(self):
        self.client.force_login(self.user)
        # Missing header
        res1 = self.client.post(self.url)
        self.assertEqual(res1.status_code, 400)
        self.assertEqual(res1.json(), {'error': 'invalid_key'})

        # Empty header
        res2 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(res2.status_code, 400)
        self.assertEqual(res2.json(), {'error': 'invalid_key'})

        # Exceeding 100 chars
        res3 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='x' * 101)
        self.assertEqual(res3.status_code, 400)
        self.assertEqual(res3.json(), {'error': 'invalid_key'})

    def test_nonexistent_instance_returns_404(self):
        self.client.force_login(self.user)
        url_nonexistent = reverse('api-bookinstance-reserve', args=[str(uuid.uuid4())])
        response = self.client.post(url_nonexistent, HTTP_IDEMPOTENCY_KEY='key1')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_unavailable_instance_returns_409(self):
        self.client.force_login(self.user)
        url_unavailable = reverse('api-bookinstance-reserve', args=[str(self.instance_on_loan.id)])
        response = self.client.post(url_unavailable, HTTP_IDEMPOTENCY_KEY='key1')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        # Ensure status didn't change
        self.instance_on_loan.refresh_from_db()
        self.assertEqual(self.instance_on_loan.status, BookInstance.LoanStatus.ON_LOAN)

    def test_successful_reservation(self):
        self.client.force_login(self.user)
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='valid-key-1')
        self.assertEqual(response.status_code, 201)
        expected_json = {
            "instance_id": str(self.instance_available.id),
            "user_id": self.user.id,
            "status": "r"
        }
        self.assertEqual(response.json(), expected_json)

        # Verify DB changes
        self.instance_available.refresh_from_db()
        self.assertEqual(self.instance_available.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance_available.borrower, self.user)
        self.assertTrue(Reservation.objects.filter(user=self.user, key='valid-key-1', instance=self.instance_available).exists())

    def test_idempotent_replay_same_user_same_key_same_instance(self):
        self.client.force_login(self.user)
        # First request
        res1 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='replay-key')
        self.assertEqual(res1.status_code, 201)
        self.assertEqual(Reservation.objects.filter(user=self.user, key='replay-key').count(), 1)

        # Replay request
        res2 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='replay-key')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), res1.json())
        self.assertEqual(Reservation.objects.filter(user=self.user, key='replay-key').count(), 1)

    def test_idempotency_conflict_same_user_same_key_different_instance(self):
        self.client.force_login(self.user)
        other_instance = BookInstance.objects.create(
            book=self.book,
            imprint='Third Edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        url_other = reverse('api-bookinstance-reserve', args=[str(other_instance.id)])

        # First reservation with key
        res1 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='shared-idemp-key')
        self.assertEqual(res1.status_code, 201)

        # Try to use same key for other_instance
        res2 = self.client.post(url_other, HTTP_IDEMPOTENCY_KEY='shared-idemp-key')
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})

        # Verify other_instance remained untouched
        other_instance.refresh_from_db()
        self.assertEqual(other_instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_independent_keys_between_different_users(self):
        # User 1 reserves instance_available with 'common-key'
        self.client.force_login(self.user)
        res1 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='common-key')
        self.assertEqual(res1.status_code, 201)

        # User 2 uses 'common-key' on another instance
        another_instance = BookInstance.objects.create(
            book=self.book,
            imprint='Fourth Edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        url_another = reverse('api-bookinstance-reserve', args=[str(another_instance.id)])

        self.client.force_login(self.user2)
        res2 = self.client.post(url_another, HTTP_IDEMPOTENCY_KEY='common-key')
        self.assertEqual(res2.status_code, 201)


class ReservationConcurrencyTest(TransactionTestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='concurrent_user1', password='password123')
        self.user2 = User.objects.create_user(username='concurrent_user2', password='password123')
        self.author = Author.objects.create(first_name='Concurrent', last_name='Author')
        self.book = Book.objects.create(title='Concurrent Book', author=self.author, summary='S', isbn='9999999999999')
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Concurrent Imprint',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.url = reverse('api-bookinstance-reserve', args=[str(self.instance.id)])

    def test_concurrent_reservations_result_in_one_success_and_one_conflict(self):
        from django.test import Client
        client1 = Client()
        client2 = Client()
        client1.force_login(self.user1)
        client2.force_login(self.user2)

        results = []

        def req(client, key):
            res = client.post(self.url, HTTP_IDEMPOTENCY_KEY=key)
            results.append((res.status_code, res.json()))

        t1 = threading.Thread(target=req, args=(client1, 'conc-key-1'))
        t2 = threading.Thread(target=req, args=(client2, 'conc-key-2'))

        t1.start()
        t2.start()
        t1.join()
        t2.join()

        status_codes = [r[0] for r in results]
        self.assertIn(201, status_codes)
        self.assertIn(409, status_codes)

        conflict_res = [r[1] for r in results if r[0] == 409][0]
        self.assertEqual(conflict_res, {'error': 'unavailable'})

        # Exactly 1 reservation created
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)


class ReservationUITest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='uiuser', password='password123')
        self.author = Author.objects.create(first_name='UI', last_name='Author')
        self.book = Book.objects.create(title='UI Book', author=self.author, summary='S', isbn='8888888888888')
        self.instance_avail = BookInstance.objects.create(
            book=self.book,
            imprint='UI Imprint',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.instance_loan = BookInstance.objects.create(
            book=self.book,
            imprint='UI Loan Imprint',
            status=BookInstance.LoanStatus.ON_LOAN
        )
        self.detail_url = reverse('book-detail', args=[self.book.id])
        self.reserve_url = reverse('bookinstance-reserve-web', args=[str(self.instance_avail.id)])

    def test_book_detail_ui_shows_reserve_form_for_available_copies(self):
        response = self.client.get(self.detail_url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, self.reserve_url)
        self.assertContains(response, 'name="idempotency_key"')
        self.assertContains(response, 'Reserve')

    def test_web_reserve_anonymous_redirects_to_login(self):
        response = self.client.post(self.reserve_url, {'idempotency_key': 'ui-key-1'})
        self.assertEqual(response.status_code, 302)
        self.assertIn('/accounts/login/', response.url)

    def test_web_reserve_authenticated_success(self):
        self.client.force_login(self.user)
        response = self.client.post(self.reserve_url, {'idempotency_key': 'ui-key-1'}, follow=True)
        self.assertEqual(response.status_code, 200)
        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance_avail.borrower, self.user)
        self.assertContains(response, f"Exemplar {self.instance_avail.id} reservado con éxito.")
