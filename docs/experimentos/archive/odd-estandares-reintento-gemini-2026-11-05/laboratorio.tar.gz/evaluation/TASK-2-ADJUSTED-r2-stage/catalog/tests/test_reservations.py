import json
import uuid
import threading
from django.test import TestCase, TransactionTestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from catalog.models import Book, Author, Genre, Language, BookInstance, Reservation

class ReservationModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='password123')
        self.author = Author.objects.create(first_name='John', last_name='Doe')
        self.book = Book.objects.create(title='Sample Book', author=self.author, isbn='1234567890123')
        self.instance = BookInstance.objects.create(book=self.book, imprint='Test Imprint', status='a')

    def test_create_reservation(self):
        res = Reservation.objects.create(user=self.user, instance=self.instance, key='key-123')
        self.assertEqual(res.user, self.user)
        self.assertEqual(res.instance, self.instance)
        self.assertEqual(res.key, 'key-123')
        self.assertIsNotNone(res.created_at)

    def test_reservation_user_key_unique_constraint(self):
        Reservation.objects.create(user=self.user, instance=self.instance, key='key-123')
        with self.assertRaises(Exception):
            Reservation.objects.create(user=self.user, instance=self.instance, key='key-123')

    def test_different_users_same_key_allowed(self):
        other_user = User.objects.create_user(username='otheruser', password='password123')
        res1 = Reservation.objects.create(user=self.user, instance=self.instance, key='key-common')
        res2 = Reservation.objects.create(user=other_user, instance=self.instance, key='key-common')
        self.assertNotEqual(res1.id, res2.id)


class ReservationAPITest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='apiuser', password='password123')
        self.other_user = User.objects.create_user(username='otheruser', password='password123')
        self.author = Author.objects.create(first_name='Jane', last_name='Austen')
        self.book = Book.objects.create(title='Pride and Prejudice', author=self.author, isbn='9876543210123')
        self.instance = BookInstance.objects.create(book=self.book, imprint='Vintage', status='a')
        self.url = f'/catalog/api/bookinstance/{self.instance.pk}/reserve/'

    def test_unauthenticated_returns_401(self):
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_method_not_allowed_get(self):
        self.client.force_login(self.user)
        response = self.client.get(self.url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 405)

    def test_invalid_key_missing_or_empty_or_too_long(self):
        self.client.force_login(self.user)
        # Missing header
        res1 = self.client.post(self.url)
        self.assertEqual(res1.status_code, 400)
        self.assertEqual(res1.json(), {'error': 'invalid_key'})

        # Empty / whitespace header
        res2 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(res2.status_code, 400)
        self.assertEqual(res2.json(), {'error': 'invalid_key'})

        # > 100 characters
        res3 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='a' * 101)
        self.assertEqual(res3.status_code, 400)
        self.assertEqual(res3.json(), {'error': 'invalid_key'})

    def test_not_found_instance(self):
        self.client.force_login(self.user)
        missing_uuid = uuid.uuid4()
        response = self.client.post(f'/catalog/api/bookinstance/{missing_uuid}/reserve/', HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_unavailable_instance(self):
        self.client.force_login(self.user)
        self.instance.status = 'm'  # Maintenance
        self.instance.save()
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, 'm')
        self.assertIsNone(self.instance.borrower)

    def test_successful_reservation(self):
        self.client.force_login(self.user)
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-success')
        self.assertEqual(response.status_code, 201)
        expected_json = {
            "instance_id": str(self.instance.pk),
            "user_id": self.user.id,
            "status": "r"
        }
        self.assertEqual(response.json(), expected_json)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, 'r')
        self.assertEqual(self.instance.borrower, self.user)
        self.assertTrue(Reservation.objects.filter(user=self.user, instance=self.instance, key='key-success').exists())

    def test_idempotent_replay_same_user_same_key_same_instance(self):
        self.client.force_login(self.user)
        # First request
        res1 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='idem-key-1')
        self.assertEqual(res1.status_code, 201)

        # Replay request
        res2 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='idem-key-1')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res1.json(), res2.json())
        self.assertEqual(Reservation.objects.filter(user=self.user, key='idem-key-1').count(), 1)

    def test_idempotency_conflict_same_user_same_key_different_instance(self):
        self.client.force_login(self.user)
        # First reservation on instance 1
        res1 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(res1.status_code, 201)

        # Second instance
        instance2 = BookInstance.objects.create(book=self.book, imprint='Another Copy', status='a')
        url2 = f'/catalog/api/bookinstance/{instance2.pk}/reserve/'

        # Reuse same key for instance2
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})

        instance2.refresh_from_db()
        self.assertEqual(instance2.status, 'a')
        self.assertIsNone(instance2.borrower)


class ReservationUITest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='webuser', password='password123')
        self.author = Author.objects.create(first_name='Leo', last_name='Tolstoy')
        self.book = Book.objects.create(title='War and Peace', author=self.author, isbn='1112223334445')
        self.avail_instance = BookInstance.objects.create(book=self.book, imprint='Hardcover', status='a')
        self.maint_instance = BookInstance.objects.create(book=self.book, imprint='Paperback', status='m')

    def test_book_detail_renders_reserve_button_only_for_available_copies(self):
        self.client.force_login(self.user)
        response = self.client.get(reverse('book-detail', args=[self.book.pk]))
        self.assertEqual(response.status_code, 200)
        reserve_url = f'/catalog/book/{self.avail_instance.pk}/reserve/'
        self.assertContains(response, reserve_url)
        unavail_reserve_url = f'/catalog/book/{self.maint_instance.pk}/reserve/'
        self.assertNotContains(response, unavail_reserve_url)
        self.assertContains(response, 'name="idempotency_key"')

    def test_ui_reserve_view_anonymous_redirects_to_login(self):
        url = f'/catalog/book/{self.avail_instance.pk}/reserve/'
        response = self.client.post(url, {'idempotency_key': 'web-key-1'})
        self.assertEqual(response.status_code, 302)
        self.assertTrue('/accounts/login/' in response.url or '/catalog/accounts/login/' in response.url or 'login' in response.url)

    def test_ui_reserve_view_success_and_flash_message(self):
        self.client.force_login(self.user)
        url = f'/catalog/book/{self.avail_instance.pk}/reserve/'
        response = self.client.post(url, {'idempotency_key': 'web-key-1'}, follow=True)
        self.assertEqual(response.status_code, 200)
        self.avail_instance.refresh_from_db()
        self.assertEqual(self.avail_instance.status, 'r')
        self.assertEqual(self.avail_instance.borrower, self.user)
        # Check flash message or confirmation
        self.assertTrue(any('reserv' in str(m).lower() for m in response.context['messages']))


class ReservationConcurrencyTest(TransactionTestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='concurrent1', password='password123')
        self.user2 = User.objects.create_user(username='concurrent2', password='password123')
        self.author = Author.objects.create(first_name='Arthur', last_name='Doyle')
        self.book = Book.objects.create(title='Sherlock Holmes', author=self.author, isbn='5556667778889')
        self.instance = BookInstance.objects.create(book=self.book, imprint='First Edition', status='a')
        self.url = f'/catalog/api/bookinstance/{self.instance.pk}/reserve/'

    def test_concurrent_reservations_result_in_one_201_and_one_409(self):
        results = []

        def make_request(user, key):
            c = Client()
            c.force_login(user)
            resp = c.post(self.url, HTTP_IDEMPOTENCY_KEY=key)
            results.append((resp.status_code, resp.json()))

        t1 = threading.Thread(target=make_request, args=(self.user1, 'conc-key-1'))
        t2 = threading.Thread(target=make_request, args=(self.user2, 'conc-key-2'))

        t1.start()
        t2.start()
        t1.join()
        t2.join()

        status_codes = sorted([r[0] for r in results])
        self.assertEqual(status_codes, [201, 409])
        conflict_res = [r[1] for r in results if r[0] == 409][0]
        self.assertEqual(conflict_res, {'error': 'unavailable'})
        self.assertEqual(Reservation.objects.count(), 1)
