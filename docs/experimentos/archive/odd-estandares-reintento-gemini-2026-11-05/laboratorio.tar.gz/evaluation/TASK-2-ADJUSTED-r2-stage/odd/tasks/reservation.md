# Task: Flujo de reserva de ejemplares disponibles

## Specs
- S1: Definir modelo Reservation en catalog.models con user, instance, key, created_at y UniqueConstraint([user, key]).
- S2: API Endpoint POST /catalog/api/bookinstance/<uuid:pk>/reserve/:
  - 401 si no autenticado ({'error': 'unauthorized'}).
  - 405 si método != POST.
  - 400 si Idempotency-Key ausente/vacía tras strip/>100 chars ({'error': 'invalid_key'}).
  - 404 si pk no existe ({'error': 'not_found'}).
  - 409 si status != 'a' ({'error': 'unavailable'}).
  - 201 Created si exitoso: status -> 'r', borrower -> user, Reservation guardada. JSON {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}.
  - Idempotencia replay: mismo usuario + misma clave + misma instancia -> 201 Created con mismo payload sin duplicar.
  - Idempotencia conflicto: mismo usuario + misma clave + distinta instancia -> 409 Conflict ({'error': 'idempotency_conflict'}).
  - Persistencia de idempotencia en BD.
- S3: Garantía de concurrencia bajo SQLite en disco: dos solicitudes concurrentes sobre misma copia 'a' resultan exactamente en 201 y 409 ('unavailable'), sin 500 database locked ni mutaciones espurias.
- S4: UI Web en /catalog/book/<int:pk>: formulario de reserva en copias con status='a' apuntando a /catalog/book/<uuid:instance_pk>/reserve/, requiere auth (redirige a login si anónimo), incluye CSRF e idempotency_key hidden, muestra confirmación tras reserva.
- S5: Suite original de 43 tests debe seguir pasando intacta.

## Tasks
- T1 [S1]: Escribir tests para modelo Reservation, API endpoint, idempotencia, concurrencia y UI (RED). [pending]
- T2 [S1]: Implementar modelo Reservation y crear migración. [pending]
- T3 [S2, S3]: Implementar endpoint POST /catalog/api/bookinstance/<uuid:pk>/reserve/ con atomic/conditional update SQLite y reintentos. [pending]
- T4 [S4]: Implementar endpoint UI /catalog/book/<uuid:instance_pk>/reserve/ y actualizar catalog/book_detail.html. [pending]
- T5 [S5]: Verificar suite completa (43 originales + nuevos) y tolerancia a concurrencia. [pending]

## Log
- L1: Petición original recibida: "Implementar flujo de reserva de ejemplares disponibles (BookInstance con status='a') para usuarios autenticados, con persistencia de reservas, garantía de idempotencia en reintentos y tolerancia a concurrencia real bajo SQLite..."
