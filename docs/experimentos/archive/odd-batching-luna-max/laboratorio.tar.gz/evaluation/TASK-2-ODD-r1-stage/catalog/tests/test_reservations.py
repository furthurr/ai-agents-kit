import re
import threading
from concurrent.futures import ThreadPoolExecutor

from django.apps import apps
from django.contrib.auth import get_user_model
from django.db import IntegrityError, close_old_connections, transaction
from django.test import Client, TestCase, TransactionTestCase
from django.urls import reverse

from catalog.models import Book, BookInstance


User = get_user_model()


class ReservationViewsTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='reader', password='password')
        self.other_user = User.objects.create_user(username='another-reader', password='password')
        self.book = Book.objects.create(
            title='Reservation Book',
            summary='A book for reservation tests.',
            isbn='1234567890123',
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Test imprint',
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        self.other_instance = BookInstance.objects.create(
            book=self.book,
            imprint='Other test imprint',
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        self.api_url = f'/catalog/api/bookinstance/{self.instance.pk}/reserve/'

    def reservation_model(self):
        return apps.get_model('catalog', 'Reservation')

    def assert_no_reservations(self):
        self.assertEqual(self.reservation_model().objects.count(), 0)

    def test_api_requires_authentication_and_only_allows_post(self):
        response = self.client.post(self.api_url, HTTP_IDEMPOTENCY_KEY='request-key')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

        csrf_client = Client(enforce_csrf_checks=True)
        response = csrf_client.post(self.api_url, HTTP_IDEMPOTENCY_KEY='request-key')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})
        csrf_client.force_login(self.user)
        response = csrf_client.post(self.api_url, HTTP_IDEMPOTENCY_KEY='request-key')
        self.assertEqual(response.status_code, 403)
        self.assert_no_reservations()

        self.client.force_login(self.user)
        response = self.client.get(self.api_url)
        self.assertEqual(response.status_code, 405)
        self.assert_no_reservations()

    def test_api_rejects_missing_empty_whitespace_and_oversized_keys_without_changes(self):
        self.client.force_login(self.user)
        invalid_headers = [
            {},
            {'HTTP_IDEMPOTENCY_KEY': ''},
            {'HTTP_IDEMPOTENCY_KEY': '   '},
            {'HTTP_IDEMPOTENCY_KEY': 'k' * 101},
        ]

        for headers in invalid_headers:
            with self.subTest(headers=headers):
                response = self.client.post(self.api_url, **headers)
                self.assertEqual(response.status_code, 400)
                self.assertEqual(response.json(), {'error': 'invalid_key'})
                self.instance.refresh_from_db()
                self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
                self.assertIsNone(self.instance.borrower_id)
                self.assert_no_reservations()

    def test_api_returns_not_found_without_creating_a_reservation(self):
        self.client.force_login(self.user)
        missing_url = '/catalog/api/bookinstance/00000000-0000-0000-0000-000000000000/reserve/'
        response = self.client.post(missing_url, HTTP_IDEMPOTENCY_KEY='missing-key')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})
        self.assert_no_reservations()

    def test_api_accepts_the_maximum_idempotency_key_length(self):
        key = 'k' * 100
        self.client.force_login(self.user)

        response = self.client.post(self.api_url, HTTP_IDEMPOTENCY_KEY=key)

        self.assertEqual(response.status_code, 201)
        self.assertEqual(self.reservation_model().objects.get(user=self.user).key, key)

    def test_api_reserves_and_persists_replay_across_sessions(self):
        self.client.force_login(self.user)
        response = self.client.post(self.api_url, HTTP_IDEMPOTENCY_KEY='reserve-this-copy')
        expected = {
            'instance_id': str(self.instance.pk),
            'user_id': self.user.pk,
            'status': BookInstance.LoanStatus.RESERVED,
        }
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), expected)

        Reservation = self.reservation_model()
        reservation = Reservation.objects.get(user=self.user, key='reserve-this-copy')
        self.assertEqual(reservation.instance_id, self.instance.pk)
        self.assertEqual(reservation.key, 'reserve-this-copy')
        self.assertIsNotNone(reservation.created_at)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)

        # A new client/session replays the durable idempotency key.
        replay_client = Client()
        replay_client.force_login(self.user)
        replay = replay_client.post(self.api_url, HTTP_IDEMPOTENCY_KEY='reserve-this-copy')
        self.assertEqual(replay.status_code, 201)
        self.assertEqual(replay.json(), expected)
        self.assertEqual(Reservation.objects.count(), 1)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)

    def test_api_conflicts_when_key_is_reused_for_another_instance_without_mutation(self):
        self.client.force_login(self.user)
        first = self.client.post(self.api_url, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(first.status_code, 201)

        response = self.client.post(
            f'/catalog/api/bookinstance/{self.other_instance.pk}/reserve/',
            HTTP_IDEMPOTENCY_KEY='shared-key',
        )
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'idempotency_conflict'})
        self.other_instance.refresh_from_db()
        self.assertEqual(self.other_instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(self.other_instance.borrower_id)
        self.assertEqual(self.reservation_model().objects.count(), 1)

    def test_idempotency_keys_are_independent_between_users(self):
        self.client.force_login(self.user)
        first = self.client.post(self.api_url, HTTP_IDEMPOTENCY_KEY='per-user-key')
        self.assertEqual(first.status_code, 201)

        other_client = Client()
        other_client.force_login(self.other_user)
        response = other_client.post(
            f'/catalog/api/bookinstance/{self.other_instance.pk}/reserve/',
            HTTP_IDEMPOTENCY_KEY='per-user-key',
        )
        self.assertEqual(response.status_code, 201)
        self.assertEqual(self.reservation_model().objects.count(), 2)

    def test_database_enforces_unique_key_per_user(self):
        Reservation = self.reservation_model()
        Reservation.objects.create(user=self.user, instance=self.instance, key='unique-in-db')

        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                Reservation.objects.create(
                    user=self.user,
                    instance=self.other_instance,
                    key='unique-in-db',
                )

        Reservation.objects.create(
            user=self.other_user,
            instance=self.other_instance,
            key='unique-in-db',
        )
        self.assertEqual(Reservation.objects.filter(key='unique-in-db').count(), 2)

    def test_unavailable_copy_returns_conflict_without_spurious_reservation(self):
        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.borrower = self.other_user
        self.instance.save(update_fields=['status', 'borrower'])
        self.client.force_login(self.user)

        response = self.client.post(self.api_url, HTTP_IDEMPOTENCY_KEY='unavailable-key')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.ON_LOAN)
        self.assertEqual(self.instance.borrower_id, self.other_user.pk)
        self.assert_no_reservations()

    def test_book_detail_renders_csrf_protected_reservation_form_for_each_available_copy(self):
        unavailable = BookInstance.objects.create(
            book=self.book,
            imprint='Not available',
            status=BookInstance.LoanStatus.MAINTENANCE,
        )
        response = self.client.get(reverse('book-detail', kwargs={'pk': self.book.pk}))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, f'action="/catalog/book/{self.instance.pk}/reserve/"')
        self.assertContains(response, f'action="/catalog/book/{self.other_instance.pk}/reserve/"')
        self.assertNotContains(response, f'action="/catalog/book/{unavailable.pk}/reserve/"')
        self.assertContains(response, 'name="csrfmiddlewaretoken"')
        self.assertContains(response, 'name="idempotency_key"')
        self.assertRegex(response.content.decode(), r'name="idempotency_key" value="[^"]+"')

    def test_web_reservation_redirects_anonymous_users_to_login(self):
        url = f'/catalog/book/{self.instance.pk}/reserve/'
        response = self.client.post(url, {'idempotency_key': 'web-key'})
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/?next='))
        self.assertEqual(self.reservation_model().objects.count(), 0)

    def test_web_reservation_uses_idempotency_and_shows_success_message(self):
        self.client.force_login(self.user)
        response = self.client.post(
            f'/catalog/book/{self.instance.pk}/reserve/',
            {'idempotency_key': 'web-reservation-key'},
            follow=True,
        )
        self.assertRedirects(response, reverse('book-detail', kwargs={'pk': self.book.pk}))
        self.assertContains(response, 'Reservation confirmed')
        self.assertEqual(self.reservation_model().objects.count(), 1)

    def test_web_reservation_enforces_csrf_token(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        detail = client.get(reverse('book-detail', kwargs={'pk': self.book.pk}))
        token = re.search(
            r'name="csrfmiddlewaretoken" value="([^"]+)"',
            detail.content.decode(),
        ).group(1)
        response = client.post(
            f'/catalog/book/{self.instance.pk}/reserve/',
            {'idempotency_key': 'csrf-web-key', 'csrfmiddlewaretoken': token},
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.reservation_model().objects.count(), 1)


class ReservationSQLiteConcurrencyTest(TransactionTestCase):
    def setUp(self):
        self.users = [
            User.objects.create_user(username='concurrent-reader-1', password='password'),
            User.objects.create_user(username='concurrent-reader-2', password='password'),
        ]
        book = Book.objects.create(
            title='Concurrent Reservation Book',
            summary='A book for concurrent reservation tests.',
            isbn='9876543210987',
        )
        self.instance = BookInstance.objects.create(
            book=book,
            imprint='Concurrent test imprint',
            status=BookInstance.LoanStatus.AVAILABLE,
        )

    def test_two_users_racing_for_one_copy_get_one_success_and_one_unavailable(self):
        url = f'/catalog/api/bookinstance/{self.instance.pk}/reserve/'
        barrier = threading.Barrier(2)
        clients = []
        for user in self.users:
            client = Client()
            client.force_login(user)
            clients.append(client)

        def reserve(user_id, client):
            close_old_connections()
            try:
                barrier.wait(timeout=10)
                response = client.post(url, HTTP_IDEMPOTENCY_KEY=f'key-{user_id}')
                return response.status_code, response.json()
            finally:
                close_old_connections()

        with ThreadPoolExecutor(max_workers=2) as executor:
            responses = list(executor.map(
                reserve,
                [user.pk for user in self.users],
                clients,
            ))

        self.assertEqual(sorted(status for status, _ in responses), [201, 409])
        errors = [body for status, body in responses if status == 409]
        self.assertEqual(errors, [{'error': 'unavailable'}])
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIn(self.instance.borrower_id, [user.pk for user in self.users])
        Reservation = apps.get_model('catalog', 'Reservation')
        self.assertEqual(Reservation.objects.count(), 1)
