import time
import uuid

from django.contrib import messages
from django.db import IntegrityError, OperationalError, connection, transaction
from django.http import Http404, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.csrf import csrf_exempt, csrf_protect
from django.views.decorators.http import require_POST

# Create your views here.

from .models import Book, Author, BookInstance, Genre, Language, Reservation

def index(request):
    """View function for home page of site."""
    # Generate counts of some of the main objects
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available copies of books
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Number of visits to this view, as counted in the session variable.
    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    # Render the HTML template index.html with the data in the context variable.
    return render(request, 'index.html', context=context)

from django.views import generic


class BookListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = Book
    paginate_by = 10

class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        copies = list(context['book'].bookinstance_set.all())
        for copy in copies:
            if copy.status == BookInstance.LoanStatus.AVAILABLE:
                copy.reservation_key = str(uuid.uuid4())
        context['book_instances'] = copies
        return context

class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre

class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10

class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language

class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10

class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10

class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance

from django.contrib.auth.mixins import LoginRequiredMixin

class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )

# Added as part of challenge!
from django.contrib.auth.mixins import PermissionRequiredMixin


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')

from django.http import HttpResponseRedirect
from django.urls import reverse
import datetime
from django.contrib.auth.decorators import login_required, permission_required
from catalog.forms import RenewBookForm


_RESERVATION_LOCK_RETRIES = 5


def _existing_reservation_outcome(user, key, instance_id):
    reservation = Reservation.objects.filter(user=user, key=key).first()
    if reservation is None:
        return None
    if reservation.instance_id == instance_id:
        return 'reserved'
    return 'idempotency_conflict'


def _reserve_available_instance(user, instance_id, key):
    """Atomically claim an available copy and persist its idempotency key.

    SQLite serializes writes rather than locking selected rows. The conditional
    update is the claim, and the reservation insert shares its transaction so
    the state change rolls back if the per-user key is already taken.
    """
    for attempt in range(_RESERVATION_LOCK_RETRIES):
        try:
            with transaction.atomic():
                if not BookInstance.objects.filter(pk=instance_id).exists():
                    return 'not_found'

                existing_outcome = _existing_reservation_outcome(user, key, instance_id)
                if existing_outcome is not None:
                    return existing_outcome

                updated = BookInstance.objects.filter(
                    pk=instance_id,
                    status=BookInstance.LoanStatus.AVAILABLE,
                ).update(
                    status=BookInstance.LoanStatus.RESERVED,
                    borrower_id=user.pk,
                )

                if not updated:
                    # A concurrent request may have committed this same key
                    # after our first lookup, so check idempotency again.
                    existing_outcome = _existing_reservation_outcome(user, key, instance_id)
                    if existing_outcome is not None:
                        return existing_outcome
                    if not BookInstance.objects.filter(pk=instance_id).exists():
                        return 'not_found'
                    return 'unavailable'

                Reservation.objects.create(user=user, instance_id=instance_id, key=key)
            return 'reserved'
        except IntegrityError:
            # A different concurrent request may have claimed this key. The
            # failed transaction rolls back its conditional BookInstance update.
            existing_outcome = _existing_reservation_outcome(user, key, instance_id)
            if existing_outcome is not None:
                return existing_outcome
            raise
        except OperationalError as error:
            message = str(error).lower()
            is_sqlite_lock = connection.vendor == 'sqlite' and (
                'locked' in message or 'busy' in message
            )
            if not is_sqlite_lock:
                raise
            if attempt + 1 < _RESERVATION_LOCK_RETRIES:
                time.sleep(min(0.01 * (2 ** attempt), 0.1))
                continue

            # A sustained SQLite lock must not escape as a 500. If a competing
            # request committed our key, return its durable outcome; otherwise
            # report the copy as unavailable without making a partial change.
            try:
                existing_outcome = _existing_reservation_outcome(user, key, instance_id)
            except OperationalError as lookup_error:
                lookup_message = str(lookup_error).lower()
                if 'locked' not in lookup_message and 'busy' not in lookup_message:
                    raise
                return 'unavailable'
            return existing_outcome or 'unavailable'


def _reservation_error_response(outcome):
    errors = {
        'not_found': (404, 'not_found'),
        'unavailable': (409, 'unavailable'),
        'idempotency_conflict': (409, 'idempotency_conflict'),
    }
    status, error = errors[outcome]
    return JsonResponse({'error': error}, status=status)


@csrf_protect
def _authenticated_reserve_book_instance_api(request, pk):
    key = (request.headers.get('Idempotency-Key') or '').strip()
    if not key or len(key) > 100:
        return JsonResponse({'error': 'invalid_key'}, status=400)

    outcome = _reserve_available_instance(request.user, pk, key)
    if outcome != 'reserved':
        return _reservation_error_response(outcome)

    return JsonResponse(
        {
            'instance_id': str(pk),
            'user_id': request.user.id,
            'status': BookInstance.LoanStatus.RESERVED,
        },
        status=201,
    )


@csrf_exempt
@require_POST
def reserve_book_instance_api(request, pk):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'unauthorized'}, status=401)
    return _authenticated_reserve_book_instance_api(request, pk)


@login_required
@require_POST
def reserve_book_instance(request, pk):
    instance = get_object_or_404(BookInstance.objects.select_related('book'), pk=pk)
    return_url = instance.book.get_absolute_url() if instance.book_id else reverse('bookinstances')
    key = (request.POST.get('idempotency_key') or '').strip()

    if not key or len(key) > 100:
        messages.error(request, 'Reservation could not be completed: invalid reservation key.')
        return redirect(return_url)

    outcome = _reserve_available_instance(request.user, pk, key)
    if outcome == 'reserved':
        messages.success(request, 'Reservation confirmed.')
    elif outcome == 'not_found':
        raise Http404('Book instance not found')
    elif outcome == 'unavailable':
        messages.error(request, 'This copy is no longer available.')
    else:
        messages.error(request, 'This reservation key was already used for another copy.')
    return redirect(return_url)


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed'))

    # If this is a GET (or any other method) create the default form
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import RestrictedError
from django.contrib.auth.mixins import PermissionRequiredMixin
from .models import Author


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'

class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    # Not recommended (potential security issue if more fields added)
    fields = '__all__'
    permission_required = 'catalog.change_author'

class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("author-delete", kwargs={"pk": self.object.pk})
            )

# Classes created for the forms challenge


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("book-delete", kwargs={"pk": self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    # fields = "__all__"
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'
