import re
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier

from django.contrib.auth import get_user_model
from django.db import IntegrityError, close_old_connections, connection, transaction
from django.test import Client, TestCase, TransactionTestCase

from catalog import models
from catalog.models import Book, BookInstance


Reservation = getattr(models, 'Reservation', None)
User = get_user_model()


class ReservationModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='reservation-model-user')
        self.other_user = User.objects.create_user(username='reservation-model-other')
        book = Book.objects.create(
            title='Reservation Model Book', summary='Summary', isbn='9780000000001')
        self.first_instance = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.AVAILABLE)
        self.second_instance = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.AVAILABLE)

    def test_public_reservation_model_fields_and_user_scoped_unique_key(self):
        self.assertIsNotNone(Reservation, 'catalog.models.Reservation must be public')
        field_names = {field.name for field in Reservation._meta.get_fields()}
        self.assertTrue({'user', 'instance', 'key', 'created_at'}.issubset(field_names))
        self.assertEqual(Reservation._meta.get_field('key').max_length, 100)
        user_field = Reservation._meta.get_field('user')
        self.assertEqual(user_field.remote_field.model, User)
        self.assertEqual(user_field.remote_field.on_delete.__name__, 'CASCADE')
        instance_field = Reservation._meta.get_field('instance')
        self.assertEqual(instance_field.remote_field.model, BookInstance)
        self.assertEqual(instance_field.remote_field.on_delete.__name__, 'CASCADE')
        self.assertTrue(Reservation._meta.get_field('created_at').auto_now_add)
        self.assertTrue(any(
            set(constraint.fields) == {'user', 'key'}
            for constraint in Reservation._meta.constraints
        ))

        Reservation.objects.create(
            user=self.user, instance=self.first_instance, key='same-key')
        Reservation.objects.create(
            user=self.other_user, instance=self.second_instance, key='same-key')
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                Reservation.objects.create(
                    user=self.user, instance=self.second_instance, key='same-key')


class ReservationApiTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='reservation-api-user')
        self.other_user = User.objects.create_user(username='reservation-api-other')
        book = Book.objects.create(
            title='Reservation API Book', summary='Summary', isbn='9780000000002')
        self.book = book
        self.available = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.AVAILABLE)
        self.other_available = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.AVAILABLE)
        self.not_available = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.RESERVED,
            borrower=self.other_user)
        self.client.force_login(self.user)

    @staticmethod
    def api_url(instance):
        return f'/catalog/api/bookinstance/{instance.pk}/reserve/'

    def assert_no_reservations(self):
        self.assertIsNotNone(Reservation, 'catalog.models.Reservation must be public')
        self.assertEqual(Reservation.objects.count(), 0)

    def test_api_requires_authentication_and_returns_json_401(self):
        response = Client().post(
            self.api_url(self.available), HTTP_IDEMPOTENCY_KEY='api-key')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})
        self.assertEqual(
            BookInstance.objects.get(pk=self.available.pk).status,
            BookInstance.LoanStatus.AVAILABLE)
        self.assert_no_reservations()

    def test_anonymous_api_gets_json_401_before_csrf_rejection(self):
        response = Client(enforce_csrf_checks=True).post(
            self.api_url(self.available), HTTP_IDEMPOTENCY_KEY='api-key')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})
        self.assertEqual(
            BookInstance.objects.get(pk=self.available.pk).status,
            BookInstance.LoanStatus.AVAILABLE)
        self.assert_no_reservations()

    def test_authenticated_api_retains_csrf_protection(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        url = self.api_url(self.available)
        rejected = client.post(url, HTTP_IDEMPOTENCY_KEY='csrf-protected-key')
        self.assertEqual(rejected.status_code, 403)
        self.assertEqual(Reservation.objects.count(), 0)

        detail = client.get(f'/catalog/book/{self.book.pk}')
        token = re.search(
            r'name="csrfmiddlewaretoken" value="([^"]+)"', detail.content.decode())
        self.assertIsNotNone(token)
        accepted = client.post(
            url,
            HTTP_IDEMPOTENCY_KEY='csrf-protected-key',
            HTTP_X_CSRFTOKEN=token.group(1),
        )
        self.assertEqual(accepted.status_code, 201)
        self.assertEqual(Reservation.objects.get().key, 'csrf-protected-key')

    def test_api_rejects_methods_other_than_post(self):
        for method in ('get', 'put'):
            response = getattr(self.client, method)(self.api_url(self.available))
            self.assertEqual(response.status_code, 405)
        self.assertEqual(
            BookInstance.objects.get(pk=self.available.pk).status,
            BookInstance.LoanStatus.AVAILABLE)
        self.assert_no_reservations()

    def test_invalid_idempotency_keys_do_not_mutate_state(self):
        invalid_headers = (None, '   ', 'k' * 101)
        for key in invalid_headers:
            kwargs = {} if key is None else {'HTTP_IDEMPOTENCY_KEY': key}
            response = self.client.post(self.api_url(self.available), **kwargs)
            self.assertEqual(response.status_code, 400)
            self.assertEqual(response.json(), {'error': 'invalid_key'})
        self.assertEqual(
            BookInstance.objects.get(pk=self.available.pk).status,
            BookInstance.LoanStatus.AVAILABLE)
        self.assert_no_reservations()

    def test_missing_instance_returns_404_without_reservation(self):
        response = self.client.post(
            '/catalog/api/bookinstance/00000000-0000-0000-0000-000000000000/reserve/',
            HTTP_IDEMPOTENCY_KEY='not-found-key')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})
        self.assert_no_reservations()

    def test_unavailable_instance_returns_conflict_without_reservation(self):
        response = self.client.post(
            self.api_url(self.not_available), HTTP_IDEMPOTENCY_KEY='unavailable-key')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        self.assertEqual(
            BookInstance.objects.get(pk=self.not_available.pk).borrower, self.other_user)
        self.assert_no_reservations()

    def test_success_reserves_instance_and_persists_the_key(self):
        response = self.client.post(
            self.api_url(self.available), HTTP_IDEMPOTENCY_KEY=' success-key ')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), {
            'instance_id': str(self.available.pk), 'user_id': self.user.pk, 'status': 'r'})
        instance = BookInstance.objects.get(pk=self.available.pk)
        self.assertEqual(instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(instance.borrower, self.user)
        self.assertEqual(Reservation.objects.get().key, 'success-key')

    def test_replay_in_new_session_returns_same_payload_without_mutation(self):
        first_response = self.client.post(
            self.api_url(self.available), HTTP_IDEMPOTENCY_KEY='replay-key')
        self.assertEqual(first_response.status_code, 201)
        reservation = Reservation.objects.get(user=self.user, key='replay-key')

        # A replay recognizes the durable reservation and does not rewrite the copy.
        BookInstance.objects.filter(pk=self.available.pk).update(
            status=BookInstance.LoanStatus.ON_LOAN, borrower=self.other_user)
        another_session = Client()
        another_session.force_login(self.user)
        close_old_connections()
        replay = another_session.post(
            self.api_url(self.available), HTTP_IDEMPOTENCY_KEY='replay-key')
        self.assertEqual(replay.status_code, 201)
        self.assertEqual(replay.json(), first_response.json())
        self.assertEqual(Reservation.objects.filter(user=self.user, key='replay-key').count(), 1)
        current_instance = BookInstance.objects.get(pk=self.available.pk)
        self.assertEqual(current_instance.status, BookInstance.LoanStatus.ON_LOAN)
        self.assertEqual(current_instance.borrower, self.other_user)
        self.assertEqual(Reservation.objects.get(pk=reservation.pk), reservation)

    def test_reusing_key_for_another_instance_is_a_conflict_without_mutation(self):
        first = self.client.post(
            self.api_url(self.available), HTTP_IDEMPOTENCY_KEY='one-use-key')
        self.assertEqual(first.status_code, 201)
        response = self.client.post(
            self.api_url(self.other_available), HTTP_IDEMPOTENCY_KEY='one-use-key')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'idempotency_conflict'})
        self.assertEqual(
            BookInstance.objects.get(pk=self.other_available.pk).status,
            BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(Reservation.objects.filter(user=self.user).count(), 1)

    def test_same_key_is_independent_between_users(self):
        first = self.client.post(
            self.api_url(self.available), HTTP_IDEMPOTENCY_KEY='per-user-key')
        self.assertEqual(first.status_code, 201)
        self.client.force_login(self.other_user)
        second = self.client.post(
            self.api_url(self.other_available), HTTP_IDEMPOTENCY_KEY='per-user-key')
        self.assertEqual(second.status_code, 201)
        self.assertEqual(Reservation.objects.filter(key='per-user-key').count(), 2)


class ReservationWebTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='reservation-web-user')
        book = Book.objects.create(
            title='Reservation Web Book', summary='Summary', isbn='9780000000003')
        self.book = book
        self.instance = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.AVAILABLE)
        self.second_instance = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.AVAILABLE)
        self.unavailable_instance = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.RESERVED)

    def test_book_detail_shows_available_copy_form_with_csrf_and_generated_key(self):
        response = self.client.get(f'/catalog/book/{self.book.pk}')
        self.assertEqual(response.status_code, 200)
        reserve_url = f'/catalog/book/{self.instance.pk}/reserve/'
        self.assertContains(response, f'action="{reserve_url}"')
        self.assertContains(response, f'action="/catalog/book/{self.second_instance.pk}/reserve/"')
        self.assertContains(response, 'name="csrfmiddlewaretoken"', count=2)
        keys = re.findall(
            r'name="idempotency_key" value="([0-9a-f]{32})"',
            response.content.decode())
        self.assertEqual(len(keys), 2)
        self.assertEqual(len(set(keys)), 2)

    def test_web_post_redirects_anonymous_user_to_login(self):
        response = self.client.post(
            f'/catalog/book/{self.instance.pk}/reserve/',
            {'idempotency_key': 'web-key'})
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/'))
        self.assertEqual(
            BookInstance.objects.get(pk=self.instance.pk).status,
            BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_web_post_reserves_and_shows_success_message(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        detail = client.get(f'/catalog/book/{self.book.pk}')
        form = re.search(
            r'<form method="post" action="([^"]+)">\s*'
            r'<input type="hidden" name="csrfmiddlewaretoken" value="([^"]+)">\s*'
            r'<input type="hidden" name="idempotency_key" value="([^"]+)">',
            detail.content.decode())
        self.assertIsNotNone(form)
        response = client.post(
            form.group(1),
            {'csrfmiddlewaretoken': form.group(2), 'idempotency_key': form.group(3)},
            follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Reserva confirmada')
        instance = BookInstance.objects.get(pk=self.instance.pk)
        self.assertEqual(instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(instance.borrower, self.user)
        self.assertEqual(Reservation.objects.get().key, form.group(3))


class ReservationConcurrencyTest(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        first_user = User.objects.create_user(username='concurrent-reservation-user-1')
        second_user = User.objects.create_user(username='concurrent-reservation-user-2')
        book = Book.objects.create(
            title='Concurrent Reservation Book', summary='Summary', isbn='9780000000004')
        self.instance = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.AVAILABLE)
        self.users = (first_user.pk, second_user.pk)

    def test_concurrent_users_get_one_success_and_one_unavailable_on_sqlite_disk(self):
        self.assertEqual(connection.vendor, 'sqlite')
        self.assertNotIn(':memory:', str(connection.settings_dict['NAME']))
        barrier = Barrier(2)
        url = f'/catalog/api/bookinstance/{self.instance.pk}/reserve/'
        clients = []
        for user_id in self.users:
            client = Client()
            client.force_login(User.objects.get(pk=user_id))
            clients.append(client)

        def reserve(client, key):
            close_old_connections()
            try:
                barrier.wait(timeout=10)
                response = client.post(url, HTTP_IDEMPOTENCY_KEY=key)
                return response.status_code, response.json()
            finally:
                close_old_connections()

        with ThreadPoolExecutor(max_workers=2) as executor:
            results = list(executor.map(
                lambda args: reserve(*args),
                ((clients[0], 'concurrent-key-1'),
                 (clients[1], 'concurrent-key-2'))))

        self.assertEqual(sorted(status for status, _ in results), [201, 409])
        self.assertEqual(
            [body for status, body in results if status == 409],
            [{'error': 'unavailable'}])
        self.assertEqual(Reservation.objects.count(), 1)
        instance = BookInstance.objects.get(pk=self.instance.pk)
        self.assertEqual(instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIn(instance.borrower_id, self.users)
