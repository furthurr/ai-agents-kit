import re
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier

from django.apps import apps
from django.contrib.auth import get_user_model
from django.db import IntegrityError, close_old_connections, connection, transaction
from django.test import Client, TestCase, TransactionTestCase
from django.urls import reverse

from catalog.models import Author, Book, BookInstance


User = get_user_model()


class ReservationFixtures:
    def make_catalog(self):
        self.user = User.objects.create_user(username='reader', password='reader-pass')
        self.other_user = User.objects.create_user(username='another-reader', password='reader-pass')
        author = Author.objects.create(first_name='Ada', last_name='Lovelace')
        book = Book.objects.create(
            title='Library book',
            author=author,
            summary='A book for reservation tests.',
            isbn='9780000000001',
        )
        self.instance = BookInstance.objects.create(
            book=book,
            imprint='Test edition',
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        self.other_instance = BookInstance.objects.create(
            book=book,
            imprint='Second test edition',
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        self.book = book

    @staticmethod
    def reservation_model():
        return apps.get_model('catalog', 'Reservation')

    def api_url(self, instance=None):
        instance = instance or self.instance
        return reverse('api-reserve-bookinstance', kwargs={'pk': instance.pk})

    def web_url(self, instance=None):
        instance = instance or self.instance
        return reverse('reserve-bookinstance', kwargs={'pk': instance.pk})


class ReservationModelTests(ReservationFixtures, TestCase):
    def setUp(self):
        self.make_catalog()

    def test_user_and_key_are_unique_but_keys_are_user_scoped(self):
        Reservation = self.reservation_model()
        self.assertEqual(Reservation._meta.get_field('user').remote_field.model, User)
        self.assertEqual(
            Reservation._meta.get_field('instance').remote_field.model,
            BookInstance,
        )
        self.assertEqual(Reservation._meta.get_field('key').max_length, 100)
        self.assertTrue(Reservation._meta.get_field('created_at').auto_now_add)
        Reservation.objects.create(user=self.user, instance=self.instance, key='same-key')
        Reservation.objects.create(user=self.other_user, instance=self.other_instance, key='same-key')

        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                Reservation.objects.create(
                    user=self.user,
                    instance=self.other_instance,
                    key='same-key',
                )

        self.assertEqual(Reservation.objects.count(), 2)


class ReservationApiTests(ReservationFixtures, TestCase):
    def setUp(self):
        self.make_catalog()
        self.client.force_login(self.user)

    def post_reservation(self, client=None, instance=None, key='request-key'):
        client = client or self.client
        return client.post(
            self.api_url(instance),
            HTTP_IDEMPOTENCY_KEY=key,
        )

    def assert_no_reservation_was_created(self):
        self.assertEqual(self.reservation_model().objects.count(), 0)

    def test_anonymous_request_returns_json_401_without_mutation(self):
        response = Client().post(self.api_url(), HTTP_IDEMPOTENCY_KEY='anon-key')

        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assert_no_reservation_was_created()

    def test_only_post_is_allowed_and_error_is_json(self):
        for response in (
            self.client.get(self.api_url()),
            self.client.put(self.api_url()),
            self.client.delete(self.api_url()),
        ):
            self.assertEqual(response.status_code, 405)
            self.assertEqual(response.json(), {'error': 'method_not_allowed'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assert_no_reservation_was_created()

    def test_missing_blank_or_oversized_idempotency_key_is_rejected(self):
        for headers in ({}, {'HTTP_IDEMPOTENCY_KEY': '  \t  '},
                        {'HTTP_IDEMPOTENCY_KEY': 'k' * 101}):
            response = self.client.post(self.api_url(), **headers)
            self.assertEqual(response.status_code, 400)
            self.assertEqual(response.json(), {'error': 'invalid_key'})

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assert_no_reservation_was_created()

    def test_missing_instance_returns_json_404_without_mutation(self):
        import uuid

        response = self.client.post(
            reverse('api-reserve-bookinstance', kwargs={'pk': uuid.uuid4()}),
            HTTP_IDEMPOTENCY_KEY='missing-instance',
        )

        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assert_no_reservation_was_created()

    def test_unavailable_instance_returns_409_without_reservation(self):
        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.save(update_fields=['status'])

        response = self.post_reservation(key='unavailable-key')

        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.ON_LOAN)
        self.assert_no_reservation_was_created()

    def test_first_reservation_updates_instance_and_persists_exact_payload(self):
        response = self.post_reservation(key='  reservation-key  ')

        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), {
            'instance_id': str(self.instance.pk),
            'user_id': self.user.id,
            'status': 'r',
        })
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.id)
        reservation = self.reservation_model().objects.get()
        self.assertEqual(reservation.key, 'reservation-key')
        self.assertEqual(reservation.user_id, self.user.id)
        self.assertEqual(reservation.instance_id, self.instance.pk)
        self.assertIsNotNone(reservation.created_at)

    def test_key_with_exactly_one_hundred_characters_is_accepted(self):
        response = self.post_reservation(instance=self.other_instance, key='k' * 100)

        self.assertEqual(response.status_code, 201)
        self.assertEqual(self.reservation_model().objects.get().key, 'k' * 100)

    def test_replay_in_a_new_client_returns_same_result_without_duplication(self):
        first_response = self.post_reservation(key='persistent-key')
        original = self.reservation_model().objects.get()

        connection.close()
        new_client = Client()
        new_client.force_login(self.user)
        replay_response = self.post_reservation(
            client=new_client,
            key='persistent-key',
        )

        self.assertEqual(first_response.status_code, 201)
        self.assertEqual(replay_response.status_code, 201)
        self.assertEqual(replay_response.json(), first_response.json())
        self.assertEqual(self.reservation_model().objects.count(), 1)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.id)
        self.assertEqual(self.reservation_model().objects.get().created_at, original.created_at)

    def test_reusing_key_for_another_instance_conflicts_without_mutation(self):
        self.assertEqual(self.post_reservation(key='one-key').status_code, 201)

        response = self.post_reservation(instance=self.other_instance, key='one-key')

        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'idempotency_conflict'})
        self.other_instance.refresh_from_db()
        self.assertEqual(self.other_instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(self.reservation_model().objects.count(), 1)


class ReservationWebTests(ReservationFixtures, TestCase):
    def setUp(self):
        self.make_catalog()

    def test_book_detail_has_csrf_protected_form_and_generated_key_for_available_copy(self):
        client = Client(enforce_csrf_checks=True)

        response = client.get(reverse('book-detail', kwargs={'pk': self.book.pk}))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, f'action="{self.web_url()}"')
        self.assertContains(response, f'action="{self.web_url(self.other_instance)}"')
        self.assertContains(response, 'name="csrfmiddlewaretoken"')
        self.assertContains(response, 'name="idempotency_key"')
        html = response.content.decode()
        keys = re.findall(r'name="idempotency_key" value="([^"]+)"', html)
        self.assertEqual(len(keys), 2)
        self.assertEqual(len(set(keys)), 2)
        for key in keys:
            self.assertTrue(key.strip())
            self.assertLessEqual(len(key), 100)

    def test_anonymous_web_post_redirects_to_login(self):
        response = Client().post(self.web_url(), {'idempotency_key': 'web-key'})

        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/?next='))
        self.assertEqual(self.reservation_model().objects.count(), 0)

    def test_csrf_protected_web_reservation_shows_success_message(self):
        self.other_instance.status = BookInstance.LoanStatus.ON_LOAN
        self.other_instance.save(update_fields=['status'])
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        detail_response = client.get(reverse('book-detail', kwargs={'pk': self.book.pk}))
        html = detail_response.content.decode()
        csrf_token = re.search(
            r'name="csrfmiddlewaretoken" value="([^"]+)"', html
        ).group(1)
        idempotency_key = re.search(
            r'name="idempotency_key" value="([^"]+)"', html
        ).group(1)

        response = client.post(
            self.web_url(),
            {
                'csrfmiddlewaretoken': csrf_token,
                'idempotency_key': idempotency_key,
            },
            follow=True,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Reserva confirmada')
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.id)
        self.assertEqual(self.reservation_model().objects.count(), 1)


class ReservationConcurrencyTests(ReservationFixtures, TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        self.make_catalog()

    def test_concurrent_users_get_one_created_and_one_unavailable_on_sqlite(self):
        barrier = Barrier(2)
        clients = [Client(), Client()]
        clients[0].force_login(self.user)
        clients[1].force_login(self.other_user)

        def reserve(client):
            close_old_connections()
            try:
                barrier.wait(timeout=10)
                return client.post(self.api_url(), HTTP_IDEMPOTENCY_KEY='concurrent-key')
            finally:
                close_old_connections()

        with ThreadPoolExecutor(max_workers=2) as executor:
            responses = list(executor.map(reserve, clients))

        self.assertEqual(sorted(response.status_code for response in responses), [201, 409])
        conflict = next(response for response in responses if response.status_code == 409)
        self.assertEqual(conflict.json(), {'error': 'unavailable'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIn(self.instance.borrower_id, {self.user.id, self.other_user.id})
        self.assertEqual(self.reservation_model().objects.count(), 1)
