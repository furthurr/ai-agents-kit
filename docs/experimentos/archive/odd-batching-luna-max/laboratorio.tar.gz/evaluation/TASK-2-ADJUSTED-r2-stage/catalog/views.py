import time
import uuid

from django.contrib import messages
from django.db import IntegrityError, OperationalError, connection, transaction
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

# Create your views here.

from .models import Book, Author, BookInstance, Genre, Language, Reservation

def index(request):
    """View function for home page of site."""
    # Generate counts of some of the main objects
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available copies of books
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Number of visits to this view, as counted in the session variable.
    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    # Render the HTML template index.html with the data in the context variable.
    return render(request, 'index.html', context=context)

from django.views import generic


class BookListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = Book
    paginate_by = 10

class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['book_instances_with_reservation_keys'] = [
            {
                'instance': instance,
                'key': uuid.uuid4().hex,
            }
            for instance in self.object.bookinstance_set.all()
        ]
        return context

class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre

class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10

class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language

class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10

class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10

class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance

from django.contrib.auth.mixins import LoginRequiredMixin

class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )

# Added as part of challenge!
from django.contrib.auth.mixins import PermissionRequiredMixin


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')

from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
import datetime
from django.contrib.auth.decorators import login_required, permission_required
from catalog.forms import RenewBookForm


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed'))

    # If this is a GET (or any other method) create the default form
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


def _existing_reservation_result(user, instance_pk, key):
    reservation = Reservation.objects.filter(user_id=user.pk, key=key).first()
    if reservation is None:
        return None
    if reservation.instance_id == instance_pk:
        return 'created'
    return 'idempotency_conflict'


def _reserve_once(user, instance_pk, key):
    with transaction.atomic():
        if not BookInstance.objects.filter(pk=instance_pk).exists():
            return 'not_found'

        existing_result = _existing_reservation_result(user, instance_pk, key)
        if existing_result:
            return existing_result

        updated = BookInstance.objects.filter(
            pk=instance_pk,
            status=BookInstance.LoanStatus.AVAILABLE,
        ).update(
            status=BookInstance.LoanStatus.RESERVED,
            borrower_id=user.pk,
        )
        if updated:
            Reservation.objects.create(user=user, instance_id=instance_pk, key=key)
            return 'created'

        # Another request may have completed this user's reservation while this
        # request was waiting to update the copy.
        existing_result = _existing_reservation_result(user, instance_pk, key)
        if existing_result:
            return existing_result
        if not BookInstance.objects.filter(pk=instance_pk).exists():
            return 'not_found'
        return 'unavailable'


def reserve_book_instance(user, instance_pk, key):
    """Reserve an available copy, retrying transient SQLite writer contention."""
    max_attempts = 6
    for attempt in range(max_attempts):
        try:
            return _reserve_once(user, instance_pk, key)
        except IntegrityError:
            # A simultaneous request using this user's key may have won the
            # unique constraint. Its committed reservation determines replay
            # versus key conflict; unrelated integrity failures still surface.
            existing_result = _existing_reservation_result(user, instance_pk, key)
            if existing_result:
                return existing_result
            raise
        except OperationalError as error:
            is_sqlite_contention = (
                connection.vendor == 'sqlite'
                and any(word in str(error).lower() for word in ('locked', 'busy'))
            )
            if not is_sqlite_contention:
                raise
            if attempt == max_attempts - 1:
                # Do not expose SQLite's transient lock error as an HTTP 500.
                return 'unavailable'
            time.sleep(0.01 * (2 ** attempt))


def _reservation_api_response(result, instance_pk, user):
    if result == 'created':
        return JsonResponse({
            'instance_id': str(instance_pk),
            'user_id': user.id,
            'status': BookInstance.LoanStatus.RESERVED,
        }, status=201)
    if result == 'not_found':
        return JsonResponse({'error': 'not_found'}, status=404)
    if result == 'idempotency_conflict':
        return JsonResponse({'error': 'idempotency_conflict'}, status=409)
    return JsonResponse({'error': 'unavailable'}, status=409)


@csrf_exempt
def api_reserve_book_instance(request, pk):
    if request.method != 'POST':
        return JsonResponse({'error': 'method_not_allowed'}, status=405)
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'unauthorized'}, status=401)

    key = (request.headers.get('Idempotency-Key') or '').strip()
    if not key or len(key) > 100:
        return JsonResponse({'error': 'invalid_key'}, status=400)

    result = reserve_book_instance(request.user, pk, key)
    return _reservation_api_response(result, pk, request.user)


@login_required
@require_POST
def reserve_book_instance_web(request, pk):
    instance = get_object_or_404(BookInstance, pk=pk)
    key = (request.POST.get('idempotency_key') or '').strip()
    if not key or len(key) > 100:
        messages.error(request, 'No se pudo reservar: la clave de reserva no es válida.')
    else:
        result = reserve_book_instance(request.user, pk, key)
        if result == 'created':
            messages.success(request, 'Reserva confirmada.')
        elif result == 'idempotency_conflict':
            messages.error(request, 'La clave de reserva ya se utilizó para otro ejemplar.')
        elif result == 'unavailable':
            messages.error(request, 'El ejemplar ya no está disponible.')
        elif result == 'not_found':
            messages.error(request, 'El ejemplar ya no existe.')
    return redirect('book-detail', pk=instance.book_id)


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import RestrictedError
from django.contrib.auth.mixins import PermissionRequiredMixin
from .models import Author


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'

class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    # Not recommended (potential security issue if more fields added)
    fields = '__all__'
    permission_required = 'catalog.change_author'

class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("author-delete", kwargs={"pk": self.object.pk})
            )

# Classes created for the forms challenge


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("book-delete", kwargs={"pk": self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    # fields = "__all__"
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'
