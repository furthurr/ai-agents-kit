import re
import uuid
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier

from django.apps import apps
from django.contrib.auth import get_user_model
from django.db import IntegrityError, close_old_connections, connection, models, transaction
from django.test import Client, TransactionTestCase
from django.urls import reverse

from catalog.models import Book, BookInstance


User = get_user_model()


def reservation_model(test_case):
    model = next(
        (
            model
            for model in apps.get_app_config("catalog").get_models()
            if model.__name__ == "Reservation"
        ),
        None,
    )
    test_case.assertIsNotNone(model, "catalog.models must expose Reservation")
    return model


class ReservationFixtures:
    def create_book_instance(self, isbn_suffix=1, status=BookInstance.LoanStatus.AVAILABLE):
        book = Book.objects.create(
            title=f"Reservation book {isbn_suffix}",
            summary="A book for reservation tests.",
            isbn=f"978000000000{isbn_suffix}",
        )
        return BookInstance.objects.create(
            book=book,
            imprint="Test imprint",
            status=status,
        )


class ReservationModelContractTest(ReservationFixtures, TransactionTestCase):
    def test_model_fields_and_user_scoped_unique_key(self):
        reservation = reservation_model(self)

        user_field = reservation._meta.get_field("user")
        self.assertIsInstance(user_field, models.ForeignKey)
        self.assertEqual(user_field.remote_field.model, User)
        self.assertEqual(user_field.remote_field.on_delete, models.CASCADE)

        instance_field = reservation._meta.get_field("instance")
        self.assertIsInstance(instance_field, models.ForeignKey)
        self.assertEqual(instance_field.remote_field.model, BookInstance)
        self.assertEqual(instance_field.remote_field.on_delete, models.CASCADE)

        self.assertEqual(reservation._meta.get_field("key").max_length, 100)
        self.assertTrue(reservation._meta.get_field("created_at").auto_now_add)
        has_user_key_constraint = (
            ("user", "key") in reservation._meta.unique_together
            or any(
                isinstance(constraint, models.UniqueConstraint)
                and constraint.fields == ("user", "key")
                for constraint in reservation._meta.constraints
            )
        )
        self.assertTrue(has_user_key_constraint)

        instance = self.create_book_instance()
        first_user = User.objects.create_user(username="reservation-owner")
        second_user = User.objects.create_user(username="reservation-other")
        reservation.objects.create(user=first_user, instance=instance, key="shared-key")
        reservation.objects.create(user=second_user, instance=instance, key="shared-key")
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                reservation.objects.create(
                    user=first_user, instance=instance, key="shared-key"
                )


class ReservationApiTest(ReservationFixtures, TransactionTestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="reserve-user", password="password")
        self.other_user = User.objects.create_user(
            username="reserve-other", password="password"
        )
        self.instance = self.create_book_instance()
        self.client = Client()
        self.client.force_login(self.user)

    def api_url(self, instance=None):
        instance = instance or self.instance
        return f"/catalog/api/bookinstance/{instance.pk}/reserve/"

    def reservations(self):
        return reservation_model(self).objects

    def post_with_key(self, key, instance=None, client=None):
        client = client or self.client
        headers = {} if key is None else {"HTTP_IDEMPOTENCY_KEY": key}
        return client.post(self.api_url(instance), **headers)

    def test_requires_authentication_with_json_401_without_mutation(self):
        response = Client().post(self.api_url(), HTTP_IDEMPOTENCY_KEY="auth-key")

        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {"error": "unauthorized"})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(self.reservations().count(), 0)

    def test_only_post_is_allowed(self):
        for method in ("get", "put", "delete"):
            with self.subTest(method=method):
                response = getattr(self.client, method)(
                    self.api_url(), HTTP_IDEMPOTENCY_KEY="method-key"
                )
                self.assertEqual(response.status_code, 405)
                self.instance.refresh_from_db()
                self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
                self.assertEqual(self.reservations().count(), 0)

    def test_rejects_missing_blank_and_overlong_keys_without_mutation(self):
        invalid_keys = (None, " \t ", "k" * 101)
        for key in invalid_keys:
            with self.subTest(key=key):
                response = self.post_with_key(key)
                self.assertEqual(response.status_code, 400)
                self.assertEqual(response.json(), {"error": "invalid_key"})
                self.instance.refresh_from_db()
                self.assertEqual(
                    self.instance.status, BookInstance.LoanStatus.AVAILABLE
                )
                self.assertEqual(self.reservations().count(), 0)

    def test_missing_instance_returns_json_404_without_mutation(self):
        response = self.client.post(
            f"/catalog/api/bookinstance/{uuid.uuid4()}/reserve/",
            HTTP_IDEMPOTENCY_KEY="missing-key",
        )

        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {"error": "not_found"})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(self.reservations().count(), 0)

    def test_unavailable_copy_returns_conflict_without_mutation(self):
        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.borrower = self.other_user
        self.instance.save(update_fields=("status", "borrower"))

        response = self.post_with_key("unavailable-key")

        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {"error": "unavailable"})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.ON_LOAN)
        self.assertEqual(self.instance.borrower_id, self.other_user.pk)
        self.assertEqual(self.reservations().count(), 0)

    def test_first_reservation_and_replay_survive_new_http_session(self):
        expected = {
            "instance_id": str(self.instance.pk),
            "user_id": self.user.pk,
            "status": "r",
        }
        first_response = self.post_with_key("persisted-reservation-key")

        self.assertEqual(first_response.status_code, 201)
        self.assertEqual(first_response.json(), expected)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)
        reservation = self.reservations().get(user=self.user, key="persisted-reservation-key")

        close_old_connections()
        new_session = Client()
        new_session.force_login(self.user)
        replay = self.post_with_key(
            "persisted-reservation-key", client=new_session
        )

        self.assertEqual(replay.status_code, 201)
        self.assertEqual(replay.json(), expected)
        self.assertEqual(
            self.reservations().filter(user=self.user, key="persisted-reservation-key").count(),
            1,
        )
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)
        self.assertEqual(
            self.reservations().get(user=self.user, key="persisted-reservation-key").pk,
            reservation.pk,
        )

    def test_reusing_key_for_another_instance_conflicts_without_mutation(self):
        other_instance = self.create_book_instance(isbn_suffix=2)
        first = self.post_with_key("single-use-key")

        self.assertEqual(first.status_code, 201)
        second = self.post_with_key("single-use-key", instance=other_instance)

        self.assertEqual(second.status_code, 409)
        self.assertEqual(second.json(), {"error": "idempotency_conflict"})
        other_instance.refresh_from_db()
        self.assertEqual(other_instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(self.reservations().count(), 1)

    def test_same_key_is_independent_for_a_different_user(self):
        other_instance = self.create_book_instance(isbn_suffix=2)
        other_client = Client()
        other_client.force_login(self.other_user)

        first = self.post_with_key("independent-key")
        second = self.post_with_key(
            "independent-key", instance=other_instance, client=other_client
        )

        self.assertEqual(first.status_code, 201)
        self.assertEqual(second.status_code, 201)
        self.assertEqual(self.reservations().filter(key="independent-key").count(), 2)

    def test_concurrent_users_cannot_reserve_the_same_sqlite_copy(self):
        self.assertEqual(connection.vendor, "sqlite")
        database_name = str(connection.settings_dict["NAME"])
        self.assertNotIn(":memory:", database_name)
        self.assertNotIn("mode=memory", database_name)

        clients = []
        for user in (self.user, self.other_user):
            client = Client()
            client.force_login(user)
            clients.append((user.pk, client))

        barrier = Barrier(2)

        def reserve_concurrently(user_id, client):
            close_old_connections()
            try:
                barrier.wait(timeout=10)
                return client.post(
                    self.api_url(),
                    HTTP_IDEMPOTENCY_KEY=f"concurrent-{user_id}",
                )
            finally:
                close_old_connections()

        with ThreadPoolExecutor(max_workers=2) as executor:
            futures = [
                executor.submit(reserve_concurrently, user_id, client)
                for user_id, client in clients
            ]
            responses = [future.result(timeout=20) for future in futures]

        self.assertEqual(sorted(response.status_code for response in responses), [201, 409])
        conflict = next(response for response in responses if response.status_code == 409)
        self.assertEqual(conflict.json(), {"error": "unavailable"})
        self.assertEqual(self.reservations().count(), 1)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIn(self.instance.borrower_id, (self.user.pk, self.other_user.pk))


class ReservationWebFlowTest(ReservationFixtures, TransactionTestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="web-reserver", password="password")
        self.instance = self.create_book_instance()
        self.unavailable_instance = self.create_book_instance(
            isbn_suffix=2, status=BookInstance.LoanStatus.ON_LOAN
        )

    def ui_url(self, instance=None):
        instance = instance or self.instance
        return f"/catalog/book/{instance.pk}/reserve/"

    def test_book_detail_shows_csrf_form_and_generated_key_only_for_available_copies(self):
        response = Client().get(reverse("book-detail", args=[self.instance.book_id]))
        content = response.content.decode()

        self.assertEqual(response.status_code, 200)
        self.assertIn(f'action="{self.ui_url()}"', content)
        self.assertNotIn(f'action="{self.ui_url(self.unavailable_instance)}"', content)
        self.assertIn('name="csrfmiddlewaretoken"', content)
        self.assertRegex(
            content,
            r'name="idempotency_key" value="[0-9a-f]{32}"',
        )

    def test_anonymous_web_post_redirects_to_login_without_mutation(self):
        response = Client().post(self.ui_url(), {"idempotency_key": "browser-key"})

        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith("/accounts/login/"))
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_authenticated_web_post_checks_csrf_and_shows_confirmation(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        detail = client.get(reverse("book-detail", args=[self.instance.book_id]))
        csrf_match = re.search(
            r'name="csrfmiddlewaretoken" value="([^"]+)"',
            detail.content.decode(),
        )
        self.assertIsNotNone(csrf_match)

        response = client.post(
            self.ui_url(),
            {
                "idempotency_key": "web-reservation-key",
                "csrfmiddlewaretoken": csrf_match.group(1),
            },
            follow=True,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Reservation confirmed")
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)
        self.assertEqual(
            reservation_model(self).objects.filter(key="web-reservation-key").count(),
            1,
        )
