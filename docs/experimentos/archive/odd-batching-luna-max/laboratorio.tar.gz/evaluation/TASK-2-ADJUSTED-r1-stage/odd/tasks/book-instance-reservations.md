# Flujo de reserva de ejemplares

## Specs

### S1 — Persistencia y API

Definir modelo público de persistencia:
- user: ForeignKey a settings.AUTH_USER_MODEL (on_delete=CASCADE u obligatorio).
- instance: ForeignKey a BookInstance (o OneToOneField / ForeignKey, on_delete=CASCADE).
- key: CharField(max_length=100) para la clave de idempotencia.
- created_at: DateTimeField(auto_now_add=True).
- Constraint de unicidad: [user, key] único (UniqueConstraint o unique_together), de modo que claves entre distintos usuarios sean independientes.

API Endpoint: POST /catalog/api/bookinstance/<uuid:pk>/reserve/
- Autenticación: Requiere usuario autenticado. Si no está autenticado, responder 401 Unauthorized con JSON {'error': 'unauthorized'}.
- Método HTTP: Solo POST permitido. GET o cualquier otro método responde 405 Method Not Allowed.
- Header de Idempotencia: Obligatorio 'Idempotency-Key' en encabezados HTTP (o 'HTTP_IDEMPOTENCY_KEY'). Debe ser no vacío tras strip y de longitud <= 100 caracteres. Si falta, está vacío o supera 100 caracteres, responder 400 Bad Request con JSON {'error': 'invalid_key'}.
- Instancia inexistente: Si pk no corresponde a ningún BookInstance existente, responder 404 Not Found con JSON {'error': 'not_found'}.
- Ejemplar no disponible: Si la copia no tiene status='a', responder 409 Conflict con JSON exacto {'error': 'unavailable'}.
- Éxito (primera reserva): Transicionar BookInstance.status a 'r' (Reserved), asignar BookInstance.borrower al usuario actual, registrar la Reservation con la clave provista. Responder 201 Created con JSON exacto:
  {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}
- Replay / Idempotencia exacta: Si el MISMO usuario realiza POST con la MISMA clave 'Idempotency-Key' para la MISMA instancia que ya reservó con esa clave, responder exactamente 201 Created con el mismo JSON {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}, sin duplicar registros de Reservation ni alterar el estado.
- Conflicto de Idempotencia: Si el MISMO usuario intenta reutilizar una 'Idempotency-Key' previamente usada para reservar OTRA instancia diferente, responder 409 Conflict con JSON exacto {'error': 'idempotency_conflict'}.
- Persistencia de idempotencia: La clave debe persistir en la base de datos de modo que un replay en una nueva conexión o sesión HTTP siga retornando 201 Created con el mismo payload.

### S2 — Concurrencia y errores sin mutaciones

Garantía de concurrencia bajo SQLite en disco:
- Dos solicitudes concurrentes de distintos usuarios sobre la misma copia 'a' deben resultar en exactamente un 201 Created y un 409 Conflict (con {'error': 'unavailable'}).
- SQLite no bloquea filas con select_for_update(); la implementación debe asegurar el resultado concurrente real (ej. mediante conditional UPDATE / atomic con verificación de rows_updated, o reintento acotado ante busy/lock) sin devolver 500 'database locked' al cliente.
- Ninguna petición fallida (400, 401, 404, 405, 409) debe mutar el estado de BookInstance ni dejar reservas espurias.

### S3 — Interfaz Web

Interfaz Web (UI):
- En /catalog/book/<int:pk>, para cada copia con status='a', incluir botón/formulario de reserva apuntando a /catalog/book/<uuid:instance_pk>/reserve/.
- POST a /catalog/book/<uuid:instance_pk>/reserve/ debe requerir autenticación (redirigiendo a login si es anónimo).
- Debe incluir token CSRF y un campo hidden con idempotency_key generada para prevenir doble envío accidental en el navegador.
- Al completarse con éxito, mostrar mensaje de confirmación visible en la interfaz (o redirigir al detalle con mensaje flash de éxito).

### S4 — Compatibilidad y límites

Suite original (43 tests) debe seguir pasando intacta. No modificar el comando renew de bibliotecarios ni violar retrocompatibilidad.

Alcance completo validado explícitamente: exactamente las reglas anteriores, sin extensiones. Trabaja solo en este workspace. Carga `ob-odd-workflow` antes de actuar y conserva tu metodología. No uses red ni delegues, no instales dependencias, no hagas commits. Runner disponible: /private/var/folders/d7/z7388kp51w532q4c0rj7hqqh0000gn/T/opencode/real-project-gemini-20261104/.venv/bin/python manage.py test. Si el flujo requiere aprobación pendiente, presenta la propuesta y espera respuesta; no la inventes.

### S5 — Petición original (L1), literal

```text
Implementar flujo de reserva de ejemplares disponibles (BookInstance con status='a') para usuarios autenticados, con persistencia de reservas, garantía de idempotencia en reintentos y tolerancia a concurrencia real bajo SQLite.

CONTRATOS EXACTOS:
1. Modelo público de persistencia:
   Definir modelo Reservation en catalog.models (o exponerlo públicamente allí) con los siguientes campos:
   - user: ForeignKey a settings.AUTH_USER_MODEL (on_delete=CASCADE u obligatorio).
   - instance: ForeignKey a BookInstance (o OneToOneField / ForeignKey, on_delete=CASCADE).
   - key: CharField(max_length=100) para la clave de idempotencia.
   - created_at: DateTimeField(auto_now_add=True).
   - Constraint de unicidad: [user, key] único (UniqueConstraint o unique_together), de modo que claves entre distintos usuarios sean independientes.
2. API Endpoint: POST /catalog/api/bookinstance/<uuid:pk>/reserve/
   - Autenticación: Requiere usuario autenticado. Si no está autenticado, responder 401 Unauthorized con JSON {'error': 'unauthorized'}.
   - Método HTTP: Solo POST permitido. GET o cualquier otro método responde 405 Method Not Allowed.
   - Header de Idempotencia: Obligatorio 'Idempotency-Key' en encabezados HTTP (o 'HTTP_IDEMPOTENCY_KEY'). Debe ser no vacío tras strip y de longitud <= 100 caracteres. Si falta, está vacío o supera 100 caracteres, responder 400 Bad Request con JSON {'error': 'invalid_key'}.
   - Instancia inexistente: Si pk no corresponde a ningún BookInstance existente, responder 404 Not Found con JSON {'error': 'not_found'}.
   - Ejemplar no disponible: Si la copia no tiene status='a', responder 409 Conflict con JSON exacto {'error': 'unavailable'}.
   - Éxito (primera reserva): Transicionar BookInstance.status a 'r' (Reserved), asignar BookInstance.borrower al usuario actual, registrar la Reservation con la clave provista. Responder 201 Created con JSON exacto:
     {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}
   - Replay / Idempotencia exacta: Si el MISMO usuario realiza POST con la MISMA clave 'Idempotency-Key' para la MISMA instancia que ya reservó con esa clave, responder exactamente 201 Created con el mismo JSON {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}, sin duplicar registros de Reservation ni alterar el estado.
   - Conflicto de Idempotencia: Si el MISMO usuario intenta reutilizar una 'Idempotency-Key' previamente usada para reservar OTRA instancia diferente, responder 409 Conflict con JSON exacto {'error': 'idempotency_conflict'}.
   - Persistencia de idempotencia: La clave debe persistir en la base de datos de modo que un replay en una nueva conexión o sesión HTTP siga retornando 201 Created con el mismo payload.
3. Garantía de concurrencia bajo SQLite en disco:
   - Dos solicitudes concurrentes de distintos usuarios sobre la misma copia 'a' deben resultar en exactamente un 201 Created y un 409 Conflict (con {'error': 'unavailable'}).
   - SQLite no bloquea filas con select_for_update(); la implementación debe asegurar el resultado concurrente real (ej. mediante conditional UPDATE / atomic con verificación de rows_updated, o reintento acotado ante busy/lock) sin devolver 500 'database locked' al cliente.
   - Ninguna petición fallida (400, 401, 404, 405, 409) debe mutar el estado de BookInstance ni dejar reservas espurias.
4. Interfaz Web (UI):
   - En /catalog/book/<int:pk>, para cada copia con status='a', incluir botón/formulario de reserva apuntando a /catalog/book/<uuid:instance_pk>/reserve/.
   - POST a /catalog/book/<uuid:instance_pk>/reserve/ debe requerir autenticación (redirigiendo a login si es anónimo).
   - Debe incluir token CSRF y un campo hidden con idempotency_key generada para prevenir doble envío accidental en el navegador.
   - Al completarse con éxito, mostrar mensaje de confirmación visible en la interfaz (o redirigir al detalle con mensaje flash de éxito).
5. Suite original (43 tests) debe seguir pasando intacta. No modificar el comando renew de bibliotecarios ni violar retrocompatibilidad.

Alcance completo validado explícitamente: exactamente las reglas anteriores, sin extensiones. Trabaja solo en este workspace. Carga `ob-odd-workflow` antes de actuar y conserva tu metodología. No uses red ni delegues, no instales dependencias, no hagas commits. Runner disponible: /private/var/folders/d7/z7388kp51w532q4c0rj7hqqh0000gn/T/opencode/real-project-gemini-20261104/.venv/bin/python manage.py test. Si el flujo requiere aprobación pendiente, presenta la propuesta y espera respuesta; no la inventes.
```

## Tasks

- [completed] T1 (S1–S4): Añadir Reservation y migración, endpoints API/UI y formulario/mensaje para reservar; no tocar renew.
- [completed] T2 (S1–S4): Escribir pruebas de contratos, idempotencia, no-mutación y concurrencia SQLite; observar RED antes de implementar.
- [completed] T3 (S1–S4): Ejecutar runner disponible y revisar persistencia, respuestas y compatibilidad; corregir hasta GREEN.

## Log

- L1: Petición original preservada literalmente desde `TASK.md`.
- Exploración: app Django Local Library; SQLite usa `catalog.BookInstance` y el detalle de libro itera `book.bookinstance_set.all`. Se verificó README, `TASK.md`, URLs, vistas, modelo, template, configuración pertinente de SQLite/CSRF/mensajes y migración actual.
- Baseline: `/private/var/folders/d7/z7388kp51w532q4c0rj7hqqh0000gn/T/opencode/real-project-gemini-20261104/.venv/bin/python manage.py test` — 43 tests OK, system check sin problemas.
- Aprobación: no queda gate pendiente; el alcance de implementación fue validado explícitamente.
- T2 RED: 13 pruebas añadidas; test runner inicialmente exponía SQLite compartido en memoria, así que `locallibrary/settings.py` fija un archivo temporal de test para ejercitar locks de SQLite en disco. RED observado: respuestas 404/HTML por rutas aún inexistentes y ausencia del modelo `Reservation`; la comprobación de que la base de test es un archivo ya pasa.
- T1: modelo `Reservation` con unicidad `[user, key]`, migración `0030_reservation`, API JSON, POST web con autenticación/CSRF/mensaje flash y reserva por conditional UPDATE en una transacción con reintentos SQLite limitados. La suite focalizada quedó GREEN: 13 tests OK, incluida carrera de dos usuarios en SQLite de archivo.
- T3: runner completo GREEN: 56 tests OK (43 originales y 13 nuevos); `manage.py check` sin incidencias; `makemigrations --check --dry-run` sin cambios; `git diff --check` limpio. Se verificaron las vistas consumidoras del nuevo helper y no se modificó la implementación de `renew_book_librarian`.
- Risk: none conocido dentro del contrato; la concurrencia de dos usuarios se ejerce contra un archivo SQLite real y no usa `select_for_update()`.
