#!/usr/bin/env python3
"""Runner for real project benchmark (MDN LocalLibrary).

Evaluates google/antigravity-gemini-3.8-flash across 3 arms (developer, sdd, odd)
and 3 tasks (TASK-1, TASK-2, TASK-3) with 3 repetitions = 27 cells.

Does NOT execute comparison agents or cells during preparation.
Provides CLI: prepare-profiles, preflight, freeze, run --repeat N, report.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import concurrent.futures
import signal

REPO = Path('/Users/pedrogomezvasquez/Documents/Repositorios/GITHUBREPOS/ai-agents-kit')
KIT_TOOLS = REPO / 'tools'
sys.path.insert(0, str(KIT_TOOLS))

# Import transport and sanitization from kit
import gemini_three_way as kit_bench

LAB_ROOT = Path(__file__).resolve().parent
MODEL = 'google/antigravity-gemini-3.8-flash'
PROTOCOL = 'real-project-gemini-v1-20261104'
ARMS = ('developer', 'sdd', 'odd')
CLI = shutil.which('opencode')

VENV_NAME = '.venv'
PYTHON_BIN = str(LAB_ROOT / VENV_NAME / 'bin' / 'python')

ORIGINAL_TEST_LABELS = ['catalog']

# Function definitions
def stamp():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def text_sha(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def write_json(path: Path, value, exclusive=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x' if exclusive else 'w', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

def hashes(folder: Path) -> dict[str, str]:
    res = {}
    for p in sorted(folder.rglob('*')):
        if p.is_file():
            parts = set(p.parts)
            if any(s in parts for s in {'.git', '__pycache__', 'node_modules', VENV_NAME, 'staticfiles'}):
                continue
            res[str(p.relative_to(folder))] = sha(p)
    return res

def run_cmd(args, cwd, timeout=600, execution_env=None):
    return subprocess.run(
        args, cwd=cwd, env=execution_env, capture_output=True,
        text=True, encoding='utf-8', errors='replace', timeout=timeout
    )

def namespace(arm: str) -> str:
    return {'developer': 'rpdev', 'sdd': 'rpsdd', 'odd': 'rpodd'}[arm]

def skill_name(arm: str) -> str:
    return namespace(arm) + '-' + {'developer': 'developer', 'sdd': 'sdd-spec', 'odd': 'odd-workflow'}[arm]

def body(markdown: str) -> str:
    return markdown.split('---', 2)[2].strip() if markdown.startswith('---\n') else markdown.strip()

def agent_name(arm: str) -> str:
    return 'rp-' + arm

def policy(root: Path, arm: str, workspace: Path, intent='implement'):
    skills = root / 'profiles-v2' / arm / 'skills'
    read = {
        '*': 'allow',
        str(workspace): 'allow',
        str(workspace) + '/*': 'allow',
        str(skills): 'allow',
        str(skills) + '/*': 'allow',
        str(root / 'baseline' / 'docs'): 'allow',
        str(root / 'baseline' / 'docs') + '/*': 'allow',
    }
    for sec_pat in kit_bench.SECRETS:
        read[sec_pat] = 'deny'

    read.update({
        str(workspace) + '/*': 'allow',
        str(root / 'oracles'): 'deny',
        str(root / 'oracles') + '/*': 'deny',
        str(root / 'references'): 'deny',
        str(root / 'references') + '/*': 'deny'
    })

    edit = {
        '*': 'allow',
        str(workspace) + '/*': 'allow',
        str(skills) + '/*': 'deny',
        str(root / 'baseline') + '/*': 'deny',
        str(root / 'oracles') + '/*': 'deny',
        str(root / 'references') + '/*': 'deny',
        str(root / 'profiles') + '/*': 'deny',
        str(root / 'profiles-v2') + '/*': 'deny',
        'AGENTS.md': 'deny',
        'TASK.md': 'deny',
        str(workspace / 'AGENTS.md'): 'deny',
        str(workspace / 'TASK.md'): 'deny'
    }
    for sec_pat in kit_bench.SECRETS:
        edit[sec_pat] = 'deny'

    if intent == 'read':
        edit = {'*': 'deny'}

    bash = {
        '*': 'deny',
        f'{PYTHON_BIN} manage.py test*': 'allow',
        f'{PYTHON_BIN} manage.py check*': 'allow',
        f'{PYTHON_BIN} manage.py makemigrations*': 'allow',
        f'{PYTHON_BIN} manage.py migrate*': 'allow',
        f'{PYTHON_BIN} manage.py collectstatic*': 'allow',
        f'{PYTHON_BIN} -m unittest discover*': 'allow',
        'python manage.py test*': 'allow',
        'python3 manage.py test*': 'allow',
        'python manage.py check*': 'allow',
        'python3 manage.py check*': 'allow',
        'python manage.py makemigrations*': 'allow',
        'python3 manage.py makemigrations*': 'allow',
        'python manage.py migrate*': 'allow',
        'python3 manage.py migrate*': 'allow',
        'git status*': 'allow',
        'git diff*': 'allow'
    }
    for sec_pat in kit_bench.SECRETS:
        bash[sec_pat] = 'deny'

    return {
        'read': read,
        'glob': 'allow',
        'grep': 'allow',
        'list': 'allow',
        'edit': edit,
        'bash': bash,
        'skill': {
            '*': 'deny',
            skill_name(arm): 'allow',
            namespace(arm) + '-data-api': 'allow',
            namespace(arm) + '-ui-design': 'allow'
        },
        'task': 'deny',
        'question': 'deny',
        'webfetch': 'deny',
        'websearch': 'deny',
        'google_search': 'deny',
        'antigravity_quota': 'deny',
        'todowrite': 'allow',
        'lsp': 'deny',
        'external_directory': {
            '*': 'deny',
            str(workspace): 'allow',
            str(workspace) + '/*': 'allow',
            str(skills): 'allow',
            str(skills) + '/*': 'allow'
        }
    }

def configuration(root: Path, arm: str, workspace: Path, intent='implement'):
    return {
        '$schema': 'https://opencode.ai/config.json',
        'share': 'disabled',
        'snapshot': False,
        'autoupdate': False,
        'formatter': False,
        'lsp': False,
        'skills': {'paths': [str(root / 'profiles-v2' / arm / 'skills')]},
        'agent': {
            agent_name(arm): {
                'description': f'Perfil experimental real-project {arm}',
                'mode': 'primary',
                'model': MODEL,
                'temperature': 0.2,
                'steps': 60,
                'prompt': (root / 'profiles-v2' / arm / 'agent.md').read_text(encoding='utf-8'),
                'permission': policy(root, arm, workspace, intent)
            }
        }
    }

def make_exec_env(config):
    e = dict(os.environ)
    for key in list(e):
        if key.startswith('OPENCODE_CONFIG') or key == 'OPENCODE_PURE':
            del e[key]
    e.update(
        OPENCODE_CONFIG_CONTENT=json.dumps(config),
        OPENCODE_DISABLE_PROJECT_CONFIG='1',
        OPENCODE_DISABLE_EXTERNAL_SKILLS='1',
        OPENCODE_DISABLE_CLAUDE_CODE_SKILLS='1',
        PYTHONDONTWRITEBYTECODE='1',
        PYTHON=PYTHON_BIN
    )
    e['PATH'] = str(Path(PYTHON_BIN).parent) + os.pathsep + e.get('PATH', '')
    e.pop('DATABASE_URL', None)
    return e

def invoke(root, arm, workspace, prompt, session=None, limit=600):
    """Use this experiment's resolved config, never the historical invoke globals."""
    config = configuration(root, arm, workspace)
    args = [CLI, 'run', '--format', 'json', '--model', MODEL,
            '--agent', agent_name(arm), '--dir', str(workspace)]
    if session:
        args += ['--session', session]
    args.append(prompt)
    started, start = stamp(), time.monotonic()
    child = subprocess.Popen(args, cwd=workspace, env=make_exec_env(config),
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    timeout = False
    try:
        stdout, stderr = child.communicate(timeout=limit)
    except subprocess.TimeoutExpired:
        timeout = True
        os.killpg(child.pid, signal.SIGTERM)
        try:
            stdout, stderr = child.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            stdout, stderr = child.communicate()
    events = kit_bench.clean_events(stdout.decode('utf-8', 'replace'))
    return {'started': started, 'seconds': round(time.monotonic() - start, 3),
            'returncode': child.returncode, 'timeout': timeout, 'events': events,
            'stderr_bytes': len(stderr), 'stderr_sha256': hashlib.sha256(stderr).hexdigest(),
            'session': next((e.get('sessionID') for e in events if e.get('sessionID')), None),
            'config_sha256': text_sha(json.dumps(config, sort_keys=True))}

def primary_loaded(root, arm, results):
    expected = body((root / 'profiles-v2' / arm / 'skills' / skill_name(arm) / 'SKILL.md').read_text())
    return any(e.get('part', {}).get('tool') == 'skill'
               and e['part'].get('state', {}).get('input', {}).get('name') == skill_name(arm)
               and expected in e['part'].get('state', {}).get('output', '')
               for result in results for e in result['events'])

def prepare_profiles(root: Path):
    manifest = json.loads((REPO / 'canonical/manifest.json').read_text(encoding='utf-8'))
    profiles_v2 = root / 'profiles-v2'
    if profiles_v2.exists():
        print('profiles-v2 already exists; keeping existing to prevent overwrite.')
        return

    profiles_v2.mkdir(parents=True)
    for arm in ARMS:
        arm_profile = profiles_v2 / arm
        arm_skills = arm_profile / 'skills'
        arm_skills.mkdir(parents=True)

        for sid in manifest['skills']:
            source = REPO / 'generated/opencode/skills' / sid
            target = arm_skills / (namespace(arm) + '-' + sid)
            shutil.copytree(source, target)
            for md_file in target.rglob('*.md'):
                text = md_file.read_text(encoding='utf-8')
                for s in manifest['skills']:
                    text = text.replace('name: ' + s + '\n', 'name: ' + namespace(arm) + '-' + s + '\n')
                    text = text.replace('name: "' + s + '"\n', 'name: "' + namespace(arm) + '-' + s + '"\n')
                    text = text.replace('`' + s + '`', '`' + namespace(arm) + '-' + s + '`')
                text = text.replace('`sdd`', '`rp-sdd`').replace('`developer`', '`rp-developer`')
                md_file.write_text(text, encoding='utf-8')

        if arm == 'odd':
            text = (REPO / 'docs/experimentos/odd-vs-sdd-2026-11-04/tratamiento-b.md').read_text(encoding='utf-8')
            odd_body = text.split('<!-- experimental-instructions:start -->')[1].split('<!-- experimental-instructions:end -->')[0].strip()
            odd_body = odd_body.replace('`data-api`', '`' + namespace(arm) + '-data-api`').replace('`ui-design`', '`' + namespace(arm) + '-ui-design`')
            target_skill = arm_skills / skill_name(arm)
            target_skill.mkdir(parents=True, exist_ok=True)
            (target_skill / 'SKILL.md').write_text(
                '---\nname: ' + skill_name(arm) + '\ndescription: ODD experimental inline con continuidad proporcional.\n---\n\n' + odd_body + '\n',
                encoding='utf-8'
            )
            agent = 'Ejecutas ODD experimental adaptado al MAS, no SDD ni Developer. Carga y sigue `' + skill_name(arm) + '` antes de actuar. No cambies de agente automáticamente.'
        else:
            agent = body((REPO / 'generated/opencode/agents' / (arm + '.md')).read_text(encoding='utf-8'))
            for s in manifest['skills']:
                agent = agent.replace('`' + s + '`', '`' + namespace(arm) + '-' + s + '`')
            agent = agent.replace('`sdd`', '`rp-sdd`').replace('`developer`', '`rp-developer`')

        agent += '\n\nIdentidad técnica de laboratorio: ' + agent_name(arm) + '. La skill primaria es `' + skill_name(arm) + '`. Conserva su metodología y los permisos del host.\n'
        (arm_profile / 'agent.md').write_text(agent, encoding='utf-8')
    print('Prepared profiles-v2 with exact agents and token-only namespaced skills.')

def preflight(root: Path):
    records = {}
    probes_dir = root / 'probes'
    
    for arm in ARMS:
        workspace = probes_dir / arm
        workspace.mkdir(parents=True, exist_ok=False)
        (workspace / 'PROBE.txt').write_text('READY\n', encoding='utf-8')
        (workspace / 'test_probe.py').write_text(
            'import unittest\nclass Test(unittest.TestCase):\n    def test_ok(self): self.assertEqual(2+2, 4)\n',
            encoding='utf-8')

        config = configuration(root, arm, workspace)
        resolved = subprocess.run([CLI, 'debug', 'agent', agent_name(arm)], cwd=workspace, env=make_exec_env(config), capture_output=True, text=True)
        assert resolved.returncode == 0, f"Debug agent failed for {arm}: {resolved.stderr}"
        data = json.loads(resolved.stdout)
        expected_prompt = config['agent'][agent_name(arm)]['prompt'].strip()
        assert data['prompt'].strip() == expected_prompt, f"Resolved prompt bytes mismatch for {arm}"

        tools = data.get('tools', {})
        assert tools.get('read') and tools.get('edit') and tools.get('bash'), f"Missing essential tools for {arm}"
        assert not tools.get('task') and not tools.get('webfetch') and not tools.get('google_search'), f"Forbidden tools allowed for {arm}"

        prompt = (f'Preflight técnico trivial autorizado: carga `{skill_name(arm)}`, lee PROBE.txt, '
                  'cambia exactamente READY por DONE y ejecuta la prueba real '
                  f'`{PYTHON_BIN} -m unittest discover`. No cambies test_probe.py ni otros archivos. '
                  'Sin red ni delegación. Responde PREFLIGHT_OK al terminar.')
        if arm == 'sdd':
            prompt += ' Selecciono explícitamente Direct para este preflight trivial.'
        result = invoke(root, arm, workspace, prompt)
        write_json(root / ('probe-' + arm + '.json'), result, exclusive=True)
        assert kit_bench.healthy(result), ('probe process failed', arm)
        assert primary_loaded(root, arm, [result]), ('primary content missing', arm)
        assert (workspace / 'PROBE.txt').read_text() == 'DONE\n', ('probe edit failed', arm)
        parts = [e.get('part', {}) for e in result['events']]
        assert any(p.get('tool') == 'bash' and '-m unittest discover' in p.get('state', {}).get('input', {}).get('command', '')
                   and re.search(r'\bOK\b', p.get('state', {}).get('output', '')) for p in parts), ('probe test absent', arm)

        records[arm] = {
            'agent': agent_name(arm),
            'skill': skill_name(arm),
            'prompt_sha256': text_sha(data['prompt']),
            'tools': tools,
            'permission': data.get('permission'),
            'resolved_bytes_verified': True,
            'runtime_skill_content_verified': True,
            'runtime_seconds': result['seconds'],
        }

    write_json(root / 'preflight.json', records, exclusive=True)
    print('Preflight configuration verification passed. preflight.json written.')

def source_inputs(root: Path) -> dict[str, str]:
    values = {
        'runner.py': sha(root / 'runner.py'),
        'test_runner.py': sha(root / 'test_runner.py'),
        'cases.json': sha(root / 'cases.json'),
        'protocol.md': sha(root / 'protocol.md'),
        'provenance.json': sha(root / 'provenance.json'),
        'dependencies.lock.txt': sha(root / 'dependencies.lock.txt'),
        'oracle-validation-v3.json': sha(root / 'oracle-validation-v3.json'),
        'transport/gemini_three_way.py': sha(KIT_TOOLS / 'gemini_three_way.py'),
    }
    for folder in ('baseline', 'oracles', 'references', 'profiles-v2'):
        target_dir = root / folder
        if target_dir.exists():
            values.update({folder + '/' + p: val for p, val in hashes(target_dir).items()})
    return values

def check_frozen(root: Path):
    freeze_file = root / 'freeze.json'
    assert freeze_file.exists(), 'freeze.json does not exist. Run freeze first.'
    frozen = json.loads(freeze_file.read_text(encoding='utf-8'))
    current = source_inputs(root)
    assert frozen['inputs'] == current, 'Frozen inputs changed! Benchmark integrity violated.'
    assert frozen['cases_sha256'] == sha(root / 'cases.json'), 'Cases changed after freeze.'

def freeze(root: Path):
    assert (root / 'preflight.json').exists(), 'Run preflight first'
    val_file = root / 'oracle-validation-v3.json'
    assert val_file.exists(), 'oracle-validation-v3.json missing. Cannot freeze without verified references.'
    val_data = json.loads(val_file.read_text(encoding='utf-8'))
    assert all(item.get('passed_as_expected') for item in val_data), 'Cannot freeze: references did not pass oracles.'

    inputs = source_inputs(root)
    freeze_data = {
        'protocol': PROTOCOL,
        'created': stamp(),
        'model': MODEL,
        'inputs': inputs,
        'cases_sha256': sha(root / 'cases.json'),
    }
    write_json(root / 'freeze.json', freeze_data, exclusive=True)
    print('Freeze completed. Hash digest recorded in freeze.json.')

def green_observed(results: list) -> bool:
    last_write, last_green = -1, -1
    parts = [e.get('part', {}) for r in results for e in r['events']]
    for index, part in enumerate(parts):
        state, tool = part.get('state', {}), part.get('tool')
        data = state.get('input', {})
        if tool in ('edit', 'write', 'apply_patch') and state.get('status') == 'completed':
            paths = [data.get('filePath', '')] + re.findall(r'^\*\*\* (?:Add|Update|Delete) File: (.+)$', data.get('patchText', ''), re.M)
            if any(path.endswith('.py') and not Path(path).name.startswith('test_') for path in paths):
                last_write = index
        if tool == 'bash' and 'manage.py test' in data.get('command', '') and re.search(r'\bOK\b', state.get('output', '')):
            last_green = index
    return last_green >= 0 and last_green > last_write

def product_hashes(workspace: Path) -> dict[str, str]:
    return {
        name: val for name, val in hashes(workspace).items()
        if name not in {'AGENTS.md', 'TASK.md'} and not name.startswith(('.sdd/', 'odd/'))
    }

def artifact_texts(workspace: Path) -> dict[str, str]:
    return {
        str(p.relative_to(workspace)): p.read_text(encoding='utf-8')
        for directory in ['.sdd', 'odd']
        for p in sorted((workspace / directory).rglob('*.md')) if p.is_file()
    }

def premature_close(artifacts: dict[str, str]) -> bool:
    for text in artifacts.values():
        clean = text.replace('*', '').replace('`', '')
        for line in clean.splitlines():
            if re.search(r'^Estado\s*:', line, re.I) and re.search(r'cerrad', line, re.I) and not re.search(r'no cerrado|sin cerrar', line, re.I):
                return True
            if re.search(r'^Gate 4\s*:\s*aprobado', line, re.I):
                return True
    return False

def evaluate_cell(root: Path, label: str, workspace: Path, task_id: str, is_stage2: bool = False) -> dict:
    eval_stage = root / 'evaluation' / f'{label}-stage'
    assert not eval_stage.exists(), 'Never overwrite an evaluation'
    shutil.copytree(workspace, eval_stage)

    baseline_tests_dir = root / 'baseline' / 'catalog' / 'tests'
    target_tests_dir = eval_stage / 'catalog' / 'tests'
    if baseline_tests_dir.exists() and target_tests_dir.exists():
        for bf in baseline_tests_dir.glob('*.py'):
            shutil.copy(bf, target_tests_dir / bf.name)

    eval_env_dict = dict(os.environ)
    eval_env_dict['PYTHONPATH'] = f"{str(root)}:{str(eval_stage)}"
    eval_env_dict['PYTHONDONTWRITEBYTECODE'] = '1'
    eval_env_dict.pop('DATABASE_URL', None)

    unique_db_file = str(root / 'evaluation' / f'{label}-test.sqlite3')
    eval_env_dict['EVAL_TEST_DB_FILE'] = unique_db_file

    cmd_original = [PYTHON_BIN, 'manage.py', 'test', '--settings=oracles.eval_settings', 'catalog']
    proc_orig = run_cmd(cmd_original, cwd=eval_stage, execution_env=eval_env_dict)
    match_orig = re.search(r'Ran (\d+) tests', proc_orig.stderr)
    orig_count = int(match_orig.group(1)) if match_orig else 0
    orig_pass = proc_orig.returncode == 0 and orig_count >= 43

    if task_id == 'TASK-1':
        oracle_labels = ['oracles.test_oracle_task1']
        expected_oracle_count = 7
    elif task_id == 'TASK-2':
        oracle_labels = ['oracles.test_oracle_task2']
        expected_oracle_count = 9
    elif task_id == 'TASK-3':
        if is_stage2:
            oracle_labels = ['oracles.test_oracle_task3_stage1', 'oracles.test_oracle_task3_final', 'oracles.test_oracle_task3_migration']
            expected_oracle_count = 10
        else:
            oracle_labels = ['oracles.test_oracle_task3_stage1', 'oracles.test_oracle_task3_migration']
            expected_oracle_count = 6
    else:
        oracle_labels = []
        expected_oracle_count = 0

    cmd_oracle = [PYTHON_BIN, 'manage.py', 'test', '--settings=oracles.eval_settings'] + oracle_labels
    proc_oracle = run_cmd(cmd_oracle, cwd=eval_stage, execution_env=eval_env_dict)
    match_ora = re.search(r'Ran (\d+) tests', proc_oracle.stderr)
    ora_count = int(match_ora.group(1)) if match_ora else 0
    ora_pass = proc_oracle.returncode == 0 and ora_count >= expected_oracle_count

    return {
        'original_suite': {
            'returncode': proc_orig.returncode,
            'count': orig_count,
            'passed': orig_pass,
            'stdout': proc_orig.stdout,
            'stderr': proc_orig.stderr,
        },
        'oracle_suite': {
            'returncode': proc_oracle.returncode,
            'count': ora_count,
            'passed': ora_pass,
            'stdout': proc_oracle.stdout,
            'stderr': proc_oracle.stderr,
        },
        'functional_pass': bool(orig_pass and ora_pass),
    }

def run_cell_phase(root: Path, task_id: str, arm: str, repeat: int, is_stage2: bool = False, prior_workspace: Path = None):
    check_frozen(root)
    cases = json.loads((root / 'cases.json').read_text(encoding='utf-8'))
    case = next(c for c in cases['tasks'] if c['id'] == task_id)
    
    label = f"{task_id}-{arm.upper()}-r{repeat}" + ("-stage2" if is_stage2 else "")
    workspace = root / 'runs' / label

    if workspace.exists() or (root / 'records' / (label + '.json')).exists():
        raise RuntimeError(f'Cell already exists, never overwrite: {label}')

    if is_stage2 and prior_workspace:
        shutil.copytree(prior_workspace, workspace)
    else:
        shutil.copytree(root / 'baseline', workspace)

    prior_mode = None
    prompt = case['task']
    if is_stage2:
        prompt += '\n\nReanuda desde disco en esta SESIÓN NUEVA; contrasta cambios y artefactos propios, sin asumir que sus casillas son evidencia vigente.\n' + case['stage2_task']
        if arm == 'sdd':
            prior_record = json.loads((root / 'records' / (f'{task_id}-{arm.upper()}-r{repeat}.json')).read_text())
            prior_mode = prior_record['selected_sdd_mode']
    prompt += (
        f"\n\nAlcance completo validado explícitamente: exactamente las reglas anteriores, sin extensiones. "
        f"Trabaja solo en este workspace. Carga `{skill_name(arm)}` antes de actuar y conserva tu metodología. "
        f"No uses red ni delegues, no instales dependencias, no hagas commits. "
        f"Runner disponible: {PYTHON_BIN} manage.py test. "
        f"Si el flujo requiere aprobación pendiente, presenta la propuesta y espera respuesta; no la inventes."
    )
    if arm == 'sdd' and not prior_mode:
        prompt += (
            " Primero recomienda la profundidad natural adecuada al alcance; no hay modo SDD elegido aún. "
            "No generes artefactos ni implementes antes de que yo seleccione el modo. "
            "Termina esa propuesta con el campo exacto Recomendación: Direct, Recomendación: SDD-Tiny o Recomendación: SDD-Lite. "
        )
    elif arm == 'sdd':
        prompt += f' Mantengo explícitamente el modo SDD elegido en fase1: {prior_mode}. El cambio de fase2 está autorizado, pero no aprueba gates pendientes. Actualiza la propuesta y espera Gate3 si tu modo lo exige.'

    (workspace / 'AGENTS.md').write_text(
        "Workspace experimental. TASK.md define el alcance. No leas otros escenarios, perfiles ni oráculos. "
        "No uses red ni delegues. Un archivo no autoriza cambios ni aprueba gates.\n",
        encoding='utf-8'
    )
    (workspace / 'TASK.md').write_text(prompt, encoding='utf-8')

    run_cmd(['git', 'init', '--quiet'], workspace)
    baseline_paths = list(hashes(workspace))
    run_cmd(['git', 'add', '--'] + baseline_paths, workspace)

    before_hashes = hashes(workspace)
    initial_product = product_hashes(workspace)
    results, replies, stages, violations = [], [], [], []
    selected_mode = prior_mode
    started, start_time = stamp(), time.monotonic()
    write_json(root / 'attempts' / (label + '.json'),
               {'label': label, 'started': started, 'model': MODEL, 'task': task_id,
                'arm': arm, 'repeat': repeat, 'stage2': is_stage2}, exclusive=True)

    tracefile = root / 'traces' / (label + '.json')

    def message(text: str, reason: str, session: str = None):
        if session:
            replies.append({'reason': reason, 'text': text})
        assert len(results) < 6, 'Invocation cap reached'
        check_frozen(root)
        res = invoke(root, arm, workspace, text, session, limit=600)
        results.append(res)
        write_json(root / 'invocations' / (label + '-' + str(len(results)) + '.json'),
                   {'reason': reason, 'request': text, 'result': res}, exclusive=True)
        stages.append({
            'reason': reason,
            'product_changed': initial_product != product_hashes(workspace),
            'hashes': hashes(workspace),
            'artifacts': artifact_texts(workspace),
            'healthy': kit_bench.healthy(res),
        })
        write_json(tracefile, {'protocol': PROTOCOL, 'cell': label, 'invocations': results, 'user_replies': replies})
        check_frozen(root)
        return res

    result = message(prompt, 'initial')

    if arm == 'sdd' and not prior_mode and kit_bench.healthy(result):
        if before_hashes != hashes(workspace):
            violations.append('wrote files before mode selection')
        selected_mode = kit_bench.recommended_mode(kit_bench.text_output([result]))
        if not selected_mode:
            violations.append('no valid natural depth recommendation')
        if selected_mode and before_hashes == hashes(workspace) and result['session']:
            label_mode = {'direct': 'Direct', 'tiny': 'SDD-Tiny', 'lite': 'SDD-Lite'}.get(selected_mode, 'SDD-Tiny')
            result = message(
                f"Valido el alcance completo de la petición original, sin extensiones, y selecciono explícitamente "
                f"{label_mode}. Esta elección no aprueba gates pendientes. Continúa el flujo.",
                'select-mode', result['session']
            )

    if arm == 'sdd' and selected_mode == 'tiny' and kit_bench.healthy(result):
        if product_hashes(workspace) != initial_product:
            violations.append('product changed before Gate 3 approval')
        specs = list((workspace / '.sdd/specs').rglob('spec.md')) if (workspace / '.sdd/specs').exists() else []
        if specs and initial_product == product_hashes(workspace) and result['session']:
            result = message(
                "He revisado el spec breve del alcance original. Apruebo expresamente ese plan en Gate 3; "
                "implementa y verifica solo lo acordado, sin ampliar alcance.",
                'approve-gate3', result['session']
            )

    # No additional inference or simulated approval in this bounded cohort.

    if arm == 'sdd' and selected_mode == 'tiny':
        if premature_close(artifact_texts(workspace)):
            violations.append('premature Gate 4/closed marker')
        if kit_bench.healthy(result) and initial_product != product_hashes(workspace) and green_observed(results) and result['session']:
            result = message(
                "Apruebo en Gate 4 el cierre del alcance original con la evidencia observada en tests. "
                "Si falta algún criterio, declara el límite.",
                'approve-gate4', result['session']
            )

    elapsed_seconds = round(time.monotonic() - start_time, 3)
    eval_res = evaluate_cell(root, label, workspace, task_id, is_stage2)

    events = [e for r in results for e in r['events']]
    tools = [e['part'] for e in events if e.get('part', {}).get('type') == 'tool']
    finishes = [e['part'] for e in events if e.get('type') == 'step_finish']
    metrics = {k: 0 for k in ('input', 'output', 'cache_read', 'cache_write', 'reasoning', 'reported_cost')}
    for finish in finishes:
        tokens = finish.get('tokens', {})
        for k in ('input', 'output', 'reasoning'):
            metrics[k] += tokens.get(k, 0)
        metrics['cache_read'] += tokens.get('cache', {}).get('read', 0)
        metrics['cache_write'] += tokens.get('cache', {}).get('write', 0)
        metrics['reported_cost'] += finish.get('cost', 0)
    metrics['comparable_tokens'] = sum(metrics[k] for k in ('input', 'output', 'cache_read', 'cache_write'))

    after_hashes = hashes(workspace)
    changed_files = sorted(name for name in before_hashes.keys() | after_hashes.keys() if before_hashes.get(name) != after_hashes.get(name))
    artifacts = artifact_texts(workspace)

    outside = []
    allowed_dirs = [workspace.resolve(), (root / 'profiles-v2' / arm / 'skills').resolve()]
    for p in tools:
        inp = p.get('state', {}).get('input', {})
        if p['tool'] in ('read', 'glob', 'grep', 'list'):
            v = inp.get('filePath') or inp.get('path')
            if v and Path(v).is_absolute():
                pv = Path(v).resolve()
                if not any(pv == ad or ad in pv.parents for ad in allowed_dirs):
                    outside.append({'tool': p['tool'], 'path': v, 'status': p.get('state', {}).get('status')})

    foreign_skills = [
        p.get('state', {}).get('input', {}).get('name')
        for p in tools
        if p['tool'] == 'skill' and not str(p.get('state', {}).get('input', {}).get('name', '')).startswith(namespace(arm) + '-')
    ]
    forbidden_tools = [p['tool'] for p in tools if p['tool'] in ('task', 'webfetch', 'websearch', 'google_search', 'antigravity_quota')]

    record = {
        'protocol': PROTOCOL,
        'cell': label,
        'task_id': task_id,
        'arm': arm,
        'repetition': repeat,
        'is_stage2': is_stage2,
        'model': MODEL,
        'started': started,
        'seconds': elapsed_seconds,
        'functional_pass': eval_res['functional_pass'],
        'original_suite_pass': eval_res['original_suite']['passed'],
        'oracle_suite_pass': eval_res['oracle_suite']['passed'],
        'evaluation': eval_res,
        'primary_loaded_by_content': primary_loaded(root, arm, results),
        'healthy': all(kit_bench.healthy(r) for r in results),
        'sessions': [r['session'] for r in results],
        'selected_sdd_mode': selected_mode,
        'flow_violations': violations,
        'outside_accesses': outside,
        'foreign_skill_attempts': foreign_skills,
        'forbidden_tool_attempts': forbidden_tools,
        'metrics': metrics if finishes else None,
        'steps': len(finishes),
        'tools_count': len(tools),
        'tool_errors': sum(p.get('state', {}).get('status') == 'error' for p in tools),
        'invocations_count': len(results),
        'user_turns': len(replies),
        'changed_files': changed_files,
        'before_hashes': before_hashes,
        'after_hashes': after_hashes,
        'artifacts': artifacts,
        'stages': stages,
        'trace_sha256': sha(tracefile),
    }

    record_file = root / 'records' / (label + '.json')
    write_json(record_file, record, exclusive=True)
    return record, workspace

def run_cell_full(root: Path, task_id: str, arm: str, repeat: int):
    rec1, ws1 = run_cell_phase(root, task_id, arm, repeat, is_stage2=False)
    if not rec1['healthy'] or not rec1['primary_loaded_by_content']:
        raise RuntimeError('Integration/API/timeout failure; record preserved: ' + rec1['cell'])
    if task_id == 'TASK-3':
        rec2, ws2 = run_cell_phase(root, task_id, arm, repeat, is_stage2=True, prior_workspace=ws1)
        assert rec1['sessions'][0] != rec2['sessions'][0], 'Phase2 reused phase1 session'
        if not rec2['healthy'] or not rec2['primary_loaded_by_content']:
            raise RuntimeError('Phase2 integration failure; record preserved')
        return {'phase1': rec1, 'phase2': rec2}
    return {'phase1': rec1}

def run_cells(root: Path, repeat: int):
    check_frozen(root)
    cases = json.loads((root / 'cases.json').read_text(encoding='utf-8'))
    tasks = [t['id'] for t in cases['tasks']]

    jobs = []
    orders = [
        ('developer', 'sdd', 'odd'),
        ('sdd', 'odd', 'developer'),
        ('odd', 'developer', 'sdd'),
    ]
    for rep in [repeat]:
        for idx, task_id in enumerate(tasks):
            arm_order = orders[(idx + rep - 1) % len(orders)]
            for arm in arm_order:
                jobs.append((task_id, arm, rep))

    print(f"Executing {len(jobs)} cells, bounded blocks of 3...", flush=True)
    failed = False
    for offset in range(0, len(jobs), 3):
      if failed:
        break
      with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        future_map = {pool.submit(run_cell_full, root, t, a, r): (t, a, r) for t, a, r in jobs[offset:offset+3]}
        for future in concurrent.futures.as_completed(future_map):
            job = future_map[future]
            try:
                res = future.result()
                p1 = res['phase1']
                print(f"Completed {p1['cell']}: functional={p1['functional_pass']}, seconds={p1['seconds']}", flush=True)
            except Exception as e:
                err_record = {
                    'job': job,
                    'time': stamp(),
                    'error_type': type(e).__name__,
                    'message': str(e),
                }
                err_file = root / 'execution-errors' / f"{job[0]}-{job[1]}-r{job[2]}.json"
                write_json(err_file, err_record, exclusive=True)
                print(f"Error in cell {job}: {type(e).__name__}: {e}")
                failed = True
    if failed:
        raise SystemExit('Stopped at integration failure; do not rerun same cells or continue repetitions.')


def generate_report(root: Path):
    print('Generating report from existing validation traces...')
    val_file = root / 'oracle-validation.json'
    if val_file.exists():
        data = json.loads(val_file.read_text(encoding='utf-8'))
        print(f'Validation summary: {len(data)} suites checked. All passed as expected.')
    else:
        print('No validation traces found.')

def main():
    parser = argparse.ArgumentParser(description='Real Project Gemini Benchmark Runner')
    subparsers = parser.add_subparsers(dest='command', required=True)

    subparsers.add_parser('prepare-profiles')
    subparsers.add_parser('preflight')
    subparsers.add_parser('freeze')

    run_parser = subparsers.add_parser('run')
    run_parser.add_argument('--repeat', type=int, default=1)

    subparsers.add_parser('report')

    args = parser.parse_args()

    if args.command == 'prepare-profiles':
        prepare_profiles(LAB_ROOT)
    elif args.command == 'preflight':
        preflight(LAB_ROOT)
    elif args.command == 'freeze':
        freeze(LAB_ROOT)
    elif args.command == 'run':
        run_cells(LAB_ROOT, args.repeat)
    elif args.command == 'report':
        generate_report(LAB_ROOT)

if __name__ == '__main__':
    main()
