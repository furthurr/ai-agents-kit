# LL-SEARCH — Búsqueda del catálogo (media-baja)

Implementa una búsqueda en el listado público existente `/catalog/books/` de LocalLibrary.

## Comportamiento solicitado

1. El parámetro GET `q` busca una subcadena, sin distinguir mayúsculas/minúsculas,
   en el título del libro **o** el nombre **o** el apellido de su autor. Se recortan
   espacios al principio y al final; no se divide la consulta en palabras.
2. Sin `q`, con `q=` o solo espacios, el listado funciona como antes: todos los
   libros, mismo orden y páginas de diez elementos. Libros sin autor siguen visibles
   y pueden encontrarse por título. No cambies el orden global de los modelos.
3. Añade al listado un formulario GET con etiqueta asociada al campo `name="q"`,
   botón de búsqueda y enlace para limpiar la búsqueda que vuelva a `/catalog/books/`.
   Conserva el texto introducido en el campo usando el escape normal de Django.
   El formulario inicia una búsqueda desde la primera página, sin arrastrar `page`.
4. La paginación de resultados conserva `q` y los demás parámetros GET, correctamente
   codificados. Mantén la paginación de las otras pantallas que comparten plantilla.
5. Cuando una búsqueda no encuentra libros muestra exactamente
   `No books match your search.`; sin filtro y con biblioteca vacía conserva
   `There are no books in the library.`. Las páginas inválidas conservan el 404 existente.
6. Mantén detalles, enlaces, autenticación, permisos y listados de autores y préstamos.
   La búsqueda es pública y de solo lectura; no añade endpoints JSON, migraciones,
   dependencias ni cambios de esquema. Reutiliza el estilo existente.
7. Añade pruebas pertinentes y ejecuta la suite disponible; informa resultados y límites.

El alcance anterior está autorizado para implementación en esta sesión. No se pide
sincronizar documentación, instalar agentes, acceder a servicios externos, delegar,
hacer commits ni publicar. Si tu procedimiento exige presentar un plan y esperar
aprobación antes de implementar, conserva ese procedimiento y declara el punto de parada:
no simules una respuesta del usuario.
