"""Hidden behavioral oracles; only the evaluator receives this module."""
from html.parser import HTMLParser
from urllib.parse import urlsplit, parse_qs

from django.test import TestCase
from django.urls import reverse
from catalog.models import Author, Book


class DOM(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.tags = []
        self.feed(text)

    def handle_starttag(self, tag, attrs):
        self.tags.append((tag, dict(attrs)))


class SearchOracle(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.author = Author.objects.create(first_name='Ada', last_name='Lovelace')
        cls.other = Author.objects.create(first_name='Grace', last_name='Hopper')
        for n in range(13):
            Book.objects.create(title=f'Needle {n:02}', author=cls.author,
                                summary='plain', isbn=f'{n:013}')
        cls.unrelated = Book.objects.create(title='Other volume', author=cls.other,
                                            summary='needle only in summary', isbn='9000000000001')
        cls.orphan = Book.objects.create(title='Orphan title', author=None,
                                         summary='plain', isbn='9000000000002')
        cls.literal = Book.objects.create(title='Space & + / ? café', author=cls.other,
                                          summary='plain', isbn='9000000000003')

    def response(self, **params):
        return self.client.get(reverse('books'), params)

    def ids(self, response):
        self.assertEqual(response.status_code, 200)
        return [b.pk for b in response.context['book_list']]

    def test_title_case_insensitive_trim(self):
        r = self.response(q='  nEeDlE  ')
        self.assertEqual(r.context['paginator'].count, 13)
        self.assertEqual(len(self.ids(r)), 10)

    def test_author_first_name(self):
        self.assertEqual(self.response(q='aDa').context['paginator'].count, 13)

    def test_author_last_name(self):
        self.assertEqual(self.response(q='lOvElAcE').context['paginator'].count, 13)

    def test_no_summary_match(self):
        r = self.response(q='needle', page=2)
        self.assertNotIn(self.unrelated.pk, self.ids(r))
        self.assertEqual(len(self.ids(r)), 3)

    def test_title_without_author(self):
        self.assertEqual(self.ids(self.response(q='orphan')), [self.orphan.pk])

    def test_empty_and_whitespace_preserve_baseline_order(self):
        expected = list(Book.objects.values_list('pk', flat=True)[:10])
        for params in ({}, {'q': ''}, {'q': '   '}):
            with self.subTest(params=params):
                self.assertEqual(self.ids(self.response(**params)), expected)
        self.assertEqual(len(self.ids(self.response(page=2))), 6)

    def test_no_results_and_empty_library_messages(self):
        r = self.response(q='not-present')
        self.assertContains(r, 'No books match your search.')
        self.assertNotContains(r, 'There are no books in the library.')
        Book.objects.all().delete()
        self.assertContains(self.response(), 'There are no books in the library.')

    def test_form_accessible_escaped_and_reset(self):
        term = '\"><script>alert(1)</script>'
        r = self.response(q=term)
        text = r.content.decode()
        tags = DOM(text).tags
        inputs = [a for t, a in tags if t == 'input' and a.get('name') == 'q']
        self.assertEqual(len(inputs), 1)
        self.assertEqual(inputs[0].get('value'), term)
        identifier = inputs[0].get('id')
        self.assertTrue(identifier)
        self.assertTrue(any(t == 'label' and a.get('for') == identifier for t, a in tags))
        self.assertTrue(any(t == 'form' and a.get('method', 'get').lower() == 'get' for t, a in tags))
        self.assertFalse(any(t == 'input' and a.get('name') == 'page' for t, a in tags))
        self.assertTrue(any(t == 'a' and a.get('href') == reverse('books') for t, a in tags))
        self.assertNotIn('<script>alert(1)</script>', text)

    def test_query_not_split_and_special_characters(self):
        self.assertEqual(self.ids(self.response(q='Space & + / ? café')), [self.literal.pk])
        self.assertEqual(self.ids(self.response(q='Ada Lovelace')), [])

    def test_next_previous_preserve_query_and_other_params(self):
        for page, target in ((1, '2'), (2, '1')):
            r = self.response(q='Needle', page=page, source='A&B +/?')
            candidates = [parse_qs(urlsplit(a['href']).query) for t, a in DOM(r.content.decode()).tags
                          if t == 'a' and 'href' in a]
            self.assertTrue(any(q.get('page') == [target] and q.get('q') == ['Needle']
                                and q.get('source') == ['A&B +/?'] for q in candidates))

    def test_invalid_page_404(self):
        for page in ('bad', '0', '99'):
            self.assertEqual(self.response(q='Needle', page=page).status_code, 404)

    def test_shared_authors_pagination_ignores_book_query(self):
        for n in range(12):
            Author.objects.create(first_name='X', last_name=f'Z{n:02}')
        for page, count in ((1, 10), (2, 4)):
            r = self.client.get(reverse('authors'), {'q': 'Needle', 'page': page, 'source': 'A&B'})
            self.assertEqual(r.status_code, 200)
            self.assertEqual(len(r.context['author_list']), count)
            self.assertEqual(r.context['paginator'].count, 14)
            target = '2' if page == 1 else '1'
            candidates = [parse_qs(urlsplit(a['href']).query) for t, a in DOM(r.content.decode()).tags
                          if t == 'a' and 'href' in a]
            self.assertTrue(any(q.get('page') == [target] and q.get('q') == ['Needle']
                                and q.get('source') == ['A&B'] for q in candidates))

    def test_readonly_details_and_auth_unchanged(self):
        before = list(Book.objects.values())
        self.response(q='Needle')
        self.assertEqual(list(Book.objects.values()), before)
        self.assertEqual(self.client.get(self.orphan.get_absolute_url()).status_code, 200)
        self.assertEqual(self.client.get(reverse('my-borrowed')).status_code, 302)

