#!/usr/bin/env python3
"""GPT-6 Luna/Copilot replication of LL-SEARCH only; append-only, no retries."""
import argparse
import json

import six_agent_deepseek_direct as direct
import six_agent_deepseek_fixed as low

MODEL = 'github-copilot/gpt-6-luna'
PACKAGE = direct.REPO / 'docs/experimentos/gpt-6-luna-ll-search-2026-11-06'
ROOT = low.ROOT.parent / 'gpt-6-luna-ll-search-20261106-v1'


def parse_catalog(text):
    marker = MODEL + '\n'
    assert marker in text, 'Exact GPT-6 Luna model absent'
    item, _ = json.JSONDecoder().raw_decode(text.split(marker, 1)[1].lstrip())
    assert (item['providerID'], item['id']) == ('github-copilot', 'gpt-6-luna')
    assert item['capabilities']['toolcall']
    assert item['capabilities']['temperature'] is False
    return {k: item[k] for k in ('id', 'providerID', 'name', 'api', 'limit', 'capabilities', 'variants')}


def engine():
    # Private module instance: do not mutate MAI's module or historical files.
    kernel = direct.module_at('luna6_private_kernel', direct.REPO / 'tools/mai_flash_benchmark.py')
    kernel.MODEL, kernel.PACKAGE, kernel.ROOT = MODEL, PACKAGE, ROOT
    kernel.COHORTS = {k: v for k, v in kernel.COHORTS.items() if k in ('low', 'sdd-low')}
    kernel.SOURCES += ('luna6_ll_search.py', 'test_luna6_ll_search.py', 'luna6_ll_search_report.py',
                       'mai_flash_report.py')
    kernel.parse_catalog = parse_catalog
    previous_summary = kernel.summarize

    def summarize(cohort):
        summary = previous_summary(cohort)
        _, root, _ = kernel.context(cohort)
        for row in summary['rows']:
            if (root / 'records' / (row['arm'] + '.json')).exists():
                record = kernel.load(root / 'records' / (row['arm'] + '.json'))
                row['acceptance'] = record['complete_acceptance']
                if 'Maximum steps reached' in row.get('final_text', ''):
                    row['status'] = 'step_limit_incomplete'
                elif row['arm'] == 'sdd_trial' and not record['complete_acceptance']:
                    row['status'] = 'awaiting_operator_review_not_automatically_a_gate'
        return summary

    kernel.summarize = summarize
    return kernel


def offline(kernel, cohort):
    base, root, source = kernel.context(cohort)
    assert not (root / 'offline.json').exists()
    records = {'real_model_calls': 0, 'profiles': {}}
    for arm in base.ARMS:
        assert base.hashes(root / 'profiles' / arm) == base.hashes(source / 'profiles' / arm)
        process = base.command(root, arm, ['opencode', 'debug', 'agent', base.agent_name(arm), '--pure'])
        assert process.returncode == 0
        resolved = json.loads(process.stdout)
        configured = base.configuration(root, arm)['agent'][base.agent_name(arm)]
        assert resolved['model'] == {'providerID': 'github-copilot', 'modelID': 'gpt-6-luna'}
        assert 'temperature' not in configured and 'variant' not in configured
        if 'prompt' in configured:
            assert resolved['prompt'] == configured['prompt']
        else:
            assert resolved.get('native') and not resolved.get('prompt')
        catalog = base.command(root, arm, ['opencode', 'models', 'github-copilot', '--verbose', '--pure'])
        assert catalog.returncode == 0
        provider = parse_catalog(catalog.stdout)
        skills = base.command(root, arm, ['opencode', 'debug', 'skill', '--pure'])
        assert skills.returncode == 0
        available = json.loads(skills.stdout)
        external = [s for s in available if s['location'] != '<built-in>']
        expected = sorted(p.parent.name for p in (root / 'profiles' / arm / 'skills').glob('*/SKILL.md'))
        assert sorted(s['name'] for s in external) == expected
        proof = kernel.runtime.probe(base, root / 'runtime-probes', arm)
        assert base.hashes(root / 'runs' / arm) == kernel.load(root / 'initial' / (arm + '.json'))
        records['profiles'][arm] = {'provider': provider, 'skills': [s['name'] for s in available], 'probe': proof}
    records['baseline43'] = base.evaluate(root, 'pre-original43', root / 'baseline', include_added=False)
    records['reference56'] = base.evaluate(root, 'pre-reference56', root / 'reference')
    assert records['baseline43']['passed'] and records['baseline43']['tests'] == 43
    assert records['reference56']['passed'] and records['reference56']['tests'] == 56
    base.write_json(root / 'offline.json', records, exclusive=True)
    base.write_json(root / 'freeze.json', {'created': base.stamp(), 'files': kernel.frozen_inputs(base, root)}, exclusive=True)
    print(json.dumps({'offline_passed': cohort, 'real_model_calls': 0, 'model': MODEL}), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['prepare', 'offline', 'check', 'run', 'report', 'export'])
    parser.add_argument('cohort', choices=['low', 'sdd-low', 'all'])
    args = parser.parse_args()
    kernel = engine()
    for cohort in kernel.COHORTS if args.cohort == 'all' else (args.cohort,):
        if args.command == 'offline':
            offline(kernel, cohort)
        elif args.command == 'check':
            base, root, _ = kernel.context(cohort)
            base.check_frozen(root)
        elif args.command == 'report':
            print(json.dumps(kernel.summarize(cohort), ensure_ascii=False, indent=2))
        else:
            getattr(kernel, args.command)(cohort)
    if args.command == 'run' and args.cohort == 'all':
        import luna6_ll_search_report
        luna6_ll_search_report.generate(kernel)


if __name__ == '__main__':
    main()
