#!/usr/bin/env python3
"""Post-run audit only: no model calls, retries or changes to participant code.

Preserves initial exports and corrects their heuristic status in a separate report.
"""
import hashlib
import json
import re
import tarfile
from collections import Counter

import mai_flash_benchmark as lab

NAMES = {'build_sin_mas': 'Build sin MAS', 'build_mas': 'Build con MAS',
         'developer_actual': 'Developer instalado', 'v2': 'Developer v2 candidato2',
         'v2_reforzado': 'Candidato2 + dos refuerzos', 'sdd_trial': 'SDD instalado'}


def stats(result):
    text = result.get('stderr', '') + result.get('stdout', '')
    found = re.search(r'Found (\d+) test', text)
    failures = re.findall(r'^FAIL: ([^\n]+)', text, re.M)
    errors = re.findall(r'^ERROR: ([^\n]+)', text, re.M)
    return {'passed': result['returncode'] == 0, 'executed': result.get('tests'),
            'discovered': int(found.group(1)) if found else None,
            'failure_count': len(failures), 'error_count': len(errors),
            'failure_names': failures, 'error_names': errors}


def verify_archive(base, destination):
    manifest = lab.load(destination / 'manifest.json')
    archive = destination / 'laboratorio.tar.gz'
    assert base.sha(archive) == manifest['archive_sha256']
    with tarfile.open(archive, 'r:gz') as handle:
        members = handle.getmembers()
        assert len(members) == len(manifest['files'])
        assert len({m.name for m in members}) == len(members)
        for member in members:
            assert member.isfile()
            assert hashlib.sha256(handle.extractfile(member).read()).hexdigest() == manifest['files'][member.name]
    return {'members_verified_sha256': len(members), 'archive_sha256': base.sha(archive)}


def classify(cohort, row, record):
    final = row['final_text']
    if 'Maximum steps reached' in final:
        return 'step_limit_incomplete'
    if cohort == 'sdd-high' and not record['changed']:
        # Actual trace is an access/path blockage, NOT an SDD mode/approval gate.
        return 'blocked_wrong_workspace_path'
    if cohort == 'high' and row['arm'] == 'developer_actual' and not record['changed']:
        return 'awaiting_plan_approval_and_path_blockage'
    return 'accepted' if record['complete_acceptance'] else 'delivered_not_accepted'


def describe(row):
    if row['status_reviewed'] == 'step_limit_incomplete':
        return 'Incompleto: límite de 60 pasos'
    if row['status_reviewed'] == 'blocked_wrong_workspace_path':
        return 'Bloqueado: confundió ruta del workspace'
    if row['status_reviewed'] == 'awaiting_plan_approval_and_path_blockage':
        return 'Pausa de plan + bloqueo de ruta; sin entrega'
    if row['acceptance']:
        return 'PASS'
    if row['task'] == 'high':
        return 'FAIL: 401/CSRF y sin tests nuevos'
    if row['arm'] == 'sdd_trial':
        return 'FAIL: fixture propia (Language duplicado)'
    return 'FAIL: pruebas propias'


def number(value, digits=None):
    if digits is None:
        return f'{value:,}'.replace(',', '.')
    return f'{value:.{digits}f}'.replace('.', ',')


def tables(rows):
    output = []
    for task, title in [('low', 'LL-SEARCH — media-baja'), ('high', 'TASK-2 — alta')]:
        output += ['## ' + title, '',
            '| Configuración | Tokens comparables | Tiempo | Pasos | Tests nuevos | Conjunta | Aceptación |',
            '|---|---:|---:|---:|---:|---|---|']
        for row in sorted((r for r in rows if r['task'] == task), key=lambda r: r['tokens']['total']):
            joint = row['joint_reviewed']
            joint_text = (str(joint['executed']) + '/' + str(joint['executed'])) if joint['passed'] else (
                f"{joint['executed']} ejecutados; {joint['failure_count']} fallos, {joint['error_count']} errores")
            output += [f"| {NAMES[row['arm']]} | {number(row['tokens']['total'])} | {number(row['seconds'], 3)} s | "
                f"{row['steps']} | {row['new_test_methods']} | {joint_text} | {describe(row)} |"]
        output.append('')
    return '\n'.join(output)


def main():
    destination = lab.PACKAGE / 'revision-posterior'
    assert not destination.exists(), 'Append-only audit; do not repeat'
    destination.mkdir()
    rows, integrity = [], {}
    for cohort in lab.COHORTS:
        base, root, _ = lab.context(cohort)
        base.check_frozen(root)
        integrity[cohort] = verify_archive(base, lab.PACKAGE / cohort)
        summary = lab.load(lab.PACKAGE / cohort / 'resultados.json')
        for raw in summary['rows']:
            row = dict(raw)
            arm = row['arm']
            record = lab.load(root / 'records' / (arm + '.json'))
            trace = lab.load(root / 'traces' / (arm + '.json'))
            tools = [e['part'] for e in trace['events'] if e.get('part', {}).get('type') == 'tool']
            row['task'] = 'high' if cohort.endswith('high') else 'low'
            row['cohort'] = cohort
            row['status_initial_export'] = row['status']
            row['status_reviewed'] = classify(cohort, row, record)
            row['acceptance'] = record['complete_acceptance']
            row['joint_reviewed'] = stats(record['joint'])
            row['tool_error_counts'] = dict(Counter(p['tool'] for p in tools if p.get('state', {}).get('status') == 'error'))
            row['wrong_shared_python_project_path_attempts'] = sum(
                'real-project-gemini-20261104' in json.dumps(p.get('state', {}).get('input', {}))
                and p['tool'] in ('read', 'glob', 'grep') for p in tools)
            row['no_product_delivery'] = not any(p.startswith(('catalog/', 'templates/')) for p in record['changed'])
            if row['task'] == 'low':
                # Diagnostic isolation of the same 13 oracles, no changed solution.
                proof = base.evaluate(root, arm + '-post-oracle13', root / 'runs' / arm,
                                      subset=['bench_oracles.test_search'])
                row['oracle_reviewed'] = stats(proof)
                base.write_json(destination / cohort / (arm + '-oracle13.json'), proof, exclusive=True)
            else:
                row['oracle_reviewed'] = stats(record['oracle9'])
                row['edges_reviewed'] = stats(record['edges5'])
            if arm == 'sdd_trial':
                spec = root / 'runs' / arm / '.sdd'
                row['sdd_artifacts'] = sorted(str(p.relative_to(root / 'runs' / arm)) for p in base.files(spec)) if spec.exists() else []
            # Keep audit focused; full final text and reads remain in original export.
            row.pop('files_read', None)
            row.pop('final_text', None)
            rows.append(row)
        base.check_frozen(root)
    totals = {'tokens': sum(r['tokens']['total'] for r in rows),
              'reasoning_separate': sum(r['tokens']['reasoning'] for r in rows),
              'seconds': round(sum(r['seconds'] for r in rows), 3), 'steps': sum(r['steps'] for r in rows),
              'initial_invocations': len(rows)}
    data = {'model': lab.MODEL, 'rows': rows, 'totals': totals, 'archive_verification': integrity,
        'inference_calls_during_post_audit': 0,
        'corrections_to_initial_export': [
            'Build con MAS in both tasks reached the native 60-step boundary despite null harness stop_reason.',
            'SDD high did not request an SDD mode gate: it mistook the shared Python environment path for the target workspace.',
            'Developer high requested plan approval and reported path restrictions; it is not a delivered implementation.',
            'SDD low discovered 60 tests but executed only 56 because its class fixture failed; new tests are 4, not zero.'
        ]}
    base.write_json(destination / 'resultados-revisados.json', data, exclusive=True)
    text = '# Resultados MAI-Code-1.1-Flash\n\n'
    text += '**12 invocaciones iniciales; 2 entregas aceptadas en media-baja, 0 en alta.**\n\n'
    text += tables(rows)
    text += '\n## Interpretación y límites\n\n'
    text += ('- Todos conservan 43/43 originales separados y sus métodos AST. Check y consistencia de migraciones pasan.\n'
        '- Media-baja: las entregas de Build sin MAS, candidato2 y SDD pasan los 13 oráculos aislados, '
        'pero fallan sus propias pruebas. Esto no equivale a un defecto funcional externo demostrado. '
        'Build con MAS deja trabajo incompleto y falla 8 de los 13 oráculos.\n'
        '- SDD media-baja: 60 tests descubiertos, 56 ejecutados y un error de setUpClass por crear '
        'Language("English") duplicado. Los cuatro tests nuevos no llegaron a ejecutarse.\n'
        '- Alta: Build sin MAS, candidato2 y reforzado pasan 9/9 oráculos y 52/52 conjunta, '
        'pero no conservan tests nuevos y fallan 1/5 bordes (403 en vez de 401 con CSRF real).\n'
        '- Developer alta solicita aprobación del plan, sin cambios, tras intentos sobre la ruta equivocada. '
        'Es una pausa sin implementación evaluable, no una implementación de reservas fallida.\n'
        '- SDD alta termina bloqueado por confundir el directorio del Python compartido con el workspace. '
        'No pidió selección SDD-Lite ni cargó sdd-spec. El estado automático '
        '`awaiting_user_gate_or_mode_review` del primer exportador era una heurística incorrecta; '
        'la revisión lo corrige sin sobrescribir esa evidencia.\n'
        '- Build con MAS alcanza 60 pasos en ambas tareas; la traza contiene el cierre nativo '
        '“Maximum steps reached” aunque el recolector registra stop_reason=null. No se presenta como terminación completa.\n'
        '- Fricción real: hubo lecturas/rutas/comandos denegados. Varios participantes intentaron inspeccionar '
        'el directorio de la .venv compartida, no su workspace. Los probes sí demostraron acceso permitido '
        'al workspace correcto; no se relajaron permisos ni se corrigieron trayectorias. El prompt heredado '
        'no nombra explícitamente la ruta del workspace, aunque CLI/cwd sí: es una limitación experimental.\n'
        '- Temperatura no soportada en MAI; predeterminado del proveedor y sin variante explícita. '
        'Proveedor, tokenizer y contexto distintos de DeepSeek; n=1, no conclusión causal ni universal.\n'
        '- No se certifica fidelidad procedural completa de ningún perfil. SDD media-baja carga sdd-spec '
        'pero no deja artefactos .sdd en el workspace autorizado.\n'
        '- No hubo reintentos del operador, continuación automática, reparación de participantes ni inferencias auxiliares. '
        'La pausa de Developer y el bloqueo SDD no se reanudaron.\n\n')
    text += f"Total observado: **{number(totals['tokens'])} tokens comparables**, **{number(totals['seconds'], 3)} s**, **{totals['steps']} pasos**. "
    text += 'Reasoning numérico separado; no es factura, preparación/investigador desconocidos.\n\n'
    text += ('Evidencia inicial intacta en low/, high/, sdd-low/ y sdd-high/. '
        'La revisión posterior conserva los oráculos aislados y resultados-revisados.json. '
        'Los cuatro archivos se verificaron íntegramente por SHA256; manifest-revision.json '
        'cubre las auditorías suplementarias y esta revisión. Sin commits/push ni cambios globales.\n')
    (destination / 'RESULTADOS.md').write_text(text)
    supplemental = {}
    for cohort in lab.COHORTS:
        for p in base.files(lab.PACKAGE / cohort / 'audits'):
            supplemental[str(p.relative_to(lab.PACKAGE))] = base.sha(p)
    for p in base.files(destination):
        supplemental[str(p.relative_to(lab.PACKAGE))] = base.sha(p)
    base.write_json(destination / 'manifest-revision.json', {'files': supplemental,
        'original_archives': integrity}, exclusive=True)
    print(text)


if __name__ == '__main__':
    main()
