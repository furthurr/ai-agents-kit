#!/usr/bin/env python3
"""Offline supplemental oracle evaluation and Luna LL-SEARCH evidence report."""
import json

import luna6_ll_search as lab
from mai_flash_report import NAMES, number, stats, verify_archive


def generate(kernel):
    destination = lab.PACKAGE / 'revision'
    assert not destination.exists(), 'Append-only revision'
    destination.mkdir(parents=True)
    rows, integrity = [], {}
    for cohort in kernel.COHORTS:
        base, root, _ = kernel.context(cohort)
        base.check_frozen(root)
        integrity[cohort] = verify_archive(base, lab.PACKAGE / cohort)
        for original in kernel.summarize(cohort)['rows']:
            row = dict(original)
            arm = row['arm']
            if not (root / 'records' / (arm + '.json')).exists():
                rows.append(row)
                continue
            record = kernel.load(root / 'records' / (arm + '.json'))
            proof = base.evaluate(root, arm + '-post-oracle13', root / 'runs' / arm,
                                  subset=['bench_oracles.test_search'])
            base.write_json(destination / cohort / (arm + '-oracle13.json'), proof, exclusive=True)
            row['cohort'] = cohort
            row['joint_reviewed'] = stats(record['joint'])
            row['oracle13_reviewed'] = stats(proof)
            row['no_product_delivery'] = not any(p.startswith(('catalog/', 'templates/')) for p in record['changed'])
            row['procedure_fidelity_certified'] = False
            # Preserve exact final output for human decisions; no automatic approval.
            rows.append(row)
        base.check_frozen(root)
    accepted = sum(r.get('acceptance') is True for r in rows)
    totals = {'tokens': sum((r.get('tokens') or {}).get('total', 0) for r in rows),
        'metrics_complete_all': all(r.get('metrics_complete') for r in rows),
        'seconds': round(sum(r.get('seconds') or 0 for r in rows), 3),
        'steps': sum(r.get('steps') or 0 for r in rows),
        'invocations': sum(r.get('tokens') is not None for r in rows)}
    data = {'model': lab.MODEL, 'rows': rows, 'totals': totals,
        'accepted_deliveries': accepted, 'archive_verification': integrity,
        'post_analysis_inference_calls': 0, 'procedure_fidelity_certified': False}
    base.write_json(destination / 'resultados.json', data, exclusive=True)
    lines = ['# GPT-6 Luna / Copilot — LL-SEARCH (media-baja)', '',
        f"**{totals['invocations']} invocaciones iniciales, {accepted} entregas aceptadas.**", '',
        '| Configuración | Tokens comparables | Tiempo | Pasos | Tests nuevos | Oráculos | Conjunta | Aceptación |',
        '|---|---:|---:|---:|---:|---|---|---|']
    for row in sorted(rows, key=lambda r: (r.get('tokens') or {}).get('total', float('inf'))):
        if 'joint_reviewed' not in row:
            lines.append(f"| {NAMES[row['arm']]} | — | — | — | — | — | — | No ejecutado |")
            continue
        joint, oracle = row['joint_reviewed'], row['oracle13_reviewed']
        joint_text = f"{joint['executed']}/{joint['executed']}" if joint['passed'] else (
            f"{joint['executed']} ejecutados; {joint['failure_count']} fallos, {joint['error_count']} errores")
        oracle_text = '13/13' if oracle['passed'] else f"FAIL ({oracle['failure_count']} fallos, {oracle['error_count']} errores)"
        result = 'PASS' if row['acceptance'] else row['status']
        lines.append(f"| {NAMES[row['arm']]} | {number(row['tokens']['total'])} | {number(row['seconds'], 3)} s | "
            f"{row['steps']} | {row['new_test_methods']} | {oracle_text} | {joint_text} | {result} |")
    lines += ['', '## Alcance y límites', '',
        '- Solo LL-SEARCH. No se ejecutó TASK-2 Alta.',
        '- Mismos snapshots, checkout, tarea, oráculos y allowlists de las pruebas previas; copias nuevas, sin soluciones reutilizadas.',
        '- Modelo nativo `github-copilot/gpt-6-luna`, sin variante explícita. Temperatura no soportada; predeterminado del proveedor.',
        '- 1.800 s / 60 pasos / umbral 5 M tokens por invocación. Sin reintentos, inferencias auxiliares ni respuestas simuladas.',
        '- Una pausa o bloqueo no equivale a implementación fallida ni a permiso para reanudar. Consultar final_text en resultados.json.',
        '- Fidelidad procedural no certificada; aceptación funcional y entrega de pruebas se mantienen separadas.',
        '- n=1, proveedor/tokenizer/caché/latencia distintos; no concluir superioridad universal. Tokens no equivalen a factura.',
        '- Se preserva la fricción del prompt heredado: el Python compartido está fuera del workspace; no se ampliaron permisos.',
        '- Evidencia anterior intacta; sin cambios globales, commits ni push.', '',
        f"Total observado: {number(totals['tokens'])} tokens comparables, {number(totals['seconds'], 3)} s y {totals['steps']} pasos.", '',
        'Ver resultados.json, los dos archivos de evidencia y manifest.json de esta revisión.']
    (destination / 'RESULTADOS.md').write_text('\n'.join(lines) + '\n')
    selected = list(base.files(destination))
    for cohort in kernel.COHORTS:
        selected.extend(base.files(lab.PACKAGE / cohort / 'audits'))
    hashes = {str(p.relative_to(lab.PACKAGE)): base.sha(p) for p in selected}
    base.write_json(destination / 'manifest.json', {'files': hashes, 'original_archives': integrity}, exclusive=True)
    for relative, expected in hashes.items():
        assert base.sha(lab.PACKAGE / relative) == expected
    print('\n'.join(lines), flush=True)


if __name__ == '__main__':
    generate(lab.engine())
