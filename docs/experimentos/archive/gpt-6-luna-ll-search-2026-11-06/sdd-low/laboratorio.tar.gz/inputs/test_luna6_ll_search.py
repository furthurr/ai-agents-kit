import copy
import json
import unittest

import luna6_ll_search as lab
import mai_flash_benchmark as historical


class LunaTests(unittest.TestCase):
    def test_private_adapter_does_not_mutate_mai(self):
        kernel = lab.engine()
        self.assertEqual(historical.MODEL, 'github-copilot/mai-code-1.1-flash')
        self.assertEqual(kernel.MODEL, 'github-copilot/gpt-6-luna')
        self.assertNotEqual(kernel.ROOT, historical.ROOT)
        self.assertEqual(list(kernel.COHORTS), ['low', 'sdd-low'])
        self.assertEqual(sum(len(v[1]) for v in kernel.COHORTS.values()), 6)

    def test_only_model_transport_paths_and_unsupported_temperature_differ(self):
        kernel = lab.engine()
        for cohort in kernel.COHORTS:
            base, root, source = kernel.context(cohort)
            for arm in base.ARMS:
                old = kernel.load(source / 'configs' / (arm + '.json'))
                saved = copy.deepcopy(old)
                text = json.dumps(old).replace(str(source), str(root))
                expected = json.loads(text.replace(str(source).lstrip('/'), str(root).lstrip('/')))
                expected.pop('provider', None)
                expected['enabled_providers'] = ['github-copilot']
                for agent in expected['agent'].values():
                    agent['model'] = lab.MODEL
                    agent.pop('temperature', None)
                self.assertEqual(base.configuration(root, arm), expected)
                self.assertEqual(old, saved)
                self.assertEqual((base.TIMEOUT, base.STEP_LIMIT, base.TOKEN_LIMIT), (1800, 60, 5000000))

    def test_catalog_refuses_wrong_model(self):
        with self.assertRaises(AssertionError):
            lab.parse_catalog('github-copilot/gpt-6-sol\n{}')

    def test_no_high_cohort_is_accepted(self):
        with self.assertRaises(KeyError):
            lab.engine().context('high')


if __name__ == '__main__':
    unittest.main()
