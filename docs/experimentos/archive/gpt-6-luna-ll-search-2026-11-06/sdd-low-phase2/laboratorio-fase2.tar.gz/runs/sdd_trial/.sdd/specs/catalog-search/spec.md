# SDD-Tiny — Búsqueda del catálogo de libros

Modo SDD: tiny
Estado: Planificado
Gate 3: pendiente
Calificación de feature: Esfuerzo previsto del LLM: 4 🟢; referente F04; reglas de coincidencia, límites y regresión de listado/paginación acotados sobre patrones existentes; supuestos: vista de listado y paginación Django actuales permanecen como base; atención: normal; exceeds_x13=false
Profundidad recomendada / seleccionada: SDD-Tiny / SDD-Tiny (elección explícita del usuario)

## Alcance y aceptación

- Objetivo y resultado esperado: permitir que cualquier visitante busque en el listado público `/catalog/books/` sin cambiar la navegación ni los datos del catálogo.
- Comportamientos y criterios verificables:
  1. Con `q` con contenido, el sistema compara la consulta como una sola subcadena, sin distinguir mayúsculas/minúsculas, contra título, nombre o apellido del autor; elimina espacios al principio y al final. No separa la consulta en palabras.
  2. Sin `q`, con `q=` o con solo espacios, el sistema muestra todos los libros en el orden global existente y en páginas de diez. Los libros sin autor permanecen visibles y se encuentran mediante el título.
  3. El listado incluye un formulario GET con etiqueta asociada al campo `name="q"`, botón para buscar y enlace de limpieza a `/catalog/books/`. El campo vuelve a mostrar el texto de consulta con escape HTML normal. Enviar el formulario inicia la búsqueda sin conservar `page`.
  4. Los enlaces de paginación del listado conservan `q` y los demás parámetros GET, con codificación correcta; la paginación compartida de otras pantallas no cambia.
  5. Una búsqueda sin coincidencias muestra exactamente `No books match your search.`. Con biblioteca vacía y sin filtro se conserva exactamente `There are no books in the library.`. Los valores de página inválidos continúan respondiendo 404.
  6. Se conservan detalles y enlaces de libros, autenticación, permisos y listados de autores y préstamos. La búsqueda es pública y de solo lectura.
- Errores y casos límite: consulta vacía/solo espacios; coincidencia en cada campo permitido; autor nulo; caracteres que requieren codificación en enlaces y escape en el campo; página inválida; ausencia de resultados filtrados frente a catálogo vacío sin filtro.
- Invariantes: no se altera el orden global de los modelos; no se cambia persistencia, esquema ni permisos; el filtro afecta solo el listado de libros.
- Exclusiones y supuestos: no se añaden endpoints JSON, migraciones, dependencias, cambios de esquema, sincronización documental ni cambios de configuración de despliegue. Se reutilizan la vista genérica y la paginación existentes.

## Enfoque técnico y estrategia de pruebas

- Enfoque/patrones existentes: limitar el cambio al queryset de la vista del listado de libros, su plantilla y pruebas de vistas; conservar la paginación compartida y sus parámetros GET. No modificar ordenamientos globales ni otras vistas.
- Riesgos e invariantes que requieren pruebas: la búsqueda no debe excluir libros sin autor; las condiciones sobre autor deben combinarse con OR respecto del título; `q` y parámetros adicionales deben sobrevivir a paginación sin afectar otros listados; se deben distinguir vacíos filtrados y no filtrados.
- Estrategia: verificación focalizada con pruebas Django de criterios de búsqueda, normalización, entradas vacías, autor nulo, formularios/limpieza, paginación/codificación, errores 404 y regresión de la paginación compartida. Después ejecutar `python manage.py test catalog` y `python manage.py check` usando los comandos disponibles/autorizados.

## Checklist

- [ ] Implementar el filtrado opcional de `q` y conservar orden, paginación y alcance de libros.
- [ ] Añadir formulario GET, limpieza y mensajes de estado vacío según filtro.
- [ ] Añadir pruebas focalizadas de búsqueda, estados límite y paginación compartida.
- [ ] Ejecutar pruebas de catálogo y comprobación Django; registrar resultados observados.

## Verificación y cierre

- Estado inicial: Planificado; spec creado antes de modificar código de producto.
- Gate 3: pendiente de aprobación explícita del usuario; no se implementará antes de esa aprobación.
- Baseline o comprobación inicial: pendiente; no ejecutada.
- Verificación final: no ejecutada.
- Fallos locales y reparaciones: ninguno observado hasta ahora.
- Excepciones/limitaciones: ejecución de comandos sujeta a permisos efectivos del host; no se declarará resultado si no puede ejecutarse.
- Gate 4: pendiente tras implementar y documentar evidencia.
- Estado final: Planificado.
