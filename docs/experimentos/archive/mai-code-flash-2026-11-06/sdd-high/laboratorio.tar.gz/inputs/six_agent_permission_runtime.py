"""Exercise the actual OpenCode tool pipeline with a scripted localhost provider.

No model is contacted or inferred. Synthetic usage is not experiment performance.
Never record request bodies/headers or raw transport; fixtures contain no secrets.
"""
import copy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import shutil
import subprocess
import threading

import six_agent_workspace_permissions as permissions


def probe(base, root, arm):
    workspace = root / 'runs' / arm
    workspace.mkdir(parents=True)
    (workspace / 'catalog').mkdir()
    (workspace / 'catalog/views.py').write_text('from django.shortcuts import render\n')
    (workspace / 'manage.py').write_text('print("OFFLINE_CHECK_OK")\n')
    if arm != 'build_sin_mas':
        (workspace / 'AGENTS.md').write_text('Offline synthetic permission fixture. No inference.\n')
    reference = root / 'reference'
    reference.mkdir(exist_ok=True)
    (reference / 'outside.txt').write_text('OUTSIDE_FIXTURE_NOT_SECRET\n')
    profile = root / 'profiles' / arm
    base.copy_safe(base.DEFAULT_ROOT / 'profiles' / arm, profile)
    (root / 'hosts' / arm / 'opencode').mkdir(parents=True)
    script = [
        ('read', {'filePath': str(workspace / 'catalog/views.py')}),
        ('edit', {'filePath': str(workspace / 'catalog/views.py'),
                  'oldString': 'from django.shortcuts import render',
                  'newString': 'from django.shortcuts import render\n# OFFLINE_EDIT_OK'}),
        ('write', {'filePath': str(workspace / 'catalog/probe.txt'), 'content': 'OFFLINE_WRITE_OK\n'}),
        ('read', {'filePath': str(reference / 'outside.txt')}),
        ('bash', {'command': base.PYTHON + ' manage.py check'}),
    ]
    if arm != 'build_sin_mas':
        for name in ['data-api', 'ui-design'] + ([] if arm == 'build_mas' else [base.primary(arm)]):
            script.append(('skill', {'name': name}))
        script.append(('read', {'filePath': str(profile / 'skills/data-api/SKILL.md')}))
    count, scripted = [0], [0]
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_POST(self):
            # Consume but do not retain requests. Never inspect auth headers.
            request = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            count[0] += 1
            index = scripted[0]
            # OpenCode also uses the provider for title generation. Those requests
            # have no tools and must not consume a scripted tool response.
            if not request.get('tools'):
                message, finish = {'role': 'assistant', 'content': 'Offline permission fixture'}, 'stop'
            elif index < len(script):
                scripted[0] += 1
                tool, args = script[index]
                calls = [{'index': 0, 'id': 'offline_' + str(index), 'type': 'function',
                          'function': {'name': tool, 'arguments': json.dumps(args)}}]
                message = {'role': 'assistant', 'content': None, 'tool_calls': calls}
                finish = 'tool_calls'
            else:
                message, finish = {'role': 'assistant', 'content': 'OFFLINE_PROBE_DONE'}, 'stop'
            self.send_response(200)
            if request.get('stream'):
                self.send_header('Content-Type', 'text/event-stream')
                self.end_headers()
                chunk = {'id': 'offline-fixture', 'object': 'chat.completion.chunk', 'created': 0,
                         'model': 'permission-probe', 'choices': [{'index': 0, 'delta': message, 'finish_reason': finish}],
                         'usage': {'prompt_tokens': 1, 'completion_tokens': 1, 'total_tokens': 2}}
                self.wfile.write(('data: ' + json.dumps(chunk) + '\n\ndata: [DONE]\n\n').encode())
            else:
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                value = {'id': 'offline-fixture', 'object': 'chat.completion', 'created': 0,
                         'model': 'permission-probe', 'choices': [{'index': 0, 'message': message, 'finish_reason': finish}],
                         'usage': {'prompt_tokens': 1, 'completion_tokens': 1, 'total_tokens': 2}}
                self.wfile.write(json.dumps(value).encode())
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    cfg = copy.deepcopy(base.configuration(root, arm))
    identifier = 'offline-permission-probe'
    cfg['provider'] = {identifier: {'npm': '@ai-sdk/openai-compatible',
        'options': {'baseURL': f'http://127.0.0.1:{server.server_port}/v1', 'apiKey': 'offline-placeholder'},
        'models': {'probe': {'name': 'Scripted tool fixture, not a model', 'toolcall': True,
                             'limit': {'context': 1000000, 'output': 1000}}}}}
    cfg['enabled_providers'] = [identifier]
    cfg['agent'][base.agent_name(arm)]['model'] = identifier + '/probe'
    cfg['agent'][base.agent_name(arm)]['steps'] = 20
    try:
        process = subprocess.run(['opencode', 'run', '--pure', '--format', 'json', '--model', identifier + '/probe',
                                  '--title', 'Offline synthetic permission fixture',
                                  '--agent', base.agent_name(arm), '--dir', str(workspace),
                                  'Offline scripted tool permission fixture. No inference.'],
                                 cwd=workspace, env=base.environment(root, arm, cfg),
                                 capture_output=True, text=True, timeout=120)
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
    events = base.clean_events(process.stdout)
    tools = [e['part'] for e in events if e.get('part', {}).get('type') == 'tool']
    errors = [e for e in events if e.get('type') == 'error']
    statuses = [p.get('state', {}).get('status') for p in tools]
    expected = ['completed', 'completed', 'completed', 'error', 'completed'] + ['completed'] * (len(script)-5)
    result = {'arm': arm, 'synthetic_localhost_only': True, 'real_model_calls': 0,
              'requests_to_scripted_stub': count[0], 'process_returncode': process.returncode,
              'scripted_tool_responses': scripted[0],
              'expected_statuses': expected, 'observed_statuses': statuses,
              'tools': [{'tool': p['tool'], 'status': p.get('state', {}).get('status'),
                         'error_category': p.get('state', {}).get('error_category')} for p in tools],
              'api_errors_sanitized': errors,
              'edited': '# OFFLINE_EDIT_OK' in (workspace / 'catalog/views.py').read_text(),
              'written': (workspace / 'catalog/probe.txt').exists()}
    result['passed'] = process.returncode == 0 and statuses == expected and result['edited'] and result['written'] and not errors
    base.write_json(root / (arm + '-proof.json'), result, exclusive=True)
    assert result['passed'], result
    return result
