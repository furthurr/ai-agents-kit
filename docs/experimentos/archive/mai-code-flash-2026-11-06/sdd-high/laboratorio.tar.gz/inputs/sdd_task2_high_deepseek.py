#!/usr/bin/env python3
"""Append-only SDD TASK-2 alta operator. Reuses the frozen high evaluator.

One real invocation, no retries, no simulated approvals. The participant may
pause at a real gate; the operator stops instead of fabricating a user answer.
"""
import argparse
import json
from pathlib import Path
import shutil

import five_agent_deepseek_high as high
import six_agent_deepseek_direct as direct
import six_agent_deepseek_fixed as low
import six_agent_workspace_permissions as permissions

REPO = direct.REPO
ROOT = low.ROOT.parent / 'sdd-task2-high-deepseek-20261106-v2'
PACKAGE = REPO / 'docs/experimentos/sdd-task2-high-deepseek-2026-11-06'
ARM = 'sdd_trial'
SOURCES = ('sdd_task2_high_deepseek.py', 'test_sdd_task2_high_deepseek.py',
           'five_agent_deepseek_high.py', 'five_agent_deepseek_high_report.py',
           'six_agent_deepseek.py', 'six_agent_deepseek_direct.py',
           'six_agent_deepseek_fixed.py', 'six_agent_workspace_permissions.py',
           'six_agent_permission_runtime.py', 'gemini_three_way.py')
HISTORY = high.HISTORY
HIGH_PACKAGE = high.PACKAGE


def configuration(base, root, arm):
    assert arm == ARM
    cfg = base.common_configuration(root, ARM)
    agent = cfg['agent'][base.agent_name(ARM)]
    agent['model'] = direct.MODEL
    agent['permission']['skill'] = {'*': 'deny', 'data-api': 'allow',
                                    'ui-design': 'allow', 'sdd-spec': 'allow'}
    cfg['provider'] = direct.transport()
    cfg['enabled_providers'] = ['deepseek']
    workspace = root / 'runs' / arm
    skills = root / 'profiles' / arm / 'skills'
    for operation in ('read', 'edit'):
        rules = agent['permission'][operation]
        guards = {k: v for k, v in rules.items() if v == 'deny' and k != '*'}
        for form in permissions.resource_forms(workspace / '.sdd', workspace):
            rules[form] = 'allow'
            rules[form + '/*'] = 'allow'
        for key, value in guards.items():
            rules.pop(key, None)
            rules[key] = value
    return cfg


def check(base, root):
    assert base.freeze_inputs(root) == json.loads((root / 'freeze.json').read_text())['files']
    for name in SOURCES:
        assert base.sha(REPO / 'tools' / name) == base.sha(root / 'inputs' / name)
    low.context().check_frozen(low.ROOT)


def context():
    base = high.context()
    base.common_configuration = base.configuration
    base.configuration = lambda root, arm: configuration(base, root, arm)
    base.ARMS, base.ALL_ARMS = (ARM,), (ARM,)
    base.primary = lambda arm: 'sdd-spec'
    base.DEFAULT_ROOT = ROOT
    base.check_frozen = lambda root: check(base, root)
    return base


def prepare(base):
    low.context().check_frozen(low.ROOT)
    assert not ROOT.exists(), 'Never overwrite an experiment'
    ROOT.mkdir()
    (ROOT / 'inputs').mkdir()
    for name in SOURCES:
        shutil.copyfile(REPO / 'tools' / name, ROOT / 'inputs' / name)
    # Frozen inputs of the five-arm high cohort: same literal task, oracles and
    # reference overlay. No participant solution is reused.
    for name in ('tarea.md', 'oracle_edges.py'):
        shutil.copyfile(HIGH_PACKAGE / name, ROOT / 'inputs' / name)
    shutil.copyfile(HISTORY / 'oracles/test_oracle_task2.py', ROOT / 'inputs/oracle_search.py')
    shutil.copyfile(REPO / 'tools/six_agent_deepseek.py', ROOT / 'inputs/runner.py')
    shutil.copyfile(REPO / 'tools/gemini_three_way.py', ROOT / 'inputs/sanitizer_source.py')
    base.copy_safe(low.ROOT / 'baseline', ROOT / 'baseline')
    base.copy_safe(ROOT / 'baseline', ROOT / 'reference')
    for folder in ('catalog', 'templates'):
        high.copy_overlay(base, HISTORY / 'references/TASK-2' / folder, ROOT / 'reference' / folder)
    base.copy_safe(low.ROOT / 'mas-context', ROOT / 'mas-context')
    workspace = ROOT / 'runs' / ARM
    base.copy_safe(ROOT / 'baseline', workspace)
    high.copy_overlay(base, ROOT / 'mas-context', workspace)
    previous_readme = low.ROOT / 'runs/build_mas/README.md'
    initial = json.loads((low.ROOT / 'initial/build_mas.json').read_text())
    assert base.sha(previous_readme) == initial['README.md']
    shutil.copyfile(previous_readme, workspace / 'README.md')
    profile = ROOT / 'profiles' / ARM
    profile.mkdir(parents=True)
    agent_source = base.INSTALLED / 'agent/sdd.md'
    shutil.copyfile(agent_source, profile / 'installed-agent-source.md')
    (profile / 'agent.md').write_text(base.body(agent_source.read_text()) + '\n')
    for name in ('sdd-spec', 'data-api', 'ui-design'):
        base.copy_safe(base.INSTALLED / 'skills' / name, profile / 'skills' / name)
    (ROOT / 'hosts' / ARM / 'opencode').mkdir(parents=True)
    base.write_json(ROOT / 'initial' / (ARM + '.json'), base.hashes(workspace), exclusive=True)
    base.write_json(ROOT / 'configs' / (ARM + '.json'), base.configuration(ROOT, ARM), exclusive=True)
    base.write_json(ROOT / 'sources.json', {
        'captured_at': base.stamp(), 'previous_cohort': str(low.ROOT),
        'high_cohort': str(high.ROOT), 'task_source': str(HIGH_PACKAGE / 'tarea.md'),
        'historical_oracle': str(HISTORY / 'oracles/test_oracle_task2.py'),
        'reference_overlay': str(HISTORY / 'references/TASK-2'),
        'installed_agent_path': str(agent_source), 'installed_agent_sha256': base.sha(agent_source),
        'installed_skill_hashes': {name: base.hashes(base.INSTALLED / 'skills' / name)
                                  for name in ('sdd-spec', 'data-api', 'ui-design')},
        'source_commit': '3120b4302bf87a1b8c84d06662c2b8787f7da5f8',
        'fixture': 'exact experimental MAS, not a historical bootstrap',
        'temporal_extension': True}, exclusive=True)
    base.write_json(ROOT / 'budget.json', {
        'authorized_initial_invocations': 1, 'model': direct.MODEL,
        'provider': 'deepseek', 'api': 'https://api.deepseek.com',
        'temperature': 0.2, 'explicit_variant': None,
        'timeout_seconds': 1800, 'steps': 60, 'token_boundary': 5000000,
        'retries': 0, 'auxiliary_inference': False, 'simulated_approvals': False,
        'resume_requires_actual_user_response': True}, exclusive=True)
    shutil.copyfile(low.ROOT / 'mas-files.json', ROOT / 'mas-files.json')
    base.write_json(ROOT / 'sdd-pending.json', {'state': 'prepared_for_this_extension',
                    'launched': False, 'simulated_approvals': 0,
                    'note': 'SDD high arm added after the frozen five-arm cohort'}, exclusive=True)
    kernel = (REPO / 'tools/six_agent_permission_runtime.py').read_text()
    assert kernel.count("'catalog/probe.txt'") == 2
    kernel = kernel.replace("'catalog/probe.txt'", "'.sdd/specs/offline-probe/requirements.md'")
    assert kernel.count("base.PYTHON + ' manage.py check'") == 1
    kernel = kernel.replace("base.PYTHON + ' manage.py check'", "base.PYTHON + ' manage.py makemigrations catalog'")
    seam = "    if arm != 'build_sin_mas':\n        for name in"
    assert kernel.count(seam) == 1
    kernel = kernel.replace(seam, "    script.append(('bash', {'command': base.PYTHON + ' manage.py migrate'}))\n" + seam)
    kernel = kernel.replace(seam, "    script.append(('write', {'filePath': str(workspace / 'catalog/migrations/0030_offline_probe.py'), 'content': '# Synthetic permission probe only\\n'}))\n" + seam)
    (ROOT / 'inputs/high-runtime.py').write_text(kernel)
    print(json.dumps({'prepared': str(ROOT), 'real_model_calls': 0}))


def offline(base):
    records = {}
    assert base.hashes(ROOT / 'baseline') == base.hashes(low.ROOT / 'baseline')
    assert base.hashes(ROOT / 'reference') == base.hashes(high.ROOT / 'reference')
    records['original43'] = high.evaluate(base, ROOT, 'baseline-original', ROOT / 'baseline', 'original')
    records['baseline_oracle9'] = high.evaluate(base, ROOT, 'baseline-absent-feature', ROOT / 'baseline', 'oracle')
    records['reference_oracle9'] = high.evaluate(base, ROOT, 'reference-oracle9', ROOT / 'reference', 'oracle')
    records['reference_joint52'] = high.evaluate(base, ROOT, 'reference-joint52', ROOT / 'reference')
    records['reference_edges5'] = high.evaluate(base, ROOT, 'reference-edges5', ROOT / 'reference', 'edges')
    assert records['original43']['passed'] and records['original43']['tests'] == 43
    assert not records['baseline_oracle9']['passed']
    assert records['reference_oracle9']['passed'] and records['reference_oracle9']['tests'] == 9
    assert records['reference_joint52']['passed'] and records['reference_joint52']['tests'] == 52
    variants = {
        'auth': ([("{'error': 'unauthorized'}, status=401", "{'error': 'unauthorized'}, status=200")],
                 'test_api_auth_required'),
        'replay': ([('if existing_res:', 'if False and existing_res:'),
                    ('if check_replay and str(check_replay.instance_id)',
                     'if False and check_replay and str(check_replay.instance_id)')],
                   'test_api_successful_reserve_and_replay_idempotency'),
        'conditional-update': ([('filter(pk=pk, status=BookInstance.LoanStatus.AVAILABLE).update(',
                                 'filter(pk=pk).update(')], 'test_api_unavailable_copy'),
    }
    for name, (changes, test) in variants.items():
        folder = ROOT / 'mutations' / name
        base.copy_safe(ROOT / 'reference', folder)
        target = folder / 'catalog/views.py'
        text = target.read_text()
        for before, after in changes:
            assert before in text
            text = text.replace(before, after)
        target.write_text(text)
        proof = high.evaluate(base, ROOT, 'mutation-' + name, folder, 'oracle',
                              ['bench_oracles.test_high.Task2OracleModelAndApiTest.' + test])
        assert not proof['passed'], 'Oracle insensitive to mutation ' + name
        records['mutation-' + name] = proof
    resolved = base.command(ROOT, ARM, ['opencode', 'debug', 'agent', base.agent_name(ARM), '--pure'])
    assert resolved.returncode == 0, 'Agent resolution failed'
    agent = json.loads(resolved.stdout)
    assert agent['prompt'] == (ROOT / 'profiles' / ARM / 'agent.md').read_text()
    skills = base.command(ROOT, ARM, ['opencode', 'debug', 'skill', '--pure'])
    assert skills.returncode == 0
    external = [item for item in json.loads(skills.stdout) if item['location'] != '<built-in>']
    assert sorted(item['name'] for item in external) == ['data-api', 'sdd-spec', 'ui-design']
    for item in external:
        assert str(ROOT / 'profiles' / ARM / 'skills') in item['location']
    catalog = base.command(ROOT, ARM, ['opencode', 'models', 'deepseek', '--verbose', '--pure'])
    assert catalog.returncode == 0
    provider = direct.parse_catalog(catalog.stdout)
    cfg = base.configuration(ROOT, ARM)
    assert cfg == json.loads((ROOT / 'configs' / (ARM + '.json')).read_text())
    assert cfg['enabled_providers'] == ['deepseek']
    assert 'openrouter' not in json.dumps(cfg).lower()
    runtime = direct.module_at('sdd_high_runtime', ROOT / 'inputs/high-runtime.py')
    records['runtime_proof'] = runtime.probe(base, ROOT / 'runtime-probes', ARM)
    assert base.hashes(ROOT / 'runs' / ARM) == json.loads((ROOT / 'initial' / (ARM + '.json')).read_text())
    records.update(provider=provider, agent_prompt_exact=True,
                   skills=[item['name'] for item in external], real_model_calls=0)
    base.write_json(ROOT / 'offline.json', records, exclusive=True)
    base.write_json(ROOT / 'freeze.json', {'created': base.stamp(),
                    'files': base.freeze_inputs(ROOT)}, exclusive=True)
    print(json.dumps({'offline_passed': True, 'real_model_calls': 0, 'frozen': True}))


def run(base):
    assert not (ROOT / 'calls' / (ARM + '.json')).exists(), 'No retries or automatic continuation'
    trace = base.invoke(ROOT, ARM)
    record = high.evaluate_arm(base, ROOT, ARM)
    final_text = '\n'.join(e['part']['text'] for e in trace['events'] if e.get('type') == 'text')
    sessions = sorted({e['sessionID'] for e in trace['events'] if e.get('sessionID')})
    state = 'halted' if trace['stop_reason'] else 'awaiting_operator_review'
    base.write_json(ROOT / 'operator-state.json', {
        'state': state, 'session_ids': sessions, 'final_text': final_text,
        'measurement': trace['measurement'], 'seconds': trace['seconds'],
        'stop_reason': trace['stop_reason'], 'simulated_approvals': 0,
        'complete_acceptance': record['complete_acceptance'],
        'primary_acceptance': record['primary_acceptance'],
        'extended_contract_pass': record['extended_contract_pass'],
        'note': 'A gate or plan pause is not a functional failure; no answer was fabricated.'}, exclusive=True)
    print(json.dumps({'state': state, 'measurement': trace['measurement'],
                      'seconds': trace['seconds'], 'stop_reason': trace['stop_reason'],
                      'primary_acceptance': record['primary_acceptance'],
                      'extended_contract_pass': record['extended_contract_pass'],
                      'new_tests': record['tests_changed'],
                      'final_text': final_text}, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['prepare', 'offline', 'check', 'run'])
    args = parser.parse_args()
    base = context()
    {'prepare': lambda: prepare(base), 'offline': lambda: offline(base),
     'check': lambda: check(base, ROOT), 'run': lambda: run(base)}[args.command]()


if __name__ == '__main__':
    main()
