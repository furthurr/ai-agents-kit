#!/usr/bin/env python3
"""New direct-provider cohort; reuse a private copy of the frozen pilot engine."""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess

REPO = Path(__file__).resolve().parent.parent
PACKAGE = REPO / 'docs/experimentos/seis-agentes-deepseek-directo-2026-11-06'
PRIOR_PACKAGE = REPO / 'docs/experimentos/seis-agentes-deepseek-2026-11-06'
ROOT = Path('/var/folders/d7/z7388kp51w532q4c0rj7hqqh0000gn/T/opencode/six-agent-deepseek-direct-20261106-v1').resolve()
MODEL = 'deepseek/deepseek-flash'


def module_at(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def transport():
    # Public catalog definition only; host auth remains managed by OpenCode.
    return {'deepseek': {'name': 'DeepSeek', 'npm': '@ai-sdk/openai-compatible',
        'options': {'baseURL': 'https://api.deepseek.com'},
        'models': {'deepseek-flash': {'id': 'deepseek-flash', 'name': 'DeepSeek V4.1 Flash 1017',
            'family': 'deepseek-flash', 'release_date': '2026-10-17',
            'reasoning': True, 'temperature': True, 'toolcall': True, 'attachment': True,
            'interleaved': {'field': 'reasoning_content'},
            'modalities': {'input': ['text', 'image'], 'output': ['text']},
            'cost': {'input': 0.15, 'output': 0.6, 'cache_read': 0.003, 'cache_write': 0},
            'limit': {'context': 1048576, 'output': 393216},
            'variants': {key: {'reasoningEffort': key} for key in ('low', 'high', 'max')}}}}}


def parse_catalog(text):
    marker = 'deepseek/deepseek-flash\n'
    assert marker in text, 'Exact direct-provider model absent'
    data, _ = json.JSONDecoder().raw_decode(text.split(marker, 1)[1].lstrip())
    assert data['providerID'] == 'deepseek' and data['id'] == 'deepseek-flash'
    assert data['name'] == 'DeepSeek V4.1 Flash 1017'
    assert data['api'] == {'id': 'deepseek-flash', 'url': 'https://api.deepseek.com', 'npm': '@ai-sdk/openai-compatible'}
    return {k: data[k] for k in ('id', 'providerID', 'name', 'api', 'limit', 'capabilities', 'variants')}


def context():
    base = module_at('direct_private_pilot', REPO / 'tools/six_agent_deepseek.py')
    base.MODEL, base.PACKAGE, base.DEFAULT_ROOT = MODEL, PACKAGE, ROOT
    original_configuration = base.configuration

    def configuration(root, arm):
        cfg = original_configuration(root, arm)
        cfg['provider'] = transport()
        cfg['enabled_providers'] = ['deepseek']
        return cfg

    base.configuration = configuration
    old_check = base.check_frozen

    def check(root):
        old_check(root)
        for name in ('six_agent_deepseek_direct.py', 'test_six_agent_deepseek_direct.py'):
            assert base.sha(REPO / 'tools' / name) == base.sha(root / 'inputs' / name), 'Direct adapter changed after freeze'
    base.check_frozen = check
    return base


def prepare(base, root):
    for name in ('tarea.md', 'oracle_search.py'):
        target = PACKAGE / name
        assert not target.exists(), 'Never overwrite experiment inputs'
        shutil.copyfile(PRIOR_PACKAGE / name, target)
        assert base.sha(target) == base.sha(PRIOR_PACKAGE / name)
    base.prepare(root)
    for name in ('six_agent_deepseek_direct.py', 'test_six_agent_deepseek_direct.py'):
        shutil.copyfile(REPO / 'tools' / name, root / 'inputs' / name)
    process = subprocess.run(['opencode', 'models', 'deepseek', '--verbose'],
                             capture_output=True, text=True, timeout=120)
    assert process.returncode == 0
    base.write_json(root / 'inputs/provider-host.json', parse_catalog(process.stdout), exclusive=True)
    base.write_json(root / 'inputs/cohort.json', {'new_budget_explicitly_approved': True,
                    'prior_attempt_excluded': 'HTTP402 OpenRouter; not a performance control',
                    'model': MODEL, 'variant': 'provider default, no explicit variant',
                    'automatic': 5, 'manual_sdd_reserved': 1}, exclusive=True)


def offline(base, root):
    base.offline(root)
    resolved = {}
    for arm in base.ARMS:
        process = base.command(root, arm, ['opencode', 'models', 'deepseek', '--verbose', '--pure'])
        assert process.returncode == 0
        resolved[arm] = parse_catalog(process.stdout)
        cfg = base.configuration(root, arm)
        assert cfg == json.loads((root / 'configs' / (arm + '.json')).read_text())
        assert cfg['enabled_providers'] == ['deepseek']
        assert 'apiKey' not in json.dumps(cfg['provider'])
    base.write_json(root / 'inputs/provider-isolated.json', resolved, exclusive=True)
    print('Direct DeepSeek provider resolved identically in all five profiles; no inference.')


def report(base, root, export=False):
    reporter = module_at('direct_private_reporter', REPO / 'tools/six_agent_deepseek_report.py')
    reporter.lab = base
    if export:
        reporter.export(root, PACKAGE / 'evidencia')
    else:
        print(json.dumps(reporter.summarize(root), ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['prepare', 'offline', 'freeze', 'check', 'run', 'report', 'export'])
    parser.add_argument('--background', action='store_true')
    args = parser.parse_args()
    base = context()
    if args.background:
        assert args.command == 'run'
        child = subprocess.Popen([base.PYTHON, '-B', str(Path(__file__)), 'run'],
                                 stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 start_new_session=True)
        print(json.dumps({'pid': child.pid, 'root': str(ROOT), 'model': MODEL}))
        return
    actions = {'prepare': lambda: prepare(base, ROOT), 'offline': lambda: offline(base, ROOT),
               'freeze': lambda: base.freeze(ROOT), 'check': lambda: base.check_frozen(ROOT),
               'run': lambda: base.run(ROOT), 'report': lambda: report(base, ROOT),
               'export': lambda: report(base, ROOT, True)}
    actions[args.command]()


if __name__ == '__main__':
    main()
