import json
import threading
import uuid
from pathlib import Path
from django.test import TestCase, TransactionTestCase, Client
from django.contrib.auth import get_user_model
from django.db import connection, connections
from django.apps import apps

User = get_user_model()

class Task2OracleModelAndApiTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        Author = apps.get_model('catalog', 'Author')
        Book = apps.get_model('catalog', 'Book')
        BookInstance = apps.get_model('catalog', 'BookInstance')

        cls.user1 = User.objects.create_user(username='alice', password='password123')
        cls.user2 = User.objects.create_user(username='bob', password='password123')
        cls.author = Author.objects.create(first_name='Leo', last_name='Tolstoy')
        cls.book = Book.objects.create(
            title='War and Peace',
            author=cls.author,
            summary='Historical epic.',
            isbn='1234567890123'
        )
        cls.copy_available = BookInstance.objects.create(
            book=cls.book,
            imprint='Moscow 1869',
            status='a'
        )
        cls.copy_maintenance = BookInstance.objects.create(
            book=cls.book,
            imprint='Moscow 1869',
            status='m'
        )

    def setUp(self):
        self.client = Client()

    def test_reservation_model_fields_and_uniqueness(self):
        try:
            Reservation = apps.get_model('catalog', 'Reservation')
        except LookupError:
            self.fail('Reservation model not found in catalog.models')

        # Public contract: Reservation has user, instance, key, created_at, unique(user, key)
        r1 = Reservation.objects.create(
            user=self.user1,
            instance=self.copy_available,
            key='test-key-1'
        )
        self.assertIsNotNone(r1.created_at)
        self.assertEqual(r1.user, self.user1)
        self.assertEqual(r1.instance, self.copy_available)
        self.assertEqual(r1.key, 'test-key-1')

        # Different user can use the same key
        r2 = Reservation.objects.create(
            user=self.user2,
            instance=self.copy_maintenance,
            key='test-key-1'
        )
        self.assertIsNotNone(r2)

    def test_api_auth_required(self):
        url = f'/catalog/api/bookinstance/{self.copy_available.id}/reserve/'
        res = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-unauth')
        self.assertEqual(res.status_code, 401)
        self.assertEqual(res.json(), {'error': 'unauthorized'})

    def test_api_method_get_not_allowed(self):
        self.client.force_login(self.user1)
        url = f'/catalog/api/bookinstance/{self.copy_available.id}/reserve/'
        res = self.client.get(url, HTTP_IDEMPOTENCY_KEY='key-get')
        self.assertEqual(res.status_code, 405)

    def test_api_key_validation(self):
        self.client.force_login(self.user1)
        url = f'/catalog/api/bookinstance/{self.copy_available.id}/reserve/'
        # Missing key
        res1 = self.client.post(url)
        self.assertEqual(res1.status_code, 400)
        self.assertEqual(res1.json(), {'error': 'invalid_key'})

        # Empty key
        res2 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(res2.status_code, 400)
        self.assertEqual(res2.json(), {'error': 'invalid_key'})

        # Key exceeding 100 chars
        res3 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='k' * 101)
        self.assertEqual(res3.status_code, 400)
        self.assertEqual(res3.json(), {'error': 'invalid_key'})

    def test_api_not_found(self):
        self.client.force_login(self.user1)
        random_pk = uuid.uuid4()
        url = f'/catalog/api/bookinstance/{random_pk}/reserve/'
        res = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-nf')
        self.assertEqual(res.status_code, 404)
        self.assertIn('application/json', res.headers.get('Content-Type', ''))
        self.assertEqual(res.json(), {'error': 'not_found'})

    def test_api_unavailable_copy(self):
        self.client.force_login(self.user1)
        url = f'/catalog/api/bookinstance/{self.copy_maintenance.id}/reserve/'
        res = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-unavail')
        self.assertEqual(res.status_code, 409)
        self.assertEqual(res.json(), {'error': 'unavailable'})
        # Ensure status did not change
        self.copy_maintenance.refresh_from_db()
        self.assertEqual(self.copy_maintenance.status, 'm')

    def test_api_successful_reserve_and_replay_idempotency(self):
        try:
            Reservation = apps.get_model('catalog', 'Reservation')
        except LookupError:
            self.fail('Reservation model not found in catalog.models')
        BookInstance = apps.get_model('catalog', 'BookInstance')

        self.client.force_login(self.user1)
        url = f'/catalog/api/bookinstance/{self.copy_available.id}/reserve/'
        key = 'unique-key-123'
        res1 = self.client.post(url, HTTP_IDEMPOTENCY_KEY=key)
        self.assertEqual(res1.status_code, 201)
        expected_payload = {
            'instance_id': str(self.copy_available.id),
            'user_id': self.user1.id,
            'status': 'r'
        }
        self.assertEqual(res1.json(), expected_payload)

        # Verify DB state
        self.copy_available.refresh_from_db()
        self.assertEqual(self.copy_available.status, 'r')
        self.assertEqual(self.copy_available.borrower, self.user1)
        self.assertTrue(Reservation.objects.filter(user=self.user1, key=key).exists())

        # Exact replay with same user, key, instance -> exact 201 & same payload
        # Test replay on a completely new client/connection to ensure persistence replay
        client_replay = Client()
        client_replay.force_login(self.user1)
        res2 = client_replay.post(url, HTTP_IDEMPOTENCY_KEY=key)
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), expected_payload)
        self.assertEqual(Reservation.objects.filter(user=self.user1, key=key).count(), 1)

        # Idempotency conflict: same user & same key for ANOTHER instance
        another_copy = BookInstance.objects.create(book=self.book, imprint='Test', status='a')
        url_another = f'/catalog/api/bookinstance/{another_copy.id}/reserve/'
        res3 = self.client.post(url_another, HTTP_IDEMPOTENCY_KEY=key)
        self.assertEqual(res3.status_code, 409)
        self.assertEqual(res3.json(), {'error': 'idempotency_conflict'})
        # The losing copy must remain available ('a') for another user
        another_copy.refresh_from_db()
        self.assertEqual(another_copy.status, 'a')
        self.assertIsNone(another_copy.borrower)

    def test_ui_reserve_page(self):
        BookInstance = apps.get_model('catalog', 'BookInstance')
        self.client.force_login(self.user1)
        new_copy = BookInstance.objects.create(book=self.book, imprint='UI Imprint', status='a')
        detail_res = self.client.get(f'/catalog/book/{self.book.id}')
        self.assertEqual(detail_res.status_code, 200)
        self.assertIn(f'/catalog/book/{new_copy.id}/reserve/', detail_res.content.decode('utf-8'))

        # UI POST reserve
        reserve_url = f'/catalog/book/{new_copy.id}/reserve/'
        post_res = self.client.post(reserve_url, {'idempotency_key': 'ui-key-1'}, follow=True)
        self.assertEqual(post_res.status_code, 200)
        new_copy.refresh_from_db()
        self.assertEqual(new_copy.status, 'r')
        self.assertEqual(new_copy.borrower, self.user1)


class Task2OracleConcurrencyRealDbTest(TransactionTestCase):
    """Tests concurrency against real disk database with independent connections."""

    def test_concurrency_barrier_three_trials(self):
        try:
            Reservation = apps.get_model('catalog', 'Reservation')
        except LookupError:
            self.fail('Reservation model not found in catalog.models')
        Author = apps.get_model('catalog', 'Author')
        Book = apps.get_model('catalog', 'Book')
        BookInstance = apps.get_model('catalog', 'BookInstance')

        # Assert test DB is not in-memory and path exists on disk
        test_db_name = str(connection.settings_dict.get('NAME', ''))
        self.assertNotIn(':memory:', test_db_name, 'Test database must not be in-memory SQLite')
        self.assertTrue(Path(test_db_name).exists(), f'Test database file does not exist: {test_db_name}')

        for trial in range(1, 4):
            author = Author.objects.create(first_name=f'Trial{trial}', last_name='Author')
            book = Book.objects.create(title=f'Trial Book {trial}', author=author, isbn=f'888888888888{trial}')
            copy = BookInstance.objects.create(book=book, imprint='Concurrency Test', status='a')

            u1 = User.objects.create_user(username=f'alice_{trial}', password='password')
            u2 = User.objects.create_user(username=f'bob_{trial}', password='password')

            barrier = threading.Barrier(2)
            results = []
            exceptions = []

            c1 = Client()
            c1.force_login(u1)
            c2 = Client()
            c2.force_login(u2)

            def worker(client, key):
                try:
                    barrier.wait(timeout=10)
                    resp = client.post(
                        f'/catalog/api/bookinstance/{copy.id}/reserve/',
                        HTTP_IDEMPOTENCY_KEY=key
                    )
                    results.append((resp.status_code, resp.json()))
                except Exception as ex:
                    exceptions.append(ex)
                finally:
                    for conn in connections.all():
                        conn.close()

            t1 = threading.Thread(target=worker, args=(c1, f'key-trial-{trial}-u1'))
            t2 = threading.Thread(target=worker, args=(c2, f'key-trial-{trial}-u2'))

            t1.start()
            t2.start()
            t1.join(timeout=15)
            t2.join(timeout=15)

            # Assert threads are dead (not alive)
            self.assertFalse(t1.is_alive(), f'Thread 1 still alive in trial {trial}')
            self.assertFalse(t2.is_alive(), f'Thread 2 still alive in trial {trial}')
            self.assertEqual(exceptions, [], f'Exceptions occurred during concurrency test: {exceptions}')

            status_codes = sorted([r[0] for r in results])
            self.assertEqual(
                status_codes,
                [201, 409],
                f'Trial {trial} failed: expected [201, 409] but got {status_codes}. Payloads: {results}'
            )

            # Exactly one 201 created and one 409 unavailable
            resp_201 = [r[1] for r in results if r[0] == 201][0]
            resp_409 = [r[1] for r in results if r[0] == 409][0]
            self.assertEqual(resp_201['status'], 'r')
            self.assertEqual(resp_409, {'error': 'unavailable'})

            copy.refresh_from_db()
            self.assertEqual(copy.status, 'r')
            self.assertIn(copy.borrower, [u1, u2])
            self.assertEqual(Reservation.objects.filter(instance=copy).count(), 1)
