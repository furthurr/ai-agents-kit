#!/usr/bin/env python3
"""Offline report/export only. Never launches a model or edits a solution."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import tarfile

import six_agent_deepseek as lab


def load(path):
    return json.loads(path.read_text()) if path.exists() else None


def summarize(root):
    rows = []
    for arm in lab.ALL_ARMS:
        trace = load(root / 'traces' / (arm + '.json'))
        record = load(root / 'records' / (arm + '.json'))
        if trace is None:
            rows.append({'arm': arm, 'status': 'manual_pending' if arm == 'sdd' else 'not_launched',
                         'tokens': None, 'seconds': None, 'acceptance': None})
            continue
        events = trace['events']
        evaluable = trace['measurement']['steps'] > 0
        tools = [e['part'] for e in events if e.get('part', {}).get('type') == 'tool']
        reads = [p.get('state', {}).get('input', {}).get('filePath') for p in tools if p.get('tool') == 'read']
        skills = [p.get('state', {}).get('input', {}).get('name') for p in tools if p.get('tool') == 'skill']
        verified = []
        for name in skills:
            path = root / 'profiles' / arm / 'skills' / name / 'SKILL.md'
            if path.is_file() and any(p.get('tool') == 'skill' and p.get('state', {}).get('input', {}).get('name') == name
                                     and lab.body(path.read_text()) in p.get('state', {}).get('output', '') for p in tools):
                verified.append(name)
        rows.append({'arm': arm, 'status': trace['stop_reason'] or 'finished',
                     'tokens': trace['measurement']['observed'], 'metrics_complete': trace['measurement']['complete'],
                     'seconds': trace['seconds'], 'steps': trace['measurement']['steps'],
                     'tool_counts': dict(Counter(p['tool'] for p in tools)),
                     'skills_invoked': skills, 'skills_loaded_by_content': sorted(set(verified)),
                     'files_read': reads, 'errors': [e['error'] for e in events if e.get('type') == 'error'],
                     'acceptance': record['complete_acceptance'] if record and evaluable else None,
                     'functional_pass': record['functional_pass'] if record and evaluable else None,
                     'test_delivery': record['test_delivery'] if record and evaluable else None,
                     'artifact_evaluation_only': not evaluable,
                     'original43_pass': record['original43']['passed'] if record else None,
                     'joint_tests': record['joint']['tests'] if record else None,
                     'joint_pass': record['joint']['passed'] if record else None,
                     'changed': record['changed'] if record else None,
                     'final_text': '\n'.join(e['part']['text'] for e in events if e.get('type') == 'text')})
    return {'model': lab.MODEL, 'root': str(root), 'rows': rows,
            'batch': load(root / 'batch-end.json'), 'halt': load(root / 'halt.json'),
            'comparison_valid': all(r.get('acceptance') is True for r in rows),
            'limits': ['One repetition; no statistical or causal performance conclusion.',
                       'SDD requires manual operator; missing runs are not zero cost.',
                       'Single-session pilot does not evaluate resumption.',
                       'Researcher/preparation tokens unknown, not zero.',
                       'Tool permissions, not OS sandbox. Native provider internal retries are not independently observable.']}


def export(root, destination):
    assert (root / 'batch-end.json').exists(), 'Do not export an active or unfinished batch'
    lab.check_frozen(root)
    destination.mkdir(parents=True, exist_ok=True)
    summary = summarize(root)
    lab.write_json(destination / 'resultados.json', summary, exclusive=True)
    archive = destination / 'laboratorio.tar.gz'
    selected = []
    for folder in ('inputs', 'profiles', 'configs', 'baseline', 'reference', 'initial', 'mas-context',
                   'runs', 'traces', 'calls', 'requests', 'records'):
        selected.extend(lab.files(root / folder))
    selected.extend(p for p in root.glob('*.json') if not lab.unsafe(p))
    selected.extend(p for p in (root / 'evaluation').glob('*.json') if not lab.unsafe(p))
    selected = [p for p in selected if p.suffix not in ('.sqlite3', '.db')]
    with tarfile.open(archive, 'x:gz') as handle:
        for path in sorted(set(selected)):
            assert path.is_file() and not lab.unsafe(path)
            handle.add(path, arcname=str(path.relative_to(root)), recursive=False)
    with tarfile.open(archive, 'r:gz') as handle:
        members = handle.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        assert len(members) == len(set(selected))
        expected = {str(p.relative_to(root)): lab.sha(p) for p in selected}
        for member in members:
            assert hashlib.sha256(handle.extractfile(member).read()).hexdigest() == expected[member.name]
    lab.write_json(destination / 'manifest.json', {'archive_sha256': lab.sha(archive),
                   'files': {str(p.relative_to(root)): lab.sha(p) for p in sorted(set(selected))},
                   'excluded': ['hosts', 'private reasoning', 'raw transport', 'credentials',
                                'venv', 'staticfiles', 'SQLite', 'evaluation staged copies'],
                   'root': str(root)}, exclusive=True)
    print(json.dumps({'archive_files': len(members), 'archive_sha256': lab.sha(archive),
                      'rows': [{k: row.get(k) for k in ('arm', 'status', 'acceptance', 'seconds', 'tokens')}
                               for row in summary['rows']]}, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=lab.DEFAULT_ROOT)
    parser.add_argument('--export', action='store_true')
    args = parser.parse_args()
    if args.export:
        export(args.root, lab.PACKAGE / 'evidencia')
    else:
        print(json.dumps(summarize(args.root), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
