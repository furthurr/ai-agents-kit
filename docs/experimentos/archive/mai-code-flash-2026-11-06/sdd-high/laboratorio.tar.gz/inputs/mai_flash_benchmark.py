#!/usr/bin/env python3
"""Append-only MAI replication of the frozen LocalLibrary experiments.

Uses native Copilot authentication through OpenCode; never reads credentials.
No retries, inferred approvals, automatic resumes or auxiliary inference.
"""
import argparse
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

import five_agent_deepseek_high as high
import sdd_ll_search_deepseek as sdd_low
import sdd_task2_high_deepseek as sdd_high
import six_agent_deepseek_direct as direct
import six_agent_deepseek_fixed as low
import six_agent_deepseek_report as report
import six_agent_permission_runtime as runtime

REPO = direct.REPO
MODEL = 'github-copilot/mai-code-1.1-flash'
PACKAGE = REPO / 'docs/experimentos/mai-code-flash-2026-11-06'
ROOT = low.ROOT.parent / 'mai-code-flash-20261106-v1'
COHORTS = {
    'low': (low.ROOT, low.context().ARMS),
    'high': (high.ROOT, low.context().ARMS),
    'sdd-low': (sdd_low.ROOT, (sdd_low.ARM,)),
    'sdd-high': (sdd_high.ROOT, (sdd_high.ARM,)),
}
SOURCES = ('mai_flash_benchmark.py', 'test_mai_flash_benchmark.py',
           'six_agent_deepseek.py', 'six_agent_deepseek_direct.py',
           'six_agent_deepseek_fixed.py', 'six_agent_deepseek_report.py',
           'five_agent_deepseek_high.py', 'six_agent_permission_runtime.py',
           'six_agent_workspace_permissions.py', 'sdd_ll_search_deepseek.py',
           'sdd_task2_high_deepseek.py', 'gemini_three_way.py')


def load(path):
    return json.loads(path.read_text())


def remap_config(cfg, old, new):
    text = json.dumps(cfg).replace(str(old), str(new))
    text = text.replace(str(old).lstrip('/'), str(new).lstrip('/'))
    cfg = json.loads(text)
    cfg.pop('provider', None)
    cfg['enabled_providers'] = ['github-copilot']
    for agent in cfg['agent'].values():
        agent['model'] = MODEL
        # The native MAI catalog explicitly declares temperature unsupported.
        agent.pop('temperature', None)
        assert 'variant' not in agent
    return cfg


def parse_catalog(text):
    marker = MODEL + '\n'
    assert marker in text, 'Requested MAI model absent from isolated host catalog'
    item, _ = json.JSONDecoder().raw_decode(text.split(marker, 1)[1].lstrip())
    assert item['providerID'] == 'github-copilot'
    assert item['id'] == 'mai-code-1.1-flash'
    assert item['capabilities']['toolcall']
    assert item['capabilities']['temperature'] is False
    return {k: item[k] for k in ('id', 'providerID', 'name', 'api', 'limit', 'capabilities', 'variants')}


def frozen_inputs(base, root):
    result = {}
    for folder in ('inputs', 'profiles', 'configs', 'baseline', 'reference', 'initial', 'mas-context'):
        result.update({folder + '/' + k: v for k, v in base.hashes(root / folder).items()})
    for name in ('budget.json', 'sources.json', 'offline.json'):
        result[name] = base.sha(root / name)
    return result


def context(cohort):
    source, arms = COHORTS[cohort]
    root = ROOT / cohort
    base = direct.module_at('mai_private_' + cohort, REPO / 'tools/six_agent_deepseek.py')
    base.MODEL, base.DEFAULT_ROOT, base.ARMS, base.ALL_ARMS = MODEL, root, arms, arms
    base.subprocess = low.ExplicitTitleProcesses()

    def config(target, arm):
        # Read the exact historical config, not today's installed profile.
        return remap_config(load(source / 'configs' / (arm + '.json')), source, target)

    base.configuration = config
    base.agent_name = lambda arm: next(iter(config(root, arm)['agent']))
    old_primary = base.primary
    base.primary = lambda arm: 'sdd-spec' if arm == 'sdd_trial' else old_primary(arm)

    def check(target):
        assert frozen_inputs(base, target) == load(target / 'freeze.json')['files'], 'Frozen MAI inputs changed'
        for name in SOURCES:
            assert base.sha(REPO / 'tools' / name) == base.sha(target / 'inputs' / name), name

    base.check_frozen = check
    return base, root, source


def prepare(cohort):
    base, root, source = context(cohort)
    assert not root.exists(), 'Never overwrite or reset an experiment'
    root.mkdir(parents=True)
    for folder in ('baseline', 'mas-context'):
        base.copy_safe(source / folder, root / folder)
    ref_source = high.ROOT if cohort.endswith('high') else low.ROOT
    base.copy_safe(ref_source / 'reference', root / 'reference')
    (root / 'inputs').mkdir()
    for name in ('tarea.md', 'oracle_search.py'):
        shutil.copyfile(source / 'inputs' / name, root / 'inputs' / name)
    if cohort.endswith('high'):
        shutil.copyfile(source / 'inputs/oracle_edges.py', root / 'inputs/oracle_edges.py')
    for name in SOURCES:
        shutil.copyfile(REPO / 'tools' / name, root / 'inputs' / name)
    for arm in base.ARMS:
        base.copy_safe(source / 'profiles' / arm, root / 'profiles' / arm)
        workspace = root / 'runs' / arm
        base.copy_safe(root / 'baseline', workspace)
        if arm != 'build_sin_mas':
            high.copy_overlay(base, root / 'mas-context', workspace)
            readme = source / 'runs' / arm / 'README.md'
            assert base.sha(readme) == load(source / 'initial' / (arm + '.json'))['README.md']
            shutil.copyfile(readme, workspace / 'README.md')
        assert base.hashes(workspace) == load(source / 'initial' / (arm + '.json')), 'Initial workspace differs'
        (root / 'hosts' / arm / 'opencode').mkdir(parents=True)
        base.write_json(root / 'initial' / (arm + '.json'), base.hashes(workspace), exclusive=True)
        base.write_json(root / 'configs' / (arm + '.json'), base.configuration(root, arm), exclusive=True)
    base.write_json(root / 'sources.json', {'historical_root': str(source),
        'historical_freeze_sha256': base.sha(source / 'freeze.json'),
        'baseline_commit': '3120b4302bf87a1b8c84d06662c2b8787f7da5f8',
        'profiles_exact': {a: base.hashes(root / 'profiles' / a) for a in base.ARMS},
        'task_sha256': base.sha(root / 'inputs/tarea.md'),
        'only_config_deltas': ['workspace paths', 'native Copilot model/provider', 'unsupported temperature removed'],
        'solutions_reused': False}, exclusive=True)
    base.write_json(root / 'budget.json', {'model': MODEL, 'initial_invocations': len(base.ARMS),
        'timeout_seconds': 1800, 'steps': 60, 'token_boundary': 5000000,
        'temperature': None, 'temperature_supported': False, 'explicit_variant': None,
        'retries': 0, 'auxiliary_inference': False, 'simulated_approvals': False,
        'resume_requires_actual_user_response': True}, exclusive=True)
    print(json.dumps({'prepared': cohort, 'real_model_calls': 0}), flush=True)


def evaluate(base, root, cohort, label, workspace, original=False):
    if cohort.endswith('high'):
        return high.evaluate(base, root, label, workspace, 'original' if original else 'joint')
    return base.evaluate(root, label, workspace, include_added=not original)


def offline(cohort):
    base, root, source = context(cohort)
    assert not (root / 'offline.json').exists()
    records = {'real_model_calls': 0, 'profiles': {}}
    for arm in base.ARMS:
        assert base.hashes(root / 'profiles' / arm) == base.hashes(source / 'profiles' / arm)
        agent = base.command(root, arm, ['opencode', 'debug', 'agent', base.agent_name(arm), '--pure'])
        assert agent.returncode == 0
        resolved = json.loads(agent.stdout)
        cfg_agent = base.configuration(root, arm)['agent'][base.agent_name(arm)]
        assert resolved['model'] == {'providerID': 'github-copilot', 'modelID': 'mai-code-1.1-flash'}
        if 'prompt' in cfg_agent:
            assert resolved['prompt'] == cfg_agent['prompt']
        else:
            assert resolved.get('native') and not resolved.get('prompt')
        catalog = base.command(root, arm, ['opencode', 'models', 'github-copilot', '--verbose', '--pure'])
        assert catalog.returncode == 0
        provider = parse_catalog(catalog.stdout)
        skills = base.command(root, arm, ['opencode', 'debug', 'skill', '--pure'])
        assert skills.returncode == 0
        available = json.loads(skills.stdout)
        external = [s for s in available if s['location'] != '<built-in>']
        expected = sorted(p.parent.name for p in (root / 'profiles' / arm / 'skills').glob('*/SKILL.md'))
        assert sorted(s['name'] for s in external) == expected
        # Same real-host scripted permission probe; no calls to MAI or Copilot.
        proof = runtime.probe(base, root / 'runtime-probes', arm)
        records['profiles'][arm] = {'provider': provider, 'skills': [s['name'] for s in available], 'probe': proof}
        assert base.hashes(root / 'runs' / arm) == load(root / 'initial' / (arm + '.json'))
    records['baseline43'] = evaluate(base, root, cohort, 'pre-original43', root / 'baseline', True)
    records['reference'] = evaluate(base, root, cohort, 'pre-reference', root / 'reference')
    assert records['baseline43']['passed'] and records['baseline43']['tests'] == 43
    assert records['reference']['passed'] and records['reference']['tests'] == (52 if cohort.endswith('high') else 56)
    base.write_json(root / 'offline.json', records, exclusive=True)
    base.write_json(root / 'freeze.json', {'created': base.stamp(), 'files': frozen_inputs(base, root)}, exclusive=True)
    print(json.dumps({'offline_passed': cohort, 'real_model_calls': 0}), flush=True)


def test_methods(base, folder):
    result = {}
    for p in base.files(folder / 'catalog/tests'):
        if p.suffix == '.py':
            tree = ast.parse(p.read_text())
            for cls in (n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)):
                for method in cls.body:
                    if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)) and method.name.startswith('test'):
                        result[(str(p.relative_to(folder)), cls.name, method.name)] = ast.dump(method)
    return result


def evaluate_arm(base, root, cohort, arm):
    record = high.evaluate_arm(base, root, arm) if cohort.endswith('high') else base.evaluate_arm(root, arm)
    before = test_methods(base, root / 'baseline')
    after = test_methods(base, root / 'runs' / arm)
    audit = {'new_test_methods': len(after.keys() - before.keys()),
             'original_methods_preserved': all(after.get(k) == v for k, v in before.items()),
             'procedure_fidelity_certified': False}
    if not audit['original_methods_preserved']:
        record['complete_acceptance'] = False
        record['functional_pass'] = False
        base.write_json(root / 'records' / (arm + '.json'), record)
    base.write_json(root / 'audits' / (arm + '.json'), audit, exclusive=True)
    return record


def summarize(cohort):
    base, root, _ = context(cohort)
    reporter = direct.module_at('mai_report_' + cohort, REPO / 'tools/six_agent_deepseek_report.py')
    reporter.lab = base
    summary = reporter.summarize(root)
    for row in summary['rows']:
        arm = row['arm']
        if not (root / 'records' / (arm + '.json')).exists():
            continue
        row.update(load(root / 'audits' / (arm + '.json')))
        if cohort.endswith('high'):
            rec = load(root / 'records' / (arm + '.json'))
            row.update(oracle9_pass=rec['oracle9']['passed'], edges5_pass=rec['edges5']['passed'],
                       migration_check_pass=rec['migration_check']['passed'])
        if arm == 'sdd_trial' and not row['acceptance'] and not row['changed']:
            row['status'] = 'awaiting_user_gate_or_mode_review'
            row['acceptance'] = None
    summary['cohort'] = cohort
    summary['temperature'] = 'unsupported; provider default'
    summary['comparison_valid'] = False
    summary['comparison_note'] = 'Descriptive n=1 replication; functional acceptance is not procedural certification.'
    return summary


def export(cohort):
    base, root, _ = context(cohort)
    base.check_frozen(root)
    destination = PACKAGE / cohort
    assert not destination.exists(), 'Append-only export'
    reporter = direct.module_at('mai_export_' + cohort, REPO / 'tools/six_agent_deepseek_report.py')
    reporter.lab = base
    reporter.summarize = lambda _: summarize(cohort)
    reporter.export(root, destination)
    # Separate audit files supplement the archive without changing its manifest.
    base.copy_safe(root / 'audits', destination / 'audits')


def run(cohort):
    base, root, _ = context(cohort)
    base.check_frozen(root)
    base.write_json(root / 'batch-start.json', {'started': base.stamp(), 'arms': base.ARMS, 'model': MODEL}, exclusive=True)
    start = time.monotonic()
    for arm in base.ARMS:
        trace = base.invoke(root, arm)
        record = evaluate_arm(base, root, cohort, arm)
        print(json.dumps({'cohort': cohort, 'arm': arm, 'stop': trace['stop_reason'],
            'seconds': trace['seconds'], 'tokens': trace['measurement'], 'acceptance': record['complete_acceptance']}), flush=True)
        if trace['stop_reason']:
            break
    base.write_json(root / 'batch-end.json', {'finished': base.stamp(), 'wall_seconds': round(time.monotonic()-start, 3),
        'calls': len(list((root / 'calls').glob('*.json'))), 'halted': (root / 'halt.json').exists()}, exclusive=True)
    export(cohort)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['prepare', 'offline', 'check', 'run', 'report', 'export'])
    parser.add_argument('cohort', choices=list(COHORTS) + ['all'])
    args = parser.parse_args()
    for cohort in COHORTS if args.cohort == 'all' else (args.cohort,):
        if args.command == 'check':
            base, root, _ = context(cohort)
            base.check_frozen(root)
        elif args.command == 'report':
            print(json.dumps(summarize(cohort), ensure_ascii=False, indent=2))
        else:
            globals()[args.command](cohort)


if __name__ == '__main__':
    main()
