#!/usr/bin/env python3
"""Append-only SDD LL-SEARCH operator. No fabricated approvals or automatic resume.

Uses the previous evaluator/stream collector without changing the historical runner.
The logical arm is sdd_trial; the actual OpenCode agent is named sdd.
"""
import argparse
import json
from pathlib import Path
import shutil
import subprocess

import six_agent_deepseek_direct as direct
import six_agent_deepseek_fixed as low
import six_agent_workspace_permissions as permissions

REPO = direct.REPO
ROOT = low.ROOT.parent / 'sdd-ll-search-deepseek-20261106-v2'
PACKAGE = REPO / 'docs/experimentos/sdd-ll-search-deepseek-2026-11-06'
ARM = 'sdd_trial'
SOURCES = ('sdd_ll_search_deepseek.py', 'test_sdd_ll_search_deepseek.py',
           'six_agent_deepseek.py', 'six_agent_deepseek_direct.py',
           'six_agent_deepseek_fixed.py', 'six_agent_workspace_permissions.py',
           'six_agent_permission_runtime.py', 'gemini_three_way.py')


def configuration(base, root, arm):
    assert arm == ARM
    # Native Build's policy is the historical common policy, not its prompt.
    cfg = base.common_configuration(root, 'build_mas')
    cfg = json.loads(json.dumps(cfg).replace('/build_mas', '/' + ARM))
    assert len(cfg['agent']) == 1
    agent = next(iter(cfg['agent'].values()))
    agent.update(mode='primary', description='Installed SDD experimental snapshot',
                 prompt=(root / 'profiles' / arm / 'agent.md').read_text())
    agent['permission']['skill']['sdd-spec'] = 'allow'
    cfg['agent'] = {'sdd': agent}
    cfg['provider'] = direct.transport()
    cfg['enabled_providers'] = ['deepseek']
    workspace, skills = root / 'runs' / arm, root / 'profiles' / arm / 'skills'
    cfg = permissions.corrected_configuration(cfg, workspace, skills)
    # Only the SDD procedure's additional artifacts; no global relative allow.
    for operation in ('read', 'edit'):
        rules = cfg['agent']['sdd']['permission'][operation]
        guards = {k: v for k, v in rules.items() if v == 'deny' and k != '*'}
        for form in permissions.resource_forms(workspace / '.sdd', workspace):
            rules[form] = 'allow'
            rules[form + '/*'] = 'allow'
        for key, value in guards.items():
            rules.pop(key, None)
            rules[key] = value
    return cfg


def context():
    base = direct.context()
    base.common_configuration = base.configuration
    base.configuration = lambda root, arm: configuration(base, root, arm)
    base.agent_name = lambda arm: 'sdd'
    base.primary = lambda arm: 'sdd-spec'
    base.ARMS, base.ALL_ARMS = (ARM,), (ARM,)
    base.DEFAULT_ROOT = ROOT
    base.subprocess = low.ExplicitTitleProcesses()
    base.check_frozen = lambda root: check(base, root)
    return base


def frozen_inputs(base, root):
    result = {}
    for folder in ('inputs', 'profiles', 'configs', 'initial', 'baseline', 'mas-context'):
        result.update({folder + '/' + k: v for k, v in base.hashes(root / folder).items()})
    for name in ('budget.json', 'sources.json', 'offline.json'):
        result[name] = base.sha(root / name)
    return result


def check(base, root):
    assert frozen_inputs(base, root) == json.loads((root / 'freeze.json').read_text())['files']
    for name in SOURCES:
        assert base.sha(REPO / 'tools' / name) == base.sha(root / 'inputs' / name)
    low.context().check_frozen(low.ROOT)


def prepare(base):
    low.context().check_frozen(low.ROOT)
    assert not ROOT.exists(), 'Never overwrite an experiment'
    ROOT.mkdir()
    (ROOT / 'inputs').mkdir()
    for name in SOURCES:
        shutil.copyfile(REPO / 'tools' / name, ROOT / 'inputs' / name)
    for name in ('tarea.md', 'oracle_search.py'):
        shutil.copyfile(low.ROOT / 'inputs' / name, ROOT / 'inputs' / name)
    base.copy_safe(low.ROOT / 'baseline', ROOT / 'baseline')
    base.copy_safe(low.ROOT / 'mas-context', ROOT / 'mas-context')
    workspace = ROOT / 'runs' / ARM
    base.copy_safe(ROOT / 'baseline', workspace)
    for source in base.files(ROOT / 'mas-context'):
        target = workspace / source.relative_to(ROOT / 'mas-context')
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    # Recover exact initial README only after checking it was never modified.
    previous_readme = low.ROOT / 'runs/build_mas/README.md'
    initial = json.loads((low.ROOT / 'initial/build_mas.json').read_text())
    assert base.sha(previous_readme) == initial['README.md']
    shutil.copyfile(previous_readme, workspace / 'README.md')
    profile = ROOT / 'profiles' / ARM
    profile.mkdir(parents=True)
    agent_source = base.INSTALLED / 'agent/sdd.md'
    shutil.copyfile(agent_source, profile / 'installed-agent-source.md')
    (profile / 'agent.md').write_text(base.body(agent_source.read_text()) + '\n')
    for name in ('sdd-spec', 'data-api', 'ui-design'):
        base.copy_safe(base.INSTALLED / 'skills' / name, profile / 'skills' / name)
    (ROOT / 'hosts' / ARM / 'opencode').mkdir(parents=True)
    base.write_json(ROOT / 'initial' / (ARM + '.json'), base.hashes(workspace), exclusive=True)
    base.write_json(ROOT / 'configs' / (ARM + '.json'), base.configuration(ROOT, ARM), exclusive=True)
    base.write_json(ROOT / 'sources.json', {
        'captured_at': base.stamp(), 'previous_cohort': str(low.ROOT),
        'installed_agent_path': str(agent_source), 'installed_agent_sha256': base.sha(agent_source),
        'installed_skill_hashes': {name: base.hashes(base.INSTALLED / 'skills' / name)
                                  for name in ('sdd-spec', 'data-api', 'ui-design')},
        'baseline_commit': '3120b4302bf87a1b8c84d06662c2b8787f7da5f8',
        'fixture': 'exact prior experimental MAS, not a historical bootstrap',
        'temporal_extension_not_contemporaneous_control': True}, exclusive=True)
    base.write_json(ROOT / 'budget.json', {
        'authorized_initial_invocations': 1, 'model': direct.MODEL,
        'provider': 'deepseek', 'api': 'https://api.deepseek.com',
        'temperature': 0.2, 'explicit_variant': None,
        'timeout_seconds': 1800, 'steps': 60, 'token_boundary': 5000000,
        'retries': 0, 'auxiliary_inference': False, 'simulated_approvals': False,
        'resume_requires_actual_user_response': True}, exclusive=True)
    print(json.dumps({'prepared': str(ROOT), 'real_model_calls': 0}))


def offline(base):
    assert not (ROOT / 'offline.json').exists()
    cfg = base.configuration(ROOT, ARM)
    assert cfg == json.loads((ROOT / 'configs' / (ARM + '.json')).read_text())
    assert cfg['enabled_providers'] == ['deepseek']
    assert cfg['agent']['sdd']['model'] == direct.MODEL
    assert 'variant' not in cfg['agent']['sdd']
    resolved = base.command(ROOT, ARM, ['opencode', 'debug', 'agent', 'sdd', '--pure'])
    assert resolved.returncode == 0, 'Agent resolution failed'
    agent = json.loads(resolved.stdout)
    assert agent['prompt'] == (ROOT / 'profiles' / ARM / 'agent.md').read_text()
    skills = base.command(ROOT, ARM, ['opencode', 'debug', 'skill', '--pure'])
    assert skills.returncode == 0
    available = json.loads(skills.stdout)
    external = [item for item in available if item['location'] != '<built-in>']
    assert sorted(item['name'] for item in external) == ['data-api', 'sdd-spec', 'ui-design']
    for item in external:
        assert str(ROOT / 'profiles' / ARM / 'skills') in item['location']
    catalog = base.command(ROOT, ARM, ['opencode', 'models', 'deepseek', '--verbose', '--pure'])
    assert catalog.returncode == 0
    provider = direct.parse_catalog(catalog.stdout)
    # Scripted actual-host probe additionally writes a nested SDD artifact.
    runtime_source = (REPO / 'tools/six_agent_permission_runtime.py').read_text()
    assert runtime_source.count("'catalog/probe.txt'") == 2
    runtime_source = runtime_source.replace("'catalog/probe.txt'", "'.sdd/specs/offline-probe/spec.md'")
    probe_source = ROOT / 'inputs/sdd-runtime.py'
    probe_source.write_text(runtime_source)
    runtime = direct.module_at('sdd_permission_runtime', probe_source)
    proof = runtime.probe(base, ROOT / 'runtime-probes', ARM)
    original = base.evaluate(ROOT, 'pre-original43', ROOT / 'baseline', include_added=False)
    reference = base.evaluate(ROOT, 'pre-reference56', low.ROOT / 'reference')
    assert original['passed'] and original['tests'] == 43
    assert reference['passed'] and reference['tests'] == 56
    assert base.hashes(ROOT / 'runs' / ARM) == json.loads((ROOT / 'initial' / (ARM + '.json')).read_text())
    base.write_json(ROOT / 'offline.json', {
        'passed': True, 'provider': provider, 'agent_prompt_exact': True,
        'skills': [item['name'] for item in available], 'runtime': proof,
        'baseline43': original['passed'], 'reference56': reference['passed'],
        'real_model_calls': 0}, exclusive=True)
    base.write_json(ROOT / 'freeze.json', {'created': base.stamp(), 'files': frozen_inputs(base, ROOT)}, exclusive=True)
    print(json.dumps({'offline_passed': True, 'real_model_calls': 0, 'frozen': True}))


def run(base):
    assert not (ROOT / 'calls' / (ARM + '.json')).exists(), 'No retries or automatic continuation'
    result = base.invoke(ROOT, ARM)
    final_text = '\n'.join(e['part']['text'] for e in result['events'] if e.get('type') == 'text')
    session_ids = sorted({e['sessionID'] for e in result['events'] if e.get('sessionID')})
    base.write_json(ROOT / 'operator-state.json', {
        'state': 'halted' if result['stop_reason'] else 'awaiting_operator_review',
        'session_ids': session_ids, 'final_text': final_text,
        'measurement': result['measurement'], 'seconds': result['seconds'],
        'stop_reason': result['stop_reason'], 'simulated_approvals': 0,
        'acceptance': None, 'note': 'Do not interpret gate/mode pause as implementation failure.'}, exclusive=True)
    print(json.dumps({'state': 'awaiting_operator_review', 'measurement': result['measurement'],
                      'seconds': result['seconds'], 'stop_reason': result['stop_reason'],
                      'final_text': final_text}, ensure_ascii=False, indent=2))


def export(base):
    check(base, ROOT)
    assert not PACKAGE.exists(), 'Append-only evidence export'
    PACKAGE.mkdir(parents=True)
    for folder in ('inputs', 'profiles', 'configs', 'initial', 'baseline', 'mas-context',
                   'traces', 'requests', 'calls', 'records'):
        if (ROOT / folder).exists():
            base.copy_safe(ROOT / folder, PACKAGE / 'evidencia' / folder)
    for name in ('freeze.json', 'offline.json', 'sources.json', 'budget.json', 'operator-state.json'):
        shutil.copyfile(ROOT / name, PACKAGE / name)
    base.write_json(PACKAGE / 'manifest.json', {'created': base.stamp(), 'root': str(ROOT),
                    'files': base.hashes(PACKAGE)}, exclusive=True)
    print(json.dumps({'exported': str(PACKAGE)}))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['prepare', 'offline', 'check', 'run', 'export'])
    args = parser.parse_args()
    base = context()
    {'prepare': lambda: prepare(base), 'offline': lambda: offline(base),
     'check': lambda: check(base, ROOT), 'run': lambda: run(base), 'export': lambda: export(base)}[args.command]()


if __name__ == '__main__':
    main()
