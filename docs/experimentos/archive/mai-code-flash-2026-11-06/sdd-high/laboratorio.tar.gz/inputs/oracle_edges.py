"""Additional tests of literal TASK-2 edges. Kept separate from historic nine."""
from html.parser import HTMLParser
from django.apps import apps
from django.contrib.auth import get_user_model
from django.db import IntegrityError, transaction
from django.test import TestCase, Client


class Inputs(HTMLParser):
    def __init__(self, text):
        super().__init__()
        self.inputs = []
        self.feed(text)

    def handle_starttag(self, tag, attrs):
        if tag == 'input':
            self.inputs.append(dict(attrs))


class ReservationEdges(TestCase):
    def setUp(self):
        self.User = get_user_model()
        self.user = self.User.objects.create_user(username='edge-one')
        self.other = self.User.objects.create_user(username='edge-two')
        self.Book = apps.get_model('catalog', 'Book')
        self.Copy = apps.get_model('catalog', 'BookInstance')
        self.Reservation = apps.get_model('catalog', 'Reservation')
        self.book = self.Book.objects.create(title='Protocol Book', isbn='7777777777777')
        self.instance = self.Copy.objects.create(book=self.book, imprint='Fixture', status='a')
        self.api = f'/catalog/api/bookinstance/{self.instance.pk}/reserve/'
        self.ui = f'/catalog/book/{self.instance.pk}/reserve/'

    def test_database_unique_user_key(self):
        second = self.Copy.objects.create(book=self.book, imprint='Second', status='a')
        self.Reservation.objects.create(user=self.user, instance=self.instance, key='same')
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                self.Reservation.objects.create(user=self.user, instance=second, key='same')
        self.Reservation.objects.create(user=self.other, instance=second, key='same')
        self.assertEqual(self.Reservation.objects.count(), 2)
        self.assertEqual(self.Reservation._meta.get_field('key').max_length, 100)
        self.assertTrue(self.Reservation._meta.get_field('created_at').auto_now_add)

    def test_api_all_other_methods_405(self):
        self.client.force_login(self.user)
        for method in ('get', 'head', 'put', 'patch', 'delete', 'options'):
            with self.subTest(method=method):
                response = getattr(self.client, method)(self.api, HTTP_IDEMPOTENCY_KEY='method')
                self.assertEqual(response.status_code, 405)
        self.assertEqual(self.Reservation.objects.count(), 0)

    def test_anonymous_api_401_json_with_real_csrf(self):
        response = Client(enforce_csrf_checks=True).post(self.api, HTTP_IDEMPOTENCY_KEY='anon')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})
        self.assertEqual(self.Reservation.objects.count(), 0)

    def test_anonymous_ui_cannot_reserve(self):
        response = Client(raise_request_exception=False).post(self.ui, {'idempotency_key': 'anonymous-ui'})
        self.assertEqual(response.status_code, 302)
        self.assertIn('/accounts/login/', response.headers['Location'])
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, 'a')
        self.assertIsNone(self.instance.borrower)
        self.assertEqual(self.Reservation.objects.count(), 0)

    def test_ui_real_csrf_and_visible_confirmation(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        page = client.get(f'/catalog/book/{self.book.pk}')
        tokens = [item['value'] for item in Inputs(page.content.decode()).inputs
                  if item.get('name') == 'csrfmiddlewaretoken' and item.get('value')]
        self.assertTrue(tokens, 'Reserve UI must supply a real CSRF token')
        keys = [item['value'] for item in Inputs(page.content.decode()).inputs
                if item.get('name') == 'idempotency_key' and item.get('type') == 'hidden' and item.get('value')]
        self.assertTrue(keys, 'Reserve UI must generate a nonempty hidden idempotency key')
        denied = client.post(self.ui, {'idempotency_key': keys[0]})
        self.assertEqual(denied.status_code, 403)
        self.assertEqual(self.Reservation.objects.count(), 0)
        accepted = client.post(self.ui, {'idempotency_key': keys[0], 'csrfmiddlewaretoken': tokens[0]}, follow=True)
        self.assertEqual(accepted.status_code, 200)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, 'r')
        self.assertEqual(self.instance.borrower_id, self.user.pk)
        self.assertEqual(self.Reservation.objects.count(), 1)
        self.assertIn('reserv', accepted.content.decode().lower())
