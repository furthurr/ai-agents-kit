import copy
import json
from pathlib import Path
import unittest

import mai_flash_benchmark as lab


class MAIReplicationTests(unittest.TestCase):
    def test_model_and_budget_in_engine(self):
        base, _, _ = lab.context('low')
        self.assertEqual(base.MODEL, 'github-copilot/mai-code-1.1-flash')
        self.assertEqual((base.TIMEOUT, base.STEP_LIMIT, base.TOKEN_LIMIT), (1800, 60, 5000000))

    def test_remap_preserves_permissions_and_prompt(self):
        for cohort in lab.COHORTS:
            base, root, source = lab.context(cohort)
            for arm in base.ARMS:
                old = lab.load(source / 'configs' / (arm + '.json'))
                original = copy.deepcopy(old)
                new = lab.remap_config(old, source, root)
                self.assertEqual(old, original)
                text = json.dumps(old).replace(str(source), str(root))
                expected = json.loads(text.replace(str(source).lstrip('/'), str(root).lstrip('/')))
                expected.pop('provider', None)
                expected['enabled_providers'] = ['github-copilot']
                for agent in expected['agent'].values():
                    agent['model'] = lab.MODEL
                    agent.pop('temperature', None)
                self.assertEqual(new, expected)
                self.assertNotIn('deepseek', json.dumps(new))

    def test_sdd_is_isolated_and_preserves_actual_agent_name(self):
        for cohort in ('sdd-low', 'sdd-high'):
            base, root, _ = lab.context(cohort)
            self.assertEqual(base.ARMS, ('sdd_trial',))
            policy = base.configuration(root, 'sdd_trial')['agent'][base.agent_name('sdd_trial')]['permission']
            self.assertEqual(policy['skill']['sdd-spec'], 'allow')
            self.assertEqual(policy['task'], 'deny')
            self.assertEqual(policy['question'], 'deny')

    def test_titles_are_explicit(self):
        self.assertTrue(issubclass(lab.low.ExplicitTitleProcesses, object))


if __name__ == '__main__':
    unittest.main()
