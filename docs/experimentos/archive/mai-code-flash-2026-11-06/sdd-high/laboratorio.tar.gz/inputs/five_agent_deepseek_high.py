#!/usr/bin/env python3
"""Five new TASK-2 trajectories, direct DeepSeek, frozen prior profiles; no SDD."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import time

import six_agent_deepseek_direct as direct
import six_agent_deepseek_fixed as low
import six_agent_workspace_permissions as permissions

REPO = direct.REPO
PACKAGE = REPO / 'docs/experimentos/cinco-agentes-deepseek-alta-2026-11-06'
ROOT = low.ROOT.parent / 'five-agent-deepseek-high-20261106-v1'
HISTORY = low.context().SOURCE
SOURCES = ('five_agent_deepseek_high.py', 'test_five_agent_deepseek_high.py',
           'six_agent_deepseek_direct.py', 'test_six_agent_deepseek_direct.py',
           'six_agent_workspace_permissions.py', 'six_agent_permission_runtime.py')
SOFT_STOPS = {'timeout', 'step_budget', 'token_budget'}


class Processes(low.ExplicitTitleProcesses):
    def Popen(self, args, **kwargs):
        if args[:2] == ['opencode', 'run'] and '--title' not in args:
            args = args[:2] + ['--title', 'TASK-2-Alta-' + Path(kwargs['cwd']).name] + args[2:]
        return subprocess.Popen(args, **kwargs)


def context():
    base = direct.context()
    base.PACKAGE, base.DEFAULT_ROOT = PACKAGE, ROOT
    base.ALL_ARMS = base.ARMS
    base.subprocess = Processes()
    previous_config, previous_check, previous_write = base.configuration, base.check_frozen, base.write_json

    def config(root, arm):
        cfg = previous_config(root, arm)
        policy = cfg['agent'][base.agent_name(arm)]['permission']
        old = policy['bash']
        additions = {prefix + ' manage.py ' + command + '*': 'allow'
                     for prefix in (base.PYTHON, 'python', 'python3')
                     for command in ('makemigrations', 'migrate', 'showmigrations')}
        policy['bash'] = {'*': 'deny', **{k: v for k, v in old.items() if k != '*'}, **additions,
                          **{k: v for k, v in old.items() if k != '*' and v == 'deny'}}
        return permissions.corrected_configuration(cfg, root / 'runs' / arm, root / 'profiles' / arm / 'skills')

    def check(root):
        previous_check(root)
        for name in SOURCES:
            assert base.sha(REPO / 'tools' / name) == base.sha(root / 'inputs' / name), 'Frozen high source changed'

    def write(path, data, exclusive=False):
        if path == ROOT / 'halt.json' and data.get('reason') in SOFT_STOPS:
            path = ROOT / 'cell-stops' / (data['arm'] + '.json')
        return previous_write(path, data, exclusive)

    base.configuration, base.check_frozen, base.write_json = config, check, write
    base.evaluate = lambda root, label, workspace, include_added=True, subset=None: evaluate(
        base, root, label, workspace, 'joint' if include_added else 'original', subset)
    return base


def copy_overlay(base, source, target):
    for file in base.files(source):
        if file.suffix in ('.sqlite3', '.db'):
            continue
        out = target / file.relative_to(source)
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(file, out)


def prepare(base):
    low.context().check_frozen(low.ROOT)
    assert not ROOT.exists(), 'New root required'
    ROOT.mkdir()
    inputs = ROOT / 'inputs'
    inputs.mkdir()
    case = next(c for c in json.loads((HISTORY / 'cases.json').read_text())['tasks'] if c['id'] == 'TASK-2')
    base.write_json(inputs / 'case.json', case, exclusive=True)
    # Keep the exact literal contract; common authorization is in the same runner wrapper as prior cohort.
    task = case['task'] + '\n\nAlcance completo de implementación autorizado, sin extensiones. '
    task += ('Conserva tu metodología: si exige aprobación pendiente, presenta la propuesta y espera; '
             'no inventes una respuesta. Añade migraciones sin reescribir las históricas. '
             'No se autoriza bootstrap/sync documental, delegación, dependencias nuevas ni publicación.\n')
    (PACKAGE / 'tarea.md').write_text(task)
    for name in ('tarea.md', 'protocolo.md', 'oracle_edges.py'):
        shutil.copyfile(PACKAGE / name, inputs / name)
    shutil.copyfile(HISTORY / 'oracles/test_oracle_task2.py', inputs / 'oracle_search.py')
    shutil.copyfile(HISTORY / 'cases.json', inputs / 'historical-cases.json')
    shutil.copyfile(REPO / 'tools/six_agent_deepseek.py', inputs / 'runner.py')
    shutil.copyfile(REPO / 'tools/gemini_three_way.py', inputs / 'sanitizer_source.py')
    for name in SOURCES:
        shutil.copyfile(REPO / 'tools' / name, inputs / name)
    base.copy_safe(low.ROOT / 'baseline', ROOT / 'baseline')
    base.copy_safe(ROOT / 'baseline', ROOT / 'reference')
    for folder in ('catalog', 'templates'):
        copy_overlay(base, HISTORY / 'references/TASK-2' / folder, ROOT / 'reference' / folder)
    base.copy_safe(low.ROOT / 'mas-context', ROOT / 'mas-context')
    for arm in base.ARMS:
        workspace = ROOT / 'runs' / arm
        base.copy_safe(ROOT / 'baseline', workspace)
        base.copy_safe(low.ROOT / 'profiles' / arm, ROOT / 'profiles' / arm)
        (ROOT / 'profiles' / arm / 'skills').mkdir(exist_ok=True)
        (ROOT / 'hosts' / arm / 'opencode').mkdir(parents=True)
        if arm != 'build_sin_mas':
            copy_overlay(base, ROOT / 'mas-context', workspace)
            old_readme = low.ROOT / 'runs' / arm / 'README.md'
            prior_initial = json.loads((low.ROOT / 'initial' / (arm + '.json')).read_text())
            assert base.sha(old_readme) == prior_initial['README.md']
            shutil.copyfile(old_readme, workspace / 'README.md')
        base.write_json(ROOT / 'initial' / (arm + '.json'), base.hashes(workspace), exclusive=True)
        base.write_json(ROOT / 'configs' / (arm + '.json'), base.configuration(ROOT, arm), exclusive=True)
    base.write_json(ROOT / 'budget.json', {'new_real_invocations': 5, 'model': direct.MODEL,
        'timeout_seconds': 1800, 'steps': 60, 'token_boundary': 5000000, 'retries': 0,
        'nominal_total_tokens': 25000000, 'synthetic_probes_are_not_inference': True,
        'individual_limits_do_not_cancel_other_arms': True}, exclusive=True)
    base.write_json(ROOT / 'sources.json', {'previous_cohort': str(low.ROOT),
        'profiles_exact': {arm: base.hashes(ROOT / 'profiles' / arm) for arm in base.ARMS},
        'historical_oracle_sha256': base.sha(inputs / 'oracle_search.py'),
        'task_literal_sha256': hashlib.sha256(case['task'].encode()).hexdigest(),
        'source_commit': '3120b4302bf87a1b8c84d06662c2b8787f7da5f8'}, exclusive=True)
    shutil.copyfile(low.ROOT / 'mas-files.json', ROOT / 'mas-files.json')
    base.write_json(ROOT / 'sdd-pending.json', {'state': 'not_in_scope', 'launched': False}, exclusive=True)
    # Private runtime fixture tests writing a new migration and both migration commands.
    kernel = (REPO / 'tools/six_agent_permission_runtime.py').read_text()
    assert kernel.count("'catalog/probe.txt'") == 2
    kernel = kernel.replace("'catalog/probe.txt'", "'catalog/migrations/0030_offline_probe.py'")
    assert kernel.count("base.PYTHON + ' manage.py check'") == 1
    kernel = kernel.replace("base.PYTHON + ' manage.py check'", "base.PYTHON + ' manage.py makemigrations catalog'")
    seam = "    if arm != 'build_sin_mas':\n        for name in"
    assert kernel.count(seam) == 1
    kernel = kernel.replace(seam, "    script.append(('bash', {'command': base.PYTHON + ' manage.py migrate'}))\n" + seam)
    (inputs / 'high-runtime.py').write_text(kernel)
    print(json.dumps({'prepared': str(ROOT), 'model': direct.MODEL, 'task': case['name'], 'real_calls': 0}))


def test_settings(stage):
    (stage / 'bench_oracles').mkdir()
    (stage / 'bench_oracles/__init__.py').write_text('')
    (stage / 'bench_oracles/settings.py').write_text(
        'from locallibrary.settings import *\nimport os\n'
        "SECRET_KEY = 'offline-placeholder'\nALLOWED_HOSTS = ['testserver','127.0.0.1']\n"
        "DATABASES = {'default': {'ENGINE': 'django.db.backends.sqlite3', 'NAME': os.environ['EVAL_DB'], "
        "'TEST': {'NAME': os.environ['EVAL_DB']}, 'OPTIONS': {'timeout': 5}}}\n"
        "STORAGES = {'default': {'BACKEND': 'django.core.files.storage.FileSystemStorage'}, "
        "'staticfiles': {'BACKEND': 'django.contrib.staticfiles.storage.StaticFilesStorage'}}\n")


def execute(base, stage, db, command):
    start = time.monotonic()
    try:
        process = subprocess.run([base.PYTHON, 'manage.py', *command, '--settings=bench_oracles.settings'],
                    cwd=stage, env=base.eval_env(stage, db), capture_output=True, text=True, timeout=300)
        stdout, stderr, code, timed_out = process.stdout, process.stderr, process.returncode, False
    except subprocess.TimeoutExpired as error:
        stdout = error.stdout.decode(errors='replace') if isinstance(error.stdout, bytes) else error.stdout or ''
        stderr = error.stderr.decode(errors='replace') if isinstance(error.stderr, bytes) else error.stderr or ''
        code, timed_out = None, True
    match = re.search(r'Ran (\d+) tests?', stdout + stderr)
    return {'returncode': code, 'passed': code == 0, 'tests': int(match.group(1)) if match else None,
            'stdout': stdout, 'stderr': stderr, 'timeout': timed_out, 'seconds': round(time.monotonic()-start, 3)}


def evaluate(base, root, label, workspace, mode='joint', subset=None):
    stage = root / 'evaluation' / label
    base.copy_safe(workspace, stage)
    for path in stage.glob('*.sqlite3'):
        path.unlink()  # Disposable copied fixtures only; never source/product databases.
    if mode == 'original':
        shutil.rmtree(stage / 'catalog/tests')
        shutil.copytree(root / 'baseline/catalog/tests', stage / 'catalog/tests')
    test_settings(stage)
    shutil.copyfile(root / 'inputs/oracle_search.py', stage / 'bench_oracles/test_high.py')
    shutil.copyfile(root / 'inputs/oracle_edges.py', stage / 'bench_oracles/test_edges.py')
    labels = subset or {'original': ['catalog.tests.test_models', 'catalog.tests.test_forms', 'catalog.tests.test_views'],
                       'oracle': ['bench_oracles.test_high'], 'edges': ['bench_oracles.test_edges'],
                       'joint': ['catalog', 'bench_oracles.test_high']}[mode]
    result = execute(base, stage, stage.parent / (label + '.sqlite3'), ['test', '--noinput', *labels])
    base.write_json(root / 'evaluation' / (label + '.json'), result, exclusive=True)
    return result


def evaluate_arm(base, root, arm):
    workspace = root / 'runs' / arm
    original = evaluate(base, root, arm + '-original43', workspace, 'original')
    oracle = evaluate(base, root, arm + '-oracle9', workspace, 'oracle')
    joint = evaluate(base, root, arm + '-joint', workspace)
    edges = evaluate(base, root, arm + '-edges5', workspace, 'edges')
    stage = root / 'evaluation' / (arm + '-joint')
    check = execute(base, stage, stage.parent / (arm + '-check.sqlite3'), ['check'])
    migrations = execute(base, stage, stage.parent / (arm + '-migration.sqlite3'), ['makemigrations', '--check', '--dry-run'])
    before, after = json.loads((root / 'initial' / (arm + '.json')).read_text()), base.hashes(workspace)
    changed = [name for name in sorted(before.keys() | after.keys()) if before.get(name) != after.get(name)]
    forbidden = [name for name in changed if name.startswith('locallibrary/') or name in ('requirements.txt', 'AGENTS.md')
                 or (name.startswith('catalog/migrations/') and name in before)]
    tests = [name for name in changed if name.startswith('catalog/tests/') and name.endswith('.py')]
    functional = original['passed'] and original['tests'] == 43 and oracle['passed'] and oracle['tests'] == 9
    functional = functional and joint['passed'] and check['passed'] and migrations['passed'] and not forbidden
    data = {'arm': arm, 'original43': original, 'oracle9': oracle, 'joint': joint, 'edges5': edges,
        'check': check, 'migration_check': migrations, 'changed': changed, 'forbidden_changes': forbidden,
        'tests_changed': tests, 'functional_pass': bool(functional), 'test_delivery': bool(tests),
        'primary_acceptance': bool(functional and tests), 'extended_contract_pass': edges['passed'] and edges['tests'] == 5}
    data['complete_acceptance'] = data['primary_acceptance'] and data['extended_contract_pass']
    base.write_json(root / 'records' / (arm + '.json'), data, exclusive=True)
    return data


def offline(base):
    records = {'profiles': {}, 'isolation': {}}
    baseline = base.hashes(ROOT / 'baseline')
    assert baseline == base.hashes(HISTORY / 'original')
    for arm in base.ARMS:
        assert base.hashes(ROOT / 'profiles' / arm) == base.hashes(low.ROOT / 'profiles' / arm)
        current = base.hashes(ROOT / 'runs' / arm)
        assert all(current[name] == value for name, value in baseline.items() if name != 'README.md' or arm == 'build_sin_mas')
        if arm == 'build_sin_mas':
            assert current == baseline
        records['isolation'][arm] = True
        agent = base.command(ROOT, arm, ['opencode', 'debug', 'agent', base.agent_name(arm), '--pure'])
        assert agent.returncode == 0
        resolved = json.loads(agent.stdout)
        if arm.startswith('build_'):
            assert resolved.get('native') and not resolved.get('prompt')
        skills = base.command(ROOT, arm, ['opencode', 'debug', 'skill', '--pure'])
        assert skills.returncode == 0
        names = sorted(item['name'] for item in json.loads(skills.stdout))
        expected = ['customize-opencode'] + ([] if arm == 'build_sin_mas' else ['data-api', 'ui-design'] + ([] if arm == 'build_mas' else [base.primary(arm)]))
        assert names == sorted(expected)
        catalog = base.command(ROOT, arm, ['opencode', 'models', 'deepseek', '--verbose', '--pure'])
        assert catalog.returncode == 0
        records['profiles'][arm] = {'skills': names, 'native': resolved.get('native', False),
                                    'provider': direct.parse_catalog(catalog.stdout)}
    records['original43'] = evaluate(base, ROOT, 'baseline-original', ROOT / 'baseline', 'original')
    records['baseline_oracle9'] = evaluate(base, ROOT, 'baseline-absent-feature', ROOT / 'baseline', 'oracle')
    records['reference_oracle9'] = evaluate(base, ROOT, 'reference-oracle9', ROOT / 'reference', 'oracle')
    records['reference_joint52'] = evaluate(base, ROOT, 'reference-joint52', ROOT / 'reference')
    records['reference_edges5_diagnostic'] = evaluate(base, ROOT, 'reference-edges5', ROOT / 'reference', 'edges')
    assert records['original43']['passed'] and records['original43']['tests'] == 43
    assert not records['baseline_oracle9']['passed']
    assert records['reference_oracle9']['passed'] and records['reference_oracle9']['tests'] == 9
    assert records['reference_joint52']['passed'] and records['reference_joint52']['tests'] == 52
    variants = {
        'auth': ([("{'error': 'unauthorized'}, status=401", "{'error': 'unauthorized'}, status=200")], 'test_api_auth_required'),
        'replay': ([('if existing_res:', 'if False and existing_res:'),
                    ('if check_replay and str(check_replay.instance_id)', 'if False and check_replay and str(check_replay.instance_id)')],
                    'test_api_successful_reserve_and_replay_idempotency'),
        'conditional-update': ([('filter(pk=pk, status=BookInstance.LoanStatus.AVAILABLE).update(', 'filter(pk=pk).update(')],
                                'test_api_unavailable_copy'),
    }
    for name, (changes, test) in variants.items():
        folder = ROOT / 'mutations' / name
        base.copy_safe(ROOT / 'reference', folder)
        target = folder / 'catalog/views.py'
        text = target.read_text()
        for before, after in changes:
            assert before in text
            text = text.replace(before, after)
        target.write_text(text)
        proof = evaluate(base, ROOT, 'mutation-' + name, folder, 'oracle',
                         ['bench_oracles.test_high.Task2OracleModelAndApiTest.' + test])
        assert not proof['passed']
        records['mutation-' + name] = proof
    runtime = direct.module_at('high_runtime_private', ROOT / 'inputs/high-runtime.py')
    proofs = [runtime.probe(base, ROOT / 'runtime-probes', arm) for arm in base.ARMS]
    records['runtime_proofs'] = proofs
    base.write_json(ROOT / 'inputs/runtime-proof.json', {'real_model_calls': 0, 'profiles': proofs}, exclusive=True)
    base.write_json(ROOT / 'offline.json', records, exclusive=True)
    print('High offline checks passed: profiles, physical SQLite reference, mutations, actual-host migration permissions. No real inference.')


def run(base):
    base.check_frozen(ROOT)
    base.write_json(ROOT / 'batch-start.json', {'started': base.stamp(), 'arms': base.ARMS,
                   'model': base.MODEL, 'task': 'TASK-2'}, exclusive=True)
    start = time.monotonic()
    for arm in base.ARMS:
        trace = base.invoke(ROOT, arm)
        record = evaluate_arm(base, ROOT, arm)
        print(json.dumps({'arm': arm, 'reason': trace['stop_reason'], 'tokens': trace['measurement'],
                          'primary': record['primary_acceptance'], 'extended': record['extended_contract_pass']}), flush=True)
        if trace['stop_reason'] and trace['stop_reason'] not in SOFT_STOPS:
            break
    base.write_json(ROOT / 'batch-end.json', {'finished': base.stamp(), 'wall_seconds': round(time.monotonic()-start, 3),
                   'calls': len(list((ROOT / 'calls').glob('*.json'))), 'halted': (ROOT / 'halt.json').exists()}, exclusive=True)


def report(base, export=False):
    reporter = direct.module_at('high_reporter', REPO / 'tools/six_agent_deepseek_report.py')
    reporter.lab = base
    if export:
        reporter.export(ROOT, PACKAGE / 'evidencia')
        return
    value = reporter.summarize(ROOT)
    for row in value['rows']:
        row.pop('final_text', None)
        row.pop('files_read', None)
        path = ROOT / 'records' / (row['arm'] + '.json')
        if path.exists():
            data = json.loads(path.read_text())
            row.update(primary_acceptance=data['primary_acceptance'], extended_contract_pass=data['extended_contract_pass'],
                       oracle9=data['oracle9']['passed'], edges5=data['edges5']['passed'])
    print(json.dumps(value, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['prepare', 'offline', 'freeze', 'check', 'run', 'report', 'export'])
    parser.add_argument('--background', action='store_true')
    args = parser.parse_args()
    base = context()
    if args.background:
        assert args.command == 'run'
        child = subprocess.Popen([base.PYTHON, '-B', str(Path(__file__)), 'run'],
              stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        print(json.dumps({'pid': child.pid, 'root': str(ROOT), 'model': base.MODEL, 'task': 'TASK-2'}))
        return
    {'prepare': lambda: prepare(base), 'offline': lambda: offline(base), 'freeze': lambda: base.freeze(ROOT),
     'check': lambda: base.check_frozen(ROOT), 'run': lambda: run(base),
     'report': lambda: report(base), 'export': lambda: report(base, True)}[args.command]()


if __name__ == '__main__':
    main()
