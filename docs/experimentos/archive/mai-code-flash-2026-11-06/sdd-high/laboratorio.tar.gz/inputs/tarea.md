Implementar flujo de reserva de ejemplares disponibles (BookInstance con status='a') para usuarios autenticados, con persistencia de reservas, garantía de idempotencia en reintentos y tolerancia a concurrencia real bajo SQLite.

CONTRATOS EXACTOS:
1. Modelo público de persistencia:
   Definir modelo Reservation en catalog.models (o exponerlo públicamente allí) con los siguientes campos:
   - user: ForeignKey a settings.AUTH_USER_MODEL (on_delete=CASCADE u obligatorio).
   - instance: ForeignKey a BookInstance (o OneToOneField / ForeignKey, on_delete=CASCADE).
   - key: CharField(max_length=100) para la clave de idempotencia.
   - created_at: DateTimeField(auto_now_add=True).
   - Constraint de unicidad: [user, key] único (UniqueConstraint o unique_together), de modo que claves entre distintos usuarios sean independientes.
2. API Endpoint: POST /catalog/api/bookinstance/<uuid:pk>/reserve/
   - Autenticación: Requiere usuario autenticado. Si no está autenticado, responder 401 Unauthorized con JSON {'error': 'unauthorized'}.
   - Método HTTP: Solo POST permitido. GET o cualquier otro método responde 405 Method Not Allowed.
   - Header de Idempotencia: Obligatorio 'Idempotency-Key' en encabezados HTTP (o 'HTTP_IDEMPOTENCY_KEY'). Debe ser no vacío tras strip y de longitud <= 100 caracteres. Si falta, está vacío o supera 100 caracteres, responder 400 Bad Request con JSON {'error': 'invalid_key'}.
   - Instancia inexistente: Si pk no corresponde a ningún BookInstance existente, responder 404 Not Found con JSON {'error': 'not_found'}.
   - Ejemplar no disponible: Si la copia no tiene status='a', responder 409 Conflict con JSON exacto {'error': 'unavailable'}.
   - Éxito (primera reserva): Transicionar BookInstance.status a 'r' (Reserved), asignar BookInstance.borrower al usuario actual, registrar la Reservation con la clave provista. Responder 201 Created con JSON exacto:
     {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}
   - Replay / Idempotencia exacta: Si el MISMO usuario realiza POST con la MISMA clave 'Idempotency-Key' para la MISMA instancia que ya reservó con esa clave, responder exactamente 201 Created con el mismo JSON {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}, sin duplicar registros de Reservation ni alterar el estado.
   - Conflicto de Idempotencia: Si el MISMO usuario intenta reutilizar una 'Idempotency-Key' previamente usada para reservar OTRA instancia diferente, responder 409 Conflict con JSON exacto {'error': 'idempotency_conflict'}.
   - Persistencia de idempotencia: La clave debe persistir en la base de datos de modo que un replay en una nueva conexión o sesión HTTP siga retornando 201 Created con el mismo payload.
3. Garantía de concurrencia bajo SQLite en disco:
   - Dos solicitudes concurrentes de distintos usuarios sobre la misma copia 'a' deben resultar en exactamente un 201 Created y un 409 Conflict (con {'error': 'unavailable'}).
   - SQLite no bloquea filas con select_for_update(); la implementación debe asegurar el resultado concurrente real (ej. mediante conditional UPDATE / atomic con verificación de rows_updated, o reintento acotado ante busy/lock) sin devolver 500 'database locked' al cliente.
   - Ninguna petición fallida (400, 401, 404, 405, 409) debe mutar el estado de BookInstance ni dejar reservas espurias.
4. Interfaz Web (UI):
   - En /catalog/book/<int:pk>, para cada copia con status='a', incluir botón/formulario de reserva apuntando a /catalog/book/<uuid:instance_pk>/reserve/.
   - POST a /catalog/book/<uuid:instance_pk>/reserve/ debe requerir autenticación (redirigiendo a login si es anónimo).
   - Debe incluir token CSRF y un campo hidden con idempotency_key generada para prevenir doble envío accidental en el navegador.
   - Al completarse con éxito, mostrar mensaje de confirmación visible en la interfaz (o redirigir al detalle con mensaje flash de éxito).
5. Suite original (43 tests) debe seguir pasando intacta. No modificar el comando renew de bibliotecarios ni violar retrocompatibilidad.

Alcance completo de implementación autorizado, sin extensiones. Conserva tu metodología: si exige aprobación pendiente, presenta la propuesta y espera; no inventes una respuesta. Añade migraciones sin reescribir las históricas. No se autoriza bootstrap/sync documental, delegación, dependencias nuevas ni publicación.
