"""Offline proposed fix for workspace-relative tool permission resources.

Does not edit existing configurations, start sessions, or relax external-directory guards.
Integration into a new frozen cohort and runtime verification remain pending.
"""
import copy
import fnmatch
from pathlib import Path


def decision(rules, resource):
    """Model ordered wildcard rules for the simple literal/* paths used here."""
    action = 'ask'
    for pattern, value in rules.items():
        if fnmatch.fnmatchcase(resource, pattern):
            action = value
    return action


def resource_forms(absolute, workspace):
    absolute, workspace = Path(absolute).resolve(), Path(workspace).resolve()
    forms = [str(absolute), str(absolute).lstrip('/')]
    if absolute == workspace or workspace in absolute.parents:
        forms.append(str(absolute.relative_to(workspace)))
    return list(dict.fromkeys(forms))


def corrected_configuration(config, workspace, skills):
    result = copy.deepcopy(config)
    assert len(result['agent']) == 1
    permission = next(iter(result['agent'].values()))['permission']
    initial = copy.deepcopy(permission)
    workspace, skills = Path(workspace).resolve(), Path(skills).resolve()
    # Exact existing root entries only, never a general relative '*' allow.
    root_entries = [p for p in workspace.iterdir() if not p.is_symlink()]
    for operation in ('read', 'edit'):
        rules = dict(initial[operation])
        for entry in root_entries:
            for form in resource_forms(entry, workspace):
                rules[form + ('/*' if entry.is_dir() else '')] = 'allow'
                rules[form] = 'allow'
        for form in resource_forms(workspace, workspace):
            if operation == 'read':
                rules[form] = 'allow'
        if operation == 'read':
            for form in resource_forms(skills, workspace):
                rules[form] = 'allow'
                rules[form + '/*'] = 'allow'
        # Reappend all explicit denies LAST: secret guards and project AGENTS remain effective.
        for pattern, action in initial[operation].items():
            if action == 'deny' and pattern != '*':
                rules.pop(pattern, None)
                rules[pattern] = action
        for form in resource_forms(workspace / 'AGENTS.md', workspace):
            if operation == 'edit':
                rules[form] = 'deny'
        permission[operation] = rules
    assert permission['external_directory'] == initial['external_directory']
    assert permission['bash'] == initial['bash'] and permission['task'] == 'deny'
    return result
