#!/usr/bin/env python3
"""Isolated repaired cohort. Includes real-host scripted, zero-inference tool probes."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess

import six_agent_deepseek_direct as direct
import six_agent_workspace_permissions as permission_fix
import six_agent_permission_runtime as runtime

REPO = direct.REPO
PACKAGE = REPO / 'docs/experimentos/seis-agentes-deepseek-corregido-2026-11-06'
ROOT = direct.ROOT.parent / 'six-agent-deepseek-fixed-20261106-v2'
SOURCES = ('six_agent_deepseek_direct.py', 'test_six_agent_deepseek_direct.py',
           'six_agent_workspace_permissions.py', 'test_six_agent_workspace_permissions.py',
           'six_agent_permission_runtime.py', 'six_agent_deepseek_fixed.py', 'test_six_agent_deepseek_fixed.py')


class ExplicitTitleProcesses:
    """Prevent automatic title inference without changing the historical engine."""
    def __getattr__(self, name):
        return getattr(subprocess, name)

    def Popen(self, args, **kwargs):
        if args[:2] == ['opencode', 'run'] and '--title' not in args:
            args = args[:2] + ['--title', 'LL-SEARCH-' + Path(kwargs['cwd']).name] + args[2:]
        return subprocess.Popen(args, **kwargs)


def context():
    base = direct.context()
    base.PACKAGE, base.DEFAULT_ROOT = PACKAGE, ROOT
    base.subprocess = ExplicitTitleProcesses()
    previous_config = base.configuration

    def config(root, arm):
        return permission_fix.corrected_configuration(previous_config(root, arm),
                    root / 'runs' / arm, root / 'profiles' / arm / 'skills')

    base.configuration = config
    old_check = base.check_frozen

    def check(root):
        old_check(root)
        for name in SOURCES:
            assert base.sha(REPO / 'tools' / name) == base.sha(root / 'inputs' / name), 'Fixed adapter source changed'
    base.check_frozen = check
    return base


def prepare(base):
    for name in ('tarea.md', 'oracle_search.py'):
        target = PACKAGE / name
        if target.exists():
            assert base.sha(target) == base.sha(direct.PACKAGE / name)
        else:
            shutil.copyfile(direct.PACKAGE / name, target)
    base.prepare(ROOT)
    for name in SOURCES:
        shutil.copyfile(REPO / 'tools' / name, ROOT / 'inputs' / name)
    base.write_json(ROOT / 'budget.json', {'real_invocations_this_cohort': 5,
        'remaining_allocated_to_automatic_arms': 5, 'synthetic_localhost_probes_are_not_inference': True,
        'previous_direct_harness_attempts': 1, 'sdd_manual_requires_additional_budget': True,
        'model': direct.MODEL, 'timeout': 1800, 'steps': 60, 'token_boundary': 5000000, 'retries': 0})
    base.write_json(ROOT / 'inputs/cohort.json', {'user_authorized_repair_and_finish': True,
        'prior_attempts_preserved_and_excluded_from_comparison': True, 'synthetic_probes_required_before_inference': True}, exclusive=True)


def offline(base):
    direct.offline(base, ROOT)
    probes = ROOT / 'runtime-probes'
    assert not probes.exists()
    results = []
    for arm in base.ARMS:
        results.append(runtime.probe(base, probes, arm))
        print('Actual host synthetic permission proof passed: ' + arm, flush=True)
    base.write_json(ROOT / 'inputs/runtime-proof.json', {'real_model_calls': 0, 'profiles': results}, exclusive=True)


def report(base, export=False):
    reporter = direct.module_at('fixed_reporter', REPO / 'tools/six_agent_deepseek_report.py')
    reporter.lab = base
    if export:
        reporter.export(ROOT, PACKAGE / 'evidencia')
    else:
        rows = reporter.summarize(ROOT)
        for row in rows['rows']:
            row.pop('final_text', None)
            row.pop('files_read', None)
        print(json.dumps(rows, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['prepare', 'offline', 'freeze', 'check', 'run', 'report', 'analyze', 'export'])
    parser.add_argument('--background', action='store_true')
    args = parser.parse_args()
    base = context()
    if args.background:
        assert args.command == 'run'
        child = subprocess.Popen([base.PYTHON, '-B', str(Path(__file__)), 'run'],
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        print(json.dumps({'pid': child.pid, 'root': str(ROOT), 'model': base.MODEL}))
        return
    if args.command == 'analyze':
        analysis = direct.module_at('fixed_analysis', REPO / 'tools/six_agent_deepseek_direct_analysis.py')
        analysis.analyze(base, ROOT)
        return
    {'prepare': lambda: prepare(base), 'offline': lambda: offline(base),
     'freeze': lambda: base.freeze(ROOT), 'check': lambda: base.check_frozen(ROOT),
     'run': lambda: base.run(ROOT), 'report': lambda: report(base),
     'export': lambda: report(base, True)}[args.command]()


if __name__ == '__main__':
    main()
