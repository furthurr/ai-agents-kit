# Quality Bar — agnóstica a la tecnología

Cargar en **Fase 2 (Design)**, **Implementación** y **Fase 4**. No cargar en Fase 1.
Redactar y aplicar **sin** nombres de framework en el núcleo del checklist; el stack concreto sale del steering.

## Checklist

1. **Capas:** UI no conoce persistencia concreta; dominio no importa frameworks de UI.
2. **DI:** composition root único; repos/servicios/puertos inyectados.
3. **Singletons:** prohibido singleton de infraestructura (repos, storage, network) salvo justificación explícita en `design.md`.
4. **I/O:** fuera del hilo/loop de UI cuando la plataforma lo permita (leer steering).
5. **Errores:** tipados o `Result`; no `catch` vacío; log en fallos de infraestructura.
6. **Persistencia encapsulada:** un solo módulo/adaptador toca storage/BD; UI y domain no llaman APIs crudas de persistencia.
7. **RNF auto-audit:** en `standard`, verificar 3–5 RNF críticos del propio
   spec. En Tiny/Lite, revisar solo los RNF declarados y aplicables; no inventar cuotas.
8. **Verificación adaptativa:** comportamiento nuevo/modificado usa pruebas o checks
   focalizados y bugfix usa regresión; caracterización protege refactors. «Sin test
   nuevo» solo sin cambio observable o con excepción explícita y verificación alternativa.
9. **PBT:** solo si hay un invariante algebraico claro (ver `testing.md`).
10. **Proporcionalidad design (`standard`):** techo orientativo ~250 líneas; 1 flowchart + 1 sequence; C4/ER solo si hay BD interna real o el requisito lo necesita.
11. **Tipos:** sin `any` / tipos opacos cuando el lenguaje lo permita (steering).
12. **Código mínimo:** implementación mínima correcta; no crear abstracciones, mocks o
   capas anticipadas solo para satisfacer tests.

## Integración

- **Fase 2:** el design debe satisfacer este bar; citar excepciones en `design.md` si las hay.
- **Implementación:** revisar este bar antes de marcar waves de UI/datos como `[x]`.
- **Fase 4:** spot-check explícito (lista corta en `verification.md`).
- **Cierre lite:** spot-check proporcional en el `verification.md` compacto, sin
  convertirlo en Fase 4 ni añadir Gate 4.
- **SDD-Tiny:** spot-check proporcional y limitaciones/fallos observados en el mismo
  `spec.md`; no exige cuota de RNF ni omite pruebas necesarias por riesgo.
- **Atención especial:** controles concretos y evidencia de garantías; el icono
  naranja no justifica omitir mecanismos de concurrencia, integridad o recuperación.
- **Entregas:** verificar garantías transversales e integración antes de cerrar el conjunto.
