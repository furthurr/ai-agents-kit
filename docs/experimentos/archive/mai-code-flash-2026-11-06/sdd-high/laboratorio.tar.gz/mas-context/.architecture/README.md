# Contexto para IA — fixture experimental
Base MDN LocalLibrary 3120b4302bf87a1b8c84d06662c2b8787f7da5f8. Django renderiza HTML con ORM y SQLite. `locallibrary/urls.py` incluye `catalog/urls.py`. `catalog/views.py` reúne listas y CRUD; `catalog/templates/base_generic.html` es compartida. No hay frontend SPA. Evidencia adicional: `docs/lab-context.md`.
