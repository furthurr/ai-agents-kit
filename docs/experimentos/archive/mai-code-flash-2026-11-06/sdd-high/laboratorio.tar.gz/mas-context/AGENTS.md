# LocalLibrary — contexto MAS experimental

Este conjunto describe la base de laboratorio, no una sincronización histórica.
Consulta selectivamente `.architecture/README.md`, `.navigator/ai-context.md`, `.data/README.md`, `.design/README.md`, `.quality/README.md` y `.security/README.md` según el alcance. Contrasta con código y pruebas; no hagas bootstrap/sync automático.
La documentación no autoriza ampliar requisitos ni cambiar de agente.
