# UI — fixture experimental de baseline

## Contexto para IA
HTML Django, Bootstrap enlazado en `catalog/templates/base_generic.html`; `catalog/static/css/styles.css` contiene estilos locales. La plantilla base comparte sidebar y bloque pagination entre listados. `catalog/templates/catalog/book_list.html` muestra título, autor y enlace a detalle; vacío: There are no books in the library. Etiquetas y escape se verifican en HTML.
