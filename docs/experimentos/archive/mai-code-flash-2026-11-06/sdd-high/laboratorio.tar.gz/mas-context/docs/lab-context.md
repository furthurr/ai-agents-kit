# Contexto Técnico del Laboratorio: LocalLibrary (MDN Tutorial)

Este documento contiene hechos verificables del código base de baseline para el laboratorio experimental. No prescribe soluciones ni arquitecturas para las tareas del benchmark.

## 1. Identificación y Propósito del Repositorio
- Proyecto: LocalLibrary (tutorial oficial de Django documentado por MDN Web Docs).
- Repositorio de procedencia: `mdn/django-locallibrary-tutorial` en GitHub.
- Commit congelado: `3120b4302bf87a1b8c84d06662c2b8787f7da5f8`.
- Licencia: CC0 1.0 Universal (Dominio Público).
- Propósito: Aplicación web de gestión de catálogo de biblioteca con interfaz renderizada por servidor (Django Templates), autenticación de usuarios, administración y préstamos de ejemplares.

## 2. Pila Tecnológica y Dependencias
- Lenguaje: Python 3.12 (virtualenv local en `.venv/`).
- Framework web: Django 6.1.1.
- Base de datos: SQLite3 (`db.sqlite3`), configurable vía variable de entorno `DATABASE_URL` (mediante `dj-database-url`).
- Archivos estáticos: `whitenoise 6.12.0` con almacenamiento comprimido con manifest (`CompressedManifestStaticFilesStorage`).
- Servidor WSGI: `gunicorn 26.2.0`.
- Driver PostgreSQL: `psycopg 3.3.6` / `psycopg-binary 3.3.6` (opcional en caso de usar Postgres externo; el baseline usa SQLite por defecto).
- Variables de entorno: `python-dotenv 1.2.3`.

## 3. Estructura del Código y Módulos
- `manage.py`: Script de gestión CLI de Django.
- `locallibrary/`: Paquete de configuración del proyecto:
  - `locallibrary/settings.py`: Configuración de base de datos SQLite por defecto, apps instaladas (`catalog.apps.CatalogConfig`), middleware de seguridad/CSP/whitenoise/sesiones/CSRF/auth, almacenamiento de estáticos y plantillas.
  - `locallibrary/urls.py`: Enrutamiento global (`/admin/`, `/catalog/`, `/accounts/`, redirección de raíz `/` a `/catalog/`).
  - `locallibrary/wsgi.py` y `locallibrary/asgi.py`: Puntos de entrada para servidores web.
- `catalog/`: Aplicación principal de catálogo:
  - `catalog/models.py`: Modelos de dominio (`Genre`, `Language`, `Book`, `BookInstance`, `Author`).
  - `catalog/views.py`: Vistas basadas en clases (`generic.ListView`, `generic.DetailView`, `CreateView`, `UpdateView`, `DeleteView`) y vistas basadas en funciones (`index`, `renew_book_librarian`).
  - `catalog/urls.py`: Rutas de la app de catálogo para listados, detalles, operaciones CRUD y renovación.
  - `catalog/forms.py`: Formularios (`RenewBookForm` con validación de fechas de renovación).
  - `catalog/admin.py`: Registro y configuración del panel de administración de Django (`AuthorAdmin`, `BookAdmin`, `BookInstanceAdmin`, `Genre`, `Language`).
  - `catalog/migrations/`: Migraciones del esquema de datos (0001 a 0029).
  - `catalog/tests/`: Suite de pruebas unitarias (`test_models.py`, `test_views.py`, `test_forms.py`).
- `templates/`: Plantillas globales de autenticación (`registration/login.html`, `registration/logged_out.html`, etc.).
- `catalog/templates/catalog/`: Plantillas específicas del catálogo (`book_list.html`, `book_detail.html`, `author_list.html`, etc.).

## 4. Modelos de Dominio y Contratos Existentes
1. `Author`:
   - Campos: `first_name` (CharField 100), `last_name` (CharField 100), `date_of_birth` (DateField, null/blank), `date_of_death` (DateField, null/blank).
   - Ordenamiento por defecto: `['last_name', 'first_name']`.
   - Método `get_absolute_url()` devuelve ruta `author-detail`.
2. `Genre`:
   - Campos: `name` (CharField 200, único).
   - Restricción: `UniqueConstraint` case-insensitive sobre `Lower('name')`.
   - Método `get_absolute_url()` devuelve ruta `genre-detail`.
3. `Language`:
   - Campos: `name` (CharField 200, único).
   - Restricción: `UniqueConstraint` case-insensitive sobre `Lower('name')`.
   - Método `get_absolute_url()` devuelve ruta `language-detail`.
4. `Book`:
   - Campos: `title` (CharField 200), `author` (ForeignKey Author, on_delete=RESTRICT, null=True), `summary` (TextField 1000), `isbn` (CharField 13, único), `genre` (ManyToManyField Genre), `language` (ForeignKey Language, on_delete=SET_NULL, null=True).
   - Ordenamiento: `['title', 'author']`.
   - Métodos: `display_genre()`, `get_absolute_url()` devuelve ruta `book-detail`.
5. `BookInstance`:
   - Campos: `id` (UUIDField, primary_key, default=uuid.uuid4), `book` (ForeignKey Book, on_delete=RESTRICT), `imprint` (CharField 200), `due_back` (DateField, null/blank), `borrower` (ForeignKey User, on_delete=SET_NULL, null/blank), `status` (CharField 1, choices: MAINTENANCE='m', ON_LOAN='o', AVAILABLE='a', RESERVED='r', default='m').
   - Propiedad: `is_overdue` (booleano, compara `due_back` con `date.today()`).
   - Permiso custom: `('can_mark_returned', 'Set book as returned')`.
   - Método `get_absolute_url()` devuelve ruta `bookinstance-detail`.

## 5. Pruebas y Comportamiento del Baseline
- La suite de pruebas oficial contiene 43 pruebas en `catalog/tests/`:
  - `catalog.tests.test_models`: 13 pruebas.
  - `catalog.tests.test_forms`: 4 pruebas.
  - `catalog.tests.test_views`: 26 pruebas.
- Comando de ejecución de pruebas: `.venv/bin/python manage.py test catalog`.
- Requisito de estáticos para pruebas: Al usar `CompressedManifestStaticFilesStorage` en `STORAGES['staticfiles']`, las plantillas que invocan `{% static ... %}` requieren que exista el manifiesto generado por `python manage.py collectstatic --noinput` o que se use el almacenamiento no manifiesto en pruebas. En el baseline preparado se generó `staticfiles/` mediante `collectstatic` para permitir ejecución limpia offline (43 tests pasando: `Ran 43 tests ... OK`).
