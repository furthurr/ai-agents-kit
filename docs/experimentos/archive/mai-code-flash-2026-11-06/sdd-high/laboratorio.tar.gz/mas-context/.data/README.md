# Datos — fixture experimental de baseline

## Contexto para IA
`catalog/models.py`: Book(title, author nullable, summary, isbn unique, genre M2M, language nullable), Author(first_name,last_name), Genre, Language, BookInstance. Book ordena por title/author; Author por last_name/first_name. `catalog/views.py`: BookListView y AuthorListView paginan a 10; catálogo público HTML. Préstamos personales requieren login; renovación requiere can_mark_returned. No hay contrato JSON de búsqueda. No almacenar datos personales reales en fixtures.
