# Mapa focalizado — fixture experimental
Listas y permisos: `catalog/views.py`. Entidades: `catalog/models.py`. Rutas: `catalog/urls.py`. Formularios: `catalog/forms.py`. HTML: `catalog/templates/`; estilos: `catalog/static/css/styles.css`. Tests: `catalog/tests/`. Este mapa no sustituye las fuentes.
