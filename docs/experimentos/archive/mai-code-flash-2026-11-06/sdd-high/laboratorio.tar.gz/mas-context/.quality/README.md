# Verificación — fixture experimental
La suite heredada está en `catalog/tests/`: modelos, formularios y vistas. Ejecutar `python manage.py test catalog` y `python manage.py check`. El manifiesto de estáticos se obtiene con `python manage.py collectstatic --noinput`. Los tests heredados no certifican todo comportamiento nuevo.
