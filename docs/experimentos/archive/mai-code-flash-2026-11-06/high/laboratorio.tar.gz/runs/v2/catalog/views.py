import datetime
import time
import uuid

from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db import DatabaseError, IntegrityError, OperationalError, transaction
from django.db.models import RestrictedError
from django.http import HttpResponseNotAllowed, HttpResponseRedirect, JsonResponse
from django.shortcuts import get_object_or_404, render
from django.urls import reverse, reverse_lazy
from django.views import generic
from django.views.decorators.http import require_http_methods
from django.views.generic.edit import CreateView, DeleteView, UpdateView

from .forms import RenewBookForm
from .models import Author, Book, BookInstance, Genre, Language, Reservation


def _get_header_or_post_key(request):
    key = request.headers.get('Idempotency-Key')
    if key is None:
        key = request.META.get('HTTP_IDEMPOTENCY_KEY')
    if key is None:
        key = request.POST.get('idempotency_key')
    if key is None:
        return None, 'invalid_key'
    key = str(key).strip()
    if not key or len(key) > 100:
        return None, 'invalid_key'
    return key, None


def _success_payload(instance_pk, user_id):
    return {
        'instance_id': str(instance_pk),
        'user_id': user_id,
        'status': BookInstance.LoanStatus.RESERVED,
    }


def _reserve_instance_for_user(user, instance_pk, key):
    try:
        instance = BookInstance.objects.filter(pk=instance_pk).first()
        if instance is None:
            return {'code': 404, 'payload': {'error': 'not_found'}}
        existing = Reservation.objects.filter(user=user, key=key).select_related('instance').first()
        if existing:
            if existing.instance_id == instance_pk:
                return {'code': 201, 'payload': _success_payload(instance_pk, user.id)}
            return {'code': 409, 'payload': {'error': 'idempotency_conflict'}}
    except (OperationalError, DatabaseError):
        pass

    for attempt in range(10):
        try:
            with transaction.atomic():
                existing = Reservation.objects.filter(user=user, key=key).select_related('instance').first()
                if existing:
                    if existing.instance_id == instance_pk:
                        return {'code': 201, 'payload': _success_payload(instance_pk, user.id)}
                    return {'code': 409, 'payload': {'error': 'idempotency_conflict'}}

                updated = BookInstance.objects.filter(
                    pk=instance_pk,
                    status=BookInstance.LoanStatus.AVAILABLE,
                ).update(status=BookInstance.LoanStatus.RESERVED, borrower=user)
                if updated != 1:
                    return {'code': 409, 'payload': {'error': 'unavailable'}}

                try:
                    Reservation.objects.create(user=user, instance_id=instance_pk, key=key)
                except IntegrityError:
                    BookInstance.objects.filter(pk=instance_pk, status=BookInstance.LoanStatus.RESERVED, borrower_id=user.id).update(
                        status=BookInstance.LoanStatus.AVAILABLE,
                        borrower=None,
                    )
                    conflict = Reservation.objects.filter(user=user, key=key).select_related('instance').first()
                    if conflict:
                        if conflict.instance_id == instance_pk:
                            return {'code': 201, 'payload': _success_payload(instance_pk, user.id)}
                        return {'code': 409, 'payload': {'error': 'idempotency_conflict'}}
                    raise

                return {'code': 201, 'payload': _success_payload(instance_pk, user.id)}
        except (OperationalError, DatabaseError):
            if attempt == 9:
                raise
            time.sleep(0.05 * (attempt + 1))

    return {'code': 409, 'payload': {'error': 'unavailable'}}


def reserve_book_instance_api(request, pk):
    if request.method != 'POST':
        return JsonResponse({'error': 'method_not_allowed'}, status=405)

    if not request.user.is_authenticated:
        return JsonResponse({'error': 'unauthorized'}, status=401)

    key, key_error = _get_header_or_post_key(request)
    if key_error:
        return JsonResponse({'error': key_error}, status=400)

    result = _reserve_instance_for_user(request.user, pk, key)
    return JsonResponse(result['payload'], status=result['code'])


@login_required
def reserve_book_instance_web(request, instance_pk):
    if request.method != 'POST':
        return HttpResponseRedirect(reverse('book-detail', kwargs={'pk': BookInstance.objects.filter(pk=instance_pk).values_list('book_id', flat=True).first()}))

    key, key_error = _get_header_or_post_key(request)
    if key_error:
        messages.error(request, 'Invalid reservation key.')
        return HttpResponseRedirect(reverse('book-detail', kwargs={'pk': BookInstance.objects.filter(pk=instance_pk).values_list('book_id', flat=True).first()}))

    instance = get_object_or_404(BookInstance, pk=instance_pk)
    result = _reserve_instance_for_user(request.user, instance_pk, key)
    if result['code'] == 201:
        messages.success(request, 'Reservation confirmed.')
    elif result['code'] == 409 and result['payload'].get('error') == 'idempotency_conflict':
        messages.error(request, 'This reservation key is already in use for another copy.')
    elif result['code'] == 404:
        messages.error(request, 'The requested copy was not found.')
    else:
        messages.error(request, 'This copy is not available for reservation.')
    return HttpResponseRedirect(reverse('book-detail', kwargs={'pk': instance.book_id}))


def index(request):
    """View function for home page of site."""
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    num_instances_available = BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()

    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    return render(request, 'index.html', context=context)


class BookListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = Book
    paginate_by = 10


class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        available_copies = list(self.object.bookinstance_set.filter(status=BookInstance.LoanStatus.AVAILABLE))
        for copy in available_copies:
            if self.request.user.is_authenticated:
                copy.reserve_key = f'{copy.id}-{self.request.user.id}-{uuid.uuid4().hex}'
            else:
                copy.reserve_key = f'{copy.id}-anon-{uuid.uuid4().hex}'
        context['available_copies'] = available_copies
        return context


class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10


class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre


class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10


class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language


class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10


class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10


class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance


class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    if request.method == 'POST':
        form = RenewBookForm(request.POST)
        if form.is_valid():
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()
            return HttpResponseRedirect(reverse('all-borrowed'))
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'


class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    fields = '__all__'
    permission_required = 'catalog.change_author'


class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(reverse('author-delete', kwargs={'pk': self.object.pk}))


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(reverse('book-delete', kwargs={'pk': self.object.pk}))


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name']
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name']
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name']
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name']
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'
