import datetime
import uuid

from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db import DatabaseError, transaction
from django.db.models import RestrictedError
from django.http import HttpResponseNotAllowed, HttpResponseRedirect, JsonResponse
from django.shortcuts import get_object_or_404, render
from django.urls import reverse, reverse_lazy
from django.views import generic
from django.views.generic.edit import CreateView, DeleteView, UpdateView

from catalog.forms import RenewBookForm

from .models import Author, Book, BookInstance, Genre, Language, Reservation


def index(request):
    """View function for home page of site."""
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE
    ).count()
    num_authors = Author.objects.count()

    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    return render(request, 'index.html', context=context)


class BookListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = Book
    paginate_by = 10


class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book


class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10


class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre


class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10


class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language


class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10


class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10


class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance


class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(
            status__exact=BookInstance.LoanStatus.ON_LOAN
        ).order_by('due_back')


def _get_valid_idempotency_key(request):
    key = request.META.get('HTTP_IDEMPOTENCY_KEY')
    if key is None:
        key = request.POST.get('idempotency_key')
    if key is None:
        return None
    key = str(key).strip()
    if not key or len(key) > 100:
        return None
    return key


def _reservation_payload(instance, user):
    return {
        'instance_id': str(instance.pk),
        'user_id': user.id,
        'status': instance.status,
    }


def _reserve_instance(user, instance, key):
    exact = Reservation.objects.filter(user=user, key=key, instance=instance).first()
    if exact is not None:
        return True, _reservation_payload(instance, user), 201

    if Reservation.objects.filter(user=user, key=key).exclude(instance=instance).exists():
        return False, {'error': 'idempotency_conflict'}, 409

    if instance.status != BookInstance.LoanStatus.AVAILABLE:
        return False, {'error': 'unavailable'}, 409

    for attempt in range(5):
        try:
            with transaction.atomic():
                current = BookInstance.objects.select_for_update().get(pk=instance.pk)

                existing = Reservation.objects.filter(user=user, key=key, instance=current).first()
                if existing is not None:
                    return True, _reservation_payload(current, user), 201

                if Reservation.objects.filter(user=user, key=key).exclude(instance=current).exists():
                    return False, {'error': 'idempotency_conflict'}, 409

                if current.status != BookInstance.LoanStatus.AVAILABLE:
                    return False, {'error': 'unavailable'}, 409

                updated = BookInstance.objects.filter(
                    pk=current.pk,
                    status=BookInstance.LoanStatus.AVAILABLE,
                ).update(
                    status=BookInstance.LoanStatus.RESERVED,
                    borrower=user,
                )
                if updated != 1:
                    return False, {'error': 'unavailable'}, 409

                Reservation.objects.create(user=user, instance=current, key=key)
                current.refresh_from_db()
                return True, _reservation_payload(current, user), 201
        except DatabaseError as exc:
            lowered = str(exc).lower()
            if 'locked' not in lowered and 'busy' not in lowered:
                raise
            if attempt == 4:
                return False, {'error': 'unavailable'}, 409

    return False, {'error': 'unavailable'}, 409


def reserve_book_instance_api(request, pk):
    if request.method != 'POST':
        return JsonResponse({'error': 'method_not_allowed'}, status=405)

    if not request.user.is_authenticated:
        return JsonResponse({'error': 'unauthorized'}, status=401)

    key = _get_valid_idempotency_key(request)
    if key is None:
        return JsonResponse({'error': 'invalid_key'}, status=400)

    instance = BookInstance.objects.filter(pk=pk).first()
    if instance is None:
        return JsonResponse({'error': 'not_found'}, status=404)

    success, payload, status_code = _reserve_instance(request.user, instance, key)
    return JsonResponse(payload, status=status_code)


@login_required
def reserve_book_instance_web(request, instance_pk):
    if request.method != 'POST':
        return HttpResponseNotAllowed(['POST'])

    instance = get_object_or_404(BookInstance, pk=instance_pk)
    key = _get_valid_idempotency_key(request)
    if key is None:
        messages.error(request, 'Reservation key is invalid.')
        return HttpResponseRedirect(instance.book.get_absolute_url())

    success, payload, status_code = _reserve_instance(request.user, instance, key)
    if success:
        messages.success(request, 'Book copy reserved successfully.')
        return HttpResponseRedirect(instance.book.get_absolute_url())

    error = payload.get('error', 'unknown')
    if error == 'idempotency_conflict':
        messages.error(request, 'This reservation key has been used for a different copy.')
    elif error == 'unavailable':
        messages.error(request, 'This copy is no longer available.')
    else:
        messages.error(request, 'Unable to reserve this copy.')
    return HttpResponseRedirect(instance.book.get_absolute_url())


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    if request.method == 'POST':
        form = RenewBookForm(request.POST)
        if form.is_valid():
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()
            return HttpResponseRedirect(reverse('all-borrowed'))
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'


class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    fields = '__all__'
    permission_required = 'catalog.change_author'


class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse('author-delete', kwargs={'pk': self.object.pk})
            )


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse('book-delete', kwargs={'pk': self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name']
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name']
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name']
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name']
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'
