from django.shortcuts import render

# Create your views here.

from .models import Book, Author, BookInstance, Genre, Language, Reservation

from django.db import IntegrityError, OperationalError, transaction
from django.http import HttpResponseNotAllowed, JsonResponse
from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
import time
import uuid


def _booking_payload(instance, user):
    return {"instance_id": str(instance.pk), "user_id": user.id, "status": "r"}


def _idempotency_key_from_request(request):
    key = request.headers.get('Idempotency-Key', request.META.get('HTTP_IDEMPOTENCY_KEY'))
    if key is None:
        return None
    key = key.strip()
    if not key or len(key) > 100:
        return None
    return key


def _reserve_instance_for_request(request, instance, key):
    payload = _booking_payload(instance, request.user)
    reservation = Reservation.objects.filter(user=request.user, key=key).first()
    if reservation is not None:
        if reservation.instance_id != instance.pk:
            return None, 409, {'error': 'idempotency_conflict'}
        return payload, 201, None

    for attempt in range(8):
        try:
            with transaction.atomic():
                reservation = Reservation.objects.filter(user=request.user, key=key).first()
                if reservation is not None:
                    if reservation.instance_id != instance.pk:
                        return None, 409, {'error': 'idempotency_conflict'}
                    return payload, 201, None

                updated = BookInstance.objects.filter(
                    pk=instance.pk,
                    status=BookInstance.LoanStatus.AVAILABLE,
                ).update(status=BookInstance.LoanStatus.RESERVED, borrower=request.user)
                if updated == 0:
                    return None, 409, {'error': 'unavailable'}

                try:
                    Reservation.objects.create(user=request.user, instance=instance, key=key)
                except IntegrityError:
                    conflict = Reservation.objects.filter(user=request.user, key=key).first()
                    if conflict is not None and conflict.instance_id != instance.pk:
                        return None, 409, {'error': 'idempotency_conflict'}
                    return payload, 201, None
                return payload, 201, None
        except OperationalError as exc:
            if 'locked' not in str(exc).lower():
                raise
            if attempt < 7:
                time.sleep(0.05 * (attempt + 1))
                continue
            return None, 409, {'error': 'unavailable'}
    return None, 409, {'error': 'unavailable'}


def reserve_bookinstance(request, pk):
    if request.method != 'POST':
        return JsonResponse({'error': 'method_not_allowed'}, status=405)
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'unauthorized'}, status=401)

    key = _idempotency_key_from_request(request)
    if key is None:
        return JsonResponse({'error': 'invalid_key'}, status=400)

    try:
        instance = BookInstance.objects.get(pk=pk)
    except BookInstance.DoesNotExist:
        return JsonResponse({'error': 'not_found'}, status=404)

    payload, status_code, error = _reserve_instance_for_request(request, instance, key)
    if error is not None:
        return JsonResponse(error, status=status_code)
    return JsonResponse(payload, status=status_code)


@login_required
def reserve_bookinstance_web(request, instance_pk):
    if request.method != 'POST':
        return HttpResponseNotAllowed(['POST'])

    key = request.POST.get('idempotency_key', '').strip()
    if not key or len(key) > 100:
        messages.error(request, 'Invalid reservation key.')
        return redirect('book-detail', pk=request.POST.get('book_id') if request.POST.get('book_id') else instance_pk)

    instance = get_object_or_404(BookInstance, pk=instance_pk)
    payload, status_code, error = _reserve_instance_for_request(request, instance, key)
    if error is not None:
        if error.get('error') == 'idempotency_conflict':
            messages.error(request, 'This reservation key has already been used for a different copy.')
        elif error.get('error') == 'unavailable':
            messages.error(request, 'This copy is no longer available.')
        elif error.get('error') == 'not_found':
            messages.error(request, 'The copy could not be found.')
        return redirect(instance.book.get_absolute_url())

    messages.success(request, 'Book copy reserved successfully.')
    return redirect(instance.book.get_absolute_url())


def index(request):
    """View function for home page of site."""
    # Generate counts of some of the main objects
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available copies of books
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Number of visits to this view, as counted in the session variable.
    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    # Render the HTML template index.html with the data in the context variable.
    return render(request, 'index.html', context=context)

from django.views import generic


class BookListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = Book
    paginate_by = 10

class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre

class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10

class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language

class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10

class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10

class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance

from django.contrib.auth.mixins import LoginRequiredMixin

class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )

# Added as part of challenge!
from django.contrib.auth.mixins import PermissionRequiredMixin


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')

from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
import datetime
from django.contrib.auth.decorators import login_required, permission_required
from catalog.forms import RenewBookForm


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed'))

    # If this is a GET (or any other method) create the default form
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import RestrictedError
from django.contrib.auth.mixins import PermissionRequiredMixin
from .models import Author


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'

class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    # Not recommended (potential security issue if more fields added)
    fields = '__all__'
    permission_required = 'catalog.change_author'

class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("author-delete", kwargs={"pk": self.object.pk})
            )

# Classes created for the forms challenge


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("book-delete", kwargs={"pk": self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    # fields = "__all__"
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'
