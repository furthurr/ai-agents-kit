# ODD Task: task-2-reservation

## Specs
- S1: Definir modelo Reservation en catalog.models con user (ForeignKey a settings.AUTH_USER_MODEL), instance (ForeignKey a BookInstance), key (CharField(max_length=100)), created_at (DateTimeField(auto_now_add=True)) y constraint de unicidad [user, key].
- S2: API Endpoint POST /catalog/api/bookinstance/<uuid:pk>/reserve/:
  - Autenticación: Requiere usuario autenticado (401 Unauthorized con {'error': 'unauthorized'}).
  - Método HTTP: Solo POST (405 Method Not Allowed para otros).
  - Header Idempotency-Key obligatorio: strip, len <= 100; si falta, vacío o >100 -> 400 Bad Request con {'error': 'invalid_key'}.
  - Instancia inexistente: 404 Not Found con {'error': 'not_found'}.
  - Ejemplar no disponible: status != 'a' -> 409 Conflict con {'error': 'unavailable'}.
  - Éxito (primera reserva): transicionar status a 'r', borrower=request.user, guardar Reservation con key provista. Retornar 201 Created con {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}.
  - Replay / Idempotencia exacta: mismo usuario, misma key, misma instancia ya reservada -> 201 Created idéntico payload sin duplicar Reservation ni alterar estado.
  - Conflicto de Idempotencia: mismo usuario, misma key para OTRA instancia -> 409 Conflict con {'error': 'idempotency_conflict'}.
  - Persistencia de idempotencia: persistir en BD para sesiones/conexiones subsiguientes.
- S3: Concurrencia real bajo SQLite:
  - Dos solicitudes concurrentes de distintos usuarios sobre la misma copia 'a' -> exactamente un 201 Created y un 409 Conflict {'error': 'unavailable'}.
  - Uso de conditional UPDATE atómico / rowcount verification y retry ante locks sin 500 database locked.
  - Ninguna petición fallida (400, 401, 404, 405, 409) muta el estado de BookInstance ni deja reservas espurias.
- S4: Interfaz Web (UI):
  - En /catalog/book/<int:pk>, para cada copia con status='a', incluir botón/formulario de reserva apuntando a /catalog/book/<uuid:instance_pk>/reserve/.
  - POST /catalog/book/<uuid:instance_pk>/reserve/ requiere autenticación (login_required).
  - Incluye token CSRF y campo hidden idempotency_key generado.
  - Al completarse con éxito, mensaje de confirmación visible (flash message de éxito o confirmación en detalle).
- S5: Suite original de 43 tests debe seguir pasando intacta.

## Tasks
- T1 (S1): Modelo Reservation y migración. [COMPLETED]
- T2 (S2, S3): API endpoint de reserva con idempotencia y concurrencia. [COMPLETED]
- T3 (S4): UI web en book_detail y vista de reserva web. [COMPLETED]
- T4 (S1-S5): Pruebas completas (RED -> GREEN) y verificación de suite de 43 tests originales. [COMPLETED]

## Log
- L1: Petición original recibida:
  "Implementar flujo de reserva de ejemplares disponibles (BookInstance con status='a') para usuarios autenticados, con persistencia de reservas, garantía de idempotencia en reintentos y tolerancia a concurrencia real bajo SQLite."
- L2: Implementado modelo Reservation con constraint de unicidad (user, key) y migración 0030_reservation.py.
- L3: Implementado endpoint API POST /catalog/api/bookinstance/<uuid:pk>/reserve/ y vista web POST /catalog/book/<uuid:instance_pk>/reserve/.
- L4: Implementada UI web en book_detail.html con soporte de mensajes en base_generic.html.
- L5: Verificación ejecutada: 16 nuevos tests creados y pasando; 59 tests en total (43 originales + 16 nuevos) pasando con éxito (GREEN).

