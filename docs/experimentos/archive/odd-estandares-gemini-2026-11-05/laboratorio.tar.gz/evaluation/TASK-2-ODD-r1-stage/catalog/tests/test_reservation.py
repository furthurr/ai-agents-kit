import uuid
from django.test import TestCase, TransactionTestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from catalog.models import Book, Author, Genre, Language, BookInstance, Reservation
import concurrent.futures

User = get_user_model()


class ReservationModelTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='password123')
        self.user2 = User.objects.create_user(username='testuser2', password='password123')
        self.author = Author.objects.create(first_name='Gabriel', last_name='Garcia Marquez')
        self.book = Book.objects.create(title='Cien Anos de Soledad', author=self.author, isbn='1234567890123')
        self.instance1 = BookInstance.objects.create(book=self.book, imprint='Test Imprint 1', status='a')
        self.instance2 = BookInstance.objects.create(book=self.book, imprint='Test Imprint 2', status='a')

    def test_reservation_creation_and_fields(self):
        reservation = Reservation.objects.create(
            user=self.user,
            instance=self.instance1,
            key='key-123'
        )
        self.assertEqual(reservation.user, self.user)
        self.assertEqual(reservation.instance, self.instance1)
        self.assertEqual(reservation.key, 'key-123')
        self.assertIsNotNone(reservation.created_at)

    def test_reservation_uniqueness_user_key(self):
        Reservation.objects.create(user=self.user, instance=self.instance1, key='idem-key-1')
        # Same user, same key should fail uniqueness
        with self.assertRaises(Exception):
            Reservation.objects.create(user=self.user, instance=self.instance2, key='idem-key-1')

    def test_reservation_different_users_same_key(self):
        # Different users can use the same key
        r1 = Reservation.objects.create(user=self.user, instance=self.instance1, key='idem-key-1')
        r2 = Reservation.objects.create(user=self.user2, instance=self.instance2, key='idem-key-1')
        self.assertNotEqual(r1.id, r2.id)


class ReservationApiTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='user1', password='password123')
        self.user2 = User.objects.create_user(username='user2', password='password123')
        self.author = Author.objects.create(first_name='Jane', last_name='Austen')
        self.book = Book.objects.create(title='Pride and Prejudice', author=self.author, isbn='9876543210123')
        self.instance = BookInstance.objects.create(book=self.book, imprint='First edition', status='a')
        self.reserve_url = reverse('api-bookinstance-reserve', kwargs={'pk': self.instance.pk})

    def test_api_unauthorized_user(self):
        response = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_api_method_not_allowed(self):
        self.client.login(username='user1', password='password123')
        response = self.client.get(self.reserve_url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 405)

    def test_api_missing_or_invalid_idempotency_key(self):
        self.client.login(username='user1', password='password123')
        # Missing key
        response = self.client.post(self.reserve_url)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

        # Empty key after strip
        response = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

        # Key exceeding 100 chars
        response = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='k' * 101)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

    def test_api_nonexistent_instance(self):
        self.client.login(username='user1', password='password123')
        non_existent_url = reverse('api-bookinstance-reserve', kwargs={'pk': uuid.uuid4()})
        response = self.client.post(non_existent_url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_api_unavailable_instance(self):
        self.client.login(username='user1', password='password123')
        self.instance.status = 'm'
        self.instance.save()
        response = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})

    def test_api_successful_reservation(self):
        self.client.login(username='user1', password='password123')
        response = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), {
            "instance_id": str(self.instance.pk),
            "user_id": self.user.id,
            "status": "r"
        })
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, 'r')
        self.assertEqual(self.instance.borrower, self.user)
        self.assertTrue(Reservation.objects.filter(user=self.user, instance=self.instance, key='key-123').exists())

    def test_api_idempotent_replay_same_instance(self):
        self.client.login(username='user1', password='password123')
        # First request
        res1 = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='key-same')
        self.assertEqual(res1.status_code, 201)
        expected_json = {
            "instance_id": str(self.instance.pk),
            "user_id": self.user.id,
            "status": "r"
        }
        self.assertEqual(res1.json(), expected_json)

        # Replay same request
        res2 = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='key-same')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), expected_json)

        # Check no duplicate reservations
        self.assertEqual(Reservation.objects.filter(user=self.user, key='key-same').count(), 1)

    def test_api_idempotency_conflict_different_instance(self):
        self.client.login(username='user1', password='password123')
        res1 = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='key-reuse')
        self.assertEqual(res1.status_code, 201)

        instance2 = BookInstance.objects.create(book=self.book, imprint='Second edition', status='a')
        url2 = reverse('api-bookinstance-reserve', kwargs={'pk': instance2.pk})

        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='key-reuse')
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})

        # Verify instance2 is still available
        instance2.refresh_from_db()
        self.assertEqual(instance2.status, 'a')
        self.assertIsNone(instance2.borrower)

    def test_api_failed_requests_do_not_mutate_state(self):
        # 400 does not mutate
        self.client.login(username='user1', password='password123')
        res = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='')
        self.assertEqual(res.status_code, 400)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, 'a')
        self.assertIsNone(self.instance.borrower)
        self.assertEqual(Reservation.objects.count(), 0)


class ReservationConcurrencyTests(TransactionTestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='concurrent_user1', password='password123')
        self.user2 = User.objects.create_user(username='concurrent_user2', password='password123')
        self.author = Author.objects.create(first_name='Concurrent', last_name='Author')
        self.book = Book.objects.create(title='Concurrency Book', author=self.author, isbn='1112223334445')
        self.instance = BookInstance.objects.create(book=self.book, imprint='Concurrent copy', status='a')
        self.url = reverse('api-bookinstance-reserve', kwargs={'pk': self.instance.pk})

    def test_concurrent_reservations_same_instance(self):
        from django.test import Client

        c1 = Client()
        c1.force_login(self.user1)

        c2 = Client()
        c2.force_login(self.user2)

        def try_reserve(client, key):
            return client.post(self.url, HTTP_IDEMPOTENCY_KEY=key)

        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            future1 = executor.submit(try_reserve, c1, 'key-c1')
            future2 = executor.submit(try_reserve, c2, 'key-c2')
            r1 = future1.result()
            r2 = future2.result()

        status_codes = sorted([r1.status_code, r2.status_code])
        self.assertEqual(status_codes, [201, 409])

        if r1.status_code == 201:
            self.assertEqual(r2.json(), {'error': 'unavailable'})
        else:
            self.assertEqual(r1.json(), {'error': 'unavailable'})

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, 'r')
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)


class ReservationUITests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='ui_user', password='password123')
        self.author = Author.objects.create(first_name='UI', last_name='Tester')
        self.book = Book.objects.create(title='UI Test Book', author=self.author, isbn='9998887776665')
        self.instance_avail = BookInstance.objects.create(book=self.book, imprint='Copy 1', status='a')
        self.instance_loan = BookInstance.objects.create(book=self.book, imprint='Copy 2', status='o')

    def test_book_detail_shows_reserve_form_for_available_only(self):
        response = self.client.get(reverse('book-detail', kwargs={'pk': self.book.pk}))
        self.assertEqual(response.status_code, 200)
        reserve_avail_url = reverse('bookinstance-reserve-ui', kwargs={'instance_pk': self.instance_avail.pk})
        self.assertContains(response, reserve_avail_url)
        self.assertContains(response, 'idempotency_key')
        self.assertContains(response, 'Reserve')

        reserve_loan_url = f"/catalog/book/{self.instance_loan.pk}/reserve/"
        self.assertNotContains(response, reserve_loan_url)

    def test_ui_reserve_requires_login(self):
        url = reverse('bookinstance-reserve-ui', kwargs={'instance_pk': self.instance_avail.pk})
        response = self.client.post(url, {'idempotency_key': 'web-key-1'})
        # Should redirect to login
        self.assertEqual(response.status_code, 302)
        self.assertIn('/accounts/login/', response.url)

    def test_ui_reserve_success_and_flash_message(self):
        self.client.login(username='ui_user', password='password123')
        url = reverse('bookinstance-reserve-ui', kwargs={'instance_pk': self.instance_avail.pk})
        response = self.client.post(url, {'idempotency_key': 'web-key-1'}, follow=True)
        self.assertEqual(response.status_code, 200)
        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, 'r')
        self.assertEqual(self.instance_avail.borrower, self.user)
        # Message of confirmation visible
        self.assertContains(response, 'successfully reserved')
