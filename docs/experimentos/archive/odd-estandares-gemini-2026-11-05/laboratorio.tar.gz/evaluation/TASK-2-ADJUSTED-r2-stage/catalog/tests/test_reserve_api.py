import uuid
import threading
from django.test import TransactionTestCase
from django.test import TestCase, Client
from django.db import connection
from django.contrib.auth import get_user_model
from django.urls import reverse
from catalog.models import Book, BookInstance, Genre, Language, Reservation


User = get_user_model()

class ReserveAPITests(TestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='user1', password='password123')
        self.user2 = User.objects.create_user(username='user2', password='password123')
        self.book = Book.objects.create(
            title='Test Book',
            summary='Test summary',
            isbn='1234567890123'
        )
        self.instance_available = BookInstance.objects.create(
            book=self.book,
            imprint='Test imprint',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.instance_on_loan = BookInstance.objects.create(
            book=self.book,
            imprint='Test imprint 2',
            status=BookInstance.LoanStatus.ON_LOAN
        )
        self.reserve_url = f'/catalog/api/bookinstance/{self.instance_available.id}/reserve/'

    def test_anonymous_user_returns_401(self):
        response = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_get_method_returns_405(self):
        self.client.login(username='user1', password='password123')
        response = self.client.get(self.reserve_url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 405)

    def test_missing_or_invalid_idempotency_key_returns_400(self):
        self.client.login(username='user1', password='password123')
        # Missing header
        res1 = self.client.post(self.reserve_url)
        self.assertEqual(res1.status_code, 400)
        self.assertEqual(res1.json(), {'error': 'invalid_key'})

        # Empty / whitespace key
        res2 = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(res2.status_code, 400)
        self.assertEqual(res2.json(), {'error': 'invalid_key'})

        # Key longer than 100 chars
        res3 = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='a' * 101)
        self.assertEqual(res3.status_code, 400)
        self.assertEqual(res3.json(), {'error': 'invalid_key'})

    def test_nonexistent_instance_returns_404(self):
        self.client.login(username='user1', password='password123')
        bad_url = f'/catalog/api/bookinstance/{uuid.uuid4()}/reserve/'
        res = self.client.post(bad_url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(res.status_code, 404)
        self.assertEqual(res.json(), {'error': 'not_found'})

    def test_unavailable_instance_returns_409(self):
        self.client.login(username='user1', password='password123')
        unavailable_url = f'/catalog/api/bookinstance/{self.instance_on_loan.id}/reserve/'
        res = self.client.post(unavailable_url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(res.status_code, 409)
        self.assertEqual(res.json(), {'error': 'unavailable'})
        self.instance_on_loan.refresh_from_db()
        self.assertEqual(self.instance_on_loan.status, BookInstance.LoanStatus.ON_LOAN)

    def test_successful_reservation(self):
        self.client.login(username='user1', password='password123')
        res = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='key-success-1')
        self.assertEqual(res.status_code, 201)
        expected = {
            "instance_id": str(self.instance_available.id),
            "user_id": self.user1.id,
            "status": "r"
        }
        self.assertEqual(res.json(), expected)

        # Check DB mutations
        self.instance_available.refresh_from_db()
        self.assertEqual(self.instance_available.status, 'r')
        self.assertEqual(self.instance_available.borrower, self.user1)

        reservation = Reservation.objects.get(user=self.user1, key='key-success-1')
        self.assertEqual(reservation.instance, self.instance_available)

    def test_replay_idempotency_returns_exact_201(self):
        self.client.login(username='user1', password='password123')
        # First request
        res1 = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='key-replay-1')
        self.assertEqual(res1.status_code, 201)
        expected = {
            "instance_id": str(self.instance_available.id),
            "user_id": self.user1.id,
            "status": "r"
        }
        self.assertEqual(res1.json(), expected)

        # Replay request
        res2 = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='key-replay-1')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), expected)
        self.assertEqual(Reservation.objects.filter(user=self.user1, key='key-replay-1').count(), 1)

    def test_idempotency_conflict_returns_409(self):
        self.client.login(username='user1', password='password123')
        # Reserve first copy with key-conflict-1
        res1 = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='key-conflict-1')
        self.assertEqual(res1.status_code, 201)

        # Another available instance
        another_instance = BookInstance.objects.create(
            book=self.book,
            imprint='Another imprint',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        another_url = f'/catalog/api/bookinstance/{another_instance.id}/reserve/'

        # Attempt to use same key for another instance
        res2 = self.client.post(another_url, HTTP_IDEMPOTENCY_KEY='key-conflict-1')
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})
        another_instance.refresh_from_db()
        self.assertEqual(another_instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_different_users_with_same_key_are_independent(self):
        # User 1 reserves instance_available with 'common-key'
        self.client.login(username='user1', password='password123')
        res1 = self.client.post(self.reserve_url, HTTP_IDEMPOTENCY_KEY='common-key')
        self.assertEqual(res1.status_code, 201)
        self.client.logout()

        # Another instance for User 2
        inst2 = BookInstance.objects.create(
            book=self.book,
            imprint='Inst 2',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        url2 = f'/catalog/api/bookinstance/{inst2.id}/reserve/'

        # User 2 reserves inst2 with same 'common-key'
        self.client.login(username='user2', password='password123')
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='common-key')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json()['user_id'], self.user2.id)


class ReserveConcurrencyTests(TransactionTestCase):
    def test_concurrent_reservations_result_in_one_201_and_one_409(self):
        user_a = User.objects.create_user(username='concurrent_a', password='password123')
        user_b = User.objects.create_user(username='concurrent_b', password='password123')
        book = Book.objects.create(
            title='Concurrent Book',
            summary='Concurrent summary',
            isbn='9999999999999'
        )
        instance = BookInstance.objects.create(
            book=book,
            imprint='Concurrent Imprint',
            status=BookInstance.LoanStatus.AVAILABLE
        )

        results = []
        barrier = threading.Barrier(2)

        def make_request(username, key):
            client = Client()
            client.login(username=username, password='password123')
            url = f'/catalog/api/bookinstance/{instance.id}/reserve/'
            try:
                barrier.wait(timeout=5)
            except Exception:
                pass
            response = client.post(url, HTTP_IDEMPOTENCY_KEY=key)
            results.append((response.status_code, response.json()))
            connection.close()

        t1 = threading.Thread(target=make_request, args=('concurrent_a', 'key-a'))
        t2 = threading.Thread(target=make_request, args=('concurrent_b', 'key-b'))

        t1.start()
        t2.start()
        t1.join()
        t2.join()

        status_codes = sorted([r[0] for r in results])
        self.assertEqual(status_codes, [201, 409])
        errors_or_success = [r[1] for r in results if r[0] == 409]
        self.assertEqual(errors_or_success[0], {'error': 'unavailable'})

        instance.refresh_from_db()
        self.assertEqual(instance.status, 'r')
        self.assertIn(instance.borrower, [user_a, user_b])
        self.assertEqual(Reservation.objects.filter(instance=instance).count(), 1)

