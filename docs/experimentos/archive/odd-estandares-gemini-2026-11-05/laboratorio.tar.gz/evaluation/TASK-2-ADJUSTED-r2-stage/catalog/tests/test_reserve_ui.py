import uuid
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from catalog.models import Book, BookInstance, Reservation

User = get_user_model()

class ReserveUIViewTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='ui_user', password='password123')
        self.book = Book.objects.create(
            title='UI Book',
            summary='UI Summary',
            isbn='1112223334445'
        )
        self.instance_available = BookInstance.objects.create(
            book=self.book,
            imprint='UI Imprint',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.instance_on_loan = BookInstance.objects.create(
            book=self.book,
            imprint='UI Imprint 2',
            status=BookInstance.LoanStatus.ON_LOAN
        )
        self.book_detail_url = reverse('book-detail', args=[self.book.id])
        self.reserve_ui_url = reverse('reserve-bookinstance', args=[self.instance_available.id])

    def test_book_detail_renders_reserve_button_and_csrf_for_available_copies(self):
        response = self.client.get(self.book_detail_url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, f'action="{self.reserve_ui_url}"')
        self.assertContains(response, 'name="csrfmiddlewaretoken"')
        self.assertContains(response, 'name="idempotency_key"')
        self.assertContains(response, 'Reserve')

    def test_unauthenticated_user_redirected_to_login(self):
        response = self.client.post(self.reserve_ui_url, {'idempotency_key': 'key-ui-1'})
        self.assertEqual(response.status_code, 302)
        self.assertIn('/accounts/login/', response.url)

    def test_authenticated_user_can_reserve_and_redirects_with_message(self):
        self.client.login(username='ui_user', password='password123')
        response = self.client.post(
            self.reserve_ui_url,
            {'idempotency_key': 'key-ui-1'},
            follow=True
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Book successfully reserved.')

        self.instance_available.refresh_from_db()
        self.assertEqual(self.instance_available.status, 'r')
        self.assertEqual(self.instance_available.borrower, self.user)
        self.assertTrue(Reservation.objects.filter(user=self.user, key='key-ui-1').exists())

    def test_ui_reserve_idempotency_replay(self):
        self.client.login(username='ui_user', password='password123')
        # First POST
        res1 = self.client.post(self.reserve_ui_url, {'idempotency_key': 'replay-key'}, follow=True)
        self.assertContains(res1, 'Book successfully reserved.')

        # Replay POST
        res2 = self.client.post(self.reserve_ui_url, {'idempotency_key': 'replay-key'}, follow=True)
        self.assertContains(res2, 'Book successfully reserved.')
        self.assertEqual(Reservation.objects.filter(user=self.user, key='replay-key').count(), 1)
