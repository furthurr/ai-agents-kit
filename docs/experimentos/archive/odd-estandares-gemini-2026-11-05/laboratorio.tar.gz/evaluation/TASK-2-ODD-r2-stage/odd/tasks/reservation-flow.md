# Reservation Flow

## Specs
- S1: Definir modelo Reservation en catalog.models con user (ForeignKey settings.AUTH_USER_MODEL, on_delete=CASCADE), instance (ForeignKey BookInstance, on_delete=CASCADE), key (CharField max_length=100), created_at (DateTimeField auto_now_add=True) y UniqueConstraint/unique_together sobre [user, key].
- S2: API Endpoint POST /catalog/api/bookinstance/<uuid:pk>/reserve/ requiriendo autenticación (401 {'error': 'unauthorized'}), solo POST (405 Method Not Allowed), header Idempotency-Key obligatorio 1..100 chars (400 {'error': 'invalid_key'}), pk no existente (404 {'error': 'not_found'}), status!='a' (409 {'error': 'unavailable'}), éxito 201 Created con {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}, replay idempotente 201 Created con mismo payload, conflicto de key reutilizada en otra instancia (409 {'error': 'idempotency_conflict'}).
- S3: Garantía de concurrencia bajo SQLite en disco asegurando exactamente un 201 Created y un 409 Conflict ante carreras por la misma copia 'a', sin 500 database locked ni mutaciones espurias ante fallos.
- S4: Interfaz Web (UI) en /catalog/book/<int:pk> con formulario de reserva para copias con status='a' apuntando a /catalog/book/<uuid:instance_pk>/reserve/, requiere login (redirige a login si anónimo), incluye CSRF e idempotency_key oculta para prevenir doble submit, y mensaje de confirmación visible al completar con éxito.
- S5: Suite original (43 tests) intacta y retrocompatibilidad preserved.

## Tasks
- [ ] T1 (S1): Modelo Reservation y migración en catalog.
- [ ] T2 (S2, S3): Vista API POST /catalog/api/bookinstance/<uuid:pk>/reserve/ con idempotencia y concurrencia.
- [ ] T3 (S4): Formulario en detalle de libro y endpoint UI /catalog/book/<uuid:instance_pk>/reserve/.
- [ ] T4 (S3, S5): Tests unitarios, de idempotencia, UI, concurrencia real SQLite y verificación completa de la suite.

## Log
- L1: Petición original recibida: "Implementar flujo de reserva de ejemplares disponibles (BookInstance con status='a') para usuarios autenticados, con persistencia de reservas, garantía de idempotencia en reintentos y tolerancia a concurrencia real bajo SQLite. CONTRATOS EXACTOS: ..."
