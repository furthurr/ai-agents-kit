import uuid
from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from catalog.models import Book, BookInstance, Reservation

User = get_user_model()

class BookInstanceUiReservationTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='ui_user', password='password123')
        self.book = Book.objects.create(title='Test UI Book', summary='Test summary', isbn='9876543210987')
        self.instance_avail = BookInstance.objects.create(
            book=self.book,
            imprint='Test imprint',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.reserve_url = f'/catalog/book/{self.instance_avail.id}/reserve/'

    def test_book_detail_renders_reserve_button_and_hidden_key(self):
        detail_url = reverse('book-detail', kwargs={'pk': self.book.pk})
        response = self.client.get(detail_url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, f'action="{self.reserve_url}"')
        self.assertContains(response, 'name="idempotency_key"')
        self.assertContains(response, 'Reserve copy')

    def test_anonymous_user_redirected_to_login(self):
        response = self.client.post(self.reserve_url, {'idempotency_key': 'key-ui-1'})
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/'))

    def test_authenticated_user_reserves_successfully(self):
        self.client.login(username='ui_user', password='password123')
        key = str(uuid.uuid4())
        response = self.client.post(self.reserve_url, {'idempotency_key': key}, follow=True)
        self.assertEqual(response.status_code, 200)
        # Check flash message on redirected book-detail page
        self.assertContains(response, 'reserved successfully')

        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, 'r')
        self.assertEqual(self.instance_avail.borrower, self.user)
        self.assertTrue(Reservation.objects.filter(user=self.user, instance=self.instance_avail, key=key).exists())

    def test_ui_double_submission_replay(self):
        self.client.login(username='ui_user', password='password123')
        key = str(uuid.uuid4())
        resp1 = self.client.post(self.reserve_url, {'idempotency_key': key}, follow=True)
        self.assertEqual(resp1.status_code, 200)
        self.assertContains(resp1, 'reserved successfully')

        # Replay with same key
        resp2 = self.client.post(self.reserve_url, {'idempotency_key': key}, follow=True)
        self.assertEqual(resp2.status_code, 200)
        self.assertContains(resp2, 'reserved successfully')
        self.assertEqual(Reservation.objects.filter(user=self.user, key=key).count(), 1)
