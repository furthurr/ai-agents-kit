import threading
import uuid
from django.test import TransactionTestCase
from django.test import Client
from django.contrib.auth import get_user_model
from django.db import connection
from catalog.models import Book, BookInstance, Reservation

User = get_user_model()

class BookInstanceConcurrencyTest(TransactionTestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='concurrent_user1', password='password123')
        self.user2 = User.objects.create_user(username='concurrent_user2', password='password123')
        self.book = Book.objects.create(title='Concurrency Test Book', summary='Test summary', isbn='1112223334445')
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Concurrency Imprint',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.url = f'/catalog/api/bookinstance/{self.instance.id}/reserve/'

    def test_concurrent_reservations_result_in_one_success_and_one_conflict(self):
        client1 = Client()
        client1.force_login(self.user1)

        client2 = Client()
        client2.force_login(self.user2)

        results = []
        barrier = threading.Barrier(2)

        def make_request(client, username, key):
            try:
                # Wait for both threads to be ready to execute simultaneously
                barrier.wait(timeout=10)
                resp = client.post(self.url, HTTP_IDEMPOTENCY_KEY=key)
                results.append((username, resp.status_code, resp.json()))
            finally:
                connection.close()

        t1 = threading.Thread(target=make_request, args=(client1, 'concurrent_user1', 'key-user-1'))
        t2 = threading.Thread(target=make_request, args=(client2, 'concurrent_user2', 'key-user-2'))

        t1.start()
        t2.start()
        t1.join(timeout=15)
        t2.join(timeout=15)

        status_codes = [r[1] for r in results]
        self.assertEqual(sorted(status_codes), [201, 409])

        success_resps = [r for r in results if r[1] == 201]
        conflict_resps = [r for r in results if r[1] == 409]

        self.assertEqual(len(success_resps), 1)
        self.assertEqual(len(conflict_resps), 1)
        self.assertEqual(conflict_resps[0][2], {'error': 'unavailable'})

        # Verify DB state
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, 'r')
        self.assertIn(self.instance.borrower, [self.user1, self.user2])

        # Exactly 1 reservation record created
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)
