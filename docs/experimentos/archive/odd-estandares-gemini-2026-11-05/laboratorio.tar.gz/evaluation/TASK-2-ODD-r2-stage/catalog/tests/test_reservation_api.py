import uuid
from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from catalog.models import Book, BookInstance, Reservation

User = get_user_model()

class BookInstanceApiReservationTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='res_user', password='password123')
        self.other_user = User.objects.create_user(username='other_user', password='password123')
        self.book = Book.objects.create(title='Test Book', summary='Test summary', isbn='1234567890123')
        self.instance_avail = BookInstance.objects.create(
            book=self.book,
            imprint='Test imprint',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.instance_loan = BookInstance.objects.create(
            book=self.book,
            imprint='Test imprint 2',
            status=BookInstance.LoanStatus.ON_LOAN
        )
        self.url = f'/catalog/api/bookinstance/{self.instance_avail.id}/reserve/'

    def test_unauthenticated_returns_401(self):
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_get_not_allowed_returns_405(self):
        self.client.login(username='res_user', password='password123')
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 405)

    def test_missing_or_invalid_idempotency_key_returns_400(self):
        self.client.login(username='res_user', password='password123')
        # Missing key
        response = self.client.post(self.url)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})
        # Empty / whitespace key
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})
        # Key > 100 chars
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='k' * 101)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

    def test_nonexistent_instance_returns_404(self):
        self.client.login(username='res_user', password='password123')
        fake_uuid = uuid.uuid4()
        response = self.client.post(f'/catalog/api/bookinstance/{fake_uuid}/reserve/', HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_unavailable_instance_returns_409(self):
        self.client.login(username='res_user', password='password123')
        response = self.client.post(f'/catalog/api/bookinstance/{self.instance_loan.id}/reserve/', HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})

    def test_successful_reservation(self):
        self.client.login(username='res_user', password='password123')
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), {
            "instance_id": str(self.instance_avail.id),
            "user_id": self.user.id,
            "status": "r"
        })
        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, 'r')
        self.assertEqual(self.instance_avail.borrower, self.user)
        self.assertTrue(Reservation.objects.filter(user=self.user, instance=self.instance_avail, key='key-123').exists())

    def test_idempotent_replay_same_instance(self):
        self.client.login(username='res_user', password='password123')
        resp1 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(resp1.status_code, 201)
        # Replay
        resp2 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(resp2.status_code, 201)
        self.assertEqual(resp2.json(), {
            "instance_id": str(self.instance_avail.id),
            "user_id": self.user.id,
            "status": "r"
        })
        self.assertEqual(Reservation.objects.filter(user=self.user, key='key-123').count(), 1)

    def test_idempotency_conflict_different_instance(self):
        self.client.login(username='res_user', password='password123')
        resp1 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(resp1.status_code, 201)

        instance2 = BookInstance.objects.create(
            book=self.book,
            imprint='Test imprint 3',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        resp2 = self.client.post(f'/catalog/api/bookinstance/{instance2.id}/reserve/', HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(resp2.status_code, 409)
        self.assertEqual(resp2.json(), {'error': 'idempotency_conflict'})
        # instance2 must remain available
        instance2.refresh_from_db()
        self.assertEqual(instance2.status, 'a')

    def test_independent_keys_across_users(self):
        # User 1 reserves
        self.client.login(username='res_user', password='password123')
        resp1 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='same-key')
        self.assertEqual(resp1.status_code, 201)
        self.client.logout()

        # User 2 reserves another instance with the same key
        instance2 = BookInstance.objects.create(
            book=self.book,
            imprint='Test imprint 3',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.client.login(username='other_user', password='password123')
        resp2 = self.client.post(f'/catalog/api/bookinstance/{instance2.id}/reserve/', HTTP_IDEMPOTENCY_KEY='same-key')
        self.assertEqual(resp2.status_code, 201)
        self.assertEqual(resp2.json(), {
            "instance_id": str(instance2.id),
            "user_id": self.other_user.id,
            "status": "r"
        })
