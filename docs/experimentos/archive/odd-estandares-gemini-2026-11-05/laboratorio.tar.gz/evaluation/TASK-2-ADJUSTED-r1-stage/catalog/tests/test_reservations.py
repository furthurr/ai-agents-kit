import uuid
import threading
from django.test import TestCase, TransactionTestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from catalog.models import Book, Author, BookInstance, Genre, Reservation

User = get_user_model()


class ReservationModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user('testuser', 'test@example.com', 'password')
        self.author = Author.objects.create(first_name='John', last_name='Doe')
        self.book = Book.objects.create(title='Test Book', author=self.author, summary='Summary', isbn='1234567890123')
        self.instance = BookInstance.objects.create(book=self.book, imprint='Test Imprint', status='a')

    def test_reservation_creation(self):
        res = Reservation.objects.create(user=self.user, instance=self.instance, key='key-1')
        self.assertEqual(res.user, self.user)
        self.assertEqual(res.instance, self.instance)
        self.assertEqual(res.key, 'key-1')
        self.assertIsNotNone(res.created_at)

    def test_reservation_unique_user_key_constraint(self):
        Reservation.objects.create(user=self.user, instance=self.instance, key='key-1')
        from django.db import IntegrityError
        with self.assertRaises(IntegrityError):
            Reservation.objects.create(user=self.user, instance=self.instance, key='key-1')

    def test_reservation_different_users_same_key(self):
        user2 = User.objects.create_user('user2', 'user2@example.com', 'password')
        res1 = Reservation.objects.create(user=self.user, instance=self.instance, key='key-1')
        res2 = Reservation.objects.create(user=user2, instance=self.instance, key='key-1')
        self.assertEqual(res1.key, res2.key)


class ReservationApiEndpointTest(TestCase):
    def setUp(self):
        self.user1 = User.objects.create_user('user1', 'u1@example.com', 'pass1')
        self.user2 = User.objects.create_user('user2', 'u2@example.com', 'pass2')
        self.author = Author.objects.create(first_name='Author', last_name='Name')
        self.book = Book.objects.create(title='Test Book', author=self.author, summary='Summary', isbn='1234567890123')
        self.instance_avail = BookInstance.objects.create(book=self.book, imprint='Imprint 1', status='a')
        self.instance_maint = BookInstance.objects.create(book=self.book, imprint='Imprint 2', status='m')

    def test_unauthenticated_request_returns_401(self):
        url = reverse('reserve-bookinstance-api', args=[self.instance_avail.id])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_method_not_allowed_get(self):
        self.client.force_login(self.user1)
        url = reverse('reserve-bookinstance-api', args=[self.instance_avail.id])
        response = self.client.get(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 405)

    def test_missing_or_invalid_idempotency_key(self):
        self.client.force_login(self.user1)
        url = reverse('reserve-bookinstance-api', args=[self.instance_avail.id])
        
        # Missing header
        res1 = self.client.post(url)
        self.assertEqual(res1.status_code, 400)
        self.assertEqual(res1.json(), {'error': 'invalid_key'})

        # Empty or spaces header
        res2 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(res2.status_code, 400)
        self.assertEqual(res2.json(), {'error': 'invalid_key'})

        # Header > 100 chars
        res3 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='a' * 101)
        self.assertEqual(res3.status_code, 400)
        self.assertEqual(res3.json(), {'error': 'invalid_key'})

    def test_instance_not_found_returns_404(self):
        self.client.force_login(self.user1)
        random_uuid = uuid.uuid4()
        url = reverse('reserve-bookinstance-api', args=[random_uuid])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_instance_unavailable_returns_409(self):
        self.client.force_login(self.user1)
        url = reverse('reserve-bookinstance-api', args=[self.instance_maint.id])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        # Verify no reservation created and status unchanged
        self.assertEqual(Reservation.objects.count(), 0)
        self.instance_maint.refresh_from_db()
        self.assertEqual(self.instance_maint.status, 'm')

    def test_successful_reservation(self):
        self.client.force_login(self.user1)
        url = reverse('reserve-bookinstance-api', args=[self.instance_avail.id])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-success')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), {
            "instance_id": str(self.instance_avail.id),
            "user_id": self.user1.id,
            "status": "r"
        })
        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, 'r')
        self.assertEqual(self.instance_avail.borrower, self.user1)
        self.assertTrue(Reservation.objects.filter(user=self.user1, instance=self.instance_avail, key='key-success').exists())

    def test_idempotent_replay_same_user_same_key_same_instance(self):
        self.client.force_login(self.user1)
        url = reverse('reserve-bookinstance-api', args=[self.instance_avail.id])
        # First call
        res1 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-replay')
        self.assertEqual(res1.status_code, 201)
        
        # Second call (replay)
        res2 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-replay')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), res1.json())
        self.assertEqual(Reservation.objects.filter(user=self.user1, key='key-replay').count(), 1)

    def test_idempotency_conflict_different_instance(self):
        instance_avail2 = BookInstance.objects.create(book=self.book, imprint='Imprint 3', status='a')
        self.client.force_login(self.user1)
        url1 = reverse('reserve-bookinstance-api', args=[self.instance_avail.id])
        url2 = reverse('reserve-bookinstance-api', args=[instance_avail2.id])
        
        res1 = self.client.post(url1, HTTP_IDEMPOTENCY_KEY='key-reuse')
        self.assertEqual(res1.status_code, 201)

        # Attempt to use same key on another instance
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='key-reuse')
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})
        # instance2 remains available
        instance_avail2.refresh_from_db()
        self.assertEqual(instance_avail2.status, 'a')

    def test_independent_idempotency_keys_across_different_users(self):
        instance_avail2 = BookInstance.objects.create(book=self.book, imprint='Imprint 4', status='a')
        self.client.force_login(self.user1)
        url1 = reverse('reserve-bookinstance-api', args=[self.instance_avail.id])
        res1 = self.client.post(url1, HTTP_IDEMPOTENCY_KEY='common-key')
        self.assertEqual(res1.status_code, 201)

        # User2 uses the same key for instance2
        self.client.force_login(self.user2)
        url2 = reverse('reserve-bookinstance-api', args=[instance_avail2.id])
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='common-key')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), {
            "instance_id": str(instance_avail2.id),
            "user_id": self.user2.id,
            "status": "r"
        })


class SQLiteConcurrencyTest(TransactionTestCase):
    def setUp(self):
        self.user1 = User.objects.create_user('c_user1', 'c1@example.com', 'pass1')
        self.user2 = User.objects.create_user('c_user2', 'c2@example.com', 'pass2')
        self.author = Author.objects.create(first_name='Author', last_name='Name')
        self.book = Book.objects.create(title='Concurrency Book', author=self.author, summary='Summary', isbn='9999999999999')
        self.instance = BookInstance.objects.create(book=self.book, imprint='Concurrency Imprint', status='a')

    def test_concurrent_reservations_result_in_one_success_and_one_conflict(self):
        from django.test import Client
        url = reverse('reserve-bookinstance-api', args=[self.instance.id])
        results = []

        c1 = Client()
        c1.force_login(self.user1)
        c2 = Client()
        c2.force_login(self.user2)

        def make_reservation(client, key):
            resp = client.post(url, HTTP_IDEMPOTENCY_KEY=key)
            results.append((resp.status_code, resp.json()))

        t1 = threading.Thread(target=make_reservation, args=(c1, 'thread-key-1'))
        t2 = threading.Thread(target=make_reservation, args=(c2, 'thread-key-2'))

        t1.start()
        t2.start()
        t1.join()
        t2.join()

        statuses = [r[0] for r in results]
        self.assertIn(201, statuses)
        self.assertIn(409, statuses)
        
        # Verify 409 error payload is {'error': 'unavailable'}
        conflict_result = [r for r in results if r[0] == 409][0]
        self.assertEqual(conflict_result[1], {'error': 'unavailable'})

        # Verify only 1 reservation in DB
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, 'r')


class ReservationWebUITest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user('ui_user', 'ui@example.com', 'password')
        self.author = Author.objects.create(first_name='Author', last_name='UI')
        self.book = Book.objects.create(title='UI Book', author=self.author, summary='Summary', isbn='8888888888888')
        self.instance_avail = BookInstance.objects.create(book=self.book, imprint='Imprint UI 1', status='a')
        self.instance_maint = BookInstance.objects.create(book=self.book, imprint='Imprint UI 2', status='m')

    def test_book_detail_shows_reserve_button_for_available_copies_only(self):
        url = reverse('book-detail', args=[self.book.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        reserve_url = reverse('reserve-book-instance', args=[self.instance_avail.id])
        self.assertContains(response, reserve_url)
        self.assertContains(response, 'idempotency_key')
        maint_reserve_url = f"/catalog/book/{self.instance_maint.id}/reserve/"
        self.assertNotContains(response, maint_reserve_url)

    def test_web_ui_reserve_unauthenticated_redirects_to_login(self):
        url = reverse('reserve-book-instance', args=[self.instance_avail.id])
        response = self.client.post(url, {'idempotency_key': str(uuid.uuid4())})
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/'))

    def test_web_ui_reserve_success_and_flash_message(self):
        self.client.force_login(self.user)
        key = str(uuid.uuid4())
        url = reverse('reserve-book-instance', args=[self.instance_avail.id])
        response = self.client.post(url, {'idempotency_key': key}, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'successfully reserved')
        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, 'r')
        self.assertEqual(self.instance_avail.borrower, self.user)
