import uuid
import concurrent.futures
from django.test import TestCase, TransactionTestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.db import connection
from catalog.models import Book, BookInstance, Author, Genre, Reservation

User = get_user_model()


class ReservationAPITests(TestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='user1', password='password123')
        self.user2 = User.objects.create_user(username='user2', password='password123')
        self.author = Author.objects.create(first_name='Gabriel', last_name='Garcia Marquez')
        self.book = Book.objects.create(
            title='Cien Anos de Soledad',
            author=self.author,
            summary='Test summary',
            isbn='1234567890123'
        )
        self.instance_avail = BookInstance.objects.create(
            book=self.book,
            imprint='Sudamericana, 1967',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.instance_loaned = BookInstance.objects.create(
            book=self.book,
            imprint='Sudamericana, 1967',
            status=BookInstance.LoanStatus.ON_LOAN
        )
        self.api_url = reverse('bookinstance-reserve-api', kwargs={'pk': self.instance_avail.pk})

    def test_anonymous_user_returns_401(self):
        response = self.client.post(
            self.api_url,
            HTTP_IDEMPOTENCY_KEY='key-123'
        )
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_method_not_allowed(self):
        self.client.login(username='user1', password='password123')
        response = self.client.get(self.api_url, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(response.status_code, 405)

    def test_missing_or_invalid_idempotency_key(self):
        self.client.login(username='user1', password='password123')
        # Missing key
        resp1 = self.client.post(self.api_url)
        self.assertEqual(resp1.status_code, 400)
        self.assertEqual(resp1.json(), {'error': 'invalid_key'})

        # Empty key (or only whitespace)
        resp2 = self.client.post(self.api_url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(resp2.status_code, 400)
        self.assertEqual(resp2.json(), {'error': 'invalid_key'})

        # Key exceeding 100 chars
        resp3 = self.client.post(self.api_url, HTTP_IDEMPOTENCY_KEY='a' * 101)
        self.assertEqual(resp3.status_code, 400)
        self.assertEqual(resp3.json(), {'error': 'invalid_key'})

    def test_non_existent_bookinstance_returns_404(self):
        self.client.login(username='user1', password='password123')
        bad_url = reverse('bookinstance-reserve-api', kwargs={'pk': uuid.uuid4()})
        response = self.client.post(bad_url, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_unavailable_bookinstance_returns_409(self):
        self.client.login(username='user1', password='password123')
        url_loaned = reverse('bookinstance-reserve-api', kwargs={'pk': self.instance_loaned.pk})
        response = self.client.post(url_loaned, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})

    def test_successful_reservation(self):
        self.client.login(username='user1', password='password123')
        response = self.client.post(self.api_url, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(response.status_code, 201)
        expected = {
            "instance_id": str(self.instance_avail.pk),
            "user_id": self.user1.id,
            "status": "r"
        }
        self.assertEqual(response.json(), expected)

        # Check DB state
        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance_avail.borrower, self.user1)
        self.assertTrue(Reservation.objects.filter(user=self.user1, instance=self.instance_avail, key='key-123').exists())

    def test_exact_replay_idempotency(self):
        self.client.login(username='user1', password='password123')
        resp1 = self.client.post(self.api_url, HTTP_IDEMPOTENCY_KEY='replay-key')
        self.assertEqual(resp1.status_code, 201)

        # Second call with same key and instance by same user
        resp2 = self.client.post(self.api_url, HTTP_IDEMPOTENCY_KEY='replay-key')
        self.assertEqual(resp2.status_code, 201)
        self.assertEqual(resp1.json(), resp2.json())
        self.assertEqual(Reservation.objects.filter(user=self.user1, key='replay-key').count(), 1)

    def test_idempotency_conflict_reusing_key_for_different_instance(self):
        self.client.login(username='user1', password='password123')
        # First reserve instance_avail
        resp1 = self.client.post(self.api_url, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(resp1.status_code, 201)

        # Another available instance
        another_inst = BookInstance.objects.create(
            book=self.book,
            imprint='Another imprint',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        url2 = reverse('bookinstance-reserve-api', kwargs={'pk': another_inst.pk})
        resp2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(resp2.status_code, 409)
        self.assertEqual(resp2.json(), {'error': 'idempotency_conflict'})

    def test_independent_idempotency_keys_between_users(self):
        # User 1 reserves instance_avail with 'common-key'
        self.client.login(username='user1', password='password123')
        resp1 = self.client.post(self.api_url, HTTP_IDEMPOTENCY_KEY='common-key')
        self.assertEqual(resp1.status_code, 201)
        self.client.logout()

        # User 2 reserves another available instance with the SAME 'common-key'
        another_inst = BookInstance.objects.create(
            book=self.book,
            imprint='Another imprint',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.client.login(username='user2', password='password123')
        url2 = reverse('bookinstance-reserve-api', kwargs={'pk': another_inst.pk})
        resp2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='common-key')
        self.assertEqual(resp2.status_code, 201)


class ReservationConcurrencyTests(TransactionTestCase):
    def test_concurrent_reservations_same_instance(self):
        author = Author.objects.create(first_name='Gabriel', last_name='Garcia Marquez')
        book = Book.objects.create(
            title='Cien Anos de Soledad',
            author=author,
            summary='Test summary',
            isbn='1234567890123'
        )
        instance = BookInstance.objects.create(
            book=book,
            imprint='Sudamericana, 1967',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        user_a = User.objects.create_user(username='usera', password='password')
        user_b = User.objects.create_user(username='userb', password='password')

        url = reverse('bookinstance-reserve-api', kwargs={'pk': instance.pk})

        from django.test import Client

        client_a = Client()
        client_a.force_login(user_a)

        client_b = Client()
        client_b.force_login(user_b)

        def try_reserve(client, key):
            res = client.post(url, HTTP_IDEMPOTENCY_KEY=key)
            connection.close()
            return res.status_code, res.json()

        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            fut_a = executor.submit(try_reserve, client_a, 'key-a')
            fut_b = executor.submit(try_reserve, client_b, 'key-b')
            res_a = fut_a.result()
            res_b = fut_b.result()

        status_codes = sorted([res_a[0], res_b[0]])
        self.assertEqual(status_codes, [201, 409])
        if res_a[0] == 409:
            self.assertEqual(res_a[1], {'error': 'unavailable'})
        else:
            self.assertEqual(res_b[1], {'error': 'unavailable'})

        instance.refresh_from_db()
        self.assertEqual(instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(Reservation.objects.filter(instance=instance).count(), 1)


class ReservationUITests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='webuser', password='password')
        self.author = Author.objects.create(first_name='Author', last_name='Tester')
        self.book = Book.objects.create(
            title='Web Book',
            author=self.author,
            summary='Web test',
            isbn='9999999999999'
        )
        self.inst_avail = BookInstance.objects.create(
            book=self.book,
            imprint='Web imprint',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.inst_loaned = BookInstance.objects.create(
            book=self.book,
            imprint='Web imprint 2',
            status=BookInstance.LoanStatus.ON_LOAN
        )

    def test_book_detail_shows_reserve_form_for_available_only(self):
        url = reverse('book-detail', kwargs={'pk': self.book.pk})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        reserve_url = reverse('bookinstance-reserve-ui', kwargs={'instance_pk': self.inst_avail.pk})
        self.assertContains(response, reserve_url)
        loaned_reserve_url = f"/catalog/book/{self.inst_loaned.pk}/reserve/"
        self.assertNotContains(response, loaned_reserve_url)
        self.assertContains(response, 'name="idempotency_key"')

    def test_ui_reserve_requires_auth(self):
        reserve_url = reverse('bookinstance-reserve-ui', kwargs={'instance_pk': self.inst_avail.pk})
        response = self.client.post(reserve_url, {'idempotency_key': str(uuid.uuid4())})
        self.assertEqual(response.status_code, 302)
        self.assertIn('/accounts/login/', response.url)

    def test_ui_reserve_success(self):
        self.client.login(username='webuser', password='password')
        reserve_url = reverse('bookinstance-reserve-ui', kwargs={'instance_pk': self.inst_avail.pk})
        key = str(uuid.uuid4())
        response = self.client.post(reserve_url, {'idempotency_key': key}, follow=True)
        self.assertEqual(response.status_code, 200)
        self.inst_avail.refresh_from_db()
        self.assertEqual(self.inst_avail.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.inst_avail.borrower, self.user)
        self.assertTrue(Reservation.objects.filter(user=self.user, instance=self.inst_avail, key=key).exists())
