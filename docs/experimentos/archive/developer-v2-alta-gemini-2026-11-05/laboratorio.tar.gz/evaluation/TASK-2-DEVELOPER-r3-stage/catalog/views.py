from django.shortcuts import render

# Create your views here.

from .models import Book, Author, BookInstance, Genre, Language, Reservation

def index(request):
    """View function for home page of site."""
    # Generate counts of some of the main objects
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available copies of books
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Number of visits to this view, as counted in the session variable.
    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    # Render the HTML template index.html with the data in the context variable.
    return render(request, 'index.html', context=context)

from django.views import generic


class BookListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = Book
    paginate_by = 10

class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre

class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10

class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language

class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10

class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10

class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance

from django.contrib.auth.mixins import LoginRequiredMixin

class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )

# Added as part of challenge!
from django.contrib.auth.mixins import PermissionRequiredMixin


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')

from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
import datetime
from django.contrib.auth.decorators import login_required, permission_required
from catalog.forms import RenewBookForm


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed'))

    # If this is a GET (or any other method) create the default form
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import RestrictedError
from django.contrib.auth.mixins import PermissionRequiredMixin
from .models import Author


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'

class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    # Not recommended (potential security issue if more fields added)
    fields = '__all__'
    permission_required = 'catalog.change_author'

class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("author-delete", kwargs={"pk": self.object.pk})
            )

# Classes created for the forms challenge


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("book-delete", kwargs={"pk": self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    # fields = "__all__"
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'


import time
import uuid as uuid_lib
from django.db import transaction, IntegrityError, OperationalError
from django.http import JsonResponse, HttpResponseNotAllowed
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from django.views.decorators.http import require_POST


def _execute_reservation_with_retry(user, pk, idempotency_key, max_retries=15):
    """
    Executes the reservation logic with retry for SQLite database lock/busy conditions.
    Returns: (status_code, response_data, reservation_or_instance)
    """
    for attempt in range(max_retries):
        try:
            with transaction.atomic():
                # 1. Check existing reservation for this user and idempotency_key
                existing_res = Reservation.objects.filter(user=user, key=idempotency_key).first()
                if existing_res:
                    if existing_res.instance_id == pk:
                        return (201, {
                            "instance_id": str(pk),
                            "user_id": user.id,
                            "status": "r"
                        }, existing_res)
                    else:
                        return (409, {"error": "idempotency_conflict"}, None)

                # 2. Check if instance exists
                try:
                    instance = BookInstance.objects.get(pk=pk)
                except BookInstance.DoesNotExist:
                    return (404, {"error": "not_found"}, None)

                # 3. Check if instance is available
                if instance.status != BookInstance.LoanStatus.AVAILABLE:
                    return (409, {"error": "unavailable"}, None)

                # 4. Atomic conditional update to handle SQLite concurrency without row-level locks
                rows_updated = BookInstance.objects.filter(
                    pk=pk,
                    status=BookInstance.LoanStatus.AVAILABLE
                ).update(
                    status=BookInstance.LoanStatus.RESERVED,
                    borrower=user
                )

                if rows_updated == 0:
                    # Concurrently reserved by another process
                    return (409, {"error": "unavailable"}, None)

                # 5. Create reservation record
                reservation = Reservation.objects.create(
                    user=user,
                    instance=instance,
                    key=idempotency_key
                )

                return (201, {
                    "instance_id": str(pk),
                    "user_id": user.id,
                    "status": "r"
                }, reservation)

        except IntegrityError:
            # Possible duplicate key race condition: recheck existing
            existing_res = Reservation.objects.filter(user=user, key=idempotency_key).first()
            if existing_res:
                if existing_res.instance_id == pk:
                    return (201, {
                        "instance_id": str(pk),
                        "user_id": user.id,
                        "status": "r"
                    }, existing_res)
                else:
                    return (409, {"error": "idempotency_conflict"}, None)
            raise
        except OperationalError as e:
            # Handle SQLite "database is locked" or "database table is locked"
            err_msg = str(e).lower()
            if "locked" in err_msg or "busy" in err_msg:
                if attempt < max_retries - 1:
                    time.sleep(0.05 * (attempt + 1))
                    continue
            raise

    return (409, {"error": "unavailable"}, None)


@csrf_exempt
def api_reserve_bookinstance(request, pk):
    """
    API endpoint: POST /catalog/api/bookinstance/<uuid:pk>/reserve/
    Requires authenticated user and Idempotency-Key header.
    """
    if request.method != 'POST':
        return HttpResponseNotAllowed(['POST'])

    if not request.user.is_authenticated:
        return JsonResponse({'error': 'unauthorized'}, status=401)

    # Header check: HTTP_IDEMPOTENCY_KEY or Idempotency-Key
    raw_key = request.headers.get('Idempotency-Key') or request.META.get('HTTP_IDEMPOTENCY_KEY')
    if raw_key is None:
        return JsonResponse({'error': 'invalid_key'}, status=400)

    idempotency_key = raw_key.strip()
    if not idempotency_key or len(idempotency_key) > 100:
        return JsonResponse({'error': 'invalid_key'}, status=400)

    status_code, data, _ = _execute_reservation_with_retry(request.user, pk, idempotency_key)
    return JsonResponse(data, status=status_code)


@login_required
@require_POST
def bookinstance_reserve_web(request, instance_pk):
    """
    Web view: POST /catalog/book/<uuid:instance_pk>/reserve/
    Requires authentication, CSRF, and handles idempotency_key from POST data.
    """
    book_instance = get_object_or_404(BookInstance, pk=instance_pk)
    book_id = book_instance.book.id if book_instance.book else None

    idempotency_key = request.POST.get('idempotency_key', '').strip()
    if not idempotency_key or len(idempotency_key) > 100:
        idempotency_key = str(uuid_lib.uuid4())

    status_code, data, _ = _execute_reservation_with_retry(request.user, instance_pk, idempotency_key)

    if status_code == 201:
        messages.success(request, f"Book copy reserved successfully!")
    elif status_code == 409:
        if data.get('error') == 'unavailable':
            messages.error(request, "Sorry, this copy is no longer available.")
        elif data.get('error') == 'idempotency_conflict':
            messages.error(request, "Idempotency conflict occurred.")
        else:
            messages.error(request, "Reservation conflict.")
    else:
        messages.error(request, f"Could not reserve copy: {data.get('error', 'unknown error')}")

    if book_id:
        return HttpResponseRedirect(reverse('book-detail', args=[str(book_id)]))
    return HttpResponseRedirect(reverse('books'))

