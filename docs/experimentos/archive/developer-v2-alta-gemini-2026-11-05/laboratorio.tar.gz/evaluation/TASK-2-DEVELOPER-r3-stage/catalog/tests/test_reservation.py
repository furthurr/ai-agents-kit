import uuid
import threading
from django.test import TestCase, TransactionTestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.db import connection
from catalog.models import Book, Author, Genre, Language, BookInstance, Reservation

User = get_user_model()


class ReservationModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='resuser', password='password123')
        self.author = Author.objects.create(first_name='Leo', last_name='Tolstoy')
        self.genre = Genre.objects.create(name='Classic')
        self.language = Language.objects.create(name='Russian')
        self.book = Book.objects.create(
            title='War and Peace',
            author=self.author,
            summary='Epic historical novel',
            isbn='1234567890123',
            language=self.language
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Publisher 1869',
            status=BookInstance.LoanStatus.AVAILABLE
        )

    def test_reservation_creation_and_str(self):
        res = Reservation.objects.create(user=self.user, instance=self.instance, key='key-123')
        self.assertEqual(res.user, self.user)
        self.assertEqual(res.instance, self.instance)
        self.assertEqual(res.key, 'key-123')
        self.assertIn('Reservation', str(res))


class ReservationAPITest(TestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='apiuser1', password='password123')
        self.user2 = User.objects.create_user(username='apiuser2', password='password123')
        self.author = Author.objects.create(first_name='Fyodor', last_name='Dostoevsky')
        self.book = Book.objects.create(
            title='Crime and Punishment',
            author=self.author,
            summary='Psychological drama',
            isbn='9876543210123'
        )
        self.instance_available = BookInstance.objects.create(
            book=self.book,
            imprint='Vintage 1866',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.instance_maintenance = BookInstance.objects.create(
            book=self.book,
            imprint='Vintage 1866',
            status=BookInstance.LoanStatus.MAINTENANCE
        )

    def test_unauthenticated_request_returns_401(self):
        url = reverse('api-reserve-bookinstance', args=[self.instance_available.id])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='req-key-1')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_method_not_allowed(self):
        self.client.force_login(self.user1)
        url = reverse('api-reserve-bookinstance', args=[self.instance_available.id])
        response = self.client.get(url, HTTP_IDEMPOTENCY_KEY='req-key-1')
        self.assertEqual(response.status_code, 405)

    def test_invalid_key_missing_or_empty_or_too_long(self):
        self.client.force_login(self.user1)
        url = reverse('api-reserve-bookinstance', args=[self.instance_available.id])

        # Missing key
        resp = self.client.post(url)
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.json(), {'error': 'invalid_key'})

        # Empty or spaces only
        resp = self.client.post(url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.json(), {'error': 'invalid_key'})

        # Too long (> 100 chars)
        resp = self.client.post(url, HTTP_IDEMPOTENCY_KEY='a' * 101)
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.json(), {'error': 'invalid_key'})

    def test_instance_not_found_returns_404(self):
        self.client.force_login(self.user1)
        non_existent_id = uuid.uuid4()
        url = reverse('api-reserve-bookinstance', args=[non_existent_id])
        resp = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-404')
        self.assertEqual(resp.status_code, 404)
        self.assertEqual(resp.json(), {'error': 'not_found'})

    def test_instance_unavailable_returns_409(self):
        self.client.force_login(self.user1)
        url = reverse('api-reserve-bookinstance', args=[self.instance_maintenance.id])
        resp = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-unavail')
        self.assertEqual(resp.status_code, 409)
        self.assertEqual(resp.json(), {'error': 'unavailable'})

        # Ensure no reservation created and status untouched
        self.instance_maintenance.refresh_from_db()
        self.assertEqual(self.instance_maintenance.status, BookInstance.LoanStatus.MAINTENANCE)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_successful_reservation(self):
        self.client.force_login(self.user1)
        url = reverse('api-reserve-bookinstance', args=[self.instance_available.id])
        resp = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-success-1')
        self.assertEqual(resp.status_code, 201)
        expected = {
            "instance_id": str(self.instance_available.id),
            "user_id": self.user1.id,
            "status": "r"
        }
        self.assertEqual(resp.json(), expected)

        # Verify DB mutation
        self.instance_available.refresh_from_db()
        self.assertEqual(self.instance_available.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance_available.borrower, self.user1)

        # Verify Reservation record
        res = Reservation.objects.get(user=self.user1, key='key-success-1')
        self.assertEqual(res.instance, self.instance_available)

    def test_idempotent_replay_same_user_same_key_same_instance(self):
        self.client.force_login(self.user1)
        url = reverse('api-reserve-bookinstance', args=[self.instance_available.id])

        # First request
        resp1 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-replay-1')
        self.assertEqual(resp1.status_code, 201)

        # Second request (replay)
        resp2 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-replay-1')
        self.assertEqual(resp2.status_code, 201)
        self.assertEqual(resp1.json(), resp2.json())

        # Reservation count should be exactly 1
        self.assertEqual(Reservation.objects.filter(user=self.user1, key='key-replay-1').count(), 1)

    def test_idempotency_conflict_different_instance(self):
        self.client.force_login(self.user1)
        # Create second available copy
        instance2 = BookInstance.objects.create(
            book=self.book,
            imprint='Second Copy',
            status=BookInstance.LoanStatus.AVAILABLE
        )

        url1 = reverse('api-reserve-bookinstance', args=[self.instance_available.id])
        url2 = reverse('api-reserve-bookinstance', args=[instance2.id])

        resp1 = self.client.post(url1, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(resp1.status_code, 201)

        # Try to reserve instance2 with same key
        resp2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(resp2.status_code, 409)
        self.assertEqual(resp2.json(), {'error': 'idempotency_conflict'})

        # Instance2 status should still be available
        instance2.refresh_from_db()
        self.assertEqual(instance2.status, BookInstance.LoanStatus.AVAILABLE)

    def test_keys_are_independent_between_different_users(self):
        # User 1 reserves instance_available
        self.client.force_login(self.user1)
        url1 = reverse('api-reserve-bookinstance', args=[self.instance_available.id])
        resp1 = self.client.post(url1, HTTP_IDEMPOTENCY_KEY='user-key-1')
        self.assertEqual(resp1.status_code, 201)

        # User 2 reserves instance2 using the SAME key 'user-key-1'
        instance2 = BookInstance.objects.create(
            book=self.book,
            imprint='Another Copy',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.client.force_login(self.user2)
        url2 = reverse('api-reserve-bookinstance', args=[instance2.id])
        resp2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='user-key-1')
        self.assertEqual(resp2.status_code, 201)

        self.assertEqual(Reservation.objects.filter(key='user-key-1').count(), 2)


class ReservationUITest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='uiuser', password='password123')
        self.author = Author.objects.create(first_name='Jane', last_name='Austen')
        self.book = Book.objects.create(
            title='Pride and Prejudice',
            author=self.author,
            summary='Classic romance',
            isbn='1112223334445'
        )
        self.instance_available = BookInstance.objects.create(
            book=self.book,
            imprint='Penguin 1813',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.instance_maintenance = BookInstance.objects.create(
            book=self.book,
            imprint='Penguin 1813 (damaged)',
            status=BookInstance.LoanStatus.MAINTENANCE
        )

    def test_book_detail_shows_reserve_button_only_for_available_copies(self):
        resp = self.client.get(reverse('book-detail', args=[self.book.id]))
        self.assertEqual(resp.status_code, 200)

        reserve_url = reverse('bookinstance-reserve-web', args=[self.instance_available.id])
        self.assertContains(resp, f'action="{reserve_url}"')
        self.assertContains(resp, 'Reserve this copy')
        self.assertContains(resp, 'name="idempotency_key"')

        # Copy in maintenance should not have reserve button
        unavail_url = reverse('bookinstance-reserve-web', args=[self.instance_maintenance.id])
        self.assertNotContains(resp, f'action="{unavail_url}"')

    def test_web_reservation_anonymous_redirects_to_login(self):
        url = reverse('bookinstance-reserve-web', args=[self.instance_available.id])
        resp = self.client.post(url, {'idempotency_key': 'test-web-key'})
        self.assertEqual(resp.status_code, 302)
        self.assertIn('/accounts/login/', resp.url)

    def test_web_reservation_success_authenticated(self):
        self.client.force_login(self.user)
        url = reverse('bookinstance-reserve-web', args=[self.instance_available.id])
        resp = self.client.post(url, {'idempotency_key': 'web-res-key-1'}, follow=True)
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "Book copy reserved successfully!")

        self.instance_available.refresh_from_db()
        self.assertEqual(self.instance_available.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance_available.borrower, self.user)


class ReservationConcurrencyTest(TransactionTestCase):
    """
    Test real concurrent requests against SQLite.
    TransactionTestCase commits data and enables real multi-threaded DB access.
    """
    def setUp(self):
        self.user1 = User.objects.create_user(username='cuser1', password='password123')
        self.user2 = User.objects.create_user(username='cuser2', password='password123')
        self.author = Author.objects.create(first_name='Concurrent', last_name='Author')
        self.book = Book.objects.create(
            title='Concurrency in SQLite',
            author=self.author,
            summary='Testing race conditions',
            isbn='9998887776665'
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Threaded press',
            status=BookInstance.LoanStatus.AVAILABLE
        )

    def test_concurrent_reservations_two_users_same_copy(self):
        from catalog.views import _execute_reservation_with_retry

        results = []

        def make_reservation(user, key):
            # Close connection so each thread opens its own SQLite connection
            connection.close()
            status_code, data, _ = _execute_reservation_with_retry(user, self.instance.id, key)
            results.append((status_code, data))
            connection.close()

        t1 = threading.Thread(target=make_reservation, args=(self.user1, 'key-c1'))
        t2 = threading.Thread(target=make_reservation, args=(self.user2, 'key-c2'))

        t1.start()
        t2.start()
        t1.join()
        t2.join()

        status_codes = [r[0] for r in results]
        self.assertIn(201, status_codes)
        self.assertIn(409, status_codes)

        conflict_result = [r[1] for r in results if r[0] == 409][0]
        self.assertEqual(conflict_result, {'error': 'unavailable'})

        # Instance must be reserved, and exactly 1 Reservation row in DB
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)
