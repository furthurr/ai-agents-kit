import uuid
from django.test import TestCase, TransactionTestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from catalog.models import Book, Author, BookInstance, Reservation
import threading
from django.db import connection

User = get_user_model()

class BookInstanceReserveAPITest(TestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='user1', password='password123')
        self.user2 = User.objects.create_user(username='user2', password='password123')
        self.author = Author.objects.create(first_name='Arthur', last_name='Conan Doyle')
        self.book = Book.objects.create(title='A Study in Scarlet', author=self.author, summary='Sherlock Holmes', isbn='1111111111111')
        self.available_instance = BookInstance.objects.create(book=self.book, imprint='London 1887', status='a')
        self.reserved_instance = BookInstance.objects.create(book=self.book, imprint='London 1888', status='r')
        self.maintenance_instance = BookInstance.objects.create(book=self.book, imprint='London 1889', status='m')
        self.url = f'/catalog/api/bookinstance/{self.available_instance.pk}/reserve/'

    def test_anonymous_user_returns_401(self):
        response = self.client.post(self.url, headers={'Idempotency-Key': 'key-1'})
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_get_method_not_allowed(self):
        self.client.login(username='user1', password='password123')
        response = self.client.get(self.url, headers={'Idempotency-Key': 'key-1'})
        self.assertEqual(response.status_code, 405)

    def test_missing_idempotency_key_returns_400(self):
        self.client.login(username='user1', password='password123')
        response = self.client.post(self.url)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

    def test_empty_or_whitespace_idempotency_key_returns_400(self):
        self.client.login(username='user1', password='password123')
        response = self.client.post(self.url, headers={'Idempotency-Key': '   '})
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

    def test_too_long_idempotency_key_returns_400(self):
        self.client.login(username='user1', password='password123')
        response = self.client.post(self.url, headers={'Idempotency-Key': 'a' * 101})
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

    def test_nonexistent_instance_returns_404(self):
        self.client.login(username='user1', password='password123')
        fake_uuid = uuid.uuid4()
        response = self.client.post(f'/catalog/api/bookinstance/{fake_uuid}/reserve/', headers={'Idempotency-Key': 'key-1'})
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_unavailable_instance_returns_409(self):
        self.client.login(username='user1', password='password123')
        # status 'r'
        response = self.client.post(f'/catalog/api/bookinstance/{self.reserved_instance.pk}/reserve/', headers={'Idempotency-Key': 'key-1'})
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        # status 'm'
        response2 = self.client.post(f'/catalog/api/bookinstance/{self.maintenance_instance.pk}/reserve/', headers={'Idempotency-Key': 'key-2'})
        self.assertEqual(response2.status_code, 409)
        self.assertEqual(response2.json(), {'error': 'unavailable'})

    def test_successful_first_reservation(self):
        self.client.login(username='user1', password='password123')
        response = self.client.post(self.url, headers={'Idempotency-Key': 'key-success'})
        self.assertEqual(response.status_code, 201)
        expected_json = {
            'instance_id': str(self.available_instance.pk),
            'user_id': self.user1.id,
            'status': 'r'
        }
        self.assertEqual(response.json(), expected_json)
        self.available_instance.refresh_from_db()
        self.assertEqual(self.available_instance.status, 'r')
        self.assertEqual(self.available_instance.borrower, self.user1)
        reservation = Reservation.objects.get(user=self.user1, key='key-success')
        self.assertEqual(reservation.instance, self.available_instance)

    def test_exact_idempotent_replay(self):
        self.client.login(username='user1', password='password123')
        res1 = self.client.post(self.url, headers={'Idempotency-Key': 'replay-key'})
        self.assertEqual(res1.status_code, 201)
        res2 = self.client.post(self.url, headers={'Idempotency-Key': 'replay-key'})
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res1.json(), res2.json())
        self.assertEqual(Reservation.objects.filter(user=self.user1, key='replay-key').count(), 1)

    def test_idempotency_conflict_different_instance(self):
        self.client.login(username='user1', password='password123')
        other_instance = BookInstance.objects.create(book=self.book, imprint='London 1890', status='a')
        res1 = self.client.post(self.url, headers={'Idempotency-Key': 'conflict-key'})
        self.assertEqual(res1.status_code, 201)
        res2 = self.client.post(f'/catalog/api/bookinstance/{other_instance.pk}/reserve/', headers={'Idempotency-Key': 'conflict-key'})
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})
        other_instance.refresh_from_db()
        self.assertEqual(other_instance.status, 'a')

    def test_failed_requests_do_not_mutate_bookinstance(self):
        self.client.login(username='user1', password='password123')
        # Attempt with invalid key
        self.client.post(self.url, headers={'Idempotency-Key': ''})
        self.available_instance.refresh_from_db()
        self.assertEqual(self.available_instance.status, 'a')
        self.assertIsNone(self.available_instance.borrower)
        self.assertEqual(Reservation.objects.count(), 0)


class BookInstanceReserveConcurrencyTest(TransactionTestCase):
    def test_concurrent_reservations_result_in_one_success_and_one_conflict(self):
        user1 = User.objects.create_user(username='concurrent_user1', password='password123')
        user2 = User.objects.create_user(username='concurrent_user2', password='password123')
        author = Author.objects.create(first_name='Arthur', last_name='Conan Doyle')
        book = Book.objects.create(title='A Study in Scarlet', author=author, summary='Sherlock Holmes', isbn='2222222222222')
        instance = BookInstance.objects.create(book=book, imprint='London 1887', status='a')
        url = f'/catalog/api/bookinstance/{instance.pk}/reserve/'

        client1 = self.client_class()
        client1.login(username='concurrent_user1', password='password123')
        client2 = self.client_class()
        client2.login(username='concurrent_user2', password='password123')

        results = []

        def make_request(client, key):
            resp = client.post(url, headers={'Idempotency-Key': key})
            results.append((resp.status_code, resp.json()))
            connection.close()

        t1 = threading.Thread(target=make_request, args=(client1, 'key-t1'))
        t2 = threading.Thread(target=make_request, args=(client2, 'key-t2'))

        t1.start()
        t2.start()
        t1.join()
        t2.join()

        status_codes = [r[0] for r in results]
        self.assertIn(201, status_codes)
        self.assertIn(409, status_codes)
        instance.refresh_from_db()
        self.assertEqual(instance.status, 'r')
        self.assertIn(instance.borrower, [user1, user2])
        self.assertEqual(Reservation.objects.filter(instance=instance).count(), 1)


class BookInstanceReserveWebTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='webuser', password='password123')
        self.author = Author.objects.create(first_name='Arthur', last_name='Conan Doyle')
        self.book = Book.objects.create(title='A Study in Scarlet', author=self.author, summary='Sherlock Holmes', isbn='3333333333333')
        self.available_instance = BookInstance.objects.create(book=self.book, imprint='London 1887', status='a')
        self.reserved_instance = BookInstance.objects.create(book=self.book, imprint='London 1888', status='r')
        self.url = f'/catalog/book/{self.available_instance.pk}/reserve/'

    def test_anonymous_user_redirected_to_login(self):
        response = self.client.post(self.url, {'idempotency_key': 'key-web-1'})
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/'))

    def test_authenticated_user_can_reserve_available_copy(self):
        self.client.login(username='webuser', password='password123')
        detail_url = reverse('book-detail', args=[self.book.id])
        # Check detail page contains the reserve form and csrf token
        resp_get = self.client.get(detail_url)
        self.assertEqual(resp_get.status_code, 200)
        self.assertContains(resp_get, f'action="{self.url}"')
        self.assertContains(resp_get, 'name="idempotency_key"')

        # Perform reservation
        response = self.client.post(self.url, {'idempotency_key': 'key-web-1'}, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertRedirects(response, detail_url)
        # Check confirmation message visible
        self.assertContains(response, 'Book copy successfully reserved')
        self.available_instance.refresh_from_db()
        self.assertEqual(self.available_instance.status, 'r')
        self.assertEqual(self.available_instance.borrower, self.user)
        self.assertEqual(Reservation.objects.filter(user=self.user, key='key-web-1').count(), 1)

    def test_authenticated_user_reserve_unavailable_copy(self):
        self.client.login(username='webuser', password='password123')
        detail_url = reverse('book-detail', args=[self.book.id])
        url_reserved = f'/catalog/book/{self.reserved_instance.pk}/reserve/'
        response = self.client.post(url_reserved, {'idempotency_key': 'key-web-2'}, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertRedirects(response, detail_url)
        self.assertContains(response, 'This copy is not available for reservation.')
        self.reserved_instance.refresh_from_db()
        self.assertEqual(self.reserved_instance.status, 'r')
