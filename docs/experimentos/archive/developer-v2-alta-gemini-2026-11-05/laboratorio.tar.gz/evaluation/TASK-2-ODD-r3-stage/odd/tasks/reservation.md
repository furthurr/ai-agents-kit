# Task: Implementar flujo de reserva de ejemplares disponibles (BookInstance con status='a')

## Specs
- S1: Modelo público de persistencia Reservation en catalog.models con campos (user, instance, key, created_at) y constraint de unicidad [user, key].
- S2: API Endpoint POST /catalog/api/bookinstance/<uuid:pk>/reserve/
  - 401 si no autenticado ({'error': 'unauthorized'}).
  - 405 si método != POST.
  - 400 si Idempotency-Key ausente, vacía tras strip o >100 caracteres ({'error': 'invalid_key'}).
  - 404 si pk no existe ({'error': 'not_found'}).
  - 409 si status != 'a' ({'error': 'unavailable'}).
  - 201 en primera reserva: transiciona status a 'r', borrower al usuario, registra Reservation, retorna {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}.
  - 201 en replay del mismo usuario con misma clave para misma instancia con idéntico payload sin duplicar registros.
  - 409 en conflicto si mismo usuario reutiliza clave con otra instancia ({'error': 'idempotency_conflict'}).
- S3: Garantía de concurrencia bajo SQLite en disco sin 500 'database locked' y con atomic/conditional UPDATE. Dos solicitudes concurrentes resultan en un 201 y un 409.
- S4: Interfaz Web (UI) en /catalog/book/<int:pk> con formulario/botón hacia /catalog/book/<uuid:instance_pk>/reserve/ para copias 'a', requiriendo autenticación, CSRF, idempotency_key oculta y feedback visual de confirmación.
- S5: Suite original de 43 tests pasando intacta sin romper retrocompatibilidad ni renovaciones de bibliotecarios.

## Tasks
- T1 [S1]: Definir Reservation en catalog/models.py y generar/aplicar migración. (completed)
- T2 [S2, S3]: Implementar endpoint API de reserva en catalog/views.py y catalog/urls.py con tests unitarios y de concurrencia/idempotencia. (completed)
- T3 [S4]: Implementar vista Web POST /catalog/book/<uuid:instance_pk>/reserve/ y actualizar catalog/templates/catalog/book_detail.html con mensajes y formulario. (completed)
- T4 [S5]: Ejecutar suite completa (43 tests originales + nuevos) y verificar integridad. (completed)

## Log
L1: "Implementar flujo de reserva de ejemplares disponibles (BookInstance con status='a') para usuarios autenticados, con persistencia de reservas, garantía de idempotencia en reintentos y tolerancia a concurrencia real bajo SQLite."
