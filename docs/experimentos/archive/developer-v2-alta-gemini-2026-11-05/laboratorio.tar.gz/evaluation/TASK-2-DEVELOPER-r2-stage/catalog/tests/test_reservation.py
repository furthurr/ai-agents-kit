import uuid
import concurrent.futures
from django.test import TestCase, TransactionTestCase, Client
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.db import connection

from catalog.models import Book, BookInstance, Author, Genre, Language, Reservation

User = get_user_model()


class ReservationModelTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='password123')
        self.author = Author.objects.create(first_name='John', last_name='Doe')
        self.book = Book.objects.create(title='Test Book', author=self.author, isbn='1234567890123')
        self.instance = BookInstance.objects.create(book=self.book, imprint='Test Imprint', status='a')

    def test_reservation_creation_and_uniqueness(self):
        res = Reservation.objects.create(user=self.user, instance=self.instance, key='key-1')
        self.assertEqual(res.key, 'key-1')
        self.assertEqual(res.user, self.user)
        self.assertEqual(res.instance, self.instance)

        # Re-using same key by another user is allowed
        user2 = User.objects.create_user(username='user2', password='password123')
        res2 = Reservation.objects.create(user=user2, instance=self.instance, key='key-1')
        self.assertEqual(res2.key, 'key-1')


class ReservationAPITests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='user1', password='password123')
        self.user2 = User.objects.create_user(username='user2', password='password123')
        self.author = Author.objects.create(first_name='Author', last_name='One')
        self.book = Book.objects.create(title='Book One', author=self.author, isbn='9876543210123')
        self.instance_avail = BookInstance.objects.create(book=self.book, imprint='Imp1', status='a')
        self.instance_loan = BookInstance.objects.create(book=self.book, imprint='Imp2', status='o')
        self.instance_maint = BookInstance.objects.create(book=self.book, imprint='Imp3', status='m')

    def test_unauthenticated_returns_401(self):
        client = Client()
        url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_avail.pk})
        resp = client.post(url, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(resp.status_code, 401)
        self.assertEqual(resp.json(), {'error': 'unauthorized'})

    def test_wrong_method_returns_405(self):
        client = Client()
        client.force_login(self.user)
        url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_avail.pk})
        resp = client.get(url, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(resp.status_code, 405)
        self.assertEqual(resp.json(), {'error': 'method_not_allowed'})

    def test_missing_or_invalid_idempotency_key(self):
        client = Client()
        client.force_login(self.user)
        url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_avail.pk})

        # Missing
        resp = client.post(url)
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.json(), {'error': 'invalid_key'})

        # Empty or spaces
        resp = client.post(url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.json(), {'error': 'invalid_key'})

        # > 100 chars
        resp = client.post(url, HTTP_IDEMPOTENCY_KEY='x' * 101)
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.json(), {'error': 'invalid_key'})

    def test_not_found_instance(self):
        client = Client()
        client.force_login(self.user)
        url = reverse('api-reserve-bookinstance', kwargs={'pk': uuid.uuid4()})
        resp = client.post(url, HTTP_IDEMPOTENCY_KEY='key-valid')
        self.assertEqual(resp.status_code, 404)
        self.assertEqual(resp.json(), {'error': 'not_found'})

    def test_unavailable_instance(self):
        client = Client()
        client.force_login(self.user)
        # status 'o'
        url_loan = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_loan.pk})
        resp = client.post(url_loan, HTTP_IDEMPOTENCY_KEY='key-valid')
        self.assertEqual(resp.status_code, 409)
        self.assertEqual(resp.json(), {'error': 'unavailable'})

        # status 'm'
        url_maint = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_maint.pk})
        resp = client.post(url_maint, HTTP_IDEMPOTENCY_KEY='key-valid-2')
        self.assertEqual(resp.status_code, 409)
        self.assertEqual(resp.json(), {'error': 'unavailable'})

    def test_successful_reservation(self):
        client = Client()
        client.force_login(self.user)
        url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_avail.pk})
        resp = client.post(url, HTTP_IDEMPOTENCY_KEY='reserve-key-1')
        self.assertEqual(resp.status_code, 201)
        expected = {
            "instance_id": str(self.instance_avail.pk),
            "user_id": self.user.id,
            "status": "r"
        }
        self.assertEqual(resp.json(), expected)

        # Verify DB changes
        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, 'r')
        self.assertEqual(self.instance_avail.borrower, self.user)
        self.assertTrue(Reservation.objects.filter(user=self.user, instance=self.instance_avail, key='reserve-key-1').exists())

    def test_idempotent_replay_same_user_same_key_same_instance(self):
        client = Client()
        client.force_login(self.user)
        url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_avail.pk})

        # First POST
        resp1 = client.post(url, HTTP_IDEMPOTENCY_KEY='reserve-key-1')
        self.assertEqual(resp1.status_code, 201)

        # Replay POST in same session
        resp2 = client.post(url, HTTP_IDEMPOTENCY_KEY='reserve-key-1')
        self.assertEqual(resp2.status_code, 201)
        self.assertEqual(resp2.json(), resp1.json())

        # Replay in completely new client / session
        new_client = Client()
        new_client.force_login(self.user)
        resp3 = new_client.post(url, HTTP_IDEMPOTENCY_KEY='  reserve-key-1  ')
        self.assertEqual(resp3.status_code, 201)
        self.assertEqual(resp3.json(), resp1.json())

        # Ensure only 1 reservation row exists
        self.assertEqual(Reservation.objects.filter(user=self.user, key='reserve-key-1').count(), 1)

    def test_idempotency_conflict_same_key_different_instance(self):
        client = Client()
        client.force_login(self.user)

        second_avail = BookInstance.objects.create(book=self.book, imprint='Imp4', status='a')

        # Reserve first instance with key 'k1'
        url1 = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_avail.pk})
        resp1 = client.post(url1, HTTP_IDEMPOTENCY_KEY='k1')
        self.assertEqual(resp1.status_code, 201)

        # Try to reserve second instance with same key 'k1'
        url2 = reverse('api-reserve-bookinstance', kwargs={'pk': second_avail.pk})
        resp2 = client.post(url2, HTTP_IDEMPOTENCY_KEY='k1')
        self.assertEqual(resp2.status_code, 409)
        self.assertEqual(resp2.json(), {'error': 'idempotency_conflict'})

        # Second instance should not have mutated
        second_avail.refresh_from_db()
        self.assertEqual(second_avail.status, 'a')
        self.assertIsNone(second_avail.borrower)

    def test_idempotency_keys_independent_across_different_users(self):
        client1 = Client()
        client1.force_login(self.user)
        url1 = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_avail.pk})
        resp1 = client1.post(url1, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(resp1.status_code, 201)

        second_avail = BookInstance.objects.create(book=self.book, imprint='Imp5', status='a')
        client2 = Client()
        client2.force_login(self.user2)
        url2 = reverse('api-reserve-bookinstance', kwargs={'pk': second_avail.pk})
        resp2 = client2.post(url2, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(resp2.status_code, 201)
        self.assertEqual(resp2.json()['user_id'], self.user2.id)


class WebUIReservationTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='webuser', password='password123')
        self.author = Author.objects.create(first_name='Author', last_name='Web')
        self.book = Book.objects.create(title='Web Book', author=self.author, isbn='1122334455667')
        self.instance_avail = BookInstance.objects.create(book=self.book, imprint='Web Imp 1', status='a')
        self.instance_loan = BookInstance.objects.create(book=self.book, imprint='Web Imp 2', status='o')

    def test_book_detail_shows_reserve_button_only_for_available(self):
        resp = self.client.get(reverse('book-detail', kwargs={'pk': self.book.pk}))
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, f'action="/catalog/book/{self.instance_avail.id}/reserve/"')
        self.assertContains(resp, 'name="idempotency_key"')
        self.assertContains(resp, 'Reserve copy')
        # instance_loan should not have form
        self.assertNotContains(resp, f'action="/catalog/book/{self.instance_loan.id}/reserve/"')

    def test_reserve_requires_login(self):
        url = reverse('reserve-book-user', kwargs={'instance_pk': self.instance_avail.pk})
        resp = self.client.post(url, {'idempotency_key': 'key-web-1'})
        self.assertEqual(resp.status_code, 302)
        self.assertTrue('/accounts/login/' in resp.url or 'login' in resp.url)

    def test_reserve_success_and_replay_web(self):
        self.client.force_login(self.user)
        url = reverse('reserve-book-user', kwargs={'instance_pk': self.instance_avail.pk})

        resp = self.client.post(url, {'idempotency_key': 'key-web-1'}, follow=True)
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, 'Book successfully reserved.')

        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, 'r')
        self.assertEqual(self.instance_avail.borrower, self.user)

        # Replay should also succeed with message
        resp2 = self.client.post(url, {'idempotency_key': 'key-web-1'}, follow=True)
        self.assertEqual(resp2.status_code, 200)
        self.assertContains(resp2, 'Book successfully reserved.')


class SQLiteConcurrencyTests(TransactionTestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='cuser1', password='password123')
        self.user2 = User.objects.create_user(username='cuser2', password='password123')
        self.author = Author.objects.create(first_name='Concurrent', last_name='Tester')
        self.book = Book.objects.create(title='Concurrency Book', author=self.author, isbn='9999999999999')
        self.instance = BookInstance.objects.create(book=self.book, imprint='Conc Imp', status='a')

    def test_concurrent_reservations_result_in_one_201_and_one_409(self):
        url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance.pk})

        def attempt_reservation(user, key):
            # Close connection so thread gets fresh db connection
            connection.close()
            client = Client()
            client.force_login(user)
            resp = client.post(url, HTTP_IDEMPOTENCY_KEY=key)
            connection.close()
            return resp.status_code, resp.json()

        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            future1 = executor.submit(attempt_reservation, self.user1, 'key-c1')
            future2 = executor.submit(attempt_reservation, self.user2, 'key-c2')

            res1 = future1.result()
            res2 = future2.result()

        status_codes = sorted([res1[0], res2[0]])
        self.assertEqual(status_codes, [201, 409])

        # Verify exact responses
        results = [res1, res2]
        success_res = [r for r in results if r[0] == 201][0]
        failure_res = [r for r in results if r[0] == 409][0]

        self.assertEqual(success_res[1]['status'], 'r')
        self.assertEqual(failure_res[1], {'error': 'unavailable'})

        # Verify DB state
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, 'r')
        self.assertIn(self.instance.borrower, [self.user1, self.user2])
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)
