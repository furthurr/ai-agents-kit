import uuid
import threading
from django.test import TestCase, TransactionTestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.db import connection
from catalog.models import Book, Author, BookInstance, Reservation

User = get_user_model()


class ReservationModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='password123')
        self.user2 = User.objects.create_user(username='testuser2', password='password123')
        self.author = Author.objects.create(first_name='Gabriel', last_name='Garcia Marquez')
        self.book = Book.objects.create(
            title='Cien Anos de Soledad',
            author=self.author,
            summary='Test summary',
            isbn='1234567890123'
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='First edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )

    def test_reservation_creation_and_uniqueness(self):
        res1 = Reservation.objects.create(
            user=self.user,
            instance=self.instance,
            key='key-123'
        )
        self.assertEqual(res1.key, 'key-123')
        self.assertEqual(res1.user, self.user)
        self.assertEqual(res1.instance, self.instance)

        # Same key for different user is allowed
        res2 = Reservation.objects.create(
            user=self.user2,
            instance=self.instance,
            key='key-123'
        )
        self.assertIsNotNone(res2.pk)

        # Same key for same user raises IntegrityError
        from django.db import IntegrityError
        with self.assertRaises(IntegrityError):
            Reservation.objects.create(
                user=self.user,
                instance=self.instance,
                key='key-123'
            )


class ReservationAPITest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='password123')
        self.user2 = User.objects.create_user(username='otheruser', password='password123')
        self.author = Author.objects.create(first_name='Gabriel', last_name='Garcia Marquez')
        self.book = Book.objects.create(
            title='Cien Anos de Soledad',
            author=self.author,
            summary='Test summary',
            isbn='1234567890123'
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='First edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.url = reverse('api-bookinstance-reserve', kwargs={'pk': self.instance.pk})

    def test_requires_authentication(self):
        response = self.client.post(self.url, headers={'Idempotency-Key': 'abc-123'})
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_method_not_allowed(self):
        self.client.login(username='testuser', password='password123')
        response = self.client.get(self.url, headers={'Idempotency-Key': 'abc-123'})
        self.assertEqual(response.status_code, 405)

    def test_missing_or_invalid_idempotency_key(self):
        self.client.login(username='testuser', password='password123')

        # Missing header
        res1 = self.client.post(self.url)
        self.assertEqual(res1.status_code, 400)
        self.assertEqual(res1.json(), {'error': 'invalid_key'})

        # Empty header
        res2 = self.client.post(self.url, headers={'Idempotency-Key': '   '})
        self.assertEqual(res2.status_code, 400)
        self.assertEqual(res2.json(), {'error': 'invalid_key'})

        # Too long header (> 100 chars)
        res3 = self.client.post(self.url, headers={'Idempotency-Key': 'k' * 101})
        self.assertEqual(res3.status_code, 400)
        self.assertEqual(res3.json(), {'error': 'invalid_key'})

        # Ensure instance wasn't touched
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_instance_not_found(self):
        self.client.login(username='testuser', password='password123')
        random_uuid = uuid.uuid4()
        not_found_url = reverse('api-bookinstance-reserve', kwargs={'pk': random_uuid})
        response = self.client.post(not_found_url, headers={'Idempotency-Key': 'abc-123'})
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_instance_unavailable(self):
        self.client.login(username='testuser', password='password123')
        self.instance.status = BookInstance.LoanStatus.MAINTENANCE
        self.instance.save()

        response = self.client.post(self.url, headers={'Idempotency-Key': 'abc-123'})
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})

        # Instance status still MAINTENANCE, no borrower assigned, no reservation created
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.MAINTENANCE)
        self.assertIsNone(self.instance.borrower)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_successful_reservation(self):
        self.client.login(username='testuser', password='password123')
        response = self.client.post(self.url, headers={'Idempotency-Key': 'key-valid-1'})
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), {
            "instance_id": str(self.instance.pk),
            "user_id": self.user.id,
            "status": "r",
        })

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower, self.user)

        res = Reservation.objects.get(user=self.user, key='key-valid-1')
        self.assertEqual(res.instance, self.instance)

    def test_idempotent_replay_same_user_same_key_same_instance(self):
        self.client.login(username='testuser', password='password123')
        # First request
        res1 = self.client.post(self.url, headers={'Idempotency-Key': 'repeat-key'})
        self.assertEqual(res1.status_code, 201)
        self.assertEqual(res1.json(), {
            "instance_id": str(self.instance.pk),
            "user_id": self.user.id,
            "status": "r",
        })
        self.assertEqual(Reservation.objects.count(), 1)

        # Second request (Replay)
        res2 = self.client.post(self.url, headers={'Idempotency-Key': 'repeat-key'})
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), {
            "instance_id": str(self.instance.pk),
            "user_id": self.user.id,
            "status": "r",
        })
        self.assertEqual(Reservation.objects.count(), 1)

    def test_idempotency_conflict_different_instance_same_key(self):
        self.client.login(username='testuser', password='password123')
        # First reserve instance 1
        res1 = self.client.post(self.url, headers={'Idempotency-Key': 'shared-key'})
        self.assertEqual(res1.status_code, 201)

        # Second instance
        instance2 = BookInstance.objects.create(
            book=self.book,
            imprint='Second edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        url2 = reverse('api-bookinstance-reserve', kwargs={'pk': instance2.pk})

        # Attempt to reserve instance 2 with the same key
        res2 = self.client.post(url2, headers={'Idempotency-Key': 'shared-key'})
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})

        # Verify instance2 was not reserved
        instance2.refresh_from_db()
        self.assertEqual(instance2.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(instance2.borrower)

    def test_independent_idempotency_keys_across_users(self):
        # User 1 reserves instance 1 with 'key-abc'
        self.client.login(username='testuser', password='password123')
        res1 = self.client.post(self.url, headers={'Idempotency-Key': 'key-abc'})
        self.assertEqual(res1.status_code, 201)
        self.client.logout()

        # Instance 2 is available
        instance2 = BookInstance.objects.create(
            book=self.book,
            imprint='Second edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        url2 = reverse('api-bookinstance-reserve', kwargs={'pk': instance2.pk})

        # User 2 uses same 'key-abc' for instance 2 -> should succeed!
        self.client.login(username='otheruser', password='password123')
        res2 = self.client.post(url2, headers={'Idempotency-Key': 'key-abc'})
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), {
            "instance_id": str(instance2.pk),
            "user_id": self.user2.id,
            "status": "r",
        })


class WebUIReservationTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='password123')
        self.author = Author.objects.create(first_name='Gabriel', last_name='Garcia Marquez')
        self.book = Book.objects.create(
            title='Cien Anos de Soledad',
            author=self.author,
            summary='Test summary',
            isbn='1234567890123'
        )
        self.available_copy = BookInstance.objects.create(
            book=self.book,
            imprint='Copy 1',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.reserved_copy = BookInstance.objects.create(
            book=self.book,
            imprint='Copy 2',
            status=BookInstance.LoanStatus.RESERVED
        )

    def test_book_detail_renders_reserve_button_for_available_copies_only(self):
        response = self.client.get(reverse('book-detail', kwargs={'pk': self.book.pk}))
        self.assertEqual(response.status_code, 200)

        # Form action for available copy is present
        reserve_url = reverse('bookinstance-reserve', kwargs={'instance_pk': self.available_copy.pk})
        self.assertContains(response, reserve_url)
        self.assertContains(response, 'idempotency_key')
        self.assertContains(response, 'Reservar')

        # No reserve form action for reserved copy
        reserved_url = reverse('bookinstance-reserve', kwargs={'instance_pk': self.reserved_copy.pk})
        self.assertNotContains(response, reserved_url)

    def test_web_reserve_requires_login(self):
        reserve_url = reverse('bookinstance-reserve', kwargs={'instance_pk': self.available_copy.pk})
        response = self.client.post(reserve_url, {'idempotency_key': 'test-web-key'})
        # Should redirect to login
        self.assertEqual(response.status_code, 302)
        self.assertIn('/accounts/login/', response.url)

    def test_web_reserve_success_and_flash_message(self):
        self.client.login(username='testuser', password='password123')
        reserve_url = reverse('bookinstance-reserve', kwargs={'instance_pk': self.available_copy.pk})
        response = self.client.post(reserve_url, {'idempotency_key': 'web-key-1'}, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'reservado con éxito')

        self.available_copy.refresh_from_db()
        self.assertEqual(self.available_copy.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.available_copy.borrower, self.user)


class ReservationConcurrencyTest(TransactionTestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='user1', password='password123')
        self.user2 = User.objects.create_user(username='user2', password='password123')
        self.author = Author.objects.create(first_name='Gabriel', last_name='Garcia Marquez')
        self.book = Book.objects.create(
            title='Cien Anos de Soledad',
            author=self.author,
            summary='Test summary',
            isbn='1234567890123'
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='First edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.url = reverse('api-bookinstance-reserve', kwargs={'pk': self.instance.pk})

    def test_concurrent_reservations_result_in_one_success_and_one_conflict(self):
        results = []

        def reserve(user, key):
            from django.test import Client
            client = Client()
            client.login(username=user.username, password='password123')
            response = client.post(self.url, headers={'Idempotency-Key': key})
            results.append((response.status_code, response.json()))
            connection.close()

        t1 = threading.Thread(target=reserve, args=(self.user1, 'key-u1'))
        t2 = threading.Thread(target=reserve, args=(self.user2, 'key-u2'))

        t1.start()
        t2.start()
        t1.join()
        t2.join()

        self.assertEqual(len(results), 2)
        status_codes = [r[0] for r in results]
        self.assertIn(201, status_codes)
        self.assertIn(409, status_codes)

        # Check the 409 body
        conflict_res = [r[1] for r in results if r[0] == 409][0]
        self.assertEqual(conflict_res, {'error': 'unavailable'})

        # Check database final state
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIn(self.instance.borrower, [self.user1, self.user2])
        self.assertEqual(Reservation.objects.count(), 1)
