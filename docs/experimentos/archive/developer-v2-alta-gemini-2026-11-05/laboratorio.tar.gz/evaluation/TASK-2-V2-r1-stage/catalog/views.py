from django.shortcuts import render

# Create your views here.

from .models import Book, Author, BookInstance, Genre, Language

def index(request):
    """View function for home page of site."""
    # Generate counts of some of the main objects
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available copies of books
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Number of visits to this view, as counted in the session variable.
    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    # Render the HTML template index.html with the data in the context variable.
    return render(request, 'index.html', context=context)

from django.views import generic


class BookListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = Book
    paginate_by = 10

class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre

class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10

class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language

class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10

class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10

class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance

from django.contrib.auth.mixins import LoginRequiredMixin

class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )

# Added as part of challenge!
from django.contrib.auth.mixins import PermissionRequiredMixin


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')

from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
import datetime
from django.contrib.auth.decorators import login_required, permission_required
from catalog.forms import RenewBookForm


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed'))

    # If this is a GET (or any other method) create the default form
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import RestrictedError
from django.contrib.auth.mixins import PermissionRequiredMixin
from .models import Author


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'

class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    # Not recommended (potential security issue if more fields added)
    fields = '__all__'
    permission_required = 'catalog.change_author'

class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("author-delete", kwargs={"pk": self.object.pk})
            )

# Classes created for the forms challenge


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("book-delete", kwargs={"pk": self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    # fields = "__all__"
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'


import time
from django.http import JsonResponse
from django.db import transaction, OperationalError, IntegrityError
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from .models import Reservation


def api_reserve_bookinstance(request, pk):
    """API endpoint to reserve a BookInstance with idempotency and concurrency protection."""
    if request.method != 'POST':
        return JsonResponse({'error': 'method_not_allowed'}, status=405)

    if not request.user.is_authenticated:
        return JsonResponse({'error': 'unauthorized'}, status=401)

    raw_key = request.headers.get('Idempotency-Key')
    if raw_key is None:
        raw_key = request.META.get('HTTP_IDEMPOTENCY_KEY')

    if raw_key is None:
        return JsonResponse({'error': 'invalid_key'}, status=400)

    key = raw_key.strip()
    if not key or len(key) > 100:
        return JsonResponse({'error': 'invalid_key'}, status=400)

    # Retry loop for concurrency under SQLite busy/lock
    max_retries = 10
    for attempt in range(max_retries):
        try:
            # 1. Check if BookInstance exists
            try:
                instance = BookInstance.objects.get(pk=pk)
            except BookInstance.DoesNotExist:
                return JsonResponse({'error': 'not_found'}, status=404)

            # 2. Check if this exact reservation already exists (replay)
            existing_res = Reservation.objects.filter(user=request.user, key=key).first()
            if existing_res:
                if existing_res.instance_id == instance.pk:
                    return JsonResponse({
                        "instance_id": str(pk),
                        "user_id": request.user.id,
                        "status": "r",
                    }, status=201)
                else:
                    return JsonResponse({'error': 'idempotency_conflict'}, status=409)

            # 3. Check instance status
            if instance.status != BookInstance.LoanStatus.AVAILABLE:
                return JsonResponse({'error': 'unavailable'}, status=409)

            # 4. Attempt atomic reservation
            with transaction.atomic():
                rows_updated = BookInstance.objects.filter(
                    pk=pk,
                    status=BookInstance.LoanStatus.AVAILABLE
                ).update(
                    status=BookInstance.LoanStatus.RESERVED,
                    borrower=request.user
                )

                if rows_updated == 0:
                    # Concurrently reserved or changed by another request
                    return JsonResponse({'error': 'unavailable'}, status=409)

                # Create Reservation record
                Reservation.objects.create(
                    user=request.user,
                    instance_id=pk,
                    key=key
                )

                return JsonResponse({
                    "instance_id": str(pk),
                    "user_id": request.user.id,
                    "status": "r",
                }, status=201)

        except IntegrityError:
            # Check if this user inserted the same key concurrently
            existing_res = Reservation.objects.filter(user=request.user, key=key).first()
            if existing_res:
                if existing_res.instance_id == pk:
                    return JsonResponse({
                        "instance_id": str(pk),
                        "user_id": request.user.id,
                        "status": "r",
                    }, status=201)
                else:
                    return JsonResponse({'error': 'idempotency_conflict'}, status=409)
            return JsonResponse({'error': 'unavailable'}, status=409)

        except OperationalError as e:
            if 'locked' in str(e).lower() or 'busy' in str(e).lower():
                if attempt < max_retries - 1:
                    time.sleep(0.05 * (2 ** attempt))
                    continue
            raise


@login_required
def reserve_bookinstance_view(request, instance_pk):
    """Web UI view for reserving a specific BookInstance."""
    instance = get_object_or_404(BookInstance, pk=instance_pk)
    book_url = reverse('book-detail', args=[instance.book.id]) if instance.book else reverse('books')

    if request.method == 'POST':
        key = request.POST.get('idempotency_key', '').strip()
        if not key or len(key) > 100:
            key = str(uuid.uuid4())

        max_retries = 10
        for attempt in range(max_retries):
            try:
                # Refresh instance
                instance.refresh_from_db()

                existing_res = Reservation.objects.filter(user=request.user, key=key).first()
                if existing_res:
                    if existing_res.instance_id == instance.pk:
                        messages.success(request, f"Reserva confirmada con éxito para el ejemplar {instance.id}.")
                        return HttpResponseRedirect(book_url)
                    else:
                        messages.error(request, "Error: Clave de reserva en conflicto.")
                        return HttpResponseRedirect(book_url)

                if instance.status != BookInstance.LoanStatus.AVAILABLE:
                    messages.error(request, "Este ejemplar ya no se encuentra disponible.")
                    return HttpResponseRedirect(book_url)

                with transaction.atomic():
                    rows_updated = BookInstance.objects.filter(
                        pk=instance.pk,
                        status=BookInstance.LoanStatus.AVAILABLE
                    ).update(
                        status=BookInstance.LoanStatus.RESERVED,
                        borrower=request.user
                    )

                    if rows_updated == 0:
                        messages.error(request, "Este ejemplar ya no se encuentra disponible.")
                        return HttpResponseRedirect(book_url)

                    Reservation.objects.create(
                        user=request.user,
                        instance=instance,
                        key=key
                    )

                    messages.success(request, f"¡Ejemplar {instance.id} reservado con éxito!")
                    return HttpResponseRedirect(book_url)

            except IntegrityError:
                existing_res = Reservation.objects.filter(user=request.user, key=key).first()
                if existing_res and existing_res.instance_id == instance.pk:
                    messages.success(request, f"Reserva confirmada con éxito para el ejemplar {instance.id}.")
                    return HttpResponseRedirect(book_url)
                messages.error(request, "No se pudo completar la reserva.")
                return HttpResponseRedirect(book_url)

            except OperationalError as e:
                if 'locked' in str(e).lower() or 'busy' in str(e).lower():
                    if attempt < max_retries - 1:
                        time.sleep(0.05 * (2 ** attempt))
                        continue
                raise

    return HttpResponseRedirect(book_url)

