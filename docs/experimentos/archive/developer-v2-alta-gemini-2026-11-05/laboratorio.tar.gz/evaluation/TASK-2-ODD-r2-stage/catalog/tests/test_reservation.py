import uuid
import concurrent.futures
from django.test import TestCase, TransactionTestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.db import connection
from catalog.models import Book, BookInstance, Author, Genre, Language, Reservation

User = get_user_model()


class ReservationModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='password123')
        self.author = Author.objects.create(first_name='John', last_name='Doe')
        self.book = Book.objects.create(title='Test Book', author=self.author, isbn='1234567890123')
        self.instance = BookInstance.objects.create(book=self.book, imprint='Test Imprint', status='a')

    def test_reservation_creation_and_str(self):
        res = Reservation.objects.create(user=self.user, instance=self.instance, key='key-123')
        self.assertEqual(res.user, self.user)
        self.assertEqual(res.instance, self.instance)
        self.assertEqual(res.key, 'key-123')
        self.assertIn('Reservation key-123', str(res))

    def test_reservation_user_key_unique_constraint(self):
        Reservation.objects.create(user=self.user, instance=self.instance, key='unique-key')
        from django.db import IntegrityError
        with self.assertRaises(IntegrityError):
            Reservation.objects.create(user=self.user, instance=self.instance, key='unique-key')

    def test_different_users_same_key(self):
        user2 = User.objects.create_user(username='testuser2', password='password123')
        res1 = Reservation.objects.create(user=self.user, instance=self.instance, key='common-key')
        res2 = Reservation.objects.create(user=user2, instance=self.instance, key='common-key')
        self.assertNotEqual(res1.user, res2.user)
        self.assertEqual(res1.key, res2.key)


class ReservationAPITest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='user1', password='password123')
        self.user2 = User.objects.create_user(username='user2', password='password123')
        self.author = Author.objects.create(first_name='Author', last_name='One')
        self.book = Book.objects.create(title='Django Guide', author=self.author, isbn='9876543210123')
        self.instance_available = BookInstance.objects.create(book=self.book, imprint='Imp1', status='a')
        self.instance_maintenance = BookInstance.objects.create(book=self.book, imprint='Imp2', status='m')
        self.instance_on_loan = BookInstance.objects.create(book=self.book, imprint='Imp3', status='o')
        self.instance_reserved = BookInstance.objects.create(book=self.book, imprint='Imp4', status='r')

    def test_unauthenticated_returns_401(self):
        url = reverse('reserve-book-instance-api', kwargs={'pk': self.instance_available.pk})
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-auth')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_method_not_allowed_get(self):
        self.client.login(username='user1', password='password123')
        url = reverse('reserve-book-instance-api', kwargs={'pk': self.instance_available.pk})
        response = self.client.get(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 405)

    def test_missing_or_invalid_idempotency_key(self):
        self.client.login(username='user1', password='password123')
        url = reverse('reserve-book-instance-api', kwargs={'pk': self.instance_available.pk})

        # Missing key
        response = self.client.post(url)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

        # Empty key after strip
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

        # Key exceeding 100 characters
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='k' * 101)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

    def test_nonexistent_instance_returns_404(self):
        self.client.login(username='user1', password='password123')
        random_uuid = uuid.uuid4()
        url = reverse('reserve-book-instance-api', kwargs={'pk': random_uuid})
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-404')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_unavailable_instance_returns_409(self):
        self.client.login(username='user1', password='password123')
        for inst in [self.instance_maintenance, self.instance_on_loan, self.instance_reserved]:
            url = reverse('reserve-book-instance-api', kwargs={'pk': inst.pk})
            response = self.client.post(url, HTTP_IDEMPOTENCY_KEY=f'key-{inst.pk}')
            self.assertEqual(response.status_code, 409)
            self.assertEqual(response.json(), {'error': 'unavailable'})
            inst.refresh_from_db()
            self.assertNotEqual(inst.borrower, self.user)
            self.assertFalse(Reservation.objects.filter(key=f'key-{inst.pk}').exists())

    def test_successful_reservation(self):
        self.client.login(username='user1', password='password123')
        url = reverse('reserve-book-instance-api', kwargs={'pk': self.instance_available.pk})
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-success-1')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), {
            "instance_id": str(self.instance_available.pk),
            "user_id": self.user.id,
            "status": "r"
        })

        self.instance_available.refresh_from_db()
        self.assertEqual(self.instance_available.status, 'r')
        self.assertEqual(self.instance_available.borrower, self.user)
        self.assertTrue(Reservation.objects.filter(user=self.user, instance=self.instance_available, key='key-success-1').exists())

    def test_idempotent_replay_same_instance(self):
        self.client.login(username='user1', password='password123')
        url = reverse('reserve-book-instance-api', kwargs={'pk': self.instance_available.pk})
        
        # First call
        res1 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-replay-1')
        self.assertEqual(res1.status_code, 201)
        data1 = res1.json()

        # Replay call with same user, key, instance
        res2 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-replay-1')
        self.assertEqual(res2.status_code, 201)
        data2 = res2.json()
        self.assertEqual(data1, data2)
        self.assertEqual(Reservation.objects.filter(user=self.user, key='key-replay-1').count(), 1)

    def test_idempotency_conflict_different_instance(self):
        self.client.login(username='user1', password='password123')
        another_inst = BookInstance.objects.create(book=self.book, imprint='Imp5', status='a')
        url1 = reverse('reserve-book-instance-api', kwargs={'pk': self.instance_available.pk})
        url2 = reverse('reserve-book-instance-api', kwargs={'pk': another_inst.pk})

        res1 = self.client.post(url1, HTTP_IDEMPOTENCY_KEY='reused-key')
        self.assertEqual(res1.status_code, 201)

        # Attempt to use same key on another instance
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='reused-key')
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})

        another_inst.refresh_from_db()
        self.assertEqual(another_inst.status, 'a')
        self.assertIsNone(another_inst.borrower)

    def test_different_users_same_idempotency_key(self):
        # User 1 reserves instance_available with 'shared-key'
        self.client.login(username='user1', password='password123')
        url1 = reverse('reserve-book-instance-api', kwargs={'pk': self.instance_available.pk})
        res1 = self.client.post(url1, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(res1.status_code, 201)

        # Another available instance
        another_inst = BookInstance.objects.create(book=self.book, imprint='Imp6', status='a')
        self.client.login(username='user2', password='password123')
        url2 = reverse('reserve-book-instance-api', kwargs={'pk': another_inst.pk})
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json()['user_id'], self.user2.id)


class ReservationUITest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='uiuser', password='password123')
        self.author = Author.objects.create(first_name='AuthorUI', last_name='LastUI')
        self.book = Book.objects.create(title='UI Book', author=self.author, isbn='1112223334445')
        self.instance_available = BookInstance.objects.create(book=self.book, imprint='UIImp1', status='a')

    def test_book_detail_renders_reserve_button_for_available_copy(self):
        response = self.client.get(reverse('book-detail', kwargs={'pk': self.book.pk}))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Reserve this copy')
        reserve_url = reverse('reserve-book-instance-ui', kwargs={'pk': self.instance_available.pk})
        self.assertContains(response, reserve_url)
        self.assertContains(response, 'name="idempotency_key"')

    def test_ui_reserve_requires_login_redirect(self):
        url = reverse('reserve-book-instance-ui', kwargs={'pk': self.instance_available.pk})
        response = self.client.post(url, {'idempotency_key': 'some-key'})
        self.assertEqual(response.status_code, 302)
        self.assertIn('/accounts/login/', response.url)

    def test_ui_reserve_success_and_flash_message(self):
        self.client.login(username='uiuser', password='password123')
        url = reverse('reserve-book-instance-ui', kwargs={'pk': self.instance_available.pk})
        response = self.client.post(url, {'idempotency_key': 'ui-key-1'}, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'successfully reserved')
        self.instance_available.refresh_from_db()
        self.assertEqual(self.instance_available.status, 'r')
        self.assertEqual(self.instance_available.borrower, self.user)


class ReservationConcurrencyTest(TransactionTestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='concurrent1', password='password123')
        self.user2 = User.objects.create_user(username='concurrent2', password='password123')
        self.author = Author.objects.create(first_name='Conc', last_name='Author')
        self.book = Book.objects.create(title='Concurrency Book', author=self.author, isbn='9998887776665')
        self.instance = BookInstance.objects.create(book=self.book, imprint='ConcImp', status='a')

    def tear_down(self):
        connection.close()

    def test_concurrent_reservations_same_copy(self):
        from django.test import Client

        c1 = Client()
        c1.login(username='concurrent1', password='password123')
        c2 = Client()
        c2.login(username='concurrent2', password='password123')
        connection.close()

        def try_reserve(client, key):
            url = reverse('reserve-book-instance-api', kwargs={'pk': self.instance.pk})
            resp = client.post(url, HTTP_IDEMPOTENCY_KEY=key)
            connection.close()
            return resp.status_code, resp.json()

        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            fut1 = executor.submit(try_reserve, c1, 'key-conc-1')
            fut2 = executor.submit(try_reserve, c2, 'key-conc-2')
            res1 = fut1.result()
            res2 = fut2.result()

        status_codes = [res1[0], res2[0]]
        self.assertIn(201, status_codes)
        self.assertIn(409, status_codes)

        # Confirm exact payload
        winner = res1[1] if res1[0] == 201 else res2[1]
        loser = res1[1] if res1[0] == 409 else res2[1]
        self.assertEqual(winner['status'], 'r')
        self.assertEqual(loser, {'error': 'unavailable'})

        # Confirm database state
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, 'r')
        self.assertIn(self.instance.borrower, [self.user1, self.user2])
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)
