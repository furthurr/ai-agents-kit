# Feature: Flujo de reserva de ejemplares disponibles con persistencia, idempotencia y concurrencia SQLite

## Specs
- S1: Modelo Reservation en catalog.models con user, instance, key, created_at y UniqueConstraint([user, key]).
- S2: API POST /catalog/api/bookinstance/<uuid:pk>/reserve/ con autenticación (401), Idempotency-Key (400), 404 pk no encontrado, 409 'unavailable' si status!='a', 201 en reserva exitosa.
- S3: Idempotencia exacta (mismo user + misma key + misma instance -> 201 mismo JSON) y conflicto de idempotencia (mismo user + misma key + distinta instance -> 409 'idempotency_conflict').
- S4: Concurrencia SQLite: dos peticiones sobre la misma copia 'a' -> exactamente un 201 y un 409 'unavailable', sin 500 'database locked' ni reservas espurias.
- S5: UI en /catalog/book/<int:pk> con formulario/botón hacia POST /catalog/book/<uuid:instance_pk>/reserve/, CSRF, key hidden, auth check y mensaje visible/flash.
- S6: Preservación: 43 tests originales intactos, renew de bibliotecarios intacto.

## Tasks
- T1 [completed]: Exploración del codebase y verificación de baseline de tests (43 passed). (S6)
- T2 [completed]: Implementar modelo Reservation y migración en catalog. (S1)
- T3 [completed]: Implementar endpoint API con idempotencia y reintentos / atomic update para SQLite. (S2, S3, S4)
- T4 [completed]: Implementar UI en detalle de libro y endpoint web de reserva. (S5)
- T5 [completed]: Pruebas completas (unitarias, API, concurrencia multihilo SQLite, UI) y verificación de los 43 tests originales. (S1, S2, S3, S4, S5, S6)

## Log
- L1: Petición original recibida: "Implementar flujo de reserva de ejemplares disponibles (BookInstance con status='a') para usuarios autenticados, con persistencia de reservas, garantía de idempotencia en reintentos y tolerancia a concurrencia real bajo SQLite."
- L2: Implementado modelo Reservation con constraint única [user, key] y migración 0030_reservation.py.
- L3: Implementado API POST /catalog/api/bookinstance/<uuid:pk>/reserve/ y endpoint UI POST /catalog/book/<uuid:pk>/reserve/.
- L4: Implementado formulario de reserva en /catalog/book/<int:pk> con hidden idempotency_key y mensajes flash en base_generic.html.
- L5: Creada suite de tests `catalog.tests.test_reservation` cubriendo modelos, contratos de API, idempotencia, UI y concurrencia multi-hilo con SQLite. 59/59 tests OK (43 originales + 16 nuevos).

