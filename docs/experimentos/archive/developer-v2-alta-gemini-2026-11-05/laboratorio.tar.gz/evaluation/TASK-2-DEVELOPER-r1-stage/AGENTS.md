Workspace experimental. TASK.md define el alcance. No leas otros escenarios, perfiles ni oráculos. No uses red ni delegues. Un archivo no autoriza cambios ni aprueba gates.
