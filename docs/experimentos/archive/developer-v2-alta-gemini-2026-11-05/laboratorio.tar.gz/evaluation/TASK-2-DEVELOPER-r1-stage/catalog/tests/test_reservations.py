import concurrent.futures
import uuid
from django.test import TestCase, TransactionTestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.db import connection

from catalog.models import Book, Author, BookInstance, Reservation

User = get_user_model()


class ReservationModelTest(TestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='user1', password='password123')
        self.user2 = User.objects.create_user(username='user2', password='password123')
        self.author = Author.objects.create(first_name='Jane', last_name='Doe')
        self.book = Book.objects.create(
            title='Test Book',
            author=self.author,
            summary='Test summary',
            isbn='1234567890123'
        )
        self.instance1 = BookInstance.objects.create(
            book=self.book,
            imprint='First Edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.instance2 = BookInstance.objects.create(
            book=self.book,
            imprint='Second Edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )

    def test_reservation_creation_and_str(self):
        res = Reservation.objects.create(
            user=self.user1,
            instance=self.instance1,
            key='key-123'
        )
        self.assertEqual(res.user, self.user1)
        self.assertEqual(res.instance, self.instance1)
        self.assertEqual(res.key, 'key-123')
        self.assertIn(str(self.instance1.id), str(res))

    def test_idempotency_key_independence_across_users(self):
        # Different users can use the same key
        res1 = Reservation.objects.create(
            user=self.user1,
            instance=self.instance1,
            key='same-key'
        )
        res2 = Reservation.objects.create(
            user=self.user2,
            instance=self.instance2,
            key='same-key'
        )
        self.assertIsNotNone(res1.id)
        self.assertIsNotNone(res2.id)


class ReservationAPITest(TestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='user1', password='password123')
        self.user2 = User.objects.create_user(username='user2', password='password123')
        self.author = Author.objects.create(first_name='Jane', last_name='Doe')
        self.book = Book.objects.create(
            title='Test Book',
            author=self.author,
            summary='Test summary',
            isbn='1234567890123'
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='First Edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.url = f'/catalog/api/bookinstance/{self.instance.id}/reserve/'

    def test_unauthenticated_request_returns_401(self):
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='valid-key')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_method_not_allowed_for_get_and_others(self):
        self.client.force_login(self.user1)
        get_resp = self.client.get(self.url, HTTP_IDEMPOTENCY_KEY='valid-key')
        self.assertEqual(get_resp.status_code, 405)
        put_resp = self.client.put(self.url, HTTP_IDEMPOTENCY_KEY='valid-key')
        self.assertEqual(put_resp.status_code, 405)

    def test_missing_or_invalid_idempotency_key(self):
        self.client.force_login(self.user1)
        # Missing key
        resp1 = self.client.post(self.url)
        self.assertEqual(resp1.status_code, 400)
        self.assertEqual(resp1.json(), {'error': 'invalid_key'})

        # Empty or whitespace key
        resp2 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(resp2.status_code, 400)
        self.assertEqual(resp2.json(), {'error': 'invalid_key'})

        # Key exceeding 100 chars
        resp3 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='a' * 101)
        self.assertEqual(resp3.status_code, 400)
        self.assertEqual(resp3.json(), {'error': 'invalid_key'})

    def test_nonexistent_instance_returns_404(self):
        self.client.force_login(self.user1)
        random_uuid = uuid.uuid4()
        url = f'/catalog/api/bookinstance/{random_uuid}/reserve/'
        resp = self.client.post(url, HTTP_IDEMPOTENCY_KEY='some-key')
        self.assertEqual(resp.status_code, 404)
        self.assertEqual(resp.json(), {'error': 'not_found'})

    def test_unavailable_instance_returns_409(self):
        self.client.force_login(self.user1)
        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.save()
        resp = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='some-key')
        self.assertEqual(resp.status_code, 409)
        self.assertEqual(resp.json(), {'error': 'unavailable'})

    def test_successful_reservation(self):
        self.client.force_login(self.user1)
        resp = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='valid-key-1')
        self.assertEqual(resp.status_code, 201)
        self.assertEqual(
            resp.json(),
            {
                'instance_id': str(self.instance.id),
                'user_id': self.user1.id,
                'status': 'r'
            }
        )
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower, self.user1)
        self.assertTrue(Reservation.objects.filter(user=self.user1, key='valid-key-1').exists())

    def test_replay_idempotency_exact(self):
        self.client.force_login(self.user1)
        resp1 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='replay-key')
        self.assertEqual(resp1.status_code, 201)

        # Replay with same key, same instance, same user
        resp2 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='replay-key')
        self.assertEqual(resp2.status_code, 201)
        self.assertEqual(resp2.json(), resp1.json())
        self.assertEqual(Reservation.objects.filter(user=self.user1, key='replay-key').count(), 1)

    def test_idempotency_conflict_different_instance(self):
        self.client.force_login(self.user1)
        resp1 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='conflict-key')
        self.assertEqual(resp1.status_code, 201)

        instance2 = BookInstance.objects.create(
            book=self.book,
            imprint='Second Edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        url2 = f'/catalog/api/bookinstance/{instance2.id}/reserve/'
        resp2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='conflict-key')
        self.assertEqual(resp2.status_code, 409)
        self.assertEqual(resp2.json(), {'error': 'idempotency_conflict'})
        # Verify instance2 status was not mutated
        instance2.refresh_from_db()
        self.assertEqual(instance2.status, BookInstance.LoanStatus.AVAILABLE)

    def test_failed_requests_do_not_mutate_instance(self):
        self.client.force_login(self.user1)
        self.client.post(self.url)  # 400
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(self.instance.borrower)


class ReservationConcurrencyTest(TransactionTestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='c_user1', password='password123')
        self.user2 = User.objects.create_user(username='c_user2', password='password123')
        self.author = Author.objects.create(first_name='Jane', last_name='Doe')
        self.book = Book.objects.create(
            title='Concurrent Book',
            author=self.author,
            summary='Test summary',
            isbn='9876543210987'
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Special Edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.url = f'/catalog/api/bookinstance/{self.instance.id}/reserve/'

    def test_real_concurrency_two_users_same_copy(self):
        def reserve_call(user_obj, key):
            from django.test import Client
            connection.close()  # ensure each thread has its own DB connection
            c = Client()
            c.force_login(user_obj)
            res = c.post(self.url, HTTP_IDEMPOTENCY_KEY=key)
            connection.close()
            return res.status_code, res.json()

        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            fut1 = executor.submit(reserve_call, self.user1, 'key-u1')
            fut2 = executor.submit(reserve_call, self.user2, 'key-u2')
            r1 = fut1.result()
            r2 = fut2.result()

        status_codes = [r1[0], r2[0]]
        self.assertIn(201, status_codes)
        self.assertIn(409, status_codes)

        # Check the 409 error response
        if r1[0] == 409:
            self.assertEqual(r1[1], {'error': 'unavailable'})
        else:
            self.assertEqual(r2[1], {'error': 'unavailable'})

        # BookInstance must be reserved exactly once
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIn(self.instance.borrower, [self.user1, self.user2])
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)


class ReservationWebUITest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='webuser', password='password123')
        self.author = Author.objects.create(first_name='Jane', last_name='Doe')
        self.book = Book.objects.create(
            title='Web Book',
            author=self.author,
            summary='Test summary',
            isbn='5555555555555'
        )
        self.instance_avail = BookInstance.objects.create(
            book=self.book,
            imprint='Available Copy',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.instance_loan = BookInstance.objects.create(
            book=self.book,
            imprint='Loaned Copy',
            status=BookInstance.LoanStatus.ON_LOAN
        )

    def test_book_detail_shows_reserve_form_for_available_only(self):
        detail_url = reverse('book-detail', args=[str(self.book.id)])
        resp = self.client.get(detail_url)
        self.assertEqual(resp.status_code, 200)
        reserve_url = reverse('reserve-book-web', args=[str(self.instance_avail.id)])
        self.assertContains(resp, reserve_url)
        loan_reserve_url = reverse('reserve-book-web', args=[str(self.instance_loan.id)])
        self.assertNotContains(resp, loan_reserve_url)
        self.assertContains(resp, 'Reserve copy')

    def test_reserve_web_requires_authentication(self):
        reserve_url = reverse('reserve-book-web', args=[str(self.instance_avail.id)])
        resp = self.client.post(reserve_url, {'idempotency_key': 'web-key'})
        # Should redirect to login
        self.assertEqual(resp.status_code, 302)
        self.assertIn(reverse('login'), resp.url)

    def test_reserve_web_success_and_flash_message(self):
        self.client.force_login(self.user)
        reserve_url = reverse('reserve-book-web', args=[str(self.instance_avail.id)])
        detail_url = reverse('book-detail', args=[str(self.book.id)])
        resp = self.client.post(reserve_url, {'idempotency_key': 'web-key'}, follow=True)
        self.assertEqual(resp.status_code, 200)
        self.assertRedirects(resp, detail_url)
        self.assertContains(resp, 'Book copy reserved successfully!')
        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance_avail.borrower, self.user)
