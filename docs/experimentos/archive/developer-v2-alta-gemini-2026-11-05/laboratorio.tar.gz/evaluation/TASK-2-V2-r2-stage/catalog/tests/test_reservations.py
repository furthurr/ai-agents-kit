import uuid
import threading
from django.test import TestCase, TransactionTestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from catalog.models import Book, Author, Genre, Language, BookInstance, Reservation


class ReservationModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='res_user', password='password123')
        self.author = Author.objects.create(first_name='Leo', last_name='Tolstoy')
        self.book = Book.objects.create(
            title='War and Peace',
            author=self.author,
            summary='Epic historical novel',
            isbn='1234567890123'
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Oxford University Press',
            status=BookInstance.LoanStatus.AVAILABLE
        )

    def test_reservation_creation(self):
        res = Reservation.objects.create(
            user=self.user,
            instance=self.instance,
            key='key-123'
        )
        self.assertEqual(res.user, self.user)
        self.assertEqual(res.instance, self.instance)
        self.assertEqual(res.key, 'key-123')
        self.assertIsNotNone(res.created_at)
        self.assertIn('key-123', str(res))


class ReservationAPITest(TestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='user1', password='password123')
        self.user2 = User.objects.create_user(username='user2', password='password123')
        self.author = Author.objects.create(first_name='Jane', last_name='Austen')
        self.book = Book.objects.create(
            title='Pride and Prejudice',
            author=self.author,
            summary='Classic romance novel',
            isbn='9876543210987'
        )
        self.instance_available = BookInstance.objects.create(
            book=self.book,
            imprint='Penguin Classics',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.instance_maintenance = BookInstance.objects.create(
            book=self.book,
            imprint='Penguin Classics',
            status=BookInstance.LoanStatus.MAINTENANCE
        )
        self.url = reverse('api-bookinstance-reserve', kwargs={'pk': self.instance_available.pk})

    def test_unauthenticated(self):
        # 401 Unauthorized with {'error': 'unauthorized'}
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key1')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_method_not_allowed(self):
        self.client.login(username='user1', password='password123')
        # GET responds with 405 Method Not Allowed
        response = self.client.get(self.url, HTTP_IDEMPOTENCY_KEY='key1')
        self.assertEqual(response.status_code, 405)

    def test_missing_or_invalid_idempotency_key(self):
        self.client.login(username='user1', password='password123')
        # Missing header
        res1 = self.client.post(self.url)
        self.assertEqual(res1.status_code, 400)
        self.assertEqual(res1.json(), {'error': 'invalid_key'})

        # Whitespace only
        res2 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(res2.status_code, 400)
        self.assertEqual(res2.json(), {'error': 'invalid_key'})

        # Exceeds 100 chars
        res3 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='k' * 101)
        self.assertEqual(res3.status_code, 400)
        self.assertEqual(res3.json(), {'error': 'invalid_key'})

    def test_instance_not_found(self):
        self.client.login(username='user1', password='password123')
        non_existent_uuid = uuid.uuid4()
        url = reverse('api-bookinstance-reserve', kwargs={'pk': non_existent_uuid})
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key1')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_instance_unavailable(self):
        self.client.login(username='user1', password='password123')
        url = reverse('api-bookinstance-reserve', kwargs={'pk': self.instance_maintenance.pk})
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key1')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})

        # Check instance status unmodified
        self.instance_maintenance.refresh_from_db()
        self.assertEqual(self.instance_maintenance.status, BookInstance.LoanStatus.MAINTENANCE)
        self.assertIsNone(self.instance_maintenance.borrower)

    def test_successful_reservation(self):
        self.client.login(username='user1', password='password123')
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key1')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), {
            'instance_id': str(self.instance_available.pk),
            'user_id': self.user1.id,
            'status': 'r'
        })

        self.instance_available.refresh_from_db()
        self.assertEqual(self.instance_available.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance_available.borrower, self.user1)
        self.assertTrue(Reservation.objects.filter(user=self.user1, key='key1').exists())

    def test_idempotent_replay_same_user_same_key_same_instance(self):
        self.client.login(username='user1', password='password123')
        # First request
        res1 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-replay')
        self.assertEqual(res1.status_code, 201)
        expected_json = {
            'instance_id': str(self.instance_available.pk),
            'user_id': self.user1.id,
            'status': 'r'
        }
        self.assertEqual(res1.json(), expected_json)

        # Replay request
        res2 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-replay')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), expected_json)

        # Check no duplicated reservations
        self.assertEqual(Reservation.objects.filter(user=self.user1, key='key-replay').count(), 1)

    def test_idempotency_conflict_same_user_same_key_different_instance(self):
        self.client.login(username='user1', password='password123')
        # Reserve first instance
        res1 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(res1.status_code, 201)

        # Create another available instance
        another_instance = BookInstance.objects.create(
            book=self.book,
            imprint='HarperCollins',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        url2 = reverse('api-bookinstance-reserve', kwargs={'pk': another_instance.pk})

        # Attempt to use the same key for another instance
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})

        # another_instance should remain available
        another_instance.refresh_from_db()
        self.assertEqual(another_instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_different_users_same_key_are_independent(self):
        # User 1 reserves instance 1 with 'key-x'
        self.client.login(username='user1', password='password123')
        res1 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-x')
        self.assertEqual(res1.status_code, 201)
        self.client.logout()

        # User 2 reserves instance 2 with the SAME 'key-x'
        another_instance = BookInstance.objects.create(
            book=self.book,
            imprint='Vintage',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        url2 = reverse('api-bookinstance-reserve', kwargs={'pk': another_instance.pk})

        self.client.login(username='user2', password='password123')
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='key-x')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), {
            'instance_id': str(another_instance.pk),
            'user_id': self.user2.id,
            'status': 'r'
        })


class ReservationConcurrencyTest(TransactionTestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='c_user1', password='password123')
        self.user2 = User.objects.create_user(username='c_user2', password='password123')
        self.author = Author.objects.create(first_name='Mary', last_name='Shelley')
        self.book = Book.objects.create(
            title='Frankenstein',
            author=self.author,
            summary='Gothic monster story',
            isbn='1112223334445'
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Lackington',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.url = reverse('api-bookinstance-reserve', kwargs={'pk': self.instance.pk})

    def test_concurrent_reservations_two_users_one_copy(self):
        """Two concurrent requests on the same available copy result in exactly one 201 and one 409."""
        results = []
        barrier = threading.Barrier(2)

        def reserve(user, key):
            from django.db import connection
            # New thread needs clean db connection in SQLite
            connection.close()
            client = Client()
            client.force_login(user)
            barrier.wait()
            resp = client.post(self.url, HTTP_IDEMPOTENCY_KEY=key)
            results.append((user.id, resp.status_code, resp.json()))
            connection.close()

        t1 = threading.Thread(target=reserve, args=(self.user1, 'key-u1'))
        t2 = threading.Thread(target=reserve, args=(self.user2, 'key-u2'))

        t1.start()
        t2.start()
        t1.join()
        t2.join()

        status_codes = [r[1] for r in results]
        self.assertIn(201, status_codes)
        self.assertIn(409, status_codes)
        self.assertEqual(len(results), 2)

        # Check that 409 returned {'error': 'unavailable'}
        conflict_result = next(r for r in results if r[1] == 409)
        self.assertEqual(conflict_result[2], {'error': 'unavailable'})

        # Check DB state: exactly 1 reservation, instance is 'r'
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)


class ReservationUITest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='ui_user', password='password123')
        self.author = Author.objects.create(first_name='George', last_name='Orwell')
        self.book = Book.objects.create(
            title='1984',
            author=self.author,
            summary='Dystopian novel',
            isbn='5556667778889'
        )
        self.instance_avail = BookInstance.objects.create(
            book=self.book,
            imprint='Secker & Warburg',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.instance_onloan = BookInstance.objects.create(
            book=self.book,
            imprint='Secker & Warburg',
            status=BookInstance.LoanStatus.ON_LOAN
        )
        self.book_detail_url = reverse('book-detail', kwargs={'pk': self.book.pk})
        self.reserve_web_url = reverse('bookinstance-reserve-web', kwargs={'pk': self.instance_avail.pk})

    def test_book_detail_shows_reserve_form_for_available_only(self):
        response = self.client.get(self.book_detail_url)
        self.assertEqual(response.status_code, 200)
        # Check form exists for available instance
        self.assertContains(response, f'action="{self.reserve_web_url}"')
        self.assertContains(response, 'name="idempotency_key"')
        self.assertContains(response, 'Reserve')

        # Should not have a form for on-loan instance
        reserve_onloan_url = reverse('bookinstance-reserve-web', kwargs={'pk': self.instance_onloan.pk})
        self.assertNotContains(response, f'action="{reserve_onloan_url}"')

    def test_web_reserve_anonymous_redirects_to_login(self):
        response = self.client.post(self.reserve_web_url, {'idempotency_key': 'web-key-1'})
        self.assertEqual(response.status_code, 302)
        self.assertIn('/accounts/login/', response.url)

    def test_web_reserve_authenticated_success_and_flash_message(self):
        self.client.login(username='ui_user', password='password123')
        response = self.client.post(
            self.reserve_web_url,
            {'idempotency_key': 'web-key-1'},
            follow=True
        )
        self.assertEqual(response.status_code, 200)
        self.assertRedirects(response, self.book_detail_url)
        # Verify success message rendered
        self.assertContains(response, 'Book copy successfully reserved!')

        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance_avail.borrower, self.user)
