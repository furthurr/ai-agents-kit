from django.shortcuts import render

# Create your views here.

from .models import Book, Author, BookInstance, Genre, Language, Reservation

def index(request):
    """View function for home page of site."""
    # Generate counts of some of the main objects
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available copies of books
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Number of visits to this view, as counted in the session variable.
    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    # Render the HTML template index.html with the data in the context variable.
    return render(request, 'index.html', context=context)

from django.views import generic


class BookListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = Book
    paginate_by = 10

class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        import uuid
        context['book_copies'] = list(context['book'].bookinstance_set.all())
        for copy in context['book_copies']:
            copy.reservation_key = uuid.uuid4().hex
        return context

class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre

class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10

class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language

class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10

class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10

class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance

from django.contrib.auth.mixins import LoginRequiredMixin

class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )

# Added as part of challenge!
from django.contrib.auth.mixins import PermissionRequiredMixin


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')

from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
import datetime
from django.contrib.auth.decorators import login_required, permission_required
from catalog.forms import RenewBookForm


import sqlite3
import time

from django.db import IntegrityError, OperationalError, connection, transaction
from django.http import JsonResponse
from django.contrib import messages
from django.views.decorators.http import require_POST


def _is_sqlite_lock_error(error):
    cause = error.__cause__
    return connection.vendor == 'sqlite' and (
        'locked' in str(error).lower()
        or getattr(cause, 'sqlite_errorcode', None) in {
            sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED,
        }
    )


def _existing_reservation_result(user, instance_id, key):
    previous = Reservation.objects.filter(user=user, key=key).first()
    if not previous:
        return None
    if str(previous.instance_id) == str(instance_id):
        return 201, {
            'instance_id': str(instance_id),
            'user_id': user.pk,
            'status': BookInstance.LoanStatus.RESERVED,
        }
    return 409, {'error': 'idempotency_conflict'}


def _reserve_copy(user, instance_id, key):
    """Reserve atomically; retry SQLite's deferred-transaction lock upgrade."""
    attempts = 6
    for attempt in range(attempts):
        try:
            with transaction.atomic():
                updated = BookInstance.objects.filter(
                    pk=instance_id,
                    status=BookInstance.LoanStatus.AVAILABLE,
                ).update(
                    status=BookInstance.LoanStatus.RESERVED,
                    borrower=user,
                )
                if not updated:
                    if not BookInstance.objects.filter(pk=instance_id).exists():
                        return 404, {'error': 'not_found'}
                    replay = _existing_reservation_result(user, instance_id, key)
                    if replay:
                        return replay
                    return 409, {'error': 'unavailable'}

                Reservation.objects.create(user=user, instance_id=instance_id, key=key)
                return 201, {
                    'instance_id': str(instance_id),
                    'user_id': user.pk,
                    'status': BookInstance.LoanStatus.RESERVED,
                }
        except IntegrityError:
            # A concurrent request may have won the unique (user, key) insert.
            replay = _existing_reservation_result(user, instance_id, key)
            if replay:
                return replay
            raise
        except OperationalError as error:
            if not _is_sqlite_lock_error(error) or attempt == attempts - 1:
                if attempt == attempts - 1 and _is_sqlite_lock_error(error):
                    # The conditional update is the first DB statement in each
                    # transaction, avoiding stale SQLite read snapshots. If an
                    # unusually long writer still exhausts the retry budget,
                    # return the domain conflict rather than leaking a lock 500.
                    replay = _existing_reservation_result(user, instance_id, key)
                    if replay:
                        return replay
                    return 409, {'error': 'unavailable'}
                raise
            # A fresh transaction is required after SQLite rejects a read-to-write
            # lock upgrade. Bounded backoff lets the winning writer commit first.
            time.sleep(0.01 * (2 ** attempt))


def _reservation_key(request, *, web=False):
    key = request.POST.get('idempotency_key') if web else request.headers.get('Idempotency-Key')
    if key is None:
        return None
    key = key.strip()
    return key if key and len(key) <= 100 else None


@require_POST
def reserve_bookinstance_api(request, pk):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'unauthorized'}, status=401)
    key = _reservation_key(request)
    if key is None:
        return JsonResponse({'error': 'invalid_key'}, status=400)
    status, payload = _reserve_copy(request.user, pk, key)
    return JsonResponse(payload, status=status)


@login_required
@require_POST
def reserve_bookinstance_web(request, instance_pk):
    instance = get_object_or_404(BookInstance, pk=instance_pk)
    key = _reservation_key(request, web=True)
    if key is None:
        messages.error(request, 'No se pudo reservar: la clave de idempotencia no es válida.')
    else:
        status, payload = _reserve_copy(request.user, instance.pk, key)
        if status == 201:
            messages.success(request, 'Reserva confirmada.')
        elif payload.get('error') == 'idempotency_conflict':
            messages.error(request, 'Esta clave ya se utilizó para otro ejemplar.')
        else:
            messages.error(request, 'El ejemplar ya no está disponible.')
    return HttpResponseRedirect(reverse('book-detail', kwargs={'pk': instance.book_id}))


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed'))

    # If this is a GET (or any other method) create the default form
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import RestrictedError
from django.contrib.auth.mixins import PermissionRequiredMixin
from .models import Author


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'

class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    # Not recommended (potential security issue if more fields added)
    fields = '__all__'
    permission_required = 'catalog.change_author'

class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("author-delete", kwargs={"pk": self.object.pk})
            )

# Classes created for the forms challenge


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("book-delete", kwargs={"pk": self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    # fields = "__all__"
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'
