import threading
import json
from concurrent.futures import ThreadPoolExecutor

from django.contrib.auth import get_user_model
from django.db import close_old_connections
from django.test import RequestFactory, TestCase, TransactionTestCase
from django.urls import reverse

from catalog.models import Author, Book, BookInstance, Reservation


class ReservationFixtureMixin:
    @classmethod
    def setUpTestData(cls):
        cls.user1 = get_user_model().objects.create_user(username='reserve-one', password='test-pass')
        cls.user2 = get_user_model().objects.create_user(username='reserve-two', password='test-pass')
        author = Author.objects.create(first_name='Test', last_name='Author')
        book = Book.objects.create(
            title='Reservation book', summary='Summary', isbn='1234567890123', author=author,
        )
        cls.instance = BookInstance.objects.create(
            book=book, imprint='Test imprint', status=BookInstance.LoanStatus.AVAILABLE,
        )
        cls.book = book

    def api_url(self, instance=None):
        instance_pk = instance.pk if isinstance(instance, BookInstance) else instance
        return reverse('api-reserve-bookinstance', kwargs={'pk': instance_pk or self.instance.pk})


class ReservationApiTests(ReservationFixtureMixin, TestCase):
    def test_authentication_and_method_contract(self):
        url = self.api_url()
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='request-one')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 405)
        self.client.force_login(self.user1)
        response = self.client.get(url)
        self.assertEqual(response.status_code, 405)

    def test_key_validation_and_missing_instance_do_not_mutate(self):
        self.client.force_login(self.user1)
        for key in ('', '   ', 'x' * 101):
            response = self.client.post(self.api_url(), HTTP_IDEMPOTENCY_KEY=key)
            self.assertEqual(response.status_code, 400)
            self.assertEqual(response.json(), {'error': 'invalid_key'})
        response = self.client.post(self.api_url(), data={})
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})
        import uuid
        response = self.client.post(self.api_url(uuid.uuid4()), HTTP_IDEMPOTENCY_KEY='missing')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertFalse(Reservation.objects.exists())

    def test_reservation_replay_and_key_conflict_persist(self):
        self.client.force_login(self.user1)
        response = self.client.post(self.api_url(), HTTP_IDEMPOTENCY_KEY='  stable-key  ')
        expected = {
            'instance_id': str(self.instance.pk), 'user_id': self.user1.pk, 'status': 'r',
        }
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), expected)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user1.pk)
        self.assertEqual(Reservation.objects.filter(user=self.user1).count(), 1)

        # A separate HTTP client/session replays the persisted request.
        replay_client = self.client_class()
        replay_client.force_login(self.user1)
        replay = replay_client.post(self.api_url(), HTTP_IDEMPOTENCY_KEY='stable-key')
        self.assertEqual(replay.status_code, 201)
        self.assertEqual(replay.json(), expected)
        self.assertEqual(Reservation.objects.filter(user=self.user1).count(), 1)

        other = BookInstance.objects.create(
            book=self.book, imprint='Another', status=BookInstance.LoanStatus.AVAILABLE,
        )
        conflict = self.client.post(self.api_url(other), HTTP_IDEMPOTENCY_KEY='stable-key')
        self.assertEqual(conflict.status_code, 409)
        self.assertEqual(conflict.json(), {'error': 'idempotency_conflict'})
        other.refresh_from_db()
        self.assertEqual(other.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(Reservation.objects.filter(user=self.user1).count(), 1)

    def test_different_users_have_independent_keys(self):
        self.client.force_login(self.user1)
        self.client.post(self.api_url(), HTTP_IDEMPOTENCY_KEY='same-key')
        other_instance = BookInstance.objects.create(
            book=self.book, imprint='Another', status=BookInstance.LoanStatus.AVAILABLE,
        )
        other_client = self.client_class()
        other_client.force_login(self.user2)
        response = other_client.post(self.api_url(other_instance), HTTP_IDEMPOTENCY_KEY='same-key')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(Reservation.objects.filter(key='same-key').count(), 2)

    def test_unavailable_copy_is_not_reserved_again(self):
        self.client.force_login(self.user1)
        self.client.post(self.api_url(), HTTP_IDEMPOTENCY_KEY='first')
        response = self.client.post(self.api_url(), HTTP_IDEMPOTENCY_KEY='second')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        self.assertEqual(Reservation.objects.count(), 1)


class ReservationWebTests(ReservationFixtureMixin, TestCase):
    def test_book_detail_shows_csrf_form_with_key_for_available_copy(self):
        response = self.client.get(reverse('book-detail', kwargs={'pk': self.book.pk}))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, reverse('reserve-bookinstance', kwargs={'instance_pk': self.instance.pk}))
        self.assertContains(response, 'name="csrfmiddlewaretoken"')
        self.assertContains(response, 'name="idempotency_key"')

    def test_web_post_requires_login_and_confirms_success(self):
        url = reverse('reserve-bookinstance', kwargs={'instance_pk': self.instance.pk})
        response = self.client.post(url, {'idempotency_key': 'web-key'})
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/'))
        self.client.force_login(self.user1)
        response = self.client.post(url, {'idempotency_key': 'web-key'})
        self.assertRedirects(response, reverse('book-detail', kwargs={'pk': self.book.pk}))
        self.assertEqual(list(response.wsgi_request._messages)[0].message, 'Reserva confirmada.')


class ReservationConcurrencyTests(ReservationFixtureMixin, TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        self.user1 = get_user_model().objects.create_user(username='race-one', password='test-pass')
        self.user2 = get_user_model().objects.create_user(username='race-two', password='test-pass')
        author = Author.objects.create(first_name='Race', last_name='Author')
        self.book = Book.objects.create(
            title='Race book', summary='Summary', isbn='1234567890123', author=author,
        )
        self.instance = BookInstance.objects.create(
            book=self.book, imprint='Test imprint', status=BookInstance.LoanStatus.AVAILABLE,
        )

    def test_two_users_racing_for_one_copy_get_one_success_and_one_conflict(self):
        url = self.api_url()
        barrier = threading.Barrier(2)

        def reserve(user_id, key):
            close_old_connections()
            try:
                user = get_user_model().objects.get(pk=user_id)
                barrier.wait(timeout=5)
                from catalog.views import reserve_bookinstance_api
                request = RequestFactory().post(url, HTTP_IDEMPOTENCY_KEY=key)
                request.user = user
                response = reserve_bookinstance_api(request, self.instance.pk)
                return response.status_code, json.loads(response.content)
            finally:
                close_old_connections()

        with ThreadPoolExecutor(max_workers=2) as executor:
            results = list(executor.map(
                lambda args: reserve(*args),
                [(self.user1.pk, 'race-one'), (self.user2.pk, 'race-two')],
            ))

        self.assertEqual(sorted(status for status, _ in results), [201, 409])
        self.assertEqual(sum(payload == {'error': 'unavailable'} for _, payload in results), 1)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(Reservation.objects.count(), 1)
