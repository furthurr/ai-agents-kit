import json
import threading
from concurrent.futures import ThreadPoolExecutor
from uuid import uuid4

from django.contrib.auth import get_user_model
from django.test import Client, RequestFactory, TestCase, TransactionTestCase
from django.urls import reverse

from catalog.models import Author, Book, BookInstance, Reservation


class ReservationApiTest(TestCase):
    def setUp(self):
        User = get_user_model()
        self.user = User.objects.create_user(username='reserve-user', password='pw')
        self.other_user = User.objects.create_user(username='reserve-other', password='pw')
        author = Author.objects.create(first_name='A', last_name='Author')
        book = Book.objects.create(title='Reservation book', summary='Summary',
                                   isbn='reserve-isbn', author=author)
        self.instance = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.AVAILABLE)
        self.url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance.pk})

    def post(self, client=None, key='key-1', url=None):
        return (client or self.client).post(
            url or self.url, HTTP_IDEMPOTENCY_KEY=key)

    def test_authentication_and_method_contract(self):
        response = self.post()
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

        self.client.force_login(self.user)
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 405)

    def test_invalid_key_and_missing_instance_do_not_mutate(self):
        self.client.force_login(self.user)
        for key in ('', ' ' , 'x' * 101):
            response = self.post(key=key)
            self.assertEqual(response.status_code, 400)
            self.assertEqual(response.json(), {'error': 'invalid_key'})
        missing_url = reverse('api-reserve-bookinstance', kwargs={'pk': uuid4()})
        response = self.post(url=missing_url)
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_success_replay_conflict_and_unavailable(self):
        self.client.force_login(self.user)
        response = self.post()
        self.assertEqual(response.status_code, 201)
        payload = {'instance_id': str(self.instance.pk), 'user_id': self.user.id, 'status': 'r'}
        self.assertEqual(response.json(), payload)

        # A new client/session can replay the durable idempotency record.
        replay_client = Client()
        replay_client.force_login(self.user)
        response = self.post(client=replay_client)
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), payload)
        self.assertEqual(Reservation.objects.count(), 1)

        other_instance = BookInstance.objects.create(
            book=self.instance.book, imprint='Second', status=BookInstance.LoanStatus.AVAILABLE)
        other_url = reverse('api-reserve-bookinstance', kwargs={'pk': other_instance.pk})
        response = self.post(url=other_url)
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'idempotency_conflict'})

        self.client.force_login(self.other_user)
        response = self.post(key='other-user-key')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower, self.user)
        self.assertEqual(Reservation.objects.count(), 1)

    def test_book_detail_shows_csrf_reservation_form_for_available_copies(self):
        response = self.client.get(self.instance.book.get_absolute_url())
        self.assertContains(response, 'name="idempotency_key"')
        self.assertContains(response, reverse('reserve-bookinstance', kwargs={'pk': self.instance.pk}))
        self.assertContains(response, 'csrfmiddlewaretoken')

    def test_web_reservation_requires_login_and_displays_confirmation(self):
        url = reverse('reserve-bookinstance', kwargs={'pk': self.instance.pk})
        response = self.client.post(url, {'idempotency_key': 'web-key'})
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/'))

        self.client.force_login(self.user)
        response = self.client.post(url, {'idempotency_key': 'web-key'})
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, self.instance.book.get_absolute_url() + '?reserved=1')
        response = self.client.get(response.url)
        self.assertContains(response, 'La copia se ha reservado correctamente.')


class ReservationConcurrencyTest(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        User = get_user_model()
        self.users = [
            User.objects.create_user(username=f'concurrent-{i}', password='pw')
            for i in range(2)
        ]
        author = Author.objects.create(first_name='A', last_name='Author')
        book = Book.objects.create(title='Concurrent book', summary='Summary',
                                   isbn='concurrent-isbn', author=author)
        self.instance = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.AVAILABLE)
        self.url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance.pk})

    def test_only_one_concurrent_request_reserves_the_copy(self):
        barrier = threading.Barrier(2)

        def reserve(user):
            from django.db import close_old_connections
            from catalog.views import reserve_bookinstance_api
            close_old_connections()
            request = RequestFactory().post(
                self.url, HTTP_IDEMPOTENCY_KEY=f'key-{user.pk}')
            request.user = user
            barrier.wait()
            response = reserve_bookinstance_api(request, self.instance.pk)
            result = (response.status_code, json.loads(response.content))
            close_old_connections()
            return result

        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(reserve, self.users))

        statuses = sorted(status for status, _ in results)
        self.assertEqual(statuses, [201, 409])
        conflict = next(payload for status, payload in results if status == 409)
        self.assertEqual(conflict, {'error': 'unavailable'})
        self.assertEqual(Reservation.objects.count(), 1)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
