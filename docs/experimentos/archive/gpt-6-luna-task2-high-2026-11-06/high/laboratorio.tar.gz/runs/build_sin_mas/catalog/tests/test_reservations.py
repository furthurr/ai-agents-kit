import uuid

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from catalog.models import Author, Book, BookInstance, Reservation


class ReservationApiTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            username='reservation-user', password='test-password'
        )
        cls.other_user = get_user_model().objects.create_user(
            username='other-reservation-user', password='test-password'
        )
        author = Author.objects.create(first_name='Test', last_name='Author')
        book = Book.objects.create(
            title='Reservation book', author=author, summary='A summary', isbn='1234567890123'
        )
        cls.instance = BookInstance.objects.create(
            book=book, imprint='Test imprint', status=BookInstance.LoanStatus.AVAILABLE
        )
        cls.other_instance = BookInstance.objects.create(
            book=book, imprint='Test imprint', status=BookInstance.LoanStatus.AVAILABLE
        )

    def api_url(self, instance=None):
        return reverse('api-reserve-bookinstance', kwargs={'pk': instance or self.instance.pk})

    def post_reservation(self, key='reservation-key', instance=None, user=None):
        if user:
            self.client.force_login(user)
        return self.client.post(
            self.api_url(instance), **{'HTTP_IDEMPOTENCY_KEY': key}
        )

    def test_requires_authentication_and_valid_key(self):
        response = self.client.post(self.api_url(), **{'HTTP_IDEMPOTENCY_KEY': 'key'})
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

        self.client.force_login(self.user)
        for key in ('', '   ', 'x' * 101):
            with self.subTest(key_length=len(key)):
                response = self.post_reservation(key=key)
                self.assertEqual(response.status_code, 400)
                self.assertEqual(response.json(), {'error': 'invalid_key'})
        self.assertEqual(Reservation.objects.count(), 0)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_reserves_and_replays_idempotently(self):
        first = self.post_reservation(user=self.user)
        self.assertEqual(first.status_code, 201)
        self.assertEqual(first.json(), {
            'instance_id': str(self.instance.pk), 'user_id': self.user.pk, 'status': 'r'
        })

        replay = self.post_reservation(user=self.user)
        self.assertEqual(replay.status_code, 201)
        self.assertEqual(replay.json(), first.json())
        self.assertEqual(Reservation.objects.count(), 1)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower, self.user)

    def test_key_reuse_for_another_instance_conflicts(self):
        self.assertEqual(self.post_reservation(user=self.user).status_code, 201)
        response = self.post_reservation(instance=self.other_instance.pk, user=self.user)
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'idempotency_conflict'})
        self.assertEqual(Reservation.objects.count(), 1)
        self.other_instance.refresh_from_db()
        self.assertEqual(self.other_instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_unavailable_missing_and_wrong_method_responses(self):
        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.save(update_fields=['status'])
        response = self.post_reservation(user=self.user)
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})

        missing_url = self.api_url(uuid.uuid4())
        response = self.client.post(missing_url, **{'HTTP_IDEMPOTENCY_KEY': 'another-key'})
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})
        self.assertEqual(self.client.get(self.api_url()).status_code, 405)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_web_form_has_csrf_and_idempotency_key_and_confirms(self):
        detail_url = reverse('book-detail', kwargs={'pk': self.instance.book_id})
        self.client.force_login(self.user)
        page = self.client.get(detail_url)
        self.assertContains(page, 'name="csrfmiddlewaretoken"')
        self.assertContains(page, 'name="idempotency_key"')

        response = self.client.post(reverse(
            'reserve-bookinstance', kwargs={'pk': self.instance.pk}
        ), {'idempotency_key': 'web-key', 'next': detail_url})
        self.assertRedirects(response, detail_url)
        self.assertContains(self.client.get(detail_url), 'El ejemplar se reservó correctamente.')

    def test_web_form_redirects_anonymous_user_to_login(self):
        response = self.client.post(reverse(
            'reserve-bookinstance', kwargs={'pk': self.instance.pk}
        ), {'idempotency_key': 'web-key'})
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/'))
