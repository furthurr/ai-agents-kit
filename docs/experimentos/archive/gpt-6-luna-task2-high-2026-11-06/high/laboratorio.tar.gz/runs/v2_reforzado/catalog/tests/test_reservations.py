import threading
import uuid
from concurrent.futures import ThreadPoolExecutor

from django.contrib.auth import get_user_model
from django.db import close_old_connections, connections
from django.test import Client, TestCase, TransactionTestCase
from django.urls import reverse

from catalog.models import Author, Book, BookInstance, Reservation


class ReservationApiTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        User = get_user_model()
        cls.user = User.objects.create_user(username='reserve-user', password='pw')
        cls.other_user = User.objects.create_user(username='other-user', password='pw')
        author = Author.objects.create(first_name='A', last_name='Author')
        book = Book.objects.create(
            title='Reservation book', summary='Summary', isbn='1234567890123', author=author
        )
        cls.available = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.AVAILABLE
        )
        cls.other_available = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.AVAILABLE
        )

    def api_url(self, instance=None):
        return reverse('api-reserve-bookinstance', kwargs={
            'pk': instance.pk if instance else uuid.uuid4(),
        })

    def post_reservation(self, instance=None, key='key-1', client=None):
        client = client or self.client
        return client.post(
            self.api_url(instance),
            **({'HTTP_IDEMPOTENCY_KEY': key} if key is not None else {}),
        )

    def test_authentication_validation_and_method_contract(self):
        url = self.api_url(self.available)
        self.assertEqual(self.client.post(url, HTTP_IDEMPOTENCY_KEY='key').status_code, 401)
        self.assertEqual(self.client.get(url).status_code, 405)
        self.client.force_login(self.user)

        for key in (None, '', '  \t ', 'x' * 101):
            response = self.post_reservation(self.available, key)
            self.assertEqual((response.status_code, response.json()), (400, {'error': 'invalid_key'}))
        self.assertEqual(self.available.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_reserves_and_replays_after_database_connection_is_reopened(self):
        self.client.force_login(self.user)
        response = self.post_reservation(self.available, '  durable-key  ')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), {
            'instance_id': str(self.available.pk),
            'user_id': self.user.pk,
            'status': 'r',
        })
        connections['default'].close()
        replay = self.post_reservation(self.available, 'durable-key')
        self.assertEqual(replay.status_code, 201)
        self.assertEqual(replay.json(), response.json())
        self.assertEqual(Reservation.objects.filter(user=self.user, key='durable-key').count(), 1)
        self.available.refresh_from_db()
        self.assertEqual(self.available.borrower, self.user)

    def test_reused_key_for_another_instance_conflicts_without_mutation(self):
        self.client.force_login(self.user)
        self.assertEqual(self.post_reservation(self.available, 'same').status_code, 201)
        response = self.post_reservation(self.other_available, 'same')
        self.assertEqual((response.status_code, response.json()), (409, {'error': 'idempotency_conflict'}))
        self.other_available.refresh_from_db()
        self.assertEqual(self.other_available.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(Reservation.objects.count(), 1)

    def test_unavailable_and_not_found_do_not_create_reservations(self):
        self.client.force_login(self.user)
        self.available.status = BookInstance.LoanStatus.ON_LOAN
        self.available.save(update_fields=['status'])
        response = self.post_reservation(self.available, 'unavailable-key')
        self.assertEqual((response.status_code, response.json()), (409, {'error': 'unavailable'}))
        response = self.post_reservation(None, 'missing-key')
        self.assertEqual((response.status_code, response.json()), (404, {'error': 'not_found'}))
        self.assertEqual(Reservation.objects.count(), 0)

    def test_same_key_is_independent_between_users(self):
        self.client.force_login(self.user)
        self.assertEqual(self.post_reservation(self.available, 'shared').status_code, 201)
        other_client = Client()
        other_client.force_login(self.other_user)
        response = self.post_reservation(self.other_available, 'shared', other_client)
        self.assertEqual(response.status_code, 201)
        self.assertEqual(Reservation.objects.filter(key='shared').count(), 2)


class ReservationWebFlowTest(TestCase):
    def setUp(self):
        User = get_user_model()
        self.user = User.objects.create_user(username='web-user', password='pw')
        author = Author.objects.create(first_name='A', last_name='Author')
        self.book = Book.objects.create(
            title='Web book', summary='Summary', isbn='1234567890124', author=author
        )
        self.instance = BookInstance.objects.create(
            book=self.book, imprint='Test', status=BookInstance.LoanStatus.AVAILABLE
        )

    def test_book_detail_has_csrf_reservation_form_and_success_message(self):
        detail_url = reverse('book-detail', kwargs={'pk': self.book.pk})
        response = self.client.get(detail_url)
        self.assertContains(response, reverse('reserve-bookinstance', kwargs={'pk': self.instance.pk}))
        self.assertContains(response, 'name="csrfmiddlewaretoken"')
        self.assertContains(response, 'name="idempotency_key"')

        reserve_url = reverse('reserve-bookinstance', kwargs={'pk': self.instance.pk})
        response = self.client.post(reserve_url, {'idempotency_key': 'web-key'})
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/'))

        self.client.force_login(self.user)
        response = self.client.post(reserve_url, {'idempotency_key': 'web-key'}, follow=True)
        self.assertEqual(response.redirect_chain, [(detail_url, 302)])
        self.assertContains(response, 'Reservation confirmed.')


class ReservationConcurrencyTest(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        User = get_user_model()
        self.users = [
            User.objects.create_user(username=f'concurrent-{index}', password='pw')
            for index in range(2)
        ]
        author = Author.objects.create(first_name='A', last_name='Author')
        book = Book.objects.create(
            title='Concurrent book', summary='Summary', isbn='1234567890125', author=author
        )
        self.instance = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.AVAILABLE
        )

    def test_only_one_of_two_concurrent_users_can_reserve(self):
        start = threading.Barrier(2)
        url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance.pk})

        def reserve(user):
            close_old_connections()
            client = Client()
            client.force_login(user)
            start.wait(timeout=5)
            response = client.post(url, HTTP_IDEMPOTENCY_KEY=f'key-{user.pk}')
            result = (response.status_code, response.json())
            connections['default'].close()
            return result

        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(reserve, self.users))

        self.assertEqual(sorted(status for status, _ in results), [201, 409])
        conflict = next(payload for status, payload in results if status == 409)
        self.assertEqual(conflict, {'error': 'unavailable'})
        self.assertEqual(Reservation.objects.count(), 1)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
