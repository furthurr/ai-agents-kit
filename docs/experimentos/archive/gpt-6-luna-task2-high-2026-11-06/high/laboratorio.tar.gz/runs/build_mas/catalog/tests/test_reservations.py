import threading
import json
from concurrent.futures import ThreadPoolExecutor

from django.contrib.auth import get_user_model
from django.db import connections
from django.test import RequestFactory, TestCase, TransactionTestCase
from django.urls import reverse

from catalog.models import Author, Book, BookInstance, Reservation


class ReservationAPITest(TestCase):
    def setUp(self):
        User = get_user_model()
        self.user = User.objects.create_user(username='reserve-user', password='test-password')
        self.other_user = User.objects.create_user(username='other-user', password='test-password')
        author = Author.objects.create(first_name='A', last_name='Writer')
        book = Book.objects.create(title='A book', summary='Summary', isbn='1234567890123', author=author)
        self.instance = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.AVAILABLE,
        )
        self.url = reverse('reserve-bookinstance-api', kwargs={'pk': self.instance.pk})

    def test_requires_authentication_and_post(self):
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

        self.client.force_login(self.user)
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 405)

    def test_rejects_missing_empty_and_long_keys_without_mutation(self):
        self.client.force_login(self.user)
        for key in ('', '   ', 'x' * 101):
            response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY=key)
            self.assertEqual(response.status_code, 400)
            self.assertEqual(response.json(), {'error': 'invalid_key'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_reservation_replay_and_key_conflict(self):
        self.client.force_login(self.user)
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='  retry-me  ')
        expected = {
            'instance_id': str(self.instance.pk),
            'user_id': self.user.pk,
            'status': 'r',
        }
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), expected)
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='retry-me')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), expected)
        self.assertEqual(Reservation.objects.filter(user=self.user, key='retry-me').count(), 1)

        other_instance = BookInstance.objects.create(
            book=self.instance.book, imprint='Another', status=BookInstance.LoanStatus.AVAILABLE,
        )
        response = self.client.post(
            reverse('reserve-bookinstance-api', kwargs={'pk': other_instance.pk}),
            HTTP_IDEMPOTENCY_KEY='retry-me',
        )
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'idempotency_conflict'})
        other_instance.refresh_from_db()
        self.assertEqual(other_instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_unavailable_and_not_found(self):
        self.client.force_login(self.user)
        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.save()
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='not-available')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        self.assertEqual(Reservation.objects.count(), 0)

        response = self.client.post(
            reverse('reserve-bookinstance-api', kwargs={'pk': '00000000-0000-0000-0000-000000000000'}),
            HTTP_IDEMPOTENCY_KEY='missing',
        )
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_book_detail_has_csrf_reservation_form(self):
        response = self.client.get(reverse('book-detail', kwargs={'pk': self.instance.book_id}))
        self.assertContains(response, reverse('reserve-bookinstance', kwargs={'pk': self.instance.pk}))
        self.assertContains(response, 'name="csrfmiddlewaretoken"')
        self.assertContains(response, 'name="idempotency_key"')

        self.client.force_login(self.user)
        response = self.client.post(
            reverse('reserve-bookinstance', kwargs={'pk': self.instance.pk}),
            {'idempotency_key': 'browser-key'},
        )
        self.assertRedirects(response, reverse('book-detail', kwargs={'pk': self.instance.book_id}) + '?reserved=1')
        follow = self.client.get(response.url)
        self.assertContains(follow, 'Copy reserved successfully.')


class ReservationConcurrencyTest(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        User = get_user_model()
        self.users = [
            User.objects.create_user(username='concurrent-a', password='test-password'),
            User.objects.create_user(username='concurrent-b', password='test-password'),
        ]
        author = Author.objects.create(first_name='A', last_name='Writer')
        book = Book.objects.create(title='A book', summary='Summary', isbn='2234567890123', author=author)
        self.instance = BookInstance.objects.create(
            book=book, imprint='Test', status=BookInstance.LoanStatus.AVAILABLE,
        )

    def test_only_one_concurrent_user_can_reserve_copy(self):
        url = reverse('reserve-bookinstance-api', kwargs={'pk': self.instance.pk})
        barrier = threading.Barrier(2)

        def reserve(user):
            connections.close_all()
            request = RequestFactory().post(url, HTTP_IDEMPOTENCY_KEY='concurrent-key')
            request.user = user
            barrier.wait(timeout=5)
            try:
                from catalog.views import reserve_bookinstance_api
                response = reserve_bookinstance_api(request, self.instance.pk)
                return response.status_code, json.loads(response.content)
            finally:
                connections.close_all()

        with ThreadPoolExecutor(max_workers=2) as executor:
            results = list(executor.map(reserve, self.users))

        self.assertEqual(sorted(status for status, _ in results), [201, 409])
        conflict = next(payload for status, payload in results if status == 409)
        self.assertEqual(conflict, {'error': 'unavailable'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)
