#!/usr/bin/env python3
"""GPT-6 Luna/Copilot TASK-2 Alta replication; five profiles plus separate SDD."""
import argparse
import json

import six_agent_deepseek_direct as direct
import six_agent_deepseek_fixed as low

MODEL = 'github-copilot/gpt-6-luna'
PACKAGE = direct.REPO / 'docs/experimentos/gpt-6-luna-task2-high-2026-11-06'
ROOT = low.ROOT.parent / 'gpt-6-luna-task2-high-20261106-v1'


def parse_catalog(text):
    marker = MODEL + '\n'
    assert marker in text, 'Exact GPT-6 Luna model absent'
    item, _ = json.JSONDecoder().raw_decode(text.split(marker, 1)[1].lstrip())
    assert (item['providerID'], item['id']) == ('github-copilot', 'gpt-6-luna')
    assert item['capabilities']['toolcall']
    assert item['capabilities']['temperature'] is False
    return {k: item[k] for k in ('id', 'providerID', 'name', 'api', 'limit', 'capabilities', 'variants')}


def engine():
    # Private instance: the frozen low cohort and MAI module remain untouched.
    kernel = direct.module_at('luna6_high_private', direct.REPO / 'tools/mai_flash_benchmark.py')
    kernel.MODEL, kernel.PACKAGE, kernel.ROOT = MODEL, PACKAGE, ROOT
    kernel.COHORTS = {k: v for k, v in kernel.COHORTS.items() if k in ('high', 'sdd-high')}
    kernel.SOURCES += ('luna6_task2_high.py', 'test_luna6_task2_high.py',
                       'luna6_task2_high_report.py', 'mai_flash_report.py')
    kernel.parse_catalog = parse_catalog
    previous = kernel.summarize

    def summarize(cohort):
        summary = previous(cohort)
        base, root, _ = kernel.context(cohort)
        for row in summary['rows']:
            arm = row['arm']
            path = root / 'records' / (arm + '.json')
            if not path.exists():
                continue
            record = kernel.load(path)
            row['acceptance'] = record['complete_acceptance']
            row['functional_pass'] = record['functional_pass']
            row['test_delivery'] = record['test_delivery']
            row['primary_acceptance'] = record['primary_acceptance']
            row['extended_contract_pass'] = record['extended_contract_pass']
            row['oracle9_pass'] = record['oracle9']['passed'] and record['oracle9']['tests'] == 9
            row['edges5_pass'] = record['edges5']['passed'] and record['edges5']['tests'] == 5
            row['migration_check_pass'] = record['migration_check']['passed']
            row['new_test_methods'] = kernel.load(root / 'audits' / (arm + '.json'))['new_test_methods']
            if 'Maximum steps reached' in row.get('final_text', ''):
                row['status'] = 'step_limit_incomplete'
            elif arm == 'sdd_trial' and not record['changed']:
                row['status'] = 'awaiting_operator_review'
        return summary

    kernel.summarize = summarize
    # Own preflight: the historical engine hard-codes the MAI model identifier.
    kernel.offline = lambda cohort: offline(kernel, cohort)
    return kernel


def offline(kernel, cohort):
    base, root, source = kernel.context(cohort)
    assert not (root / 'offline.json').exists()
    records = {'real_model_calls': 0, 'profiles': {}}
    for arm in base.ARMS:
        assert base.hashes(root / 'profiles' / arm) == base.hashes(source / 'profiles' / arm)
        agent = base.command(root, arm, ['opencode', 'debug', 'agent', base.agent_name(arm), '--pure'])
        assert agent.returncode == 0
        resolved = json.loads(agent.stdout)
        configured = base.configuration(root, arm)['agent'][base.agent_name(arm)]
        assert resolved['model'] == {'providerID': 'github-copilot', 'modelID': 'gpt-6-luna'}
        assert 'temperature' not in configured and 'variant' not in configured
        if 'prompt' in configured:
            assert resolved['prompt'] == configured['prompt']
        else:
            assert resolved.get('native') and not resolved.get('prompt')
        catalog = base.command(root, arm, ['opencode', 'models', 'github-copilot', '--verbose', '--pure'])
        assert catalog.returncode == 0
        provider = parse_catalog(catalog.stdout)
        skills = base.command(root, arm, ['opencode', 'debug', 'skill', '--pure'])
        assert skills.returncode == 0
        available = json.loads(skills.stdout)
        external = [s for s in available if s['location'] != '<built-in>']
        expected = sorted(p.parent.name for p in (root / 'profiles' / arm / 'skills').glob('*/SKILL.md'))
        assert sorted(s['name'] for s in external) == expected
        # Scripted localhost probe: exercises the real tool pipeline without a model.
        proof = kernel.runtime.probe(base, root / 'runtime-probes', arm)
        records['profiles'][arm] = {'provider': provider, 'skills': [s['name'] for s in available], 'probe': proof}
        assert base.hashes(root / 'runs' / arm) == kernel.load(root / 'initial' / (arm + '.json'))
    records['baseline43'] = kernel.evaluate(base, root, cohort, 'pre-original43', root / 'baseline', True)
    records['reference52'] = kernel.evaluate(base, root, cohort, 'pre-reference', root / 'reference')
    assert records['baseline43']['passed'] and records['baseline43']['tests'] == 43
    assert records['reference52']['passed'] and records['reference52']['tests'] == 52
    base.write_json(root / 'offline.json', records, exclusive=True)
    base.write_json(root / 'freeze.json', {'created': base.stamp(), 'files': kernel.frozen_inputs(base, root)}, exclusive=True)
    print(json.dumps({'offline_passed': cohort, 'real_model_calls': 0, 'model': MODEL}), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['prepare', 'offline', 'check', 'run', 'report', 'export'])
    parser.add_argument('cohort', choices=['high', 'sdd-high', 'all'])
    args = parser.parse_args()
    kernel = engine()
    for cohort in kernel.COHORTS if args.cohort == 'all' else (args.cohort,):
        if args.command == 'check':
            base, root, _ = kernel.context(cohort)
            base.check_frozen(root)
        elif args.command == 'report':
            print(json.dumps(kernel.summarize(cohort), ensure_ascii=False, indent=2))
        else:
            getattr(kernel, args.command)(cohort)
    if args.command == 'run' and args.cohort == 'all':
        import luna6_task2_high_report
        luna6_task2_high_report.generate(kernel)


if __name__ == '__main__':
    main()
