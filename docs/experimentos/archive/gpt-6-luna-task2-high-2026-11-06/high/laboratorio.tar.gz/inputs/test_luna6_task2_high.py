import copy
import json
import unittest

import luna6_task2_high as lab
import mai_flash_benchmark as mai


class LunaHighTests(unittest.TestCase):
    def test_isolated_from_low_and_mai(self):
        kernel = lab.engine()
        self.assertEqual(mai.MODEL, 'github-copilot/mai-code-1.1-flash')
        self.assertEqual(kernel.MODEL, lab.MODEL)
        self.assertEqual(list(kernel.COHORTS), ['high', 'sdd-high'])
        self.assertEqual(sum(len(v[1]) for v in kernel.COHORTS.values()), 6)

    def test_high_only_changes_model_paths_and_temperature(self):
        kernel = lab.engine()
        for cohort in kernel.COHORTS:
            base, root, source = kernel.context(cohort)
            for arm in base.ARMS:
                old = kernel.load(source / 'configs' / (arm + '.json'))
                saved = copy.deepcopy(old)
                text = json.dumps(old).replace(str(source), str(root))
                expected = json.loads(text.replace(str(source).lstrip('/'), str(root).lstrip('/')))
                expected.pop('provider', None)
                expected['enabled_providers'] = ['github-copilot']
                for agent in expected['agent'].values():
                    agent['model'] = lab.MODEL
                    agent.pop('temperature', None)
                self.assertEqual(base.configuration(root, arm), expected)
                self.assertEqual(old, saved)
                self.assertEqual((base.TIMEOUT, base.STEP_LIMIT, base.TOKEN_LIMIT), (1800, 60, 5000000))

    def test_requires_exact_model(self):
        with self.assertRaises(AssertionError):
            lab.parse_catalog('github-copilot/gpt-6-sol\n{}')

    def test_low_is_not_in_this_adapter(self):
        with self.assertRaises(KeyError):
            lab.engine().context('low')


if __name__ == '__main__':
    unittest.main()
