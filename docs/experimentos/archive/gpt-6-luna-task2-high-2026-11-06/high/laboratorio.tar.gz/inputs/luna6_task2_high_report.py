#!/usr/bin/env python3
"""Offline table, archive verification and manual-gate review for Luna TASK-2."""
import json

import luna6_task2_high as lab
from mai_flash_report import NAMES, number, stats, verify_archive


def outcome(row, record):
    if 'Maximum steps reached' in row.get('final_text', ''):
        return 'Incompleto: 60 pasos'
    if row['acceptance']:
        return 'PASS'
    if not record['changed']:
        return 'Pausa real; sin entrega'
    missing = []
    if not record['oracle9']['passed']:
        missing.append('oráculos')
    if not record['edges5']['passed']:
        missing.append('bordes')
    if not record['test_delivery']:
        missing.append('sin tests nuevos')
    return 'No aceptado' + ((': ' + ', '.join(missing)) if missing else '')


def generate(kernel):
    destination = lab.PACKAGE / 'revision'
    assert not destination.exists(), 'Append-only revision'
    destination.mkdir(parents=True)
    rows, integrity = [], {}
    for cohort in kernel.COHORTS:
        base, root, _ = kernel.context(cohort)
        base.check_frozen(root)
        integrity[cohort] = verify_archive(base, lab.PACKAGE / cohort)
        for original in kernel.summarize(cohort)['rows']:
            row = dict(original)
            arm = row['arm']
            path = root / 'records' / (arm + '.json')
            if not path.exists():
                row['task'] = 'high'
                rows.append(row)
                continue
            record = kernel.load(path)
            row['task'] = 'high'
            row['joint_reviewed'] = stats(record['joint'])
            row['oracle_reviewed'] = stats(record['oracle9'])
            row['edges_reviewed'] = stats(record['edges5'])
            row['reviewed_outcome'] = outcome(row, record)
            row['no_product_delivery'] = not record['changed']
            row['procedure_fidelity_certified'] = False
            rows.append(row)
        base.check_frozen(root)
    accepted = sum(r.get('acceptance') is True for r in rows)
    completed = sum(r.get('tokens') is not None for r in rows)
    totals = {'tokens': sum((r.get('tokens') or {}).get('total', 0) for r in rows),
        'seconds': round(sum(r.get('seconds') or 0 for r in rows), 3),
        'steps': sum(r.get('steps') or 0 for r in rows), 'invocations': completed}
    data = {'model': lab.MODEL, 'task': 'TASK-2 Alta', 'rows': rows, 'totals': totals,
        'accepted_deliveries': accepted, 'archive_verification': integrity,
        'post_analysis_inference_calls': 0, 'procedure_fidelity_certified': False}
    base.write_json(destination / 'resultados.json', data, exclusive=True)
    lines = ['# GPT-6 Luna / Copilot — TASK-2 Alta', '',
        f"**{completed} invocaciones iniciales, {accepted} entregas aceptadas.**", '',
        '| Configuración | Tokens | Tiempo | Pasos | Tests nuevos | Originales | Oráculos | Bordes | Conjunta | Resultado |',
        '|---|---:|---:|---:|---:|---|---|---|---|---|']
    for row in sorted(rows, key=lambda r: (r.get('tokens') or {}).get('total', float('inf'))):
        if 'joint_reviewed' not in row:
            lines.append(f"| {NAMES[row['arm']]} | — | — | — | — | — | — | — | — | No evaluado |")
            continue
        joint, oracle, edges = row['joint_reviewed'], row['oracle_reviewed'], row['edges_reviewed']
        joint_text = f"{joint['executed']}/{joint['executed']}" if joint['passed'] else (
            f"{joint['executed']} ejecutados; {joint['failure_count']} fallos, {joint['error_count']} errores")
        lines.append(f"| {NAMES[row['arm']]} | {number(row['tokens']['total'])} | {number(row['seconds'], 3)} s | "
            f"{row['steps']} | {row['new_test_methods']} | 43/43 | "
            f"{'9/9' if oracle['passed'] else 'FAIL'} | {'5/5' if edges['passed'] else 'FAIL'} | "
            f"{joint_text} | {row['reviewed_outcome']} |")
    lines += ['', '## Lectura', '',
        '- Solo TASK-2 Alta. No se reanuda el SDD de media-baja ni se interpreta esta petición como su aprobación.',
        '- Mismo contrato congelado, checkout, perfiles, oráculos y bordes; copias nuevas sin soluciones reutilizadas.',
        '- Modelo nativo `github-copilot/gpt-6-luna`, sin variante explícita. Temperatura no soportada; predeterminado del proveedor.',
        '- 1.800 s / 60 pasos / umbral 5 M por invocación. Sin reintentos, inferencias auxiliares ni aprobaciones simuladas.',
        '- Aceptación completa exige funcionalidad, oráculos, bordes, check/migraciones y pruebas nuevas persistidas.',
        '- Una pausa de gate o una aprobación pendiente no es una implementación fallida; revisar final_text.',
        '- Fidelidad procedural no certificada; n=1 y proveedor distinto impiden conclusiones causales o universales.',
        '- No se ampliaron permisos ni se corrigieron trayectorias. Evidencia anterior intacta; sin commits ni push.', '',
        f"Total observado: {number(totals['tokens'])} tokens comparables, {number(totals['seconds'], 3)} s y {totals['steps']} pasos."]
    (destination / 'RESULTADOS.md').write_text('\n'.join(lines) + '\n')
    selected = list(base.files(destination))
    for cohort in kernel.COHORTS:
        selected.extend(base.files(lab.PACKAGE / cohort / 'audits'))
    hashes = {str(p.relative_to(lab.PACKAGE)): base.sha(p) for p in selected}
    base.write_json(destination / 'manifest.json', {'files': hashes, 'original_archives': integrity}, exclusive=True)
    for relative, expected in hashes.items():
        assert base.sha(lab.PACKAGE / relative) == expected
    print('\n'.join(lines), flush=True)


if __name__ == '__main__':
    generate(lab.engine())
