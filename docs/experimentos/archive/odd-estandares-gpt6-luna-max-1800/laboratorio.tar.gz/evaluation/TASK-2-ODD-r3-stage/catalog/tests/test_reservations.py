import threading
import uuid

from django.contrib.auth import get_user_model
from django.db import close_old_connections
from django.test import Client, TestCase, TransactionTestCase
from django.urls import reverse

from catalog.models import Author, Book, BookInstance, Genre, Language, Reservation


User = get_user_model()


class ReservationViewTestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user(username='reader', password='reader-pass')
        cls.other_user = User.objects.create_user(
            username='another-reader', password='another-pass'
        )
        author = Author.objects.create(first_name='First', last_name='Author')
        genre = Genre.objects.create(name='Fiction')
        language = Language.objects.create(name='English')
        cls.book = Book.objects.create(
            title='A book',
            author=author,
            summary='A summary',
            isbn='1234567890123',
            language=language,
        )
        cls.book.genre.add(genre)
        cls.instance = BookInstance.objects.create(
            book=cls.book,
            imprint='First edition',
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        cls.other_instance = BookInstance.objects.create(
            book=cls.book,
            imprint='Second edition',
            status=BookInstance.LoanStatus.AVAILABLE,
        )

    def api_url(self, instance=None):
        return reverse(
            'api-reserve-book-instance',
            kwargs={'pk': instance or self.instance.pk},
        )

    def web_url(self, instance=None):
        return reverse(
            'reserve-book-instance',
            kwargs={'pk': instance or self.instance.pk},
        )

    def authenticated_client(self, user=None):
        client = Client()
        client.force_login(user or self.user)
        return client

    def assertUnchanged(self, instance=None):
        instance = instance or self.instance
        instance.refresh_from_db()
        self.assertEqual(instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(instance.borrower_id)
        self.assertFalse(Reservation.objects.filter(instance=instance).exists())

    def test_api_requires_authentication_and_only_accepts_post(self):
        response = self.client.post(self.api_url(), HTTP_IDEMPOTENCY_KEY='key')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

        response = self.authenticated_client().get(self.api_url())
        self.assertEqual(response.status_code, 405)
        self.assertUnchanged()

    def test_api_rejects_missing_empty_and_overlong_keys_without_mutation(self):
        client = self.authenticated_client()
        for headers in ({}, {'HTTP_IDEMPOTENCY_KEY': '  '},
                        {'HTTP_IDEMPOTENCY_KEY': 'x' * 101}):
            response = client.post(self.api_url(), **headers)
            self.assertEqual(response.status_code, 400)
            self.assertEqual(response.json(), {'error': 'invalid_key'})
            self.assertUnchanged()

    def test_api_returns_not_found_and_unavailable_without_mutation(self):
        client = self.authenticated_client()
        response = client.post(
            self.api_url(uuid.uuid4()), HTTP_IDEMPOTENCY_KEY='unknown-instance'
        )
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.save(update_fields=['status'])
        response = client.post(self.api_url(), HTTP_IDEMPOTENCY_KEY='unavailable')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        self.assertEqual(Reservation.objects.count(), 0)
        self.assertIsNone(BookInstance.objects.get(pk=self.instance.pk).borrower_id)

    def test_first_reservation_and_replay_persist_for_another_session(self):
        response = self.authenticated_client().post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY='retry-key'
        )
        expected = {
            'instance_id': str(self.instance.pk),
            'user_id': self.user.pk,
            'status': 'r',
        }
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), expected)
        self.assertEqual(Reservation.objects.filter(user=self.user).count(), 1)
        reserved = BookInstance.objects.get(pk=self.instance.pk)
        self.assertEqual(reserved.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(reserved.borrower_id, self.user.pk)

        response = self.authenticated_client().post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY='retry-key'
        )
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), expected)
        self.assertEqual(Reservation.objects.filter(user=self.user).count(), 1)

    def test_reusing_key_for_another_instance_conflicts_without_mutation(self):
        client = self.authenticated_client()
        first = client.post(self.api_url(), HTTP_IDEMPOTENCY_KEY='one-key')
        self.assertEqual(first.status_code, 201)

        response = client.post(
            self.api_url(self.other_instance.pk), HTTP_IDEMPOTENCY_KEY='one-key'
        )
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'idempotency_conflict'})
        self.assertEqual(
            BookInstance.objects.get(pk=self.other_instance.pk).status,
            BookInstance.LoanStatus.AVAILABLE,
        )
        self.assertEqual(Reservation.objects.filter(user=self.user).count(), 1)

    def test_same_key_is_independent_between_users(self):
        first = self.authenticated_client(self.user).post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY='shared-key'
        )
        second = self.authenticated_client(self.other_user).post(
            self.api_url(self.other_instance.pk), HTTP_IDEMPOTENCY_KEY='shared-key'
        )
        self.assertEqual((first.status_code, second.status_code), (201, 201))
        self.assertEqual(Reservation.objects.filter(key='shared-key').count(), 2)

    def test_book_detail_shows_csrf_protected_reservation_form(self):
        response = self.client.get(reverse('book-detail', kwargs={'pk': self.book.pk}))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'name="csrfmiddlewaretoken"')
        self.assertContains(response, 'name="idempotency_key"')
        self.assertContains(response, self.web_url())

    def test_web_reservation_requires_login_and_shows_success_message(self):
        response = self.client.post(self.web_url(), {'idempotency_key': 'web-key'})
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/'))
        self.assertUnchanged()

        response = self.authenticated_client().post(
            self.web_url(), {'idempotency_key': 'web-key'}, follow=True
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Reservation confirmed')
        self.assertEqual(Reservation.objects.filter(key='web-key').count(), 1)


class ReservationConcurrencyTestCase(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        author = Author.objects.create(first_name='First', last_name='Author')
        genre = Genre.objects.create(name='Fiction')
        language = Language.objects.create(name='English')
        book = Book.objects.create(
            title='A book', author=author, summary='A summary',
            isbn='1234567890123', language=language,
        )
        book.genre.add(genre)
        self.instance = BookInstance.objects.create(
            book=book,
            imprint='First edition',
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        self.users = [
            User.objects.create_user(username='first-reader', password='pass'),
            User.objects.create_user(username='second-reader', password='pass'),
        ]

    def test_concurrent_users_cannot_both_reserve_same_copy(self):
        from django.urls import reverse

        barrier = threading.Barrier(2)
        responses = []
        errors = []
        url = reverse('api-reserve-book-instance', kwargs={'pk': self.instance.pk})
        clients = []
        for user in self.users:
            client = Client()
            client.force_login(user)
            clients.append(client)

        def reserve(client, key):
            close_old_connections()
            try:
                barrier.wait(timeout=10)
                response = client.post(url, HTTP_IDEMPOTENCY_KEY=key)
                responses.append((response.status_code, response.json()))
            except Exception as exc:  # surfaced in the main test thread
                errors.append(exc)
            finally:
                close_old_connections()

        threads = [
            threading.Thread(target=reserve, args=(client, f'key-{index}'))
            for index, client in enumerate(clients)
        ]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=15)

        self.assertFalse(any(thread.is_alive() for thread in threads))
        self.assertEqual(errors, [])
        self.assertCountEqual([status for status, _ in responses], [201, 409])
        self.assertEqual(
            [body for status, body in responses if status == 409],
            [{'error': 'unavailable'}],
        )
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIn(self.instance.borrower_id, [user.pk for user in self.users])
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)
