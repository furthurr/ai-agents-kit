import uuid
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier

from django.contrib.auth import get_user_model
from django.db import IntegrityError, close_old_connections, connections, transaction
from django.test import Client, TestCase, TransactionTestCase

from catalog import models
from catalog.models import Author, Book, BookInstance


def reservation_api_url(instance_id):
    return f'/catalog/api/bookinstance/{instance_id}/reserve/'


def reservation_web_url(instance_id):
    return f'/catalog/book/{instance_id}/reserve/'


class ReservationDataMixin:
    def create_catalog_data(self):
        user_model = get_user_model()
        self.user = user_model.objects.create_user(username='reader')
        self.other_user = user_model.objects.create_user(username='other-reader')
        author = Author.objects.create(first_name='A', last_name='Writer')
        self.book = Book.objects.create(
            title='A Book',
            summary='A book summary',
            isbn='1234567890123',
            author=author,
        )

    def make_instance(self, status=BookInstance.LoanStatus.AVAILABLE):
        return BookInstance.objects.create(
            book=self.book,
            imprint='Library edition',
            status=status,
        )


class ReservationModelTest(ReservationDataMixin, TestCase):
    def setUp(self):
        self.create_catalog_data()

    def test_public_model_fields_and_user_scoped_unique_key(self):
        reservation_model = getattr(models, 'Reservation', None)
        self.assertIsNotNone(reservation_model)

        user_field = reservation_model._meta.get_field('user')
        self.assertEqual(user_field.remote_field.model, get_user_model())
        instance_field = reservation_model._meta.get_field('instance')
        self.assertEqual(instance_field.remote_field.model, BookInstance)
        self.assertEqual(reservation_model._meta.get_field('key').max_length, 100)
        self.assertTrue(reservation_model._meta.get_field('created_at').auto_now_add)

        first_instance = self.make_instance()
        second_instance = self.make_instance()
        reservation_model.objects.create(
            user=self.user, instance=first_instance, key='same-key')
        reservation_model.objects.create(
            user=self.other_user, instance=second_instance, key='same-key')

        with self.assertRaises(IntegrityError), transaction.atomic():
            reservation_model.objects.create(
                user=self.user, instance=second_instance, key='same-key')


class ReservationApiTest(ReservationDataMixin, TestCase):
    def setUp(self):
        self.create_catalog_data()
        self.instance = self.make_instance()
        self.url = reservation_api_url(self.instance.pk)

    def post_reservation(self, key=None, url=None, client=None):
        headers = {} if key is None else {'HTTP_IDEMPOTENCY_KEY': key}
        return (client or self.client).post(url or self.url, **headers)

    def test_requires_authentication_before_key_validation(self):
        response = self.client.post(self.url)
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(models.Reservation.objects.count(), 0)

    def test_only_accepts_post(self):
        for method in ('get', 'put', 'patch', 'delete', 'options', 'head'):
            with self.subTest(method=method):
                response = getattr(self.client, method)(self.url)
                self.assertEqual(response.status_code, 405)

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(models.Reservation.objects.count(), 0)

    def test_rejects_missing_blank_and_overlong_keys_without_mutation(self):
        self.client.force_login(self.user)
        for key in (None, '   ', 'x' * 101):
            with self.subTest(key=key):
                response = self.post_reservation(key)
                self.assertEqual(response.status_code, 400)
                self.assertEqual(response.json(), {'error': 'invalid_key'})

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(self.instance.borrower_id)
        self.assertEqual(models.Reservation.objects.count(), 0)

    def test_not_found_does_not_create_a_reservation(self):
        self.client.force_login(self.user)
        response = self.post_reservation('missing', reservation_api_url(uuid.uuid4()))
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})
        self.assertEqual(models.Reservation.objects.count(), 0)

    def test_unavailable_copy_does_not_create_a_reservation(self):
        self.client.force_login(self.user)
        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.save(update_fields=['status'])

        response = self.post_reservation('unavailable')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        self.assertEqual(models.Reservation.objects.count(), 0)

    def test_reserves_once_and_replays_after_reopening_database_connection(self):
        self.client.force_login(self.user)
        response = self.post_reservation('persistent-key')
        expected = {
            'instance_id': str(self.instance.pk),
            'user_id': self.user.pk,
            'status': 'r',
        }
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), expected)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)
        self.assertEqual(models.Reservation.objects.count(), 1)

        connections.close_all()
        fresh_client = Client()
        fresh_client.force_login(self.user)
        replay = self.post_reservation(
            'persistent-key', client=fresh_client)
        self.assertEqual(replay.status_code, 201)
        self.assertEqual(replay.json(), expected)
        self.assertEqual(models.Reservation.objects.count(), 1)

    def test_reusing_a_key_for_another_copy_conflicts_without_mutation(self):
        self.client.force_login(self.user)
        other_instance = self.make_instance()
        first = self.post_reservation('one-key')
        second = self.post_reservation(
            'one-key', reservation_api_url(other_instance.pk))

        self.assertEqual(first.status_code, 201)
        self.assertEqual(second.status_code, 409)
        self.assertEqual(second.json(), {'error': 'idempotency_conflict'})
        other_instance.refresh_from_db()
        self.assertEqual(other_instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(other_instance.borrower_id)
        self.assertEqual(models.Reservation.objects.count(), 1)

    def test_same_key_is_independent_for_another_user(self):
        other_instance = self.make_instance()
        self.client.force_login(self.user)
        first = self.post_reservation('shared-text-key')

        other_client = Client()
        other_client.force_login(self.other_user)
        second = self.post_reservation(
            'shared-text-key', reservation_api_url(other_instance.pk), other_client)

        self.assertEqual(first.status_code, 201)
        self.assertEqual(second.status_code, 201)
        self.assertEqual(models.Reservation.objects.count(), 2)


class ReservationWebTest(ReservationDataMixin, TestCase):
    def setUp(self):
        self.create_catalog_data()
        self.available_instances = [self.make_instance(), self.make_instance()]
        self.unavailable_instance = self.make_instance(BookInstance.LoanStatus.ON_LOAN)

    def test_book_detail_has_csrf_and_unique_hidden_keys_for_available_copies(self):
        response = self.client.get(f'/catalog/book/{self.book.pk}')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'csrfmiddlewaretoken')
        self.assertEqual(response.content.count(b'name="idempotency_key"'), 2)

        for instance in self.available_instances:
            self.assertContains(response, reservation_web_url(instance.pk))
        self.assertNotContains(response, reservation_web_url(self.unavailable_instance.pk))
        keys = [
            key for copy, key in response.context['reservation_copies']
            if copy.status == BookInstance.LoanStatus.AVAILABLE
        ]
        self.assertEqual(len(keys), 2)
        self.assertEqual(len(set(keys)), 2)
        for key in keys:
            self.assertContains(response, f'value="{key}"')

    def test_web_reservation_redirects_anonymous_users_to_login(self):
        instance = self.available_instances[0]
        response = self.client.post(
            reservation_web_url(instance.pk), {'idempotency_key': 'web-key'})
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/?next='))
        instance.refresh_from_db()
        self.assertEqual(instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(models.Reservation.objects.count(), 0)

    def test_web_reservation_confirms_success_visibly(self):
        instance = self.available_instances[0]
        self.client.force_login(self.user)
        response = self.client.post(
            reservation_web_url(instance.pk),
            {'idempotency_key': 'web-key'},
            follow=True,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Reservation successful.')
        instance.refresh_from_db()
        self.assertEqual(instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(instance.borrower_id, self.user.pk)
        self.assertEqual(models.Reservation.objects.count(), 1)


class ReservationConcurrencyTest(ReservationDataMixin, TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        self.create_catalog_data()
        self.instance = self.make_instance()

    def test_concurrent_users_cannot_reserve_the_same_copy(self):
        barrier = Barrier(2)
        instance_id = self.instance.pk
        user_ids = (self.user.pk, self.other_user.pk)
        clients = {}
        for user_id in user_ids:
            client = Client()
            client.force_login(get_user_model().objects.get(pk=user_id))
            clients[user_id] = client

        def reserve_as(user_id):
            close_old_connections()
            try:
                barrier.wait(timeout=10)
                response = clients[user_id].post(
                    reservation_api_url(instance_id),
                    HTTP_IDEMPOTENCY_KEY=f'user-{user_id}',
                )
                return response.status_code, response.json()
            finally:
                connections.close_all()

        with ThreadPoolExecutor(max_workers=2) as executor:
            results = list(executor.map(reserve_as, user_ids))

        self.assertEqual(sorted(status for status, _ in results), [201, 409])
        self.assertEqual(
            [body for status, body in results if status == 409],
            [{'error': 'unavailable'}],
        )
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIn(self.instance.borrower_id, user_ids)
        self.assertEqual(models.Reservation.objects.count(), 1)
