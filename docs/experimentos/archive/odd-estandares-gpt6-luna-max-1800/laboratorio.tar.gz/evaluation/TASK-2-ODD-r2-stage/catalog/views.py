import time
import uuid

from django.contrib import messages
from django.db import IntegrityError, OperationalError, connections, transaction
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

# Create your views here.

from .models import Book, Author, BookInstance, Genre, Language, Reservation

def index(request):
    """View function for home page of site."""
    # Generate counts of some of the main objects
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available copies of books
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Number of visits to this view, as counted in the session variable.
    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    # Render the HTML template index.html with the data in the context variable.
    return render(request, 'index.html', context=context)

from django.views import generic


class BookListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = Book
    paginate_by = 10

class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        copies = context['book'].bookinstance_set.all()
        context['reservation_copies'] = [
            (copy, str(uuid.uuid4())) for copy in copies
        ]
        return context

class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre

class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10

class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language

class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10

class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10

class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance

from django.contrib.auth.mixins import LoginRequiredMixin

class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )

# Added as part of challenge!
from django.contrib.auth.mixins import PermissionRequiredMixin


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')

from django.http import HttpResponseRedirect
from django.urls import reverse
import datetime
from django.contrib.auth.decorators import login_required, permission_required
from catalog.forms import RenewBookForm


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed'))

    # If this is a GET (or any other method) create the default form
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


_SQLITE_BUSY = object()


def _retry_sqlite_query(query):
    """Retry short reads that encounter transient SQLite writer locks."""
    for attempt in range(8):
        try:
            return query()
        except OperationalError as error:
            if not _is_sqlite_lock_error(error):
                raise
            if attempt == 7:
                return _SQLITE_BUSY
            time.sleep(min(0.01 * (attempt + 1), 0.1))


def _reservation_key_result(user_id, key, instance_id):
    """Return the result for a previously committed key, if one exists."""
    reservation = _retry_sqlite_query(
        lambda: Reservation.objects.filter(user_id=user_id, key=key).first())
    if reservation is _SQLITE_BUSY:
        return 'unavailable'
    if reservation is None:
        return None
    if reservation.instance_id == instance_id:
        return 'reserved'
    return 'idempotency_conflict'


def _is_sqlite_lock_error(error):
    message = str(error).lower()
    return connections['default'].vendor == 'sqlite' and (
        'locked' in message or 'busy' in message
    )


def _reserve_instance(user, instance, key):
    """Reserve an available copy atomically and persist its idempotency key."""
    if not key or len(key) > 100:
        return 'invalid_key'

    previous_result = _reservation_key_result(user.pk, key, instance.pk)
    if previous_result:
        return previous_result

    max_attempts = 8
    for attempt in range(max_attempts):
        try:
            with transaction.atomic():
                updated = BookInstance.objects.filter(
                    pk=instance.pk,
                    status=BookInstance.LoanStatus.AVAILABLE,
                ).update(
                    status=BookInstance.LoanStatus.RESERVED,
                    borrower_id=user.pk,
                )
                if updated:
                    Reservation.objects.create(
                        user_id=user.pk,
                        instance_id=instance.pk,
                        key=key,
                    )
            if not updated:
                previous_result = _reservation_key_result(
                    user.pk, key, instance.pk)
                return previous_result or 'unavailable'
            return 'reserved'
        except IntegrityError:
            # A concurrent request may have committed this user's key on a
            # different copy; the unique constraint decides which one wins.
            previous_result = _reservation_key_result(user.pk, key, instance.pk)
            if previous_result:
                return previous_result
            raise
        except OperationalError as error:
            if not _is_sqlite_lock_error(error):
                raise
            if attempt + 1 == max_attempts:
                previous_result = _reservation_key_result(
                    user.pk, key, instance.pk)
                return previous_result or 'unavailable'
            time.sleep(min(0.01 * (attempt + 1), 0.1))


def _reservation_error_response(error, status):
    return JsonResponse({'error': error}, status=status)


@require_POST
def reserve_bookinstance_api(request, pk):
    """Reserve an available book instance through the JSON API."""
    try:
        user = request.user
        is_authenticated = user.is_authenticated
    except OperationalError as error:
        if _is_sqlite_lock_error(error):
            return _reservation_error_response('unavailable', 409)
        raise

    if not is_authenticated:
        return _reservation_error_response('unauthorized', 401)

    key = request.headers.get('Idempotency-Key')
    if key is None:
        key = request.META.get('HTTP_IDEMPOTENCY_KEY', '')
    key = key.strip()
    if not key or len(key) > 100:
        return _reservation_error_response('invalid_key', 400)

    instance = _retry_sqlite_query(
        lambda: BookInstance.objects.filter(pk=pk).first())
    if instance is _SQLITE_BUSY:
        return _reservation_error_response('unavailable', 409)
    if instance is None:
        return _reservation_error_response('not_found', 404)

    result = _reserve_instance(user, instance, key)
    if result == 'reserved':
        return JsonResponse({
            'instance_id': str(pk),
            'user_id': user.pk,
            'status': BookInstance.LoanStatus.RESERVED,
        }, status=201)
    if result == 'idempotency_conflict':
        return _reservation_error_response('idempotency_conflict', 409)
    if result == 'invalid_key':
        return _reservation_error_response('invalid_key', 400)
    return _reservation_error_response('unavailable', 409)


@require_POST
@login_required
def reserve_bookinstance_web(request, pk):
    """Handle a reservation form and return the user to its book detail."""
    instance = get_object_or_404(BookInstance, pk=pk)
    key = request.POST.get('idempotency_key', '').strip()
    result = _reserve_instance(request.user, instance, key)

    if result == 'reserved':
        messages.success(request, 'Reservation successful.')
    elif result == 'invalid_key':
        messages.error(request, 'Invalid reservation key.')
    elif result == 'idempotency_conflict':
        messages.error(request, 'This reservation key was already used.')
    else:
        messages.error(request, 'This copy is no longer available.')

    return redirect(instance.book.get_absolute_url())


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import RestrictedError
from django.contrib.auth.mixins import PermissionRequiredMixin
from .models import Author


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'

class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    # Not recommended (potential security issue if more fields added)
    fields = '__all__'
    permission_required = 'catalog.change_author'

class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("author-delete", kwargs={"pk": self.object.pk})
            )

# Classes created for the forms challenge


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("book-delete", kwargs={"pk": self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    # fields = "__all__"
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'
