import threading
import uuid
from queue import Queue

from django.contrib.auth import get_user_model
from django.db import close_old_connections
from django.test import Client, TestCase, TransactionTestCase
from django.urls import reverse

from catalog.models import Author, Book, BookInstance, Reservation


User = get_user_model()


class ReservationWorkflowTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='reader', password='reader-password')
        self.other_user = User.objects.create_user(username='other-reader', password='other-password')
        author = Author.objects.create(first_name='A', last_name='Writer')
        self.book = Book.objects.create(
            title='Reservable Book',
            summary='A book available for reservation.',
            isbn='9780000000001',
            author=author,
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='First edition',
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        self.other_instance = BookInstance.objects.create(
            book=self.book,
            imprint='Second edition',
            status=BookInstance.LoanStatus.AVAILABLE,
        )

    def api_url(self, instance=None):
        return reverse('reserve-bookinstance-api', kwargs={'pk': instance or self.instance.pk})

    def post_api(self, instance=None, key='reservation-key'):
        return self.client.post(self.api_url(instance), HTTP_IDEMPOTENCY_KEY=key)

    def test_anonymous_api_request_returns_401_without_mutation(self):
        response = self.post_api()

        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_only_post_is_allowed(self):
        self.client.force_login(self.user)

        response = self.client.get(self.api_url(), HTTP_IDEMPOTENCY_KEY='reservation-key')

        self.assertEqual(response.status_code, 405)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_invalid_keys_return_400_without_mutation(self):
        self.client.force_login(self.user)

        for key in (None, '', '   ', 'x' * 101):
            with self.subTest(key=key):
                headers = {} if key is None else {'HTTP_IDEMPOTENCY_KEY': key}
                response = self.client.post(self.api_url(), **headers)
                self.assertEqual(response.status_code, 400)
                self.assertEqual(response.json(), {'error': 'invalid_key'})

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_missing_instance_returns_404_without_mutation(self):
        self.client.force_login(self.user)

        response = self.client.post(
            self.api_url(uuid.uuid4()), HTTP_IDEMPOTENCY_KEY='reservation-key')

        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})
        self.assertEqual(Reservation.objects.count(), 0)

    def test_unavailable_instance_returns_409_without_reservation(self):
        self.client.force_login(self.user)
        self.instance.status = BookInstance.LoanStatus.RESERVED
        self.instance.save(update_fields=['status'])

        response = self.post_api()

        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIsNone(self.instance.borrower)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_reservation_persists_and_replay_in_new_session_is_exact(self):
        self.client.force_login(self.user)
        first_response = self.post_api(key='persisted-key')

        self.assertEqual(first_response.status_code, 201)
        expected_payload = {
            'instance_id': str(self.instance.pk),
            'user_id': self.user.pk,
            'status': 'r',
        }
        self.assertEqual(first_response.json(), expected_payload)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower, self.user)
        self.assertEqual(Reservation.objects.filter(user=self.user, key='persisted-key').count(), 1)

        # Use a separate HTTP client/session to prove the idempotency record is persisted.
        replay_client = Client()
        replay_client.force_login(self.user)
        replay_response = replay_client.post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY='persisted-key')

        self.assertEqual(replay_response.status_code, 201)
        self.assertEqual(replay_response.json(), expected_payload)
        self.assertEqual(Reservation.objects.filter(user=self.user, key='persisted-key').count(), 1)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower, self.user)

    def test_reusing_key_for_another_instance_conflicts_without_mutation(self):
        self.client.force_login(self.user)
        self.assertEqual(self.post_api(key='one-key').status_code, 201)

        response = self.post_api(self.other_instance.pk, key='one-key')

        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'idempotency_conflict'})
        self.other_instance.refresh_from_db()
        self.assertEqual(self.other_instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(self.other_instance.borrower)
        self.assertEqual(Reservation.objects.filter(user=self.user, key='one-key').count(), 1)

    def test_same_key_is_independent_between_users(self):
        self.client.force_login(self.user)
        first_response = self.post_api(key='shared-key')

        other_client = Client()
        other_client.force_login(self.other_user)
        second_response = other_client.post(
            self.api_url(self.other_instance.pk), HTTP_IDEMPOTENCY_KEY='shared-key')

        self.assertEqual(first_response.status_code, 201)
        self.assertEqual(second_response.status_code, 201)
        self.assertEqual(
            Reservation.objects.filter(key='shared-key').values_list('user_id', flat=True).count(), 2)

    def test_book_detail_has_csrf_protected_reservation_form_and_success_message(self):
        detail_url = reverse('book-detail', kwargs={'pk': self.book.pk})
        form_url = reverse('reserve-bookinstance', kwargs={'instance_pk': self.instance.pk})
        detail_response = self.client.get(detail_url)

        self.assertEqual(detail_response.status_code, 200)
        self.assertContains(detail_response, f'action="{form_url}"')
        self.assertContains(detail_response, 'name="csrfmiddlewaretoken"')
        self.assertContains(detail_response, 'name="idempotency_key"')

        anonymous_response = self.client.post(form_url, {'idempotency_key': 'web-key'})
        self.assertEqual(anonymous_response.status_code, 302)
        self.assertTrue(anonymous_response.url.startswith('/accounts/login/'))
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)

        self.client.force_login(self.user)
        response = self.client.post(form_url, {'idempotency_key': 'web-key'})
        self.assertRedirects(response, detail_url, fetch_redirect_response=False)
        follow_response = self.client.get(response.url)
        self.assertContains(follow_response, 'Reserva confirmada.')
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(Reservation.objects.filter(user=self.user, key='web-key').count(), 1)

    def test_web_reservation_accepts_post_only(self):
        self.client.force_login(self.user)
        url = reverse('reserve-bookinstance', kwargs={'instance_pk': self.instance.pk})

        response = self.client.get(url)

        self.assertEqual(response.status_code, 405)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(Reservation.objects.count(), 0)


class ReservationConcurrencyTest(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        self.users = [
            User.objects.create_user(username='concurrent-a', password='password-a'),
            User.objects.create_user(username='concurrent-b', password='password-b'),
        ]
        author = Author.objects.create(first_name='Concurrent', last_name='Writer')
        book = Book.objects.create(
            title='Concurrent Book',
            summary='A book used in concurrent reservation tests.',
            isbn='9780000000002',
            author=author,
        )
        self.instance = BookInstance.objects.create(
            book=book,
            imprint='Concurrent edition',
            status=BookInstance.LoanStatus.AVAILABLE,
        )

    def test_two_users_racing_for_one_copy_produce_one_success_and_one_conflict(self):
        url = reverse('reserve-bookinstance-api', kwargs={'pk': self.instance.pk})
        barrier = threading.Barrier(2)
        results = Queue()
        clients = []
        for user in self.users:
            client = Client()
            client.force_login(user)
            clients.append(client)

        def reserve(user_id, client):
            close_old_connections()
            try:
                barrier.wait(timeout=10)
                response = client.post(url, HTTP_IDEMPOTENCY_KEY=f'key-{user_id}')
                results.put((response.status_code, response.json()))
            except Exception as error:  # Surface worker errors as test failures.
                results.put(error)
            finally:
                close_old_connections()

        threads = [
            threading.Thread(target=reserve, args=(user.pk, client))
            for user, client in zip(self.users, clients)
        ]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=20)

        self.assertTrue(all(not thread.is_alive() for thread in threads), 'reservation threads did not finish')
        responses = [results.get(timeout=1) for _ in threads]
        errors = [result for result in responses if isinstance(result, Exception)]
        self.assertEqual(errors, [])
        self.assertEqual(sorted(status for status, _ in responses), [201, 409])
        conflict = next(payload for status, payload in responses if status == 409)
        self.assertEqual(conflict, {'error': 'unavailable'})

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIn(self.instance.borrower_id, [user.pk for user in self.users])
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)
