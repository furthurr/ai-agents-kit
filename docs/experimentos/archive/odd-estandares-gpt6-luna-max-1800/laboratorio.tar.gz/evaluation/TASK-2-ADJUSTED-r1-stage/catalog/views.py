import time
import uuid

from django.contrib import messages
from django.db import IntegrityError, OperationalError, transaction
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.http import require_POST

# Create your views here.

from .models import Book, Author, BookInstance, Genre, Language, Reservation

def index(request):
    """View function for home page of site."""
    # Generate counts of some of the main objects
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available copies of books
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Number of visits to this view, as counted in the session variable.
    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    # Render the HTML template index.html with the data in the context variable.
    return render(request, 'index.html', context=context)

from django.views import generic


class BookListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = Book
    paginate_by = 10

class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        book_instances = list(self.object.bookinstance_set.all())
        for instance in book_instances:
            if instance.status == BookInstance.LoanStatus.AVAILABLE:
                instance.reservation_key = uuid.uuid4().hex
        context['book_instances'] = book_instances
        return context

class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre

class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10

class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language

class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10

class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10

class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance

from django.contrib.auth.mixins import LoginRequiredMixin

class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )

# Added as part of challenge!
from django.contrib.auth.mixins import PermissionRequiredMixin


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')

from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
import datetime
from django.contrib.auth.decorators import login_required, permission_required
from catalog.forms import RenewBookForm


def _reservation_response(user, instance_pk, status=201):
    if status == 201:
        return status, {
            'instance_id': str(instance_pk),
            'user_id': user.pk,
            'status': BookInstance.LoanStatus.RESERVED,
        }
    return status, {'error': 'unavailable'}


def _existing_reservation_response(reservation, user, instance_pk):
    if str(reservation.instance_id) == str(instance_pk):
        return _reservation_response(user, instance_pk)
    return 409, {'error': 'idempotency_conflict'}


def _is_sqlite_lock_error(error):
    message = str(error).lower()
    return 'database is locked' in message or 'database table is locked' in message or 'database is busy' in message


def _reserve_instance(user, instance_pk, key):
    """Atomically reserve an available copy and persist its idempotency key."""
    retry_count = 4

    for attempt in range(retry_count):
        try:
            if not BookInstance.objects.filter(pk=instance_pk).exists():
                return 404, {'error': 'not_found'}

            reservation = Reservation.objects.filter(user=user, key=key).only('instance_id').first()
            if reservation is not None:
                return _existing_reservation_response(reservation, user, instance_pk)

            try:
                with transaction.atomic():
                    rows_updated = BookInstance.objects.filter(
                        pk=instance_pk,
                        status=BookInstance.LoanStatus.AVAILABLE,
                    ).update(
                        status=BookInstance.LoanStatus.RESERVED,
                        borrower_id=user.pk,
                    )
                    if rows_updated:
                        Reservation.objects.create(
                            user=user,
                            instance_id=instance_pk,
                            key=key,
                        )
                        return _reservation_response(user, instance_pk)
            except IntegrityError:
                # A simultaneous request may have inserted this user's key.
                reservation = Reservation.objects.filter(
                    user=user, key=key).only('instance_id').first()
                if reservation is not None:
                    return _existing_reservation_response(reservation, user, instance_pk)
                raise

            # A zero-row conditional update means the copy was taken. Check the
            # key again because another in-flight request may have been a replay.
            reservation = Reservation.objects.filter(user=user, key=key).only('instance_id').first()
            if reservation is not None:
                return _existing_reservation_response(reservation, user, instance_pk)
            return _reservation_response(user, instance_pk, status=409)
        except OperationalError as error:
            if not _is_sqlite_lock_error(error):
                raise
            if attempt + 1 == retry_count:
                # Never expose a transient SQLite lock as a server error.
                return _reservation_response(user, instance_pk, status=409)
            time.sleep(0.05 * (attempt + 1))


@require_POST
def reserve_bookinstance_api(request, pk):
    """JSON endpoint for authenticated, idempotent copy reservations."""
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'unauthorized'}, status=401)

    key = request.headers.get('Idempotency-Key', '').strip()
    if not key or len(key) > 100:
        return JsonResponse({'error': 'invalid_key'}, status=400)

    status_code, body = _reserve_instance(request.user, pk, key)
    return JsonResponse(body, status=status_code)


@require_POST
@login_required
def reserve_bookinstance(request, instance_pk):
    """Handle the reservation form and report the result on the book detail."""
    instance = get_object_or_404(BookInstance, pk=instance_pk)
    key = request.POST.get('idempotency_key', '').strip()

    if not key or len(key) > 100:
        messages.error(request, 'La clave de reserva no es válida.')
    else:
        status_code, result = _reserve_instance(request.user, instance_pk, key)
        if status_code == 201:
            messages.success(request, 'Reserva confirmada.')
        elif result.get('error') == 'idempotency_conflict':
            messages.error(request, 'La clave de reserva ya se utilizó para otro ejemplar.')
        elif result.get('error') == 'unavailable':
            messages.error(request, 'Este ejemplar ya no está disponible.')

    if instance.book_id is not None:
        return HttpResponseRedirect(reverse('book-detail', kwargs={'pk': instance.book_id}))
    return HttpResponseRedirect(reverse('bookinstances'))


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed'))

    # If this is a GET (or any other method) create the default form
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import RestrictedError
from django.contrib.auth.mixins import PermissionRequiredMixin
from .models import Author


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'

class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    # Not recommended (potential security issue if more fields added)
    fields = '__all__'
    permission_required = 'catalog.change_author'

class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("author-delete", kwargs={"pk": self.object.pk})
            )

# Classes created for the forms challenge


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("book-delete", kwargs={"pk": self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    # fields = "__all__"
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'
