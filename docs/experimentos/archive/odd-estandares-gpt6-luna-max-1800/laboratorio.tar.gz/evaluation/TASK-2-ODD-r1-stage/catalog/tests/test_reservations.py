from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
import uuid

from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import IntegrityError, close_old_connections, connection, transaction
from django.test import Client, TestCase, TransactionTestCase
from django.urls import reverse

from catalog.models import Book, BookInstance, Reservation


class ReservationEndpointTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username='reservation-user', password='reservation-password'
        )
        self.book = Book.objects.create(
            title='Reservation test book',
            summary='A book used by reservation tests.',
            isbn='reservation-test-isbn',
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Test imprint',
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        self.other_instance = BookInstance.objects.create(
            book=self.book,
            imprint='Another test imprint',
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        self.other_user = get_user_model().objects.create_user(
            username='another-reservation-user',
            password='another-reservation-password',
        )

    def api_url(self, instance=None):
        instance = instance or self.instance
        return reverse('api-reserve-bookinstance', kwargs={'pk': instance.pk})

    def test_authenticated_user_can_reserve_available_copy(self):
        self.client.force_login(self.user)

        response = self.client.post(
            self.api_url(),
            HTTP_IDEMPOTENCY_KEY='reservation-key',
        )

        self.assertEqual(response.status_code, 201)
        self.assertEqual(
            response.json(),
            {
                'instance_id': str(self.instance.pk),
                'user_id': self.user.id,
                'status': BookInstance.LoanStatus.RESERVED,
            },
        )
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower, self.user)
        self.assertEqual(
            Reservation.objects.filter(user=self.user, key='reservation-key').count(),
            1,
        )

    def test_api_requires_post_for_all_other_methods(self):
        url = self.api_url()
        for method in (self.client.get, self.client.put, self.client.delete):
            with self.subTest(method=method.__name__):
                self.assertEqual(method(url).status_code, 405)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertFalse(Reservation.objects.exists())

    def test_anonymous_api_post_returns_unauthorized_json(self):
        response = self.client.post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY='reservation-key'
        )

        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertFalse(Reservation.objects.exists())

    def test_invalid_keys_do_not_mutate_copy_or_create_reservations(self):
        self.client.force_login(self.user)
        invalid_keys = (None, '', '   ', 'k' * 101)

        for key in invalid_keys:
            with self.subTest(key=key):
                headers = {} if key is None else {'HTTP_IDEMPOTENCY_KEY': key}
                response = self.client.post(self.api_url(), **headers)
                self.assertEqual(response.status_code, 400)
                self.assertEqual(response.json(), {'error': 'invalid_key'})

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertFalse(Reservation.objects.exists())

    def test_nonexistent_instance_returns_not_found_without_mutation(self):
        self.client.force_login(self.user)
        missing_id = uuid.uuid4()

        response = self.client.post(
            reverse('api-reserve-bookinstance', kwargs={'pk': missing_id}),
            HTTP_IDEMPOTENCY_KEY='reservation-key',
        )

        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})
        self.assertEqual(BookInstance.objects.count(), 2)
        self.assertFalse(Reservation.objects.exists())

    def test_unavailable_instance_returns_conflict_without_reservation(self):
        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.borrower = self.other_user
        self.instance.save()
        self.client.force_login(self.user)

        response = self.client.post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY='reservation-key'
        )

        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.ON_LOAN)
        self.assertEqual(self.instance.borrower, self.other_user)
        self.assertFalse(Reservation.objects.exists())

    def test_same_key_replay_in_a_new_http_session_is_exact_and_persistent(self):
        self.client.force_login(self.user)
        first_response = self.client.post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY='persistent-key'
        )
        new_session = Client()
        new_session.force_login(self.user)

        replay_response = new_session.post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY='persistent-key'
        )

        expected = {
            'instance_id': str(self.instance.pk),
            'user_id': self.user.id,
            'status': BookInstance.LoanStatus.RESERVED,
        }
        self.assertEqual(first_response.status_code, 201)
        self.assertEqual(first_response.json(), expected)
        self.assertEqual(replay_response.status_code, 201)
        self.assertEqual(replay_response.json(), expected)
        self.assertEqual(
            Reservation.objects.filter(user=self.user, key='persistent-key').count(),
            1,
        )
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower, self.user)

    def test_reusing_key_for_another_instance_conflicts_without_mutation(self):
        self.client.force_login(self.user)
        first_response = self.client.post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY='one-key'
        )

        response = self.client.post(
            self.api_url(self.other_instance), HTTP_IDEMPOTENCY_KEY='one-key'
        )

        self.assertEqual(first_response.status_code, 201)
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'idempotency_conflict'})
        self.other_instance.refresh_from_db()
        self.assertEqual(
            self.other_instance.status, BookInstance.LoanStatus.AVAILABLE
        )
        self.assertEqual(Reservation.objects.filter(user=self.user).count(), 1)

    def test_same_key_is_independent_for_different_users(self):
        self.client.force_login(self.user)
        first_response = self.client.post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY='shared-key'
        )
        other_client = Client()
        other_client.force_login(self.other_user)

        response = other_client.post(
            self.api_url(self.other_instance), HTTP_IDEMPOTENCY_KEY='shared-key'
        )

        self.assertEqual(first_response.status_code, 201)
        self.assertEqual(response.status_code, 201)
        self.assertEqual(
            Reservation.objects.filter(key='shared-key').count(), 2
        )

    def test_model_unique_key_constraint_is_scoped_to_user(self):
        Reservation.objects.create(
            user=self.user, instance=self.instance, key='unique-key'
        )
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                Reservation.objects.create(
                    user=self.user, instance=self.other_instance, key='unique-key'
                )

        Reservation.objects.create(
            user=self.other_user, instance=self.other_instance, key='unique-key'
        )
        self.assertEqual(Reservation.objects.filter(key='unique-key').count(), 2)


class ReservationWebFlowTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username='web-reservation-user', password='reservation-password'
        )
        self.book = Book.objects.create(
            title='Web reservation book',
            summary='A book used by web reservation tests.',
            isbn='web-reservation-test-isbn',
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Web test imprint',
            status=BookInstance.LoanStatus.AVAILABLE,
        )

    def reserve_url(self):
        return reverse('reserve-bookinstance', kwargs={'pk': self.instance.pk})

    def test_book_detail_has_csrf_protected_reservation_form_with_generated_key(self):
        unavailable_instance = BookInstance.objects.create(
            book=self.book,
            imprint='Unavailable test imprint',
            status=BookInstance.LoanStatus.MAINTENANCE,
        )
        response = self.client.get(
            reverse('book-detail', kwargs={'pk': self.book.pk})
        )
        unavailable_url = reverse(
            'reserve-bookinstance', kwargs={'pk': unavailable_instance.pk}
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, f'action="{self.reserve_url()}"')
        self.assertNotContains(response, f'action="{unavailable_url}"')
        self.assertContains(response, 'name="csrfmiddlewaretoken"')
        self.assertRegex(
            response.content.decode(),
            r'name="idempotency_key" value="[0-9a-f]{32}"',
        )

    def test_anonymous_web_reservation_redirects_to_login(self):
        response = self.client.post(
            self.reserve_url(), {'idempotency_key': 'web-key'}
        )

        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/?next='))
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertFalse(Reservation.objects.exists())

    def test_web_reservation_redirects_with_visible_confirmation(self):
        self.client.force_login(self.user)

        response = self.client.post(
            self.reserve_url(), {'idempotency_key': 'web-key'}, follow=True
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Reservation confirmed.')
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower, self.user)
        self.assertEqual(Reservation.objects.count(), 1)


class ReservationConcurrencyTests(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        user_model = get_user_model()
        self.users = [
            user_model.objects.create_user(
                username=f'concurrent-user-{index}', password='reservation-password'
            )
            for index in range(2)
        ]
        self.book = Book.objects.create(
            title='Concurrent reservation book',
            summary='A book used by concurrency tests.',
            isbn='concurrent-reservation-isbn',
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Concurrent test imprint',
            status=BookInstance.LoanStatus.AVAILABLE,
        )

    def test_two_users_racing_for_one_available_copy_have_one_winner(self):
        self.assertEqual(connection.vendor, 'sqlite')
        database_name = str(connection.settings_dict['NAME'])
        self.assertNotEqual(database_name, ':memory:')
        self.assertNotIn('mode=memory', database_name)

        session_cookies = []
        for user in self.users:
            client = Client()
            client.force_login(user)
            session_cookies.append(
                client.cookies[settings.SESSION_COOKIE_NAME].value
            )

        barrier = Barrier(2)
        url = reverse(
            'api-reserve-bookinstance', kwargs={'pk': self.instance.pk}
        )

        def reserve_in_thread(index):
            close_old_connections()
            client = Client()
            client.cookies[settings.SESSION_COOKIE_NAME] = session_cookies[index]
            barrier.wait(timeout=10)
            try:
                response = client.post(
                    url, HTTP_IDEMPOTENCY_KEY=f'concurrent-key-{index}'
                )
                return response.status_code, response.json()
            finally:
                close_old_connections()

        with ThreadPoolExecutor(max_workers=2) as executor:
            responses = list(executor.map(reserve_in_thread, range(2)))

        self.assertCountEqual([status for status, _ in responses], [201, 409])
        self.assertEqual(
            [payload for status, payload in responses if status == 409],
            [{'error': 'unavailable'}],
        )
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIn(self.instance.borrower, self.users)
        self.assertEqual(Reservation.objects.count(), 1)
