import os
import re
import threading
import tempfile
import uuid
from concurrent.futures import ThreadPoolExecutor

from django.apps import apps
from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import IntegrityError, close_old_connections, connection, connections, transaction
from django.db.migrations.executor import MigrationExecutor
from django.test import Client, TestCase, TransactionTestCase

from catalog.models import Book, BookInstance


User = get_user_model()


def reservation_model():
    return apps.get_model('catalog', 'Reservation')


class ReservationAPITests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='reserve-user', password='password')
        self.other_user = User.objects.create_user(username='other-user', password='password')
        self.book = Book.objects.create(
            title='Reservation book',
            summary='A book for reservation tests.',
            isbn='RESERVATION01',
        )
        self.instance = self.create_instance()
        self.api_url = f'/catalog/api/bookinstance/{self.instance.pk}/reserve/'
        self.web_url = f'/catalog/book/{self.instance.pk}/reserve/'

    def create_instance(self, status=BookInstance.LoanStatus.AVAILABLE):
        return BookInstance.objects.create(
            book=self.book,
            imprint='Test imprint',
            status=status,
        )

    def post_api(self, key, url=None, client=None):
        return (client or self.client).post(
            url or self.api_url,
            HTTP_IDEMPOTENCY_KEY=key,
        )

    def assert_error(self, response, status, error):
        self.assertEqual(response.status_code, status)
        self.assertEqual(response.json(), {'error': error})

    def test_anonymous_post_returns_unauthorized_without_mutation(self):
        response = self.post_api('anonymous-key')

        self.assert_error(response, 401, 'unauthorized')
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(reservation_model().objects.count(), 0)

    def test_only_post_is_allowed(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        for method in ('get', 'head', 'options', 'put', 'patch', 'delete'):
            with self.subTest(method=method):
                response = getattr(client, method)(self.api_url)
                self.assertEqual(response.status_code, 405)

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(reservation_model().objects.count(), 0)

    def test_invalid_keys_return_bad_request_without_mutation(self):
        self.client.force_login(self.user)
        cases = (
            {},
            {'HTTP_IDEMPOTENCY_KEY': ''},
            {'HTTP_IDEMPOTENCY_KEY': '   '},
            {'HTTP_IDEMPOTENCY_KEY': 'k' * 101},
        )
        for headers in cases:
            with self.subTest(headers=headers):
                response = self.client.post(self.api_url, **headers)
                self.assert_error(response, 400, 'invalid_key')

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(reservation_model().objects.count(), 0)

    def test_missing_instance_returns_not_found_without_mutation(self):
        self.client.force_login(self.user)
        url = f'/catalog/api/bookinstance/{uuid.uuid4()}/reserve/'

        response = self.post_api('missing-key', url=url)

        self.assert_error(response, 404, 'not_found')
        self.assertEqual(reservation_model().objects.count(), 0)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_unavailable_instance_returns_conflict_without_reservation(self):
        self.client.force_login(self.user)
        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.borrower = self.other_user
        self.instance.save(update_fields=['status', 'borrower'])

        response = self.post_api('unavailable-key')

        self.assert_error(response, 409, 'unavailable')
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.ON_LOAN)
        self.assertEqual(self.instance.borrower, self.other_user)
        self.assertEqual(reservation_model().objects.count(), 0)

    def test_success_reserves_instance_and_persists_reservation(self):
        self.client.force_login(self.user)

        response = self.post_api('success-key')

        expected = {
            'instance_id': str(self.instance.pk),
            'user_id': self.user.pk,
            'status': 'r',
        }
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), expected)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower, self.user)
        reservation = reservation_model().objects.get(user=self.user, key='success-key')
        self.assertEqual(reservation.instance, self.instance)
        self.assertIsNotNone(reservation.created_at)

    def test_maximum_length_key_is_accepted(self):
        self.client.force_login(self.user)
        key = 'k' * 100

        response = self.post_api(key)

        self.assertEqual(response.status_code, 201)
        self.assertTrue(reservation_model().objects.filter(user=self.user, key=key).exists())

    def test_replay_in_new_http_session_does_not_duplicate_or_mutate(self):
        self.client.force_login(self.user)
        original = self.post_api('replay-key')
        original_payload = original.json()

        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.borrower = self.other_user
        self.instance.save(update_fields=['status', 'borrower'])

        new_session = Client()
        new_session.force_login(self.user)
        replay = self.post_api('replay-key', client=new_session)

        self.assertEqual(original.status_code, 201)
        self.assertEqual(replay.status_code, 201)
        self.assertEqual(replay.json(), original_payload)
        self.assertEqual(reservation_model().objects.filter(user=self.user, key='replay-key').count(), 1)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.ON_LOAN)
        self.assertEqual(self.instance.borrower, self.other_user)

    def test_reusing_key_for_another_instance_is_conflict_without_mutation(self):
        self.client.force_login(self.user)
        self.assertEqual(self.post_api('reused-key').status_code, 201)
        second_instance = self.create_instance()

        response = self.post_api(
            'reused-key',
            url=f'/catalog/api/bookinstance/{second_instance.pk}/reserve/',
        )

        self.assert_error(response, 409, 'idempotency_conflict')
        second_instance.refresh_from_db()
        self.assertEqual(second_instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(reservation_model().objects.filter(user=self.user, key='reused-key').count(), 1)

    def test_same_key_is_independent_between_users(self):
        second_instance = self.create_instance()
        first_client = Client()
        second_client = Client()
        first_client.force_login(self.user)
        second_client.force_login(self.other_user)

        first = self.post_api('shared-key', client=first_client)
        second = self.post_api(
            'shared-key',
            url=f'/catalog/api/bookinstance/{second_instance.pk}/reserve/',
            client=second_client,
        )

        self.assertEqual(first.status_code, 201)
        self.assertEqual(second.status_code, 201)
        self.assertEqual(reservation_model().objects.filter(key='shared-key').count(), 2)

    def test_database_enforces_unique_key_per_user(self):
        Reservation = reservation_model()
        Reservation.objects.create(user=self.user, instance=self.instance, key='unique-key')
        Reservation.objects.create(user=self.other_user, instance=self.instance, key='unique-key')

        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                Reservation.objects.create(user=self.user, instance=self.instance, key='unique-key')

    def test_book_detail_renders_csrf_form_and_generated_idempotency_key(self):
        response = self.client.get(f'/catalog/book/{self.book.pk}')

        self.assertEqual(response.status_code, 200)
        content = response.content.decode()
        self.assertIn(f'action="{self.web_url}"', content)
        self.assertIn('name="csrfmiddlewaretoken"', content)
        self.assertRegex(content, r'name="idempotency_key" value="[0-9a-f]{32}"')

    def test_web_reservation_accepts_rendered_csrf_token(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        page = client.get(f'/catalog/book/{self.book.pk}')
        csrf_token = re.search(
            r'name="csrfmiddlewaretoken" value="([^"]+)"',
            page.content.decode(),
        ).group(1)

        response = client.post(
            self.web_url,
            {
                'idempotency_key': 'csrf-protected-key',
                'csrfmiddlewaretoken': csrf_token,
            },
        )

        self.assertEqual(response.status_code, 302)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)

    def test_anonymous_web_post_redirects_to_login(self):
        response = self.client.post(self.web_url, {'idempotency_key': 'web-key'})

        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/?next='))
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_web_reservation_shows_success_confirmation(self):
        self.client.force_login(self.user)

        response = self.client.post(
            self.web_url,
            {'idempotency_key': 'web-success-key'},
            follow=True,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Reserva completada correctamente.')
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower, self.user)


class ReservationConcurrencyTests(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        self._original_db_name = connection.settings_dict['NAME']
        self._had_original_options = 'OPTIONS' in connection.settings_dict
        self._original_options = connection.settings_dict.get('OPTIONS', {}).copy()
        self._temporary_db = tempfile.TemporaryDirectory(dir=settings.BASE_DIR)
        connections_database = connection.settings_dict
        connections.close_all()
        connections_database['NAME'] = os.path.join(self._temporary_db.name, 'reservations.sqlite3')
        connections_database['OPTIONS'] = {**self._original_options, 'uri': False}
        connections.close_all()
        executor = MigrationExecutor(connection)
        executor.migrate(executor.loader.graph.leaf_nodes())

        self.assertEqual(connection.vendor, 'sqlite')
        self.assertFalse(connection.is_in_memory_db(), 'Concurrency must use a file-backed SQLite database.')
        self.users = [
            User.objects.create_user(username='racer-one', password='password'),
            User.objects.create_user(username='racer-two', password='password'),
        ]
        book = Book.objects.create(
            title='Concurrent reservation',
            summary='A book for concurrent reservation tests.',
            isbn='CONCURRENT001',
        )
        self.instance = BookInstance.objects.create(
            book=book,
            imprint='Test imprint',
            status=BookInstance.LoanStatus.AVAILABLE,
        )

    def tearDown(self):
        connections.close_all()
        connection.settings_dict['NAME'] = self._original_db_name
        if self._had_original_options:
            connection.settings_dict['OPTIONS'] = self._original_options
        else:
            connection.settings_dict.pop('OPTIONS', None)
        self._temporary_db.cleanup()
        super().tearDown()

    def test_two_concurrent_users_produce_one_success_and_one_unavailable(self):
        clients = [Client(), Client()]
        for client, user in zip(clients, self.users):
            client.force_login(user)

        url = f'/catalog/api/bookinstance/{self.instance.pk}/reserve/'
        barrier = threading.Barrier(2)

        def send_request(client, key):
            close_old_connections()
            try:
                barrier.wait(timeout=10)
                response = client.post(url, HTTP_IDEMPOTENCY_KEY=key)
                return response.status_code, response.json()
            finally:
                close_old_connections()

        with ThreadPoolExecutor(max_workers=2) as executor:
            futures = [
                executor.submit(send_request, clients[index], f'race-key-{index}')
                for index in range(2)
            ]
            results = [future.result(timeout=20) for future in futures]

        self.assertCountEqual([status for status, _ in results], [201, 409])
        self.assertEqual(
            next(payload for status, payload in results if status == 409),
            {'error': 'unavailable'},
        )
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIn(self.instance.borrower, self.users)
        Reservation = reservation_model()
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)
