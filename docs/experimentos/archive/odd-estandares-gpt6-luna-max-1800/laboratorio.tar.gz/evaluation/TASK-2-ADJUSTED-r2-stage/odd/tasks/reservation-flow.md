# ODD: Flujo de reserva de ejemplares

## L1 — Petición original

```text
"Implementar flujo de reserva de ejemplares disponibles (BookInstance con status='a') para usuarios autenticados, con persistencia de reservas, garantía de idempotencia en reintentos y tolerancia a concurrencia real bajo SQLite.

CONTRATOS EXACTOS:
1. Modelo público de persistencia:
   Definir modelo Reservation en catalog.models (o exponerlo públicamente allí) con los siguientes campos:
   - user: ForeignKey a settings.AUTH_USER_MODEL (on_delete=CASCADE u obligatorio).
   - instance: ForeignKey a BookInstance (o OneToOneField / ForeignKey, on_delete=CASCADE).
   - key: CharField(max_length=100) para la clave de idempotencia.
   - created_at: DateTimeField(auto_now_add=True).
   - Constraint de unicidad: [user, key] único (UniqueConstraint o unique_together), de modo que claves entre distintos usuarios sean independientes.
2. API Endpoint: POST /catalog/api/bookinstance/<uuid:pk>/reserve/
   - Autenticación: Requiere usuario autenticado. Si no está autenticado, responder 401 Unauthorized con JSON {'error': 'unauthorized'}.
   - Método HTTP: Solo POST permitido. GET o cualquier otro método responde 405 Method Not Allowed.
   - Header de Idempotencia: Obligatorio 'Idempotency-Key' en encabezados HTTP (o 'HTTP_IDEMPOTENCY_KEY'). Debe ser no vacío tras strip y de longitud <= 100 caracteres. Si falta, está vacío o supera 100 caracteres, responder 400 Bad Request con JSON {'error': 'invalid_key'}.
   - Instancia inexistente: Si pk no corresponde a ningún BookInstance existente, responder 404 Not Found con JSON {'error': 'not_found'}.
   - Ejemplar no disponible: Si la copia no tiene status='a', responder 409 Conflict con JSON exacto {'error': 'unavailable'}.
   - Éxito (primera reserva): Transicionar BookInstance.status a 'r' (Reserved), asignar BookInstance.borrower al usuario actual, registrar la Reservation con la clave provista. Responder 201 Created con JSON exacto:
     {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}
   - Replay / Idempotencia exacta: Si el MISMO usuario realiza POST con la MISMA clave 'Idempotency-Key' para la MISMA instancia que ya reservó con esa clave, responder exactamente 201 Created con el mismo JSON {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}, sin duplicar registros de Reservation ni alterar el estado.
   - Conflicto de Idempotencia: Si el MISMO usuario intenta reutilizar una 'Idempotency-Key' previamente usada para reservar OTRA instancia diferente, responder 409 Conflict con JSON exacto {'error': 'idempotency_conflict'}.
   - Persistencia de idempotencia: La clave debe persistir en la base de datos de modo que un replay en una nueva conexión o sesión HTTP siga retornando 201 Created con el mismo payload.
3. Garantía de concurrencia bajo SQLite en disco:
   - Dos solicitudes concurrentes de distintos usuarios sobre la misma copia 'a' deben resultar en exactamente un 201 Created y un 409 Conflict (con {'error': 'unavailable'}).
   - SQLite no bloquea filas con select_for_update(); la implementación debe asegurar el resultado concurrente real (ej. mediante conditional UPDATE / atomic con verificación de rows_updated, o reintento acotado ante busy/lock) sin devolver 500 'database locked' al cliente.
   - Ninguna petición fallida (400, 401, 404, 405, 409) debe mutar el estado de BookInstance ni dejar reservas espurias.
4. Interfaz Web (UI):
   - En /catalog/book/<int:pk>, para cada copia con status='a', incluir botón/formulario de reserva apuntando a /catalog/book/<uuid:instance_pk>/reserve/.
   - POST a /catalog/book/<uuid:instance_pk>/reserve/ debe requerir autenticación (redirigiendo a login si es anónimo).
   - Debe incluir token CSRF y un campo hidden con idempotency_key generada para prevenir doble envío accidental en el navegador.
   - Al completarse con éxito, mostrar mensaje de confirmación visible en la interfaz (o redirigir al detalle con mensaje flash de éxito).
5. Suite original (43 tests) debe seguir pasando intacta. No modificar el comando renew de bibliotecarios ni violar retrocompatibilidad.

Alcance completo validado explícitamente: exactamente las reglas anteriores, sin extensiones. Trabaja solo en este workspace. Carga `ob-odd-workflow` antes de actuar y conserva tu metodología. No uses red ni delegues, no instales dependencias, no hagas commits. Runner disponible: /private/var/folders/d7/z7388kp51w532q4c0rj7hqqh0000gn/T/opencode/real-project-gemini-20261104/.venv/bin/python manage.py test. Si el flujo requiere aprobación pendiente, presenta la propuesta y espera respuesta; no la inventes."
```

## Specs

### S1 — Persistencia

Definir modelo Reservation en catalog.models (o exponerlo públicamente allí) con los siguientes campos:
- user: ForeignKey a settings.AUTH_USER_MODEL (on_delete=CASCADE u obligatorio).
- instance: ForeignKey a BookInstance (o OneToOneField / ForeignKey, on_delete=CASCADE).
- key: CharField(max_length=100) para la clave de idempotencia.
- created_at: DateTimeField(auto_now_add=True).
- Constraint de unicidad: [user, key] único (UniqueConstraint o unique_together), de modo que claves entre distintos usuarios sean independientes.

### S2 — API y idempotencia

API Endpoint: POST /catalog/api/bookinstance/<uuid:pk>/reserve/
- Autenticación: Requiere usuario autenticado. Si no está autenticado, responder 401 Unauthorized con JSON {'error': 'unauthorized'}.
- Método HTTP: Solo POST permitido. GET o cualquier otro método responde 405 Method Not Allowed.
- Header de Idempotencia: Obligatorio 'Idempotency-Key' en encabezados HTTP (o 'HTTP_IDEMPOTENCY_KEY'). Debe ser no vacío tras strip y de longitud <= 100 caracteres. Si falta, está vacío o supera 100 caracteres, responder 400 Bad Request con JSON {'error': 'invalid_key'}.
- Instancia inexistente: Si pk no corresponde a ningún BookInstance existente, responder 404 Not Found con JSON {'error': 'not_found'}.
- Ejemplar no disponible: Si la copia no tiene status='a', responder 409 Conflict con JSON exacto {'error': 'unavailable'}.
- Éxito (primera reserva): Transicionar BookInstance.status a 'r' (Reserved), asignar BookInstance.borrower al usuario actual, registrar la Reservation con la clave provista. Responder 201 Created con JSON exacto:
  {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}
- Replay / Idempotencia exacta: Si el MISMO usuario realiza POST con la MISMA clave 'Idempotency-Key' para la MISMA instancia que ya reservó con esa clave, responder exactamente 201 Created con el mismo JSON {"instance_id": str(pk), "user_id": request.user.id, "status": "r"}, sin duplicar registros de Reservation ni alterar el estado.
- Conflicto de Idempotencia: Si el MISMO usuario intenta reutilizar una 'Idempotency-Key' previamente usada para reservar OTRA instancia diferente, responder 409 Conflict con JSON exacto {'error': 'idempotency_conflict'}.
- Persistencia de idempotencia: La clave debe persistir en la base de datos de modo que un replay en una nueva conexión o sesión HTTP siga retornando 201 Created con el mismo payload.

### S3 — Concurrencia SQLite y ausencia de mutaciones fallidas

Garantía de concurrencia bajo SQLite en disco:
- Dos solicitudes concurrentes de distintos usuarios sobre la misma copia 'a' deben resultar en exactamente un 201 Created y un 409 Conflict (con {'error': 'unavailable'}).
- SQLite no bloquea filas con select_for_update(); la implementación debe asegurar el resultado concurrente real (ej. mediante conditional UPDATE / atomic con verificación de rows_updated, o reintento acotado ante busy/lock) sin devolver 500 'database locked' al cliente.
- Ninguna petición fallida (400, 401, 404, 405, 409) debe mutar el estado de BookInstance ni dejar reservas espurias.

### S4 — Interfaz Web

Interfaz Web (UI):
- En /catalog/book/<int:pk>, para cada copia con status='a', incluir botón/formulario de reserva apuntando a /catalog/book/<uuid:instance_pk>/reserve/.
- POST a /catalog/book/<uuid:instance_pk>/reserve/ debe requerir autenticación (redirigiendo a login si es anónimo).
- Debe incluir token CSRF y un campo hidden con idempotency_key generada para prevenir doble envío accidental en el navegador.
- Al completarse con éxito, mostrar mensaje de confirmación visible en la interfaz (o redirigir al detalle con mensaje flash de éxito).

### S5 — Compatibilidad original

Suite original (43 tests) debe seguir pasando intacta. No modificar el comando renew de bibliotecarios ni violar retrocompatibilidad.

## Tasks

- [completed] T1 — Añadir Reservation, su migración y prueba de constraint. (S1)
- [completed] T2 — Añadir API POST, errores exactos, idempotencia y concurrencia SQLite; probar estados persistidos. (S2, S3)
- [completed] T3 — Añadir formulario web con CSRF/clave generada, protección de login y confirmación visible. (S4)
- [completed] T4 — Ejecutar la suite original y regresiones del flujo; confirmar que renovar préstamos no cambia. (S5)

## Log

- Exploración: `catalog/models.py` define `BookInstance` con PK UUID y `status`/`borrower`; `catalog/views.py` contiene el comando de renovación que se mantiene intacto; rutas en `catalog/urls.py`; detalle y plantillas globales usan Django Templates y Django Messages está configurado.
- Fuentes documentales consultadas: `README.md` y `docs/lab-context.md`; no se detectó contrato de reservas existente. El runner estándar es el especificado por la petición.
- Baseline observado antes de cambios: `/private/var/folders/d7/z7388kp51w532q4c0rj7hqqh0000gn/T/opencode/real-project-gemini-20261104/.venv/bin/python manage.py test` — 43 tests, OK.
- RED observado en `test_anonymous_post_returns_unauthorized_without_mutation`: antes de añadir la ruta, la petición obtuvo 404 en lugar del 401 exigido.
- GREEN de reservas: `python manage.py makemigrations catalog` creó `0030_reservation.py`; `python manage.py test catalog.tests.test_reservations` — 16 tests, OK, incluyendo concurrencia en SQLite en disco temporal, replays, constraint, errores API y UI/CSRF.
- Verificación final: el runner completo informó 59 tests OK; los módulos originales (`test_models`, `test_forms`, `test_views`) se ejecutaron también por separado: 43 tests OK.
- `manage.py check`: sin incidencias; `manage.py makemigrations --check --dry-run`: sin cambios pendientes; `git diff --check`: limpio. La renovación de bibliotecarios no fue modificada.
- Clasificación: grande por requisitos multicapa extensos y concurrencia/persistencia que necesitan continuidad verificable; registrar este artefacto antes del primer cambio de producto.
