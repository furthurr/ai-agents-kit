import time

from django.db import IntegrityError, OperationalError, transaction

from .models import BookInstance, Reservation


def normalize_idempotency_key(value):
    key = (value or '').strip()
    if not key or len(key) > 100:
        return None
    return key


def _existing_key_result(user, instance_id, key):
    reservation = (
        Reservation.objects.filter(user=user, key=key)
        .only('instance_id')
        .first()
    )
    if reservation is None:
        return None
    if reservation.instance_id == instance_id:
        return 'success'
    return 'idempotency_conflict'


def _database_is_busy(error):
    message = str(error).lower()
    return 'locked' in message or 'busy' in message


def _reserve_once(user, instance_id, key):
    if not BookInstance.objects.filter(pk=instance_id).exists():
        return 'not_found'

    existing_result = _existing_key_result(user, instance_id, key)
    if existing_result is not None:
        return existing_result

    # The conditional UPDATE is the first statement inside atomic(), acquiring
    # SQLite's write lock before it checks availability.
    try:
        with transaction.atomic():
            updated = BookInstance.objects.filter(
                pk=instance_id,
                status=BookInstance.LoanStatus.AVAILABLE,
            ).update(
                status=BookInstance.LoanStatus.RESERVED,
                borrower_id=user.pk,
            )
            if updated:
                Reservation.objects.create(
                    user=user,
                    instance_id=instance_id,
                    key=key,
                )
    except IntegrityError:
        # A concurrent request may have won the unique [user, key] insert.
        # Its committed row determines whether this was a replay or reuse.
        existing_result = _existing_key_result(user, instance_id, key)
        if existing_result is not None:
            return existing_result
        if not BookInstance.objects.filter(pk=instance_id).exists():
            return 'not_found'
        return 'unavailable'

    if updated:
        return 'success'

    existing_result = _existing_key_result(user, instance_id, key)
    if existing_result is not None:
        return existing_result
    if not BookInstance.objects.filter(pk=instance_id).exists():
        return 'not_found'
    return 'unavailable'


def reserve_available_instance(user, instance_id, key):
    """Reserve an available copy atomically, including on SQLite."""
    # SQLite serializes writers. Retry bounded "busy/locked" errors from reads,
    # conditional updates and commits so contention does not leak a 500 response.
    for attempt in range(3):
        try:
            return _reserve_once(user, instance_id, key)
        except OperationalError as error:
            if not _database_is_busy(error):
                raise
            if attempt < 2:
                time.sleep(0.05 * (2 ** attempt))
    return 'unavailable'
