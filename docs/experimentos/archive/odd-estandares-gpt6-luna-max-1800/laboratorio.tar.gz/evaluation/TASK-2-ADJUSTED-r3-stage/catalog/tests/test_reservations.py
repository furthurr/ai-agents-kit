import threading
from concurrent.futures import ThreadPoolExecutor

from django.contrib.auth import get_user_model
from django.db import (
    IntegrityError,
    close_old_connections,
    connection,
    connections,
    transaction,
)
from django.db.models import CASCADE
from django.test import Client, TestCase, TransactionTestCase
from django.urls import reverse

from catalog.models import Book, BookInstance


User = get_user_model()


class ReservationTestDataMixin:
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user(username="reader", password="test-pass")
        cls.other_user = User.objects.create_user(
            username="other-reader", password="test-pass"
        )
        cls.book = Book.objects.create(
            title="Reservation book",
            summary="A book for reservation tests.",
            isbn="RESERVE00001",
        )

    def create_instance(self, status=BookInstance.LoanStatus.AVAILABLE):
        return BookInstance.objects.create(
            book=self.book, imprint="Test imprint", status=status
        )

    def api_url(self, instance):
        return reverse("api-reserve-book-instance", kwargs={"pk": instance.pk})

    def web_url(self, instance):
        return reverse("reserve-book-instance", kwargs={"pk": instance.pk})


class ReservationModelTests(ReservationTestDataMixin, TestCase):
    def test_public_model_fields_and_user_scoped_idempotency_constraint(self):
        from catalog.models import Reservation

        instance = self.create_instance()
        first = Reservation.objects.create(
            user=self.user, instance=instance, key="shared-key"
        )
        other_user_reservation = Reservation.objects.create(
            user=self.other_user, instance=instance, key="shared-key"
        )

        self.assertIsNotNone(first.created_at)
        self.assertEqual(first._meta.get_field("key").max_length, 100)
        self.assertEqual(first.user_id, self.user.pk)
        self.assertEqual(first.instance_id, instance.pk)
        self.assertEqual(first._meta.get_field("user").remote_field.model, User)
        self.assertEqual(first._meta.get_field("user").remote_field.on_delete, CASCADE)
        self.assertEqual(
            first._meta.get_field("instance").remote_field.model, BookInstance
        )
        self.assertEqual(
            first._meta.get_field("instance").remote_field.on_delete, CASCADE
        )
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                Reservation.objects.create(
                    user=self.user, instance=instance, key="shared-key"
                )
        self.assertNotEqual(first.user_id, other_user_reservation.user_id)


class ReservationApiTests(ReservationTestDataMixin, TestCase):
    def setUp(self):
        self.client.force_login(self.user)

    def post_api(self, instance, key="request-key", client=None):
        return (client or self.client).post(
            self.api_url(instance), HTTP_IDEMPOTENCY_KEY=key
        )

    def assert_api_error(self, response, status, error):
        self.assertEqual(response.status_code, status)
        self.assertEqual(response.json(), {"error": error})

    def test_anonymous_request_is_unauthorized_before_key_validation(self):
        instance = self.create_instance()

        response = Client().post(self.api_url(instance))

        self.assert_api_error(response, 401, "unauthorized")
        instance.refresh_from_db()
        self.assertEqual(instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_only_post_is_allowed(self):
        instance = self.create_instance()

        url = self.api_url(instance)
        responses = [
            getattr(self.client, method)(url)
            for method in ("get", "head", "options", "put", "patch", "delete")
        ]

        self.assertEqual([response.status_code for response in responses], [405] * 6)
        instance.refresh_from_db()
        self.assertEqual(instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_missing_blank_and_overlong_idempotency_keys_are_rejected(self):
        instance = self.create_instance()
        url = self.api_url(instance)

        responses = [
            self.client.post(url),
            self.client.post(url, HTTP_IDEMPOTENCY_KEY="   "),
            self.client.post(url, HTTP_IDEMPOTENCY_KEY="k" * 101),
        ]

        for response in responses:
            self.assert_api_error(response, 400, "invalid_key")
        instance.refresh_from_db()
        self.assertEqual(instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(self.reservation_count(), 0)

    def test_trimmed_key_at_maximum_length_is_accepted(self):
        from catalog.models import Reservation

        instance = self.create_instance()
        key = "k" * 100

        response = self.client.post(
            self.api_url(instance), HTTP_IDEMPOTENCY_KEY=f"  {key}  "
        )

        self.assertEqual(response.status_code, 201)
        self.assertEqual(
            Reservation.objects.get(user=self.user, instance=instance).key, key
        )

    def test_nonexistent_instance_returns_not_found_without_reservation(self):
        import uuid

        response = self.client.post(
            reverse("api-reserve-book-instance", kwargs={"pk": uuid.uuid4()}),
            HTTP_IDEMPOTENCY_KEY="new-key",
        )

        self.assert_api_error(response, 404, "not_found")
        self.assertEqual(self.reservation_count(), 0)

    def test_unavailable_instance_returns_conflict_without_mutation(self):
        instance = self.create_instance(BookInstance.LoanStatus.ON_LOAN)

        response = self.post_api(instance)

        self.assert_api_error(response, 409, "unavailable")
        instance.refresh_from_db()
        self.assertEqual(instance.status, BookInstance.LoanStatus.ON_LOAN)
        self.assertIsNone(instance.borrower_id)
        self.assertEqual(self.reservation_count(), 0)

    def test_success_transitions_and_persists_exact_response(self):
        instance = self.create_instance()

        response = self.post_api(instance)

        self.assertEqual(response.status_code, 201)
        self.assertEqual(
            response.json(),
            {"instance_id": str(instance.pk), "user_id": self.user.pk, "status": "r"},
        )
        instance.refresh_from_db()
        self.assertEqual(instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(instance.borrower_id, self.user.pk)
        self.assertEqual(self.reservation_count(), 1)

    def test_same_key_and_instance_replays_across_a_new_http_session(self):
        instance = self.create_instance()
        first_response = self.post_api(instance, key="persistent-key")

        new_client = Client()
        new_client.force_login(User.objects.get(pk=self.user.pk))
        replay = self.post_api(instance, key="persistent-key", client=new_client)

        self.assertEqual(first_response.status_code, 201)
        self.assertEqual(replay.status_code, 201)
        self.assertEqual(replay.json(), first_response.json())
        self.assertEqual(self.reservation_count(), 1)

    def test_reusing_key_for_another_instance_conflicts_without_mutation(self):
        first_instance = self.create_instance()
        other_instance = self.create_instance()
        self.assertEqual(self.post_api(first_instance, key="one-key").status_code, 201)

        response = self.post_api(other_instance, key="one-key")

        self.assert_api_error(response, 409, "idempotency_conflict")
        other_instance.refresh_from_db()
        self.assertEqual(other_instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(other_instance.borrower_id)
        self.assertEqual(self.reservation_count(), 1)

    def test_same_key_is_independent_between_users(self):
        first_instance = self.create_instance()
        second_instance = self.create_instance()
        first = self.post_api(first_instance, key="per-user-key")
        self.client.force_login(self.other_user)

        second = self.post_api(second_instance, key="per-user-key")

        self.assertEqual(first.status_code, 201)
        self.assertEqual(second.status_code, 201)
        self.assertEqual(self.reservation_count(), 2)

    @staticmethod
    def reservation_count():
        from catalog.models import Reservation

        return Reservation.objects.count()


class ReservationWebTests(ReservationTestDataMixin, TestCase):
    def test_book_detail_shows_csrf_protected_form_for_each_available_instance(self):
        available = self.create_instance()
        self.create_instance(BookInstance.LoanStatus.MAINTENANCE)

        response = self.client.get(reverse("book-detail", kwargs={"pk": self.book.pk}))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'name="csrfmiddlewaretoken"')
        self.assertContains(response, 'name="idempotency_key"')
        self.assertRegex(
            response.content.decode(),
            r'name="idempotency_key" value="[0-9a-f]{32}"',
        )
        self.assertContains(response, self.web_url(available))
        self.assertEqual(response.content.decode().count('name="idempotency_key"'), 1)

    def test_anonymous_web_reservation_redirects_to_login_without_mutation(self):
        instance = self.create_instance()

        response = self.client.post(
            self.web_url(instance), {"idempotency_key": "browser-key"}
        )

        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith("/accounts/login/"))
        instance.refresh_from_db()
        self.assertEqual(instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_success_redirects_with_visible_confirmation(self):
        instance = self.create_instance()
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        detail_response = client.get(
            reverse("book-detail", kwargs={"pk": self.book.pk})
        )
        self.assertEqual(detail_response.status_code, 200)
        csrf_token = client.cookies["csrftoken"].value

        response = client.post(
            self.web_url(instance),
            {
                "idempotency_key": "browser-key",
                "csrfmiddlewaretoken": csrf_token,
            },
            HTTP_X_CSRFTOKEN=csrf_token,
            follow=True,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Reserva realizada correctamente.")
        instance.refresh_from_db()
        self.assertEqual(instance.status, BookInstance.LoanStatus.RESERVED)


class ReservationConcurrencyTests(ReservationTestDataMixin, TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        self.user = User.objects.create_user(username="reader", password="test-pass")
        self.other_user = User.objects.create_user(
            username="other-reader", password="test-pass"
        )
        self.book = Book.objects.create(
            title="Reservation book",
            summary="A book for reservation tests.",
            isbn="RESERVE00001",
        )

    def test_two_users_racing_for_one_sqlite_file_copy_get_one_success(self):
        self.assertEqual(connection.vendor, "sqlite")
        instance = self.create_instance()
        url = self.api_url(instance)
        start = threading.Barrier(2)
        clients = {}
        for user_id in (self.user.pk, self.other_user.pk):
            client = Client()
            client.force_login(User.objects.get(pk=user_id))
            clients[user_id] = client

        def reserve(user_id):
            close_old_connections()
            try:
                start.wait(timeout=10)
                response = clients[user_id].post(
                    url, HTTP_IDEMPOTENCY_KEY=f"key-{user_id}"
                )
                return response.status_code, response.json()
            finally:
                connections.close_all()

        with ThreadPoolExecutor(max_workers=2) as executor:
            responses = list(executor.map(reserve, [self.user.pk, self.other_user.pk]))

        self.assertEqual(sorted(status for status, _ in responses), [201, 409])
        conflict = next(body for status, body in responses if status == 409)
        self.assertEqual(conflict, {"error": "unavailable"})
        instance.refresh_from_db()
        self.assertEqual(instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIn(instance.borrower_id, [self.user.pk, self.other_user.pk])
        from catalog.models import Reservation

        self.assertEqual(Reservation.objects.filter(instance=instance).count(), 1)
