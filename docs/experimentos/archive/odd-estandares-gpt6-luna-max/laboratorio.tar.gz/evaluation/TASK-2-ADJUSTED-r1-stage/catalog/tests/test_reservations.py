import re
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor

from django.contrib.auth import get_user_model
from django.db import close_old_connections, connection
from django.test import Client, TestCase, TransactionTestCase

from catalog import models
from catalog.models import Book, BookInstance


User = get_user_model()


class ReservationAPITests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="reader", password="password")
        self.book = Book.objects.create(
            title="A reservable book",
            summary="A short summary",
            isbn="1234567890123",
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint="Test imprint",
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        self.api_url = f"/catalog/api/bookinstance/{self.instance.pk}/reserve/"
        self.web_url = f"/catalog/book/{self.instance.pk}/reserve/"

    def reservation_model(self):
        return getattr(models, "Reservation", None)

    def reservation_count(self):
        reservation_model = self.reservation_model()
        return reservation_model.objects.count() if reservation_model else 0

    def post_api(self, key=None, client=None, url=None):
        request_client = client or self.client
        headers = {} if key is None else {"HTTP_IDEMPOTENCY_KEY": key}
        return request_client.post(url or self.api_url, **headers)

    def assert_no_reservation_mutation(self, status=BookInstance.LoanStatus.AVAILABLE):
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, status)
        self.assertIsNone(self.instance.borrower_id)
        self.assertEqual(self.reservation_count(), 0)

    def test_reservation_model_has_public_fields_and_user_scoped_unique_key(self):
        reservation_model = self.reservation_model()
        self.assertIsNotNone(reservation_model)

        user_field = reservation_model._meta.get_field("user")
        self.assertEqual(user_field.remote_field.model, User)
        self.assertEqual(user_field.remote_field.on_delete.__name__, "CASCADE")
        instance_field = reservation_model._meta.get_field("instance")
        self.assertEqual(instance_field.remote_field.model, BookInstance)
        self.assertEqual(instance_field.remote_field.on_delete.__name__, "CASCADE")
        self.assertEqual(reservation_model._meta.get_field("key").max_length, 100)
        self.assertTrue(reservation_model._meta.get_field("created_at").auto_now_add)

        unique_pairs = [
            constraint.fields
            for constraint in reservation_model._meta.constraints
            if constraint.fields
        ]
        unique_pairs.extend(list(pair) for pair in reservation_model._meta.unique_together)
        self.assertIn(["user", "key"], unique_pairs)

    def test_api_rejects_anonymous_user_with_json_401_without_mutation(self):
        response = self.post_api(key="anonymous-key")
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {"error": "unauthorized"})
        self.assert_no_reservation_mutation()

    def test_api_allows_only_post(self):
        self.client.force_login(self.user)
        get_response = self.client.get(self.api_url)
        put_response = self.client.put(self.api_url)
        self.assertEqual(get_response.status_code, 405)
        self.assertEqual(put_response.status_code, 405)
        self.assert_no_reservation_mutation()

    def test_api_rejects_missing_blank_and_overlong_idempotency_keys(self):
        self.client.force_login(self.user)
        for key in (None, "", "  \t", "x" * 101):
            with self.subTest(key=key):
                response = self.post_api(key=key)
                self.assertEqual(response.status_code, 400)
                self.assertEqual(response.json(), {"error": "invalid_key"})
                self.assert_no_reservation_mutation()

    def test_api_returns_not_found_for_missing_instance(self):
        self.client.force_login(self.user)
        missing_url = f"/catalog/api/bookinstance/{uuid.uuid4()}/reserve/"
        response = self.post_api(key="missing-copy", url=missing_url)
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {"error": "not_found"})
        self.assertEqual(self.reservation_count(), 0)

    def test_api_returns_unavailable_without_mutating_a_nonavailable_instance(self):
        self.client.force_login(self.user)
        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.save(update_fields=["status"])

        response = self.post_api(key="unavailable-copy")

        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {"error": "unavailable"})
        self.assert_no_reservation_mutation(status=BookInstance.LoanStatus.ON_LOAN)

    def test_success_reserves_copy_and_replay_survives_a_new_http_session(self):
        self.client.force_login(self.user)
        expected = {
            "instance_id": str(self.instance.pk),
            "user_id": self.user.pk,
            "status": "r",
        }

        first_response = self.post_api(key="repeatable-key")
        self.assertEqual(first_response.status_code, 201)
        self.assertEqual(first_response.json(), expected)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)
        self.assertEqual(self.reservation_count(), 1)

        new_session = Client()
        new_session.force_login(self.user)
        replay_response = self.post_api(key="repeatable-key", client=new_session)
        self.assertEqual(replay_response.status_code, 201)
        self.assertEqual(replay_response.json(), expected)
        self.assertEqual(self.reservation_count(), 1)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)

    def test_reusing_key_for_another_copy_conflicts_without_mutation(self):
        self.client.force_login(self.user)
        second_copy = BookInstance.objects.create(
            book=self.book,
            imprint="Second imprint",
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        self.assertEqual(self.post_api(key="one-key").status_code, 201)

        second_url = f"/catalog/api/bookinstance/{second_copy.pk}/reserve/"
        response = self.post_api(key="one-key", url=second_url)

        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {"error": "idempotency_conflict"})
        second_copy.refresh_from_db()
        self.assertEqual(second_copy.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(second_copy.borrower_id)
        self.assertEqual(self.reservation_count(), 1)

    def test_same_key_is_independent_between_users(self):
        second_copy = BookInstance.objects.create(
            book=self.book,
            imprint="Second imprint",
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        self.client.force_login(self.user)
        first_response = self.post_api(key="shared-key")

        second_user = User.objects.create_user(username="another-reader", password="password")
        second_client = Client()
        second_client.force_login(second_user)
        second_url = f"/catalog/api/bookinstance/{second_copy.pk}/reserve/"
        second_response = self.post_api(key="shared-key", client=second_client, url=second_url)

        self.assertEqual(first_response.status_code, 201)
        self.assertEqual(second_response.status_code, 201)
        self.assertEqual(self.reservation_count(), 2)


class ReservationWebTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="reader", password="password")
        self.book = Book.objects.create(
            title="A reservable book",
            summary="A short summary",
            isbn="1234567890123",
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint="Test imprint",
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        self.detail_url = f"/catalog/book/{self.book.pk}"
        self.web_url = f"/catalog/book/{self.instance.pk}/reserve/"

    def test_book_detail_has_csrf_and_generated_key_form_only_for_available_copies(self):
        unavailable_copy = BookInstance.objects.create(
            book=self.book,
            imprint="Unavailable imprint",
            status=BookInstance.LoanStatus.ON_LOAN,
        )

        response = self.client.get(self.detail_url)

        self.assertEqual(response.status_code, 200)
        content = response.content.decode()
        self.assertContains(response, f'action="{self.web_url}"')
        self.assertEqual(content.count('name="idempotency_key"'), 1)
        self.assertEqual(content.count('name="csrfmiddlewaretoken"'), 1)
        generated_key = re.search(r'name="idempotency_key" value="([^"]+)"', content)
        self.assertIsNotNone(generated_key)
        uuid.UUID(generated_key.group(1))
        self.assertNotIn(f"/catalog/book/{unavailable_copy.pk}/reserve/", content)

    def test_web_post_redirects_anonymous_user_to_login_without_mutation(self):
        response = self.client.post(self.web_url, {"idempotency_key": str(uuid.uuid4())})
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith("/accounts/login/"))
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(self.instance.borrower_id)

    def test_web_post_reserves_and_shows_visible_confirmation(self):
        self.client.force_login(self.user)

        response = self.client.post(
            self.web_url,
            {"idempotency_key": str(uuid.uuid4())},
            follow=True,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Reservation confirmed")
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)

    def test_authenticated_web_post_requires_the_rendered_csrf_token(self):
        csrf_client = Client(enforce_csrf_checks=True)
        csrf_client.force_login(self.user)
        page = csrf_client.get(self.detail_url)
        self.assertEqual(page.status_code, 200)
        csrf_token = re.search(
            r'name="csrfmiddlewaretoken" value="([^"]+)"',
            page.content.decode(),
        ).group(1)

        response = csrf_client.post(
            self.web_url,
            {
                "idempotency_key": str(uuid.uuid4()),
                "csrfmiddlewaretoken": csrf_token,
            },
        )

        self.assertEqual(response.status_code, 302)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)


class ReservationConcurrencyTests(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        self.users = [
            User.objects.create_user(username="reader-one", password="password"),
            User.objects.create_user(username="reader-two", password="password"),
        ]
        book = Book.objects.create(
            title="A concurrent reservation",
            summary="A short summary",
            isbn="1234567890123",
        )
        self.instance = BookInstance.objects.create(
            book=book,
            imprint="Test imprint",
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        self.url = f"/catalog/api/bookinstance/{self.instance.pk}/reserve/"
        self.start = threading.Barrier(2)

    def reserve_as_user(self, user_id):
        close_old_connections()
        try:
            user = User.objects.get(pk=user_id)
            client = Client()
            client.force_login(user)
            self.start.wait(timeout=10)
            response = client.post(
                self.url,
                HTTP_IDEMPOTENCY_KEY=f"concurrent-{user_id}",
            )
            return response.status_code, response.json()
        finally:
            close_old_connections()

    def test_two_users_racing_on_sqlite_disk_get_one_success_and_one_unavailable(self):
        self.assertEqual(connection.vendor, "sqlite")
        self.assertNotEqual(connection.settings_dict["NAME"], ":memory:")

        with ThreadPoolExecutor(max_workers=2) as executor:
            responses = list(executor.map(self.reserve_as_user, [user.pk for user in self.users]))

        self.assertEqual(sorted(status for status, _ in responses), [201, 409])
        conflict = next(body for status, body in responses if status == 409)
        self.assertEqual(conflict, {"error": "unavailable"})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIn(self.instance.borrower_id, [user.pk for user in self.users])
        reservation_model = getattr(models, "Reservation", None)
        self.assertIsNotNone(reservation_model)
        self.assertEqual(reservation_model.objects.count(), 1)
