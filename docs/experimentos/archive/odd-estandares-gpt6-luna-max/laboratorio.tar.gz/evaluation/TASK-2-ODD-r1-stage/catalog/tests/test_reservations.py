import os
import re
import threading
from concurrent.futures import ThreadPoolExecutor
from uuid import uuid4

from django.apps import apps
from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.db import close_old_connections, connection, connections
from django.test import Client, TransactionTestCase
from django.urls import reverse

from catalog.models import Book, BookInstance


class ReservationFixtureMixin:
    def setUp(self):
        super().setUp()
        user_model = get_user_model()
        self.user = user_model.objects.create_user(
            username="reservation-user", password=None
        )
        self.other_user = user_model.objects.create_user(
            username="other-reservation-user", password=None
        )
        self.book = Book.objects.create(
            title="A reservable book",
            summary="A book used to test reservations.",
            isbn="9781234567890",
        )
        self.instance = self.create_instance()

    def create_instance(self, status=BookInstance.LoanStatus.AVAILABLE):
        return BookInstance.objects.create(
            book=self.book,
            imprint="Test imprint",
            status=status,
        )

    def api_url(self, instance=None):
        instance = instance or self.instance
        return f"/catalog/api/bookinstance/{instance.pk}/reserve/"

    def web_url(self, instance=None):
        instance = instance or self.instance
        return f"/catalog/book/{instance.pk}/reserve/"

    def logged_in_client(self, user=None):
        client = Client()
        client.force_login(user or self.user)
        return client


class ReservationEndpointTests(ReservationFixtureMixin, TransactionTestCase):
    def test_reservation_model_has_the_public_persistence_contract(self):
        reservation_model = apps.get_model("catalog", "Reservation")
        self.assertEqual(reservation_model._meta.get_field("key").max_length, 100)
        self.assertTrue(reservation_model._meta.get_field("created_at").auto_now_add)
        self.assertEqual(
            reservation_model._meta.get_field("user").remote_field.model,
            get_user_model(),
        )
        self.assertEqual(
            reservation_model._meta.get_field("instance").remote_field.model,
            BookInstance,
        )
        self.assertTrue(
            any(
                {"user", "key"} == set(constraint.fields)
                for constraint in reservation_model._meta.constraints
            )
        )

    def test_api_requires_authentication_and_returns_json_401(self):
        response = Client().post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY="anonymous-key"
        )
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {"error": "unauthorized"})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_api_only_accepts_post(self):
        client = self.logged_in_client()
        for method in (client.get, client.put):
            response = method(self.api_url())
            self.assertEqual(response.status_code, 405)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_api_rejects_missing_blank_and_overlong_keys_without_mutation(self):
        client = self.logged_in_client()
        responses = [
            client.post(self.api_url()),
            client.post(self.api_url(), HTTP_IDEMPOTENCY_KEY=" \t "),
            client.post(self.api_url(), HTTP_IDEMPOTENCY_KEY="k" * 101),
        ]
        for response in responses:
            self.assertEqual(response.status_code, 400)
            self.assertEqual(response.json(), {"error": "invalid_key"})

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(self.instance.borrower_id)
        self.assertEqual(apps.get_model("catalog", "Reservation").objects.count(), 0)

    def test_api_returns_not_found_without_creating_a_reservation(self):
        client = self.logged_in_client()
        response = client.post(
            f"/catalog/api/bookinstance/{uuid4()}/reserve/",
            HTTP_IDEMPOTENCY_KEY="missing-key",
        )
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {"error": "not_found"})
        self.assertEqual(apps.get_model("catalog", "Reservation").objects.count(), 0)

    def test_unavailable_instance_returns_conflict_without_a_reservation(self):
        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.borrower = self.other_user
        self.instance.save()

        response = self.logged_in_client().post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY="unavailable-key"
        )
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {"error": "unavailable"})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.ON_LOAN)
        self.assertEqual(self.instance.borrower_id, self.other_user.pk)
        self.assertEqual(apps.get_model("catalog", "Reservation").objects.count(), 0)

    def test_success_persists_reservation_and_replay_survives_a_new_session(self):
        reservation_model = apps.get_model("catalog", "Reservation")
        key = "persisted-replay-key"
        response = self.logged_in_client().post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY=key
        )
        expected = {
            "instance_id": str(self.instance.pk),
            "user_id": self.user.pk,
            "status": "r",
        }
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), expected)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)
        self.assertEqual(
            reservation_model.objects.filter(user=self.user, key=key).count(), 1
        )

        connections.close_all()
        replay = self.logged_in_client().post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY=key
        )
        self.assertEqual(replay.status_code, 201)
        self.assertEqual(replay.json(), expected)
        self.assertEqual(
            reservation_model.objects.filter(user=self.user, key=key).count(), 1
        )
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)

    def test_reusing_a_key_for_another_instance_conflicts_without_mutation(self):
        reservation_model = apps.get_model("catalog", "Reservation")
        another_instance = self.create_instance()
        client = self.logged_in_client()
        first = client.post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY="shared-key"
        )
        self.assertEqual(first.status_code, 201)

        response = client.post(
            self.api_url(another_instance), HTTP_IDEMPOTENCY_KEY="shared-key"
        )
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {"error": "idempotency_conflict"})
        another_instance.refresh_from_db()
        self.assertEqual(
            another_instance.status, BookInstance.LoanStatus.AVAILABLE
        )
        self.assertIsNone(another_instance.borrower_id)
        self.assertEqual(reservation_model.objects.filter(key="shared-key").count(), 1)

    def test_same_key_is_independent_for_different_users(self):
        reservation_model = apps.get_model("catalog", "Reservation")
        another_instance = self.create_instance()
        first = self.logged_in_client(self.user).post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY="per-user-key"
        )
        second = self.logged_in_client(self.other_user).post(
            self.api_url(another_instance), HTTP_IDEMPOTENCY_KEY="per-user-key"
        )
        self.assertEqual(first.status_code, 201)
        self.assertEqual(second.status_code, 201)
        self.assertEqual(
            reservation_model.objects.filter(key="per-user-key").count(), 2
        )

    def test_book_detail_has_csrf_idempotency_forms_and_web_reservation_confirms(self):
        second_instance = self.create_instance()
        detail_url = reverse("book-detail", args=[self.book.pk])
        page = Client().get(detail_url)
        self.assertEqual(page.status_code, 200)
        page_html = page.content.decode()
        self.assertIn(self.web_url(), page_html)
        self.assertIn(self.web_url(second_instance), page_html)
        self.assertEqual(page_html.count('name="idempotency_key"'), 2)
        self.assertIn('name="csrfmiddlewaretoken"', page_html)
        self.assertRegex(
            page_html,
            re.compile(r'name="idempotency_key" value="[^"]+"'),
        )

        anonymous = Client().post(
            self.web_url(), {"idempotency_key": "web-key"}
        )
        self.assertEqual(anonymous.status_code, 302)
        self.assertTrue(anonymous.url.startswith("/accounts/login/"))

        client = Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        client.get(detail_url)
        csrf_token = client.cookies[settings.CSRF_COOKIE_NAME].value
        response = client.post(
            self.web_url(),
            {
                "idempotency_key": "web-reservation-key",
                "csrfmiddlewaretoken": csrf_token,
            },
            HTTP_X_CSRFTOKEN=csrf_token,
        )
        self.assertRedirects(response, detail_url)
        confirmation = client.get(response.url)
        self.assertContains(confirmation, "Reservation confirmed")
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)


class ReservationConcurrencyTests(ReservationFixtureMixin, TransactionTestCase):
    def setUp(self):
        self.original_database_settings = connections.databases["default"].copy()
        self.disk_database_name = os.path.join(
            settings.BASE_DIR, f".test-reservation-{uuid4()}.sqlite3"
        )
        connections.close_all()
        connections.databases["default"]["NAME"] = self.disk_database_name
        try:
            del connections._connections.default
        except AttributeError:
            pass
        call_command("migrate", database="default", interactive=False, verbosity=0)
        super().setUp()

    def _post_teardown(self):
        try:
            super()._post_teardown()
        finally:
            connections.close_all()
            try:
                del connections._connections.default
            except AttributeError:
                pass
            connections.databases["default"].clear()
            connections.databases["default"].update(self.original_database_settings)
            if os.path.exists(self.disk_database_name):
                os.remove(self.disk_database_name)

    def test_two_users_racing_for_one_copy_get_one_success_and_one_unavailable(self):
        self.assertEqual(connection.vendor, "sqlite")
        self.assertTrue(
            os.path.isfile(connection.settings_dict["NAME"]),
            connection.settings_dict["NAME"],
        )
        clients = []
        for user in (self.user, self.other_user):
            client = self.logged_in_client(user)
            clients.append(client.cookies[settings.SESSION_COOKIE_NAME].value)

        start = threading.Barrier(2)

        def reserve(session_key):
            close_old_connections()
            try:
                client = Client()
                client.cookies[settings.SESSION_COOKIE_NAME] = session_key
                start.wait(timeout=10)
                response = client.post(
                    self.api_url(),
                    HTTP_IDEMPOTENCY_KEY=f"concurrent-{session_key}",
                )
                return response.status_code, response.json()
            finally:
                connections.close_all()

        with ThreadPoolExecutor(max_workers=2) as executor:
            responses = list(executor.map(reserve, clients))

        self.assertEqual(sorted(status for status, _ in responses), [201, 409])
        errors = [payload for status, payload in responses if status == 409]
        successes = [payload for status, payload in responses if status == 201]
        self.assertEqual(errors, [{"error": "unavailable"}])
        self.assertEqual(
            successes[0]["instance_id"], str(self.instance.pk)
        )
        self.assertEqual(successes[0]["status"], "r")
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(
            apps.get_model("catalog", "Reservation").objects.filter(
                instance=self.instance
            ).count(),
            1,
        )
