import json
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor

from django.contrib.auth import get_user_model
from django.db import IntegrityError, close_old_connections, connection, transaction
from django.test import Client, RequestFactory, TestCase, TransactionTestCase
from django.urls import reverse

from catalog.models import Book, BookInstance, Reservation
from catalog.views import api_reserve_bookinstance


User = get_user_model()


def make_book_instance(status=BookInstance.LoanStatus.AVAILABLE):
    book = Book.objects.create(
        title=f'Reservation {uuid.uuid4()}',
        summary='Reservation test book',
        isbn=str(uuid.uuid4().int)[:13],
    )
    return BookInstance.objects.create(book=book, imprint='Test imprint', status=status)


class ReservationModelTests(TestCase):
    def test_public_model_fields_and_user_scoped_unique_key(self):
        user_field = Reservation._meta.get_field('user')
        instance_field = Reservation._meta.get_field('instance')
        key_field = Reservation._meta.get_field('key')
        created_at_field = Reservation._meta.get_field('created_at')

        self.assertEqual(user_field.remote_field.model, User)
        self.assertEqual(user_field.remote_field.on_delete.__name__, 'CASCADE')
        self.assertEqual(instance_field.remote_field.model, BookInstance)
        self.assertEqual(instance_field.remote_field.on_delete.__name__, 'CASCADE')
        self.assertEqual(key_field.max_length, 100)
        self.assertTrue(created_at_field.auto_now_add)

        user = User.objects.create_user(username='reservation-owner')
        another_user = User.objects.create_user(username='another-owner')
        first_instance = make_book_instance()
        second_instance = make_book_instance()
        Reservation.objects.create(user=user, instance=first_instance, key='same-key')

        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                Reservation.objects.create(user=user, instance=second_instance, key='same-key')

        Reservation.objects.create(user=another_user, instance=second_instance, key='same-key')


class ReservationApiTests(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        self.user = User.objects.create_user(username='api-reserver')
        self.other_user = User.objects.create_user(username='other-api-reserver')
        self.instance = make_book_instance()
        self.other_instance = make_book_instance()
        self.url = reverse('api-bookinstance-reserve', kwargs={'pk': self.instance.pk})
        self.client.force_login(self.user)

    def post_reservation(self, url=None, key='request-key', client=None):
        return (client or self.client).post(
            url or self.url,
            **({'HTTP_IDEMPOTENCY_KEY': key} if key is not None else {}),
        )

    def test_requires_authentication_and_does_not_mutate(self):
        response = Client().post(self.url, HTTP_IDEMPOTENCY_KEY='request-key')

        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(self.instance.borrower_id)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_only_post_is_allowed(self):
        self.assertEqual(self.client.get(self.url).status_code, 405)
        self.assertEqual(self.client.put(self.url, data='{}', content_type='application/json').status_code, 405)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_rejects_missing_blank_and_overlong_idempotency_keys_without_mutation(self):
        for key in (None, '', '   ', 'x' * 101):
            with self.subTest(key=key):
                response = self.post_reservation(key=key)
                self.assertEqual(response.status_code, 400)
                self.assertEqual(response.json(), {'error': 'invalid_key'})
                self.instance.refresh_from_db()
                self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
                self.assertEqual(Reservation.objects.count(), 0)

    def test_missing_instance_returns_not_found_without_mutation(self):
        missing_url = reverse('api-bookinstance-reserve', kwargs={'pk': uuid.uuid4()})

        response = self.post_reservation(url=missing_url)

        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})
        self.assertEqual(Reservation.objects.count(), 0)

    def test_unavailable_instance_returns_conflict_without_creating_reservation(self):
        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.borrower = self.other_user
        self.instance.save()

        response = self.post_reservation()

        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.ON_LOAN)
        self.assertEqual(self.instance.borrower, self.other_user)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_reserves_available_instance_and_persists_trimmed_key(self):
        response = self.post_reservation(key='  request-key  ')

        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), {
            'instance_id': str(self.instance.pk),
            'user_id': self.user.pk,
            'status': 'r',
        })
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower, self.user)
        self.assertEqual(Reservation.objects.get().key, 'request-key')

    def test_same_key_and_instance_replays_after_connection_and_session_change(self):
        first_response = self.post_reservation(key='persistent-key')
        self.assertEqual(first_response.status_code, 201)

        another_session = Client()
        another_session.force_login(self.user)
        connection.close()
        replay = self.post_reservation(key='persistent-key', client=another_session)

        self.assertEqual(replay.status_code, 201)
        self.assertEqual(replay.json(), first_response.json())
        self.assertEqual(Reservation.objects.filter(user=self.user, key='persistent-key').count(), 1)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower, self.user)

    def test_reusing_key_for_another_instance_conflicts_without_mutation(self):
        self.assertEqual(self.post_reservation(key='reused-key').status_code, 201)
        other_url = reverse('api-bookinstance-reserve', kwargs={'pk': self.other_instance.pk})

        response = self.post_reservation(url=other_url, key='reused-key')

        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'idempotency_conflict'})
        self.other_instance.refresh_from_db()
        self.assertEqual(self.other_instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(self.other_instance.borrower_id)
        self.assertEqual(Reservation.objects.filter(user=self.user, key='reused-key').count(), 1)


class ReservationWebTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='web-reserver')
        self.instance = make_book_instance()
        self.unavailable_instance = make_book_instance(status=BookInstance.LoanStatus.ON_LOAN)
        self.book_url = reverse('book-detail', kwargs={'pk': self.instance.book_id})
        self.reserve_url = reverse('bookinstance-reserve', kwargs={'instance_pk': self.instance.pk})

    def test_book_detail_includes_csrf_form_and_generated_key_for_each_available_copy(self):
        self.client.force_login(self.user)

        response = self.client.get(self.book_url)

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, f'action="{self.reserve_url}"')
        self.assertContains(response, 'name="csrfmiddlewaretoken"')
        self.assertRegex(response.content.decode(), r'name="idempotency_key" value="[a-f0-9-]+"')
        self.assertNotContains(response, f'action="{reverse("bookinstance-reserve", kwargs={"instance_pk": self.unavailable_instance.pk})}"')

    def test_anonymous_reservation_post_redirects_to_login_without_mutation(self):
        response = self.client.post(self.reserve_url, {'idempotency_key': uuid.uuid4().hex})

        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/'))
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_successful_web_reservation_shows_visible_confirmation(self):
        self.client.force_login(self.user)

        response = self.client.post(
            self.reserve_url,
            {'idempotency_key': uuid.uuid4().hex},
            follow=True,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Reservation confirmed')
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower, self.user)
        self.assertEqual(Reservation.objects.count(), 1)


class ReservationConcurrencyTests(TransactionTestCase):
    reset_sequences = True

    def test_two_users_racing_for_one_available_copy_have_one_winner(self):
        users = [
            User.objects.create_user(username='racing-reserver-1'),
            User.objects.create_user(username='racing-reserver-2'),
        ]
        instance = make_book_instance()
        request_path = reverse('api-bookinstance-reserve', kwargs={'pk': instance.pk})
        barrier = threading.Barrier(2)

        def reserve_for_user(user_id):
            close_old_connections()
            try:
                user = User.objects.get(pk=user_id)
                request = RequestFactory().post(
                    request_path,
                    HTTP_IDEMPOTENCY_KEY='simultaneous-request',
                )
                request.user = user
                barrier.wait(timeout=10)
                response = api_reserve_bookinstance(request, instance.pk)
                return response.status_code, json.loads(response.content)
            finally:
                close_old_connections()

        with ThreadPoolExecutor(max_workers=2) as executor:
            outcomes = list(executor.map(reserve_for_user, [user.pk for user in users]))

        successes = [payload for status, payload in outcomes if status == 201]
        conflicts = [payload for status, payload in outcomes if status == 409]
        self.assertEqual(len(successes), 1)
        self.assertEqual(conflicts, [{'error': 'unavailable'}])
        self.assertEqual(set(successes[0]), {'instance_id', 'user_id', 'status'})
        self.assertEqual(successes[0]['instance_id'], str(instance.pk))
        self.assertEqual(successes[0]['status'], 'r')
        self.assertIn(successes[0]['user_id'], [user.pk for user in users])

        instance.refresh_from_db()
        self.assertEqual(instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(instance.borrower_id, successes[0]['user_id'])
        self.assertEqual(Reservation.objects.filter(instance=instance).count(), 1)
