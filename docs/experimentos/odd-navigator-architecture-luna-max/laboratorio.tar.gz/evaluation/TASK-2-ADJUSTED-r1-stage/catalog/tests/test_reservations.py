import re
import uuid
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier

from django.contrib.auth import get_user_model
from django.db import IntegrityError, close_old_connections, connection, transaction
from django.test import Client, TransactionTestCase
from django.urls import reverse

from catalog.models import Author, Book, BookInstance, Genre, Language


User = get_user_model()


class ReservationFlowTests(TransactionTestCase):
    """Tests for reservation persistence, endpoints, UI and SQLite races."""

    reset_sequences = True

    def setUp(self):
        self.user = User.objects.create_user(username='reader-one')
        self.other_user = User.objects.create_user(username='reader-two')
        author = Author.objects.create(first_name='Test', last_name='Author')
        language = Language.objects.create(name='Test language')
        genre = Genre.objects.create(name='Test genre')
        self.book = Book.objects.create(
            title='Reservable book',
            summary='A book used to test reservations.',
            isbn='TESTRESERVE01',
            author=author,
            language=language,
        )
        self.book.genre.add(genre)
        self.instance = self.make_instance()
        self.other_instance = self.make_instance()

    def make_instance(self, status=BookInstance.LoanStatus.AVAILABLE):
        return BookInstance.objects.create(
            book=self.book,
            imprint='Test imprint',
            status=status,
        )

    @staticmethod
    def api_path(instance_id):
        return f'/catalog/api/bookinstance/{instance_id}/reserve/'

    @staticmethod
    def web_path(instance_id):
        return f'/catalog/book/{instance_id}/reserve/'

    def authenticated_client(self, user=None):
        client = Client()
        client.force_login(user or self.user)
        return client

    def test_reservation_model_has_user_scoped_unique_keys(self):
        from catalog.models import Reservation

        first = Reservation.objects.create(
            user=self.user, instance=self.instance, key='shared-key'
        )
        self.assertIsNotNone(first.created_at)

        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                Reservation.objects.create(
                    user=self.user, instance=self.other_instance, key='shared-key'
                )

        other_user_reservation = Reservation.objects.create(
            user=self.other_user, instance=self.other_instance, key='shared-key'
        )
        self.assertEqual(other_user_reservation.key, first.key)

    def test_api_requires_auth_and_only_accepts_post(self):
        anonymous = Client()
        response = anonymous.post(
            self.api_path(self.instance.pk), HTTP_IDEMPOTENCY_KEY='request-1'
        )
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

        client = self.authenticated_client()
        for method in ('get', 'put', 'delete'):
            response = getattr(client, method)(self.api_path(self.instance.pk))
            self.assertEqual(response.status_code, 405)

        csrf_enforcing_client = Client(enforce_csrf_checks=True)
        response = csrf_enforcing_client.post(
            self.api_path(self.instance.pk), HTTP_IDEMPOTENCY_KEY='request-2'
        )
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})
        response = csrf_enforcing_client.put(self.api_path(self.instance.pk))
        self.assertEqual(response.status_code, 405)

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertFalse(self.reservation_exists())

    def test_api_rejects_missing_blank_and_overlong_keys_without_mutation(self):
        client = self.authenticated_client()
        invalid_headers = ({}, {'HTTP_IDEMPOTENCY_KEY': ''},
                           {'HTTP_IDEMPOTENCY_KEY': '   '},
                           {'HTTP_IDEMPOTENCY_KEY': 'k' * 101})

        for headers in invalid_headers:
            response = client.post(self.api_path(self.instance.pk), **headers)
            self.assertEqual(response.status_code, 400)
            self.assertEqual(response.json(), {'error': 'invalid_key'})

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertFalse(self.reservation_exists())

    def test_api_returns_not_found_for_unknown_instance_without_mutation(self):
        response = self.authenticated_client().post(
            self.api_path(uuid.uuid4()), HTTP_IDEMPOTENCY_KEY='missing-instance'
        )
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})
        self.assertFalse(self.reservation_exists())

    def test_api_unavailable_conflict_does_not_create_reservation(self):
        unavailable = self.make_instance(status=BookInstance.LoanStatus.ON_LOAN)
        response = self.authenticated_client().post(
            self.api_path(unavailable.pk), HTTP_IDEMPOTENCY_KEY='unavailable'
        )

        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        unavailable.refresh_from_db()
        self.assertEqual(unavailable.status, BookInstance.LoanStatus.ON_LOAN)
        self.assertIsNone(unavailable.borrower_id)
        self.assertFalse(self.reservation_exists())

    def test_api_success_replays_from_a_new_session_without_duplicate_rows(self):
        from catalog.models import Reservation

        response = self.authenticated_client().post(
            self.api_path(self.instance.pk), HTTP_IDEMPOTENCY_KEY='stable-key'
        )
        expected = {
            'instance_id': str(self.instance.pk),
            'user_id': self.user.pk,
            'status': 'r',
        }
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), expected)

        connection.close()
        replay_client = self.authenticated_client()
        replay = replay_client.post(
            self.api_path(self.instance.pk), HTTP_IDEMPOTENCY_KEY=' stable-key '
        )
        self.assertEqual(replay.status_code, 201)
        self.assertEqual(replay.json(), expected)
        self.assertEqual(
            Reservation.objects.filter(user=self.user, key='stable-key').count(), 1
        )
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)

    def test_api_key_conflict_is_user_scoped_and_does_not_reserve_other_instance(self):
        from catalog.models import Reservation

        client = self.authenticated_client()
        first = client.post(
            self.api_path(self.instance.pk), HTTP_IDEMPOTENCY_KEY='reused-key'
        )
        self.assertEqual(first.status_code, 201)

        conflict = client.post(
            self.api_path(self.other_instance.pk), HTTP_IDEMPOTENCY_KEY='reused-key'
        )
        self.assertEqual(conflict.status_code, 409)
        self.assertEqual(conflict.json(), {'error': 'idempotency_conflict'})
        self.other_instance.refresh_from_db()
        self.assertEqual(self.other_instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(Reservation.objects.count(), 1)

        other_user_response = self.authenticated_client(self.other_user).post(
            self.api_path(self.other_instance.pk),
            HTTP_IDEMPOTENCY_KEY='reused-key',
        )
        self.assertEqual(other_user_response.status_code, 201)
        self.assertEqual(Reservation.objects.count(), 2)

    def test_book_detail_renders_csrf_and_unique_key_only_for_available_copies(self):
        self.other_instance.status = BookInstance.LoanStatus.RESERVED
        self.other_instance.save(update_fields=['status'])
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.user)

        response = client.get(reverse('book-detail', kwargs={'pk': self.book.pk}))
        self.assertEqual(response.status_code, 200)
        body = response.content.decode()
        self.assertIn(f'action="{self.web_path(self.instance.pk)}"', body)
        self.assertNotIn(f'action="{self.web_path(self.other_instance.pk)}"', body)
        self.assertRegex(body, r'name="csrfmiddlewaretoken" value="[^"]+"')
        self.assertRegex(body, r'name="idempotency_key" value="[0-9a-f]{32}"')

    def test_web_reservation_requires_login_and_shows_success_message(self):
        anonymous = Client()
        response = anonymous.post(
            self.web_path(self.instance.pk), {'idempotency_key': 'web-key'}
        )
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/'))

        client = Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        detail = client.get(reverse('book-detail', kwargs={'pk': self.book.pk}))
        csrf_token = re.search(
            r'name="csrfmiddlewaretoken" value="([^"]+)"',
            detail.content.decode(),
        ).group(1)
        response = client.post(
            self.web_path(self.instance.pk),
            {'idempotency_key': 'web-key', 'csrfmiddlewaretoken': csrf_token},
            follow=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Reservation confirmed.')
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)

    def test_concurrent_users_can_only_reserve_an_available_copy_once(self):
        self.assertEqual(connection.vendor, 'sqlite')
        self.assertNotEqual(connection.settings_dict['NAME'], ':memory:')
        barrier = Barrier(2)
        clients = [
            self.authenticated_client(self.user),
            self.authenticated_client(self.other_user),
        ]

        def reserve(client, key):
            close_old_connections()
            try:
                barrier.wait(timeout=10)
                response = client.post(
                    self.api_path(self.instance.pk), HTTP_IDEMPOTENCY_KEY=key
                )
                return response.status_code, response.json()
            finally:
                close_old_connections()

        with ThreadPoolExecutor(max_workers=2) as executor:
            futures = [
                executor.submit(reserve, clients[0], 'parallel-one'),
                executor.submit(reserve, clients[1], 'parallel-two'),
            ]
            results = [future.result(timeout=20) for future in futures]

        self.assertEqual(sorted(status for status, _ in results), [201, 409])
        self.assertEqual(
            next(body for status, body in results if status == 409),
            {'error': 'unavailable'},
        )
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, next(
            body['user_id'] for status, body in results if status == 201
        ))
        self.assertEqual(self.reservation_count(), 1)

    def test_concurrent_retries_with_the_same_key_replay_one_reservation(self):
        barrier = Barrier(2)
        clients = [self.authenticated_client(), self.authenticated_client()]

        def reserve(client):
            close_old_connections()
            try:
                barrier.wait(timeout=10)
                response = client.post(
                    self.api_path(self.instance.pk),
                    HTTP_IDEMPOTENCY_KEY='parallel-replay',
                )
                return response.status_code, response.json()
            finally:
                close_old_connections()

        with ThreadPoolExecutor(max_workers=2) as executor:
            futures = [executor.submit(reserve, client) for client in clients]
            results = [future.result(timeout=20) for future in futures]

        expected = {
            'instance_id': str(self.instance.pk),
            'user_id': self.user.pk,
            'status': 'r',
        }
        self.assertEqual([status for status, _ in results], [201, 201])
        self.assertEqual([body for _, body in results], [expected, expected])
        self.assertEqual(self.reservation_count(), 1)
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)

    @staticmethod
    def reservation_exists():
        from catalog.models import Reservation

        return Reservation.objects.exists()

    @staticmethod
    def reservation_count():
        from catalog.models import Reservation

        return Reservation.objects.count()
