# Resumen de Preparación y Correcciones — Build 02

## 1. Preservación y Gestión de Historial
- Se preservaron íntegramente los drafts del intento anterior (`runner.py`, `test_runner.py`, `build-summary.md` y `oracle-validation.json`) en el directorio inmutable `preparation-history/build-01/`.
- No se sobrescribieron ni eliminaron ejecuciones, trazas previas ni perfiles históricos (`profiles/` permanece como draft de build-01).

## 2. Corrección Integral de Oráculos
Se resolvieron los falsos claims y limitaciones de los oráculos:
1. **Configuración de persistencia SQLite en disco para T2 (`oracles/eval_settings.py`)**:
   - Se configuró la clave de prueba de Django `DATABASES['default']['TEST']['NAME']` conectada a una ruta de archivo SQLite en disco única por evaluación provista mediante variable de entorno (`EVAL_TEST_DB_FILE`).
   - Se validó en pruebas concurrentes que la base de datos no es `:memory:` y que el archivo existe en disco.
   - En `test_oracle_task2.py` se implementaron capturas de excepciones en hilos, barreras con timeout (`timeout=10`), aserción estricta de que los hilos terminan (`not is_alive()`), cierre explícito de conexiones y pruebas de replay idempotente con instancias nuevas de conexión y claves compartidas entre distintos usuarios/instancias.
2. **Pruebas de migración reales para T3 (`oracles/test_oracle_task3_migration.py`)**:
   - Reescrito con `MigrationExecutor` de Django: migra hacia atrás al estado base `0029_alter_genre_options_alter_language_options`, siembra datos de prueba en modelos históricos (Author, Book, BookInstance, User) con sus campos y relaciones, migra hacia adelante a las migraciones hoja, y comprueba que los IDs y estados se conservan con asignación a la sucursal `CENTRAL`.
   - Incluye prueba adicional de transición de Fase 1 a Fase 2 (`0031_seed_central_branch` a hojas finales) verificando que datos de sucursales creadas en etapa 1 sobreviven a la migración final. Bloque `finally` garantiza la restauración limpia del estado de migraciones.
3. **Aislamiento y autorización de sucursales (`oracles/test_oracle_task3_stage1.py` y `test_oracle_task3_final.py`)**:
   - Se añadieron pruebas negativas para accesos directos cross-branch en renovación (`views.renew_book_librarian`) y listado general de préstamos (`views.LoanedBooksAllListView`), validando que un usuario staff con permiso `can_mark_returned` en una sucursal recibe `403 Forbidden` al intentar renovar ejemplares de otra sucursal y no observa préstamos ajenos.
   - Respeto del contrato: se utiliza `membership.is_staff=True` para determinar privilegios locales de sucursal, sin exigir `User.is_staff=True` global de Django.
4. **Validaciones robustas para T1 (`oracles/test_oracle_task1.py`)**:
   - Se agregaron verificaciones de autores nulos (`author=None`), ordenamiento de géneros alfabéticamente en serialización JSON, descarte de duplicados de copias (`status='a'`), recorte de espacios en blanco (`trim`), desempate determinista por `(title, id)` y paginación exacta.
   - Se añadieron validaciones de accesibilidad (etiquetas de formulario `label` / `aria-label`) y parsing de parámetros de búsqueda en los enlaces de paginación HTML.
5. **Cero crash en imports en baseline**:
   - Se reemplazaron imports directos estáticos a nivel de módulo en los oráculos por descubrimientos dinámicos con `apps.get_model('catalog', ...)`. Cuando un modelo o endpoint no existe en baseline, las pruebas fallan con aserciones semánticas (`self.fail`) o comprobaciones HTTP 404 vs respuesta esperada, sin crashear la carga del módulo de pruebas de Django.

## 3. Perfiles de Agentes Corregidos (`profiles-v2/`)
- Se implementó `profiles-v2/` con agentes `Developer` y `SDD` que replican el cuerpo completo de `generated/opencode/agents/{developer,sdd}.md`.
- El tratamiento `ODD` conserva la especificación histórica exacta de `docs/experimentos/odd-vs-sdd-2026-11-04/tratamiento-b.md`.
- Se corrigió el namespace a `rpdev`, `rpsdd` y `rpodd` (sin guiones bajos no válidos).
- Sustitución estricta de nombres en frontmatter y tokens identificadores entre backticks, sin `str.replace` global indiscriminado.
- Política de permisos:
  - `read`: restringido a workspace y árbol de skills del perfil (`profiles-v2/<arm>/skills`), más baseline docs. Se deniegan explícitamente secretos y las soluciones/oráculos (`root/oracles`, `root/references`). Las referencias internas metodológicas del perfil (`profiles-v2/.../skills/.../references/`) se mantienen accesibles.
  - `edit`: permite edición amplia en el workspace de la celda y deniega explícitamente rutas de host (`baseline`, `oracles`, `references`, `profiles`, secretos, `AGENTS.md`, `TASK.md`).
  - Herramientas prohibidas denegadas explícitamente: `task`, `webfetch`, `websearch`, `google_search`, `antigravity_quota`.

## 4. Arnés del Benchmark Funcional (`runner.py`)
- Se implementó `run_cells` completo con paralelismo simétrico `ThreadPoolExecutor(max_workers=3)` y diseño contrabalanceado en bloques rotados.
- Soporte para invocaciones reales mediante `kit_bench.invoke`, captura inmediata de trazas saneadas por cada invocación en `traces/<label>.json`, métricas de tokens/costo por turno y registro final en `records/<label>.json`.
- Aislamiento de evaluación en copia independiente `evaluation/<label>-stage`, restaurando tests de baseline para garantizar que ningún test oculto quede en el workspace del agente y que los oráculos se ejecuten de forma desacoplada con SQLite en disco.
- Reanudación genuina en T3: Fase 1 ejecuta en sesión nueva independiente; al finalizar Fase 1, se abre una sesión nueva e independiente para Fase 2 partiendo del disco y artefactos dejados en Fase 1, sin transferencia de contexto de chat.
- Lógica de simulación de gates:
  - SDD: recomendación natural de profundidad (Direct / SDD-Tiny / SDD-Lite). Aprobación en Gate 3 sólo tras spec formal. Aprobación en Gate 4 sólo ante evidencia verde observada en ejecuciones reales de pruebas (`green_observed`).
  - Detección de cierres prematuros de Gate 4 (`premature_close`) y detención sin autoaprobación de decisiones funcionales nuevas.
- `freeze` y `check_frozen`: verificación de hashes de todas las fuentes de entrada (`runner.py`, `test_runner.py`, `cases.json`, `protocol.md`, `baseline`, `oracles`, `references`, `profiles-v2`).

## 5. Pruebas Unitarias Offline (`test_runner.py`)
Se implementó `test_runner.py` con 8 pruebas unitarias offline completas:
1. `test_agent_body_equivalence_and_token_namespaces`: Verifica que los prompts de Developer, SDD y ODD preservan el cuerpo completo original y usan los namespaces normalizados `rpdev`/`rpsdd`/`rpodd`.
2. `test_profiles_draft_preserved_and_not_overwritten`: Comprueba que los borradores de build-01 y carpetas anteriores no se sobrescribieron.
3. `test_policy_boundaries_and_denials`: Valida allowlists/denylists y denegación de secretos y herramientas no autorizadas.
4. `test_simulated_gates_parsers`: Comprueba el parser de recomendación de modo SDD y la detección de cierre prematuro.
5. `test_oracle_eval_settings_disk_sqlite`: Verifica la configuración de base de datos de test en disco SQLite para evaluaciones.
6. `test_oracle_validation_v2_results`: Verifica el cumplimiento de todos los oráculos en `oracle-validation-v2.json`.
7. `test_source_inputs_and_freeze_drift_check`: Comprueba la integridad del inventario de entradas para el freeze.
8. `test_configuration_keys_and_schema`: Valida la estructura y parámetros del archivo de configuración para OpenCode.

Todas las 8 pruebas offline pasan al 100% (OK).

## 6. Validación de Referencias y Baseline (`oracle-validation-v2.json`)
Se revalidaron todas las referencias frente a los oráculos actualizados y la suite preexistente:
- `baseline`: 43 tests originales OK (retcode 0).
- `baseline_oracle_task1`: Falla como esperado (7 fallos, retcode 1, comportamiento ausente).
- `baseline_oracle_task2`: Falla como esperado (9 fallos, retcode 1, comportamiento ausente sin crash import).
- `baseline_oracle_task3_stage1`: Falla como esperado (4 fallos, retcode 1, comportamiento ausente sin crash import).
- `baseline_oracle_task3_migration`: Falla como esperado (1 fallo, retcode 1, modelo ausente sin crash import).
- `references/TASK-1`: 50 tests OK (43 originales + 7 oráculo, retcode 0).
- `references/TASK-2`: 52 tests OK (43 originales + 9 oráculo con SQLite en disco, retcode 0).
- `references/TASK-3-stage1`: 49 tests OK (43 originales + 4 stage1 + 2 migración, retcode 0).
- `references/TASK-3-final`: 53 tests OK (43 originales + 4 stage1 + 4 final + 2 migración, retcode 0).
