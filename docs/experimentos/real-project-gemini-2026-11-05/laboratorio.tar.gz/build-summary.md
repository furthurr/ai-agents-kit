# Resumen de Construcción del Arnés Experimental y Soluciones de Referencia

**Fecha**: 2026-11-04  
**Modelo Asignado**: google/antigravity-gemini-3.8-flash  
**Directorio del Laboratorio**: /private/var/folders/d7/z7388kp51w532q4c0rj7hqqh0000gn/T/opencode/real-project-gemini-20261104

---

## 1. Correcciones de Contratos y Congelación de Diseño (cases.json)

1. **Preservación de Borrador Previo**:
   - Se guardó el estado original de la especificación en `cases-v1-draft.json` antes de aplicar cualquier mutación.
2. **Sustitución de Alternativas Ambiguas por Contratos Exactos**:
   - **`TASK-1` (Media-Alta)**:
     - Endpoints: UI en `/catalog/books/`, API pública en `GET /catalog/api/books/`.
     - Query parameters exactos: `q` (búsqueda substring icontains en title/summary con trim), `status` (valores válidos 'a', 'r', 'o', 'm'), `genre` y `language` (enteros positivos convertibles). Parámetros inválidos responden HTTP 400 `{"error": "invalid_query"}` en API, y HTTP 200 con mensaje comprensible en UI sin traceback.
     - Paginación fija de 10 elementos/página; ordenamiento determinista por `('title', 'id')` sin duplicados.
     - Esquema de respuesta JSON estricto con `count`, `page`, `num_pages`, `results` (`id`, `title`, `author`, `isbn`, `genre`).
   - **`TASK-2` (Alta)**:
     - Endpoint: `POST /catalog/api/bookinstance/<uuid:pk>/reserve/`.
     - Exigencia estricta de header HTTP `Idempotency-Key` (400 `{"error": "invalid_key"}` si falta, está vacío o supera 100 caracteres).
     - Respuestas de error: 401 si anónimo, 405 si GET, 404 `{"error": "not_found"}` si no existe, 409 `{"error": "unavailable"}` si no está disponible ('a').
     - Éxito 201 Created con JSON exacto `{"instance_id": "<uuid>", "user_id": <int>, "status": "r"}`.
     - Replay del mismo usuario/clave/instancia retorna el mismo 201 Created y payload idéntico sin duplicación. Mismo usuario/clave para otra instancia responde 409 `{"error": "idempotency_conflict"}`.
     - Concurrencia real bajo SQLite en disco: dos usuarios concurrentes sobre la misma copia resultan exactamente en un 201 y un 409 `unavailable` mediante conditional UPDATE atómico y reintentos acotados (evitando errores 500 "database table is locked").
     - Modelo público `Reservation` (campos `user`, `instance`, `key`, `created_at` con constraint de unicidad sobre `[user, key]`).
     - Formulario UI con CSRF y clave hidden en el detalle del libro.
   - **`TASK-3` (Muy Alta - Dos Etapas)**:
     - Catálogo bibliográfico (`Book`, `Author`, `Genre`, `Language`) permanece global y público en ambas fases; el aislamiento aplica al inventario físico (`BookInstance`) y gestión de préstamos.
     - Modelos explícitos: `Branch` (`code`, `name`, `address`), `BranchMembership` (`user`, `branch`, `is_staff`), `BookInstance.branch` y `BookInstance.origin_branch`.
     - Compatibilidad legacy: migración de datos asigna ejemplares preexistentes a `CENTRAL` ('Central Library'); usuarios autenticados sin membresías asignadas operan contra `CENTRAL`; superusuario tiene acceso a todas; usuarios con membresías solo a las suyas.
     - Endpoint de selección `POST /catalog/branches/select/` con payload `{"branch_code": "..."}`: responde 403 si no está autorizado sin mutar sesión; 200 y persiste `active_branch_code` si autorizado.
     - Endpoint inventario `GET /catalog/api/inventory/`: requiere autenticación y devuelve copias de la sucursal activa.
     - Fase 2 (Reanudación con cambio de requisito en sesión limpia): `POST /catalog/api/branch-transfer/` traslada inmediatamente ejemplares disponibles ('a') entre sucursales cuando el usuario staff tiene permisos en origen y destino (201 Created con origen inmutable y custodia actualizada); 403 si falta permiso en cualquiera de las sedes; 409 si la copia no está disponible.

---

## 2. Oráculos de Evaluación Externa (oracles/)

Se construyeron pruebas unitarias independientes (`TestCase` y `TransactionTestCase`) que no contaminan el código de los agentes y comprueban de extremo a extremo los contratos observables:
- `oracles/test_oracle_task1.py`: Valida estructura JSON de la API, filtros individuales y combinados con lógica AND, manejo de errores 400 (`invalid_query`), paginación y presencia de formulario UI con preservación de parámetros.
- `oracles/test_oracle_task2.py`: Valida modelo público `Reservation`, autenticación, validación de clave de idempotencia, respuestas de conflicto y replay exacto. Incluye prueba de concurrencia real (`Task2OracleConcurrencyRealDbTest`) con 3 repeticiones de barrera simultánea en hilos independientes sobre SQLite en disco, confirmando resolución de locks y distribución 201 / 409 sin excepciones 500.
- `oracles/test_oracle_task3_stage1.py`: Valida que el catálogo permanezca global, el endpoint de selección de sucursales con control de acceso (403 vs 200) y el endpoint de inventario filtrado por sucursal activa.
- `oracles/test_oracle_task3_final.py`: Valida transferencias interbibliotecarias en Fase 2, exigencia de permisos duales (origen y destino), rechazo de transferencias sobre copias no disponibles (409) y actualización de custodia conservando origen inmutable.
- `oracles/test_oracle_task3_migration.py`: Valida mediante `MigrationExecutor` la migración de datos limpia desde la base legacy, confirmando la creación de la sucursal `CENTRAL` y la preservación y asignación de ejemplares preexistentes.

---

## 3. Soluciones de Referencia y Validación Empírica (references/ y oracle-validation.json)

Se crearon cuatro soluciones de referencia totalmente independientes en `references/`:
1. `references/TASK-1`: Implementa vistas de búsqueda facetada, endpoint JSON `books_api` y plantilla UI adaptada.
2. `references/TASK-2`: Implementa modelo `Reservation`, migración `0030_reservation.py`, endpoint transaccional atómico con reintento ante busy locks para SQLite, y UI de reserva.
3. `references/TASK-3-stage1`: Implementa modelos `Branch` y `BranchMembership`, migraciones `0030` y `0031` (data migration sembrando Central), selector de sucursal y API de inventario.
4. `references/TASK-3-final`: Extiende la etapa 1 con modelo `BranchTransfer`, migración `0032_branchtransfer.py` y endpoint `branch_transfer_api`.

### Resultados de Verificación Empírica (`oracle-validation.json`):
- **Baseline limpio**:
  - `manage.py test catalog`: 43 tests OK.
  - Oráculos de T1, T2 y T3 ejecutados contra baseline: Fallan como corresponde (comportamiento ausente verificado honestamente con códigos de salida != 0).
- **Referencias**:
  - `references/TASK-1`: 50 tests OK (43 originales + 7 oráculo).
  - `references/TASK-2`: 52 tests OK (43 originales + 8 oráculo y concurrencia real).
  - `references/TASK-3-stage1`: 47 tests OK (43 originales + 3 oráculo + 1 migración).
  - `references/TASK-3-final`: 51 tests OK (43 originales + 4 oráculo final + 3 stage1 + 1 migración).
- Todas las salidas completas de `stdout`, `stderr` y códigos de retorno están archivadas en `oracle-validation.json`.

---

## 4. Arnés del Benchmark y Políticas de Seguridad (runner.py)

Se desarrolló `runner.py` con una interfaz CLI modular:
- Comandos soportados: `prepare-profiles`, `preflight`, `freeze`, `run --repeat N`, `report`.
- **Perfiles Namespaced**: Genera perfiles completamente aislados para `developer`, `sdd` y `odd` histórico (tratamiento B exacto) sin modificar archivos del kit de solo lectura.
- **Políticas de Permisos Rigurosas**:
  - Denegación estricta de secretos (claves, keystores, credenciales, almacenes de autenticación).
  - Edición restringida exclusivamente al espacio de trabajo de la celda activa. Prohibida la edición de perfiles, oráculos, referencias, baseline, `AGENTS.md` y `TASK.md`.
  - Bash restringido a allowlist de comandos del virtualenv (`manage.py test/check/makemigrations/migrate/collectstatic`) y comandos de consulta git (`status`, `diff`). Denegación total de herramientas de red y delegación.
  - Se declara explícitamente que la política de denegación actúa a nivel de OpenCode y no sustituye un sandbox a nivel de kernel/SO.
- **Protección de Preparación**: El comando `run` bloquea activamente la ejecución de celdas comparativas y emite advertencia de seguridad para esperar la revisión externa autorizada.

---

## 5. Pruebas Unitarias Offline del Arnés (test_runner.py)

Se implementó y ejecutó `test_runner.py` cubriendo:
- Integridad de contratos en `cases.json` por ID de criterio.
- Namespacing y aislamiento de perfiles de los tres tratamientos.
- Límites de permisos y políticas de denegación.
- Detección de drift en hashing sin incluir `.venv` ni `staticfiles`.
- Verificación de trazas en `oracle-validation.json`.
- **Resultado**: 6 pruebas unitarias ejecutadas y aprobadas en 0.026s.

---

## 6. Estado de Cumplimiento de Restricciones

- **No se ejecutaron las 27 celdas** ni preflights de agentes de comparación.
- **No se modificaron archivos del kit** de referencia.
- **No se leyeron ni generaron credenciales** ni archivos secretos.
- **No se usaron commits ni push** de git.
- Todo el trabajo permanece estrictamente acotado dentro de la raíz de este laboratorio experimental.\n