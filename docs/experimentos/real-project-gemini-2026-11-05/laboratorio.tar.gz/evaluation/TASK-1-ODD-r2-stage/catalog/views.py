from django.shortcuts import render
from django.http import JsonResponse
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q

# Create your views here.

from .models import Book, Author, BookInstance, Genre, Language

def index(request):
    """View function for home page of site."""
    # Generate counts of some of the main objects
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available copies of books
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Number of visits to this view, as counted in the session variable.
    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    # Render the HTML template index.html with the data in the context variable.
    return render(request, 'index.html', context=context)

from django.views import generic


def filter_books_queryset(get_params):
    """
    Validates query parameters and filters Book queryset.
    Returns (queryset, error_message, validated_params)
    If parameters are invalid, queryset is None and error_message is populated.
    """
    qs = Book.objects.all()

    # q param
    q = get_params.get('q')
    if q is not None:
        q_clean = q.strip()
        if q_clean != '':
            qs = qs.filter(Q(title__icontains=q_clean) | Q(summary__icontains=q_clean))

    # status param
    if 'status' in get_params:
        status = get_params.get('status')
        valid_statuses = {s.value for s in BookInstance.LoanStatus}
        if len(status) != 1 or status not in valid_statuses:
            return None, 'invalid_query', {}
        qs = qs.filter(bookinstance__status=status)
    else:
        status = ''

    # genre param
    if 'genre' in get_params:
        genre_param = get_params.get('genre')
        try:
            genre_id = int(genre_param)
            if genre_id <= 0:
                raise ValueError()
        except (ValueError, TypeError):
            return None, 'invalid_query', {}
        qs = qs.filter(genre__id=genre_id)
    else:
        genre_param = ''

    # language param
    if 'language' in get_params:
        lang_param = get_params.get('language')
        try:
            lang_id = int(lang_param)
            if lang_id <= 0:
                raise ValueError()
        except (ValueError, TypeError):
            return None, 'invalid_query', {}
        qs = qs.filter(language_id=lang_id)
    else:
        lang_param = ''

    qs = qs.order_by('title', 'id').distinct()
    return qs, None, {
        'q': q.strip() if q else '',
        'status': status,
        'genre': genre_param,
        'language': lang_param,
    }


def book_api_list(request):
    """Public API endpoint returning paginated JSON list of books."""
    qs, error, _ = filter_books_queryset(request.GET)
    if error:
        return JsonResponse({'error': error}, status=400)

    count = qs.count()
    if 'page' in request.GET:
        page_param = request.GET.get('page')
        try:
            page_num = int(page_param)
            if page_num < 1:
                raise ValueError()
        except (ValueError, TypeError):
            return JsonResponse({'error': 'invalid_query'}, status=400)
    else:
        page_num = 1

    if count == 0:
        if page_num != 1:
            return JsonResponse({'error': 'invalid_query'}, status=400)
        return JsonResponse({
            'count': 0,
            'page': 1,
            'num_pages': 1,
            'results': []
        })

    paginator = Paginator(qs, 10)

    if page_num > paginator.num_pages:
        return JsonResponse({'error': 'invalid_query'}, status=400)

    page_obj = paginator.page(page_num)

    results = []
    # Prefetch related author and genres for performance
    books_page = page_obj.object_list.select_related('author').prefetch_related('genre')
    for book in books_page:
        author_name = str(book.author) if book.author else None
        genre_names = sorted(list(book.genre.values_list('name', flat=True)))
        results.append({
            'id': book.id,
            'title': book.title,
            'author': author_name,
            'isbn': book.isbn,
            'genre': genre_names
        })

    return JsonResponse({
        'count': count,
        'page': page_num,
        'num_pages': paginator.num_pages,
        'results': results
    })


class BookListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = Book
    paginate_by = 10

    def get(self, request, *args, **kwargs):
        qs, error, current_filters = filter_books_queryset(request.GET)
        if error:
            context = {
                'book_list': [],
                'object_list': [],
                'is_paginated': False,
                'filter_error': True,
                'genres': Genre.objects.all(),
                'languages': Language.objects.all(),
                'statuses': BookInstance.LoanStatus.choices,
                'current_filters': {
                    'q': request.GET.get('q', ''),
                    'status': request.GET.get('status', ''),
                    'genre': request.GET.get('genre', ''),
                    'language': request.GET.get('language', ''),
                }
            }
            return render(request, 'catalog/book_list.html', context, status=200)

        paginator = Paginator(qs, self.paginate_by)
        page_param = request.GET.get('page')
        if page_param is None or page_param == '':
            page_num = 1
        else:
            try:
                page_num = int(page_param)
                if page_num < 1 or (page_num > paginator.num_pages and paginator.num_pages > 0):
                    raise ValueError()
            except ValueError:
                # UI responde 200 con mensaje de error o página vacía sin traceback
                context = {
                    'book_list': [],
                    'object_list': [],
                    'is_paginated': False,
                    'filter_error': True,
                    'genres': Genre.objects.all(),
                    'languages': Language.objects.all(),
                    'statuses': BookInstance.LoanStatus.choices,
                    'current_filters': current_filters
                }
                return render(request, 'catalog/book_list.html', context, status=200)

        try:
            page_obj = paginator.page(page_num)
        except (EmptyPage, PageNotAnInteger):
            page_obj = paginator.page(1) if paginator.num_pages > 0 else []

        context = {
            'book_list': page_obj.object_list if hasattr(page_obj, 'object_list') else [],
            'object_list': page_obj.object_list if hasattr(page_obj, 'object_list') else [],
            'page_obj': page_obj,
            'is_paginated': page_obj.has_other_pages() if hasattr(page_obj, 'has_other_pages') else False,
            'paginator': paginator,
            'genres': Genre.objects.all(),
            'languages': Language.objects.all(),
            'statuses': BookInstance.LoanStatus.choices,
            'current_filters': current_filters
        }
        return render(request, 'catalog/book_list.html', context)


class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre

class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10

class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language

class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10

class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10

class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance

from django.contrib.auth.mixins import LoginRequiredMixin

class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )

# Added as part of challenge!
from django.contrib.auth.mixins import PermissionRequiredMixin


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')

from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
import datetime
from django.contrib.auth.decorators import login_required, permission_required
from catalog.forms import RenewBookForm


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed'))

    # If this is a GET (or any other method) create the default form
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import RestrictedError
from django.contrib.auth.mixins import PermissionRequiredMixin
from .models import Author


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'

class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    # Not recommended (potential security issue if more fields added)
    fields = '__all__'
    permission_required = 'catalog.change_author'

class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("author-delete", kwargs={"pk": self.object.pk})
            )

# Classes created for the forms challenge


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("book-delete", kwargs={"pk": self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    # fields = "__all__"
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'
