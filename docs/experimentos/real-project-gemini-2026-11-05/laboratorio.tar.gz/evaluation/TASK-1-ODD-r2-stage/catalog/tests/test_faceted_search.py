from django.test import TestCase
from django.urls import reverse
from catalog.models import Book, Author, Genre, Language, BookInstance


class BookSearchAndFilterApiTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.author1 = Author.objects.create(first_name='Arthur', last_name='Conan Doyle')
        cls.author2 = Author.objects.create(first_name='Agatha', last_name='Christie')

        cls.genre_sci = Genre.objects.create(name='Science Fiction')
        cls.genre_mys = Genre.objects.create(name='Mystery')
        cls.genre_fan = Genre.objects.create(name='Fantasy')

        cls.lang_en = Language.objects.create(name='English')
        cls.lang_es = Language.objects.create(name='Spanish')

        # Book 1: Sherlock Holmes (Arthur Conan Doyle, Mystery, English)
        cls.book1 = Book.objects.create(
            title='A Study in Scarlet',
            author=cls.author1,
            summary='First Sherlock Holmes story featuring crime investigation.',
            isbn='1234567890123',
            language=cls.lang_en,
        )
        cls.book1.genre.add(cls.genre_mys)

        # Book 2: Poirot (Agatha Christie, Mystery & Fantasy, English)
        cls.book2 = Book.objects.create(
            title='The Mysterious Affair at Styles',
            author=cls.author2,
            summary='Hercule Poirot solves a mystery poisoning case.',
            isbn='2345678901234',
            language=cls.lang_en,
        )
        cls.book2.genre.add(cls.genre_mys, cls.genre_fan)

        # Book 3: No author (None), Science Fiction, Spanish
        cls.book3 = Book.objects.create(
            title='Future World',
            author=None,
            summary='A vision of future robots and space exploration.',
            isbn='3456789012345',
            language=cls.lang_es,
        )
        cls.book3.genre.add(cls.genre_sci)

        # Instances for book1: 'a' and 'm'
        BookInstance.objects.create(book=cls.book1, imprint='Imp1', status=BookInstance.LoanStatus.AVAILABLE)
        BookInstance.objects.create(book=cls.book1, imprint='Imp2', status=BookInstance.LoanStatus.MAINTENANCE)

        # Instances for book2: 'o'
        BookInstance.objects.create(book=cls.book2, imprint='Imp3', status=BookInstance.LoanStatus.ON_LOAN)

        # Instances for book3: 'r'
        BookInstance.objects.create(book=cls.book3, imprint='Imp4', status=BookInstance.LoanStatus.RESERVED)

    def test_api_endpoint_public_and_contract(self):
        url = '/catalog/api/books/'
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response['Content-Type'], 'application/json')
        data = response.json()
        self.assertIn('count', data)
        self.assertIn('page', data)
        self.assertIn('num_pages', data)
        self.assertIn('results', data)
        self.assertEqual(data['count'], 3)
        self.assertEqual(data['page'], 1)
        self.assertEqual(data['num_pages'], 1)
        self.assertEqual(len(data['results']), 3)

        # Verify ordering ('title', 'id')
        titles = [b['title'] for b in data['results']]
        self.assertEqual(titles, sorted(titles))

        # Check fields of book3 (no author)
        b3_data = next(b for b in data['results'] if b['id'] == self.book3.id)
        self.assertIsNone(b3_data['author'])
        self.assertEqual(b3_data['genre'], ['Science Fiction'])

        # Check fields of book2 (multiple genres sorted alphabetically)
        b2_data = next(b for b in data['results'] if b['id'] == self.book2.id)
        self.assertEqual(b2_data['author'], 'Christie, Agatha')
        self.assertEqual(b2_data['genre'], ['Fantasy', 'Mystery'])

    def test_api_filter_q(self):
        # Match in title
        response = self.client.get('/catalog/api/books/', {'q': 'Sherlock'})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 1)
        self.assertEqual(data['results'][0]['id'], self.book1.id)

        # Match in summary
        response = self.client.get('/catalog/api/books/', {'q': 'poisoning'})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 1)
        self.assertEqual(data['results'][0]['id'], self.book2.id)

        # Whitespace trim should ignore filter
        response = self.client.get('/catalog/api/books/', {'q': '   '})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()['count'], 3)

    def test_api_filter_status(self):
        # Valid status 'a'
        response = self.client.get('/catalog/api/books/', {'status': 'a'})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 1)
        self.assertEqual(data['results'][0]['id'], self.book1.id)

        # Invalid status returns 400 {'error': 'invalid_query'}
        for invalid_val in ['invalid', 'x', 'aa', '']:
            resp = self.client.get('/catalog/api/books/', {'status': invalid_val})
            self.assertEqual(resp.status_code, 400)
            self.assertEqual(resp.json(), {'error': 'invalid_query'})

    def test_api_filter_genre(self):
        response = self.client.get('/catalog/api/books/', {'genre': self.genre_sci.id})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 1)
        self.assertEqual(data['results'][0]['id'], self.book3.id)

        # Invalid genre returns 400
        for invalid_val in ['abc', '0', '-1', '1.5']:
            resp = self.client.get('/catalog/api/books/', {'genre': invalid_val})
            self.assertEqual(resp.status_code, 400)
            self.assertEqual(resp.json(), {'error': 'invalid_query'})

    def test_api_filter_language(self):
        response = self.client.get('/catalog/api/books/', {'language': self.lang_es.id})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 1)
        self.assertEqual(data['results'][0]['id'], self.book3.id)

        # Invalid language returns 400
        for invalid_val in ['foo', '0', '-5']:
            resp = self.client.get('/catalog/api/books/', {'language': invalid_val})
            self.assertEqual(resp.status_code, 400)
            self.assertEqual(resp.json(), {'error': 'invalid_query'})

    def test_api_filter_combination_and(self):
        response = self.client.get('/catalog/api/books/', {
            'q': 'Holmes',
            'genre': self.genre_mys.id,
            'language': self.lang_en.id,
            'status': 'a',
        })
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()['count'], 1)

        # No match when one condition fails
        response = self.client.get('/catalog/api/books/', {
            'q': 'Holmes',
            'genre': self.genre_sci.id,
        })
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()['count'], 0)
        self.assertEqual(response.json()['results'], [])
        self.assertEqual(response.json()['num_pages'], 1)
        self.assertEqual(response.json()['page'], 1)

    def test_api_pagination(self):
        # Create additional books to exceed 10
        for i in range(12):
            b = Book.objects.create(
                title=f'Extra Book {i:02d}',
                isbn=f'999999999{i:04d}',
                language=self.lang_en,
            )

        # Total is now 15 books -> page 1 should have 10, page 2 should have 5
        resp_p1 = self.client.get('/catalog/api/books/', {'page': 1})
        self.assertEqual(resp_p1.status_code, 200)
        d1 = resp_p1.json()
        self.assertEqual(d1['count'], 15)
        self.assertEqual(d1['page'], 1)
        self.assertEqual(d1['num_pages'], 2)
        self.assertEqual(len(d1['results']), 10)

        resp_p2 = self.client.get('/catalog/api/books/', {'page': 2})
        self.assertEqual(resp_p2.status_code, 200)
        d2 = resp_p2.json()
        self.assertEqual(d2['page'], 2)
        self.assertEqual(len(d2['results']), 5)

        # Invalid page (out of bounds or non-positive int)
        for invalid_page in [3, 0, -1, 'one', '']:
            resp = self.client.get('/catalog/api/books/', {'page': invalid_page})
            self.assertEqual(resp.status_code, 400)
            self.assertEqual(resp.json(), {'error': 'invalid_query'})


class BookSearchAndFilterUITest(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.author = Author.objects.create(first_name='Arthur', last_name='Conan Doyle')
        cls.genre = Genre.objects.create(name='Mystery')
        cls.lang = Language.objects.create(name='English')
        cls.book = Book.objects.create(
            title='A Study in Scarlet',
            author=cls.author,
            summary='Sherlock Holmes first novel',
            isbn='1234567890123',
            language=cls.lang,
        )
        cls.book.genre.add(cls.genre)
        BookInstance.objects.create(book=cls.book, imprint='Imp1', status=BookInstance.LoanStatus.AVAILABLE)

    def test_ui_has_filter_form(self):
        response = self.client.get(reverse('books'))
        self.assertEqual(response.status_code, 200)
        content = response.content.decode('utf-8')
        # Check inputs with names 'q', 'genre', 'language', 'status'
        self.assertIn('name="q"', content)
        self.assertIn('name="genre"', content)
        self.assertIn('name="language"', content)
        self.assertIn('name="status"', content)

    def test_ui_filter_q(self):
        response = self.client.get(reverse('books'), {'q': 'Sherlock'})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'A Study in Scarlet')

        # No match should show empty list message
        response = self.client.get(reverse('books'), {'q': 'NonExistentPhrase123'})
        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, 'A Study in Scarlet')
        # Visible empty message
        self.assertContains(response, 'There are no books')

    def test_ui_invalid_parameters_return_200_friendly_error(self):
        for param in [{'status': 'invalid'}, {'genre': 'not_an_int'}, {'language': '-1'}, {'page': 'xyz'}, {'page': '999'}]:
            response = self.client.get(reverse('books'), param)
            self.assertEqual(response.status_code, 200)
            self.assertTemplateUsed(response, 'catalog/book_list.html')
            self.assertContains(response, 'Invalid query parameters provided')

    def test_ui_pagination_preserves_query_params(self):
        # Create books for pagination
        for i in range(12):
            b = Book.objects.create(
                title=f'Book Series {i:02d}',
                isbn=f'888888888{i:04d}',
                language=self.lang,
            )
            b.genre.add(self.genre)

        response = self.client.get(reverse('books'), {'q': 'Book', 'genre': self.genre.id, 'page': 1})
        self.assertEqual(response.status_code, 200)
        content = response.content.decode('utf-8')
        # Should link to page 2 with preserved query parameters 'q=Book' and 'genre=...'
        self.assertIn('q=Book', content)
        self.assertIn(f'genre={self.genre.id}', content)
