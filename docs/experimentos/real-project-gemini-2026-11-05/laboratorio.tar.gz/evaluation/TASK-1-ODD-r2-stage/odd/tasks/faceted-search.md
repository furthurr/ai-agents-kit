# Task: Búsqueda y filtros facetados con paginación en UI y API

## Specs
- S1: Endpoint API `GET /catalog/api/books/` público (sin autenticación).
- S2: Query param `q`: cadena de texto. Si no está vacía tras trim (`.strip()`), filtrar libros donde `Book.title` o `Book.summary` contenga el texto (`icontains`). Si tras trim queda vacía, ignorar filtro.
- S3: Query param `status`: cadena de texto de un solo caracter. Valores válidos exactos: `'a'`, `'r'`, `'o'`, `'m'`. Filtra libros que posean al menos una copia (`BookInstance`) con status igual al valor. Si se pasa cualquier otro valor (o longitud != 1), API responde 400 con JSON exacto `{'error': 'invalid_query'}`. En UI, responder 200 mostrando mensaje amigable de error sin traceback.
- S4: Query param `genre`: entero positivo (ID de Genre). Filtra libros que tengan asociado ese Genre (`Book.genre`). Si no es entero positivo convertible (ej. texto no numérico, <= 0), API responde 400 `{'error': 'invalid_query'}`, UI 200 con mensaje de error sin traceback.
- S5: Query param `language`: entero positivo (ID de Language). Filtra libros que tengan `Book.language_id` igual a ese entero. Si no es entero positivo convertible, API responde 400 `{'error': 'invalid_query'}`, UI 200 con mensaje de error sin traceback.
- S6: Query param `page`: entero positivo >= 1. Paginación fija de 10 resultados por página. Si page no es entero >= 1 o está fuera de rango (ej. excede el total de páginas `num_pages`), API responde 400 con `{'error': 'invalid_query'}`, UI responde 200 con mensaje de error o página vacía sin traceback.
- S7: Combinación de filtros: los filtros provistos deben combinarse con lógica AND.
- S8: Ordenamiento determinista: los libros deben ordenarse siempre por `('title', 'id')` ascendente, sin duplicados en resultados (usar `.distinct()`).
- S9: Estructura de respuesta API (200 OK, `application/json`):
  ```json
  {
    "count": <total_libros_coincidentes_int>,
    "page": <pagina_actual_int>,
    "num_pages": <total_paginas_int>,
    "results": [
      {
        "id": <book_id_int>,
        "title": <book_title_str>,
        "author": <author_display_name_str_o_null>,
        "isbn": <book_isbn_str>,
        "genre": [<lista_de_nombres_de_genero_str_ordenados_alfabeticamente>]
      }
    ]
  }
  ```
  Si no hay libros en la base o tras filtrar el resultado es 0, `count=0`, `page=1`, `num_pages=1`, `results=[]`.
  `author` debe ser el nombre del autor (`f'{author.last_name}, {author.first_name}'` o `author.__str__()`) si existe, o `null` si author es null.
  `genre` debe ser la lista de nombres de género ordenados alfabéticamente.
- S10: Comportamiento UI (`/catalog/books/`):
  - Template `catalog/book_list.html` debe incluir un formulario GET con inputs etiquetados para `'q'` (input text), `'genre'` (select u opciones), `'language'` (select u opciones) y `'status'` (select u opciones).
  - La paginación (enlaces anterior/siguiente) debe preservar todos los query params activos.
  - Si la búsqueda no arroja resultados, mostrar mensaje visible de lista vacía.
  - Si los parámetros son inválidos, responder HTTP 200 renderizando mensaje de error comprensible en el HTML sin producir traceback 500.
- S11: Suite original (43 tests) debe seguir pasando intacta. Sin librerías externas pesadas (usar Django nativo y `JsonResponse`/views).

## Tasks
- T1 (S1-S9, S11): Escribir tests unitarios para endpoint API `GET /catalog/api/books/` observando RED. [completed]
- T2 (S10, S11): Escribir tests unitarios para UI `/catalog/books/` observando RED. [completed]
- T3 (S1-S9): Implementar endpoint API `catalog_api_books` y URL `/catalog/api/books/`. [completed]
- T4 (S10): Adaptar `BookListView` y `book_list.html` con filtros, formulario GET, paginación con query params preservados y manejo de errores 200. [completed]
- T5 (S1-S11): Verificación completa: suite original de 43 tests + nuevos tests, observando GREEN. [completed]

## Log
- L1: Petición recibida: "Implementar búsqueda y filtros facetados con paginación tanto en la vista UI (/catalog/books/) como en un endpoint API JSON público de lectura (GET /catalog/api/books/)..."
- L2: Implementados tests en `catalog/tests/test_faceted_search.py` observando fallos esperados (RED: 10 failures en endpoints y UI no implementados).
- L3: Implementado endpoint API `/catalog/api/books/` (`book_api_list`), lógica compartida de filtrado `filter_books_queryset` y actualización de `BookListView` y template `book_list.html`.
- L4: Ejecución de tests: 11 tests nuevos pasan (GREEN). Ejecución de suite completa: 54 tests pasan exitosamente sin regresiones en los 43 tests originales.
