Implementar búsqueda y filtros facetados con paginación tanto en la vista UI (/catalog/books/) como en un endpoint API JSON público de lectura (GET /catalog/api/books/).

CONTRATOS EXACTOS:
1. Endpoint API: GET /catalog/api/books/ (público, no requiere autenticación).
2. Parámetros de consulta (query params):
   - q: cadena de texto. Si no está vacía tras trim (.strip()), filtrar libros donde Book.title o Book.summary contenga el texto (icontains). Si tras trim queda vacía, ignorar filtro.
   - status: cadena de texto de un solo caracter. Valores válidos exactos: 'a', 'r', 'o', 'm'. Filtra libros que posean al menos una copia (BookInstance) con status igual al valor. Si se pasa cualquier otro valor (o longitud != 1), la API debe responder 400 con JSON exacto {'error': 'invalid_query'}. En UI, responder 200 mostrando mensaje amigable de error sin traceback.
   - genre: entero positivo (ID de Genre). Filtra libros que tengan asociado ese Genre (Book.genre). Si no es entero positivo convertible (ej. texto no numérico, <= 0), API responde 400 {'error': 'invalid_query'}, UI 200 con mensaje de error sin traceback.
   - language: entero positivo (ID de Language). Filtra libros que tengan Book.language_id igual a ese entero. Si no es entero positivo convertible, API responde 400 {'error': 'invalid_query'}, UI 200 con mensaje de error sin traceback.
   - page: entero positivo >= 1. Paginación fija de 10 resultados por página. Si page no es entero >= 1 o está fuera de rango (ej. excede el total de páginas num_pages), API responde 400 con {'error': 'invalid_query'}, UI responde 200 con mensaje de error o página vacía sin traceback.
   - Combinación de filtros: los filtros provistos deben combinarse con lógica AND.
   - Ordenamiento determinista: los libros deben ordenarse siempre por ('title', 'id') ascendente, sin duplicados en resultados (usar .distinct()).
3. Estructura de respuesta API (200 OK, application/json):
   {
     "count": <total_libros_coincidentes_int>,
     "page": <pagina_actual_int>,
     "num_pages": <total_paginas_int>,
     "results": [
       {
         "id": <book_id_int>,
         "title": <book_title_str>,
         "author": <author_display_name_str_o_null>,
         "isbn": <book_isbn_str>,
         "genre": [<lista_de_nombres_de_genero_str_ordenados_alfabeticamente>]
       }
     ]
   }
   Nota: Si no hay libros en la base o tras filtrar el resultado es 0, count=0, page=1, num_pages=1, results=[].
   author debe ser el nombre del autor (f'{author.last_name}, {author.first_name}' o author.__str__()) si existe, o null si author es null.
   genre debe ser la lista de nombres de género ordenados alfabéticamente.
4. Comportamiento UI (/catalog/books/):
   - Template catalog/book_list.html debe incluir un formulario GET con inputs etiquetados para 'q' (input text), 'genre' (select u opciones), 'language' (select u opciones) y 'status' (select u opciones).
   - La paginación (enlaces anterior/siguiente) debe preservar todos los query params activos.
   - Si la búsqueda no arroja resultados, mostrar mensaje visible de lista vacía.
   - Si los parámetros son inválidos, responder HTTP 200 renderizando mensaje de error comprensible en el HTML sin producir traceback 500.
5. Suite original (43 tests) debe seguir pasando intacta. No usar librerías externas pesadas (como DRF o Haystack); usar Django nativo y JsonResponse/views.

Alcance completo validado explícitamente: exactamente las reglas anteriores, sin extensiones. Trabaja solo en este workspace. Carga `rpsdd-sdd-spec` antes de actuar y conserva tu metodología. No uses red ni delegues, no instales dependencias, no hagas commits. Runner disponible: /private/var/folders/d7/z7388kp51w532q4c0rj7hqqh0000gn/T/opencode/real-project-gemini-20261104/.venv/bin/python manage.py test. Si el flujo requiere aprobación pendiente, presenta la propuesta y espera respuesta; no la inventes. Primero recomienda la profundidad natural adecuada al alcance; no hay modo SDD elegido aún. No generes artefactos ni implementes antes de que yo seleccione el modo. Termina esa propuesta con el campo exacto Recomendación: Direct, Recomendación: SDD-Tiny o Recomendación: SDD-Lite. 