from django.shortcuts import render
from django.http import JsonResponse, Http404
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q

# Create your views here.

from .models import Book, Author, BookInstance, Genre, Language


def get_filtered_books_queryset(params):
    """
    Parses and validates query parameters: q, status, genre, language.
    Returns (queryset, error_message).
    If error_message is not None, params were invalid.
    """
    VALID_STATUSES = {
        BookInstance.LoanStatus.MAINTENANCE,
        BookInstance.LoanStatus.ON_LOAN,
        BookInstance.LoanStatus.AVAILABLE,
        BookInstance.LoanStatus.RESERVED,
    }

    queryset = Book.objects.all()

    # 1. q param
    if 'q' in params:
        raw_q = params['q']
        if raw_q is not None:
            q_clean = str(raw_q).strip()
            if q_clean:
                queryset = queryset.filter(
                    Q(title__icontains=q_clean) | Q(summary__icontains=q_clean)
                )

    # 2. status param
    if 'status' in params:
        raw_status = params['status']
        if raw_status is not None and str(raw_status).strip() != '':
            status_val = str(raw_status)
            if len(status_val) != 1 or status_val not in VALID_STATUSES:
                return None, 'invalid_query'
            queryset = queryset.filter(bookinstance__status=status_val)

    # 3. genre param
    if 'genre' in params:
        raw_genre = params['genre']
        if raw_genre is not None and str(raw_genre).strip() != '':
            try:
                genre_id = int(raw_genre)
                if genre_id <= 0:
                    return None, 'invalid_query'
            except (ValueError, TypeError):
                return None, 'invalid_query'
            queryset = queryset.filter(genre__id=genre_id)

    # 4. language param
    if 'language' in params:
        raw_lang = params['language']
        if raw_lang is not None and str(raw_lang).strip() != '':
            try:
                lang_id = int(raw_lang)
                if lang_id <= 0:
                    return None, 'invalid_query'
            except (ValueError, TypeError):
                return None, 'invalid_query'
            queryset = queryset.filter(language_id=lang_id)

    # Deterministic ordering and distinct
    queryset = queryset.order_by('title', 'id').distinct()
    return queryset, None


def book_list_api(request):
    """
    Public JSON API endpoint for books search/filters and pagination:
    GET /catalog/api/books/
    """
    queryset, error = get_filtered_books_queryset(request.GET)
    if error:
        return JsonResponse({'error': 'invalid_query'}, status=400)

    raw_page = request.GET.get('page')
    PAGE_SIZE = 10
    total_count = queryset.count()

    if total_count == 0:
        if raw_page is not None and str(raw_page).strip() != '':
            try:
                page_num = int(raw_page)
                if page_num != 1:
                    return JsonResponse({'error': 'invalid_query'}, status=400)
            except (ValueError, TypeError):
                return JsonResponse({'error': 'invalid_query'}, status=400)

        return JsonResponse({
            'count': 0,
            'page': 1,
            'num_pages': 1,
            'results': [],
        }, status=200)

    paginator = Paginator(queryset, PAGE_SIZE)

    if raw_page is not None and str(raw_page).strip() != '':
        try:
            page_num = int(raw_page)
            if page_num < 1 or page_num > paginator.num_pages:
                return JsonResponse({'error': 'invalid_query'}, status=400)
        except (ValueError, TypeError):
            return JsonResponse({'error': 'invalid_query'}, status=400)
    else:
        page_num = 1

    page_obj = paginator.page(page_num)

    results = []
    # Optimize genre and author retrieval
    for book in page_obj.object_list.select_related('author').prefetch_related('genre'):
        author_display = None
        if book.author:
            author_display = f'{book.author.last_name}, {book.author.first_name}'
        genre_names = sorted(list(book.genre.values_list('name', flat=True)))
        results.append({
            'id': book.id,
            'title': book.title,
            'author': author_display,
            'isbn': book.isbn,
            'genre': genre_names,
        })

    return JsonResponse({
        'count': total_count,
        'page': page_num,
        'num_pages': paginator.num_pages,
        'results': results,
    }, status=200)

def index(request):
    """View function for home page of site."""
    # Generate counts of some of the main objects
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available copies of books
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Number of visits to this view, as counted in the session variable.
    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    # Render the HTML template index.html with the data in the context variable.
    return render(request, 'index.html', context=context)

from django.views import generic


class BookListView(generic.ListView):
    """Generic class-based view for a list of books with faceted search and filtering."""
    model = Book
    paginate_by = 10

    def get_queryset(self):
        queryset, error = get_filtered_books_queryset(self.request.GET)
        if error:
            self.query_error = True
            return Book.objects.none()
        self.query_error = False
        return queryset

    def paginate_queryset(self, queryset, page_size):
        try:
            return super().paginate_queryset(queryset, page_size)
        except (EmptyPage, PageNotAnInteger, Http404):
            self.page_out_of_range = True
            paginator = self.get_paginator(
                queryset, page_size, orphans=self.get_paginate_orphans(),
                allow_empty_first_page=self.get_allow_empty()
            )
            return (paginator, None, paginator.page(1) if paginator.count > 0 else [], False)

    def get(self, request, *args, **kwargs):
        self.query_error = False
        self.page_out_of_range = False
        try:
            return super().get(request, *args, **kwargs)
        except Http404:
            self.page_out_of_range = True
            self.object_list = Book.objects.none()
            context = self.get_context_data()
            context['is_paginated'] = False
            return self.render_to_response(context)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['all_genres'] = Genre.objects.all().order_by('name')
        context['all_languages'] = Language.objects.all().order_by('name')
        context['all_statuses'] = [
            ('a', 'Available'),
            ('r', 'Reserved'),
            ('o', 'On loan'),
            ('m', 'Maintenance'),
        ]
        context['current_q'] = self.request.GET.get('q', '').strip()
        context['current_status'] = self.request.GET.get('status', '').strip()
        context['current_genre'] = self.request.GET.get('genre', '').strip()
        context['current_language'] = self.request.GET.get('language', '').strip()
        context['query_error'] = getattr(self, 'query_error', False)
        context['page_out_of_range'] = getattr(self, 'page_out_of_range', False)
        return context

class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre

class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10

class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language

class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10

class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10

class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance

from django.contrib.auth.mixins import LoginRequiredMixin

class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )

# Added as part of challenge!
from django.contrib.auth.mixins import PermissionRequiredMixin


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')

from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
import datetime
from django.contrib.auth.decorators import login_required, permission_required
from catalog.forms import RenewBookForm


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed'))

    # If this is a GET (or any other method) create the default form
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import RestrictedError
from django.contrib.auth.mixins import PermissionRequiredMixin
from .models import Author


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'

class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    # Not recommended (potential security issue if more fields added)
    fields = '__all__'
    permission_required = 'catalog.change_author'

class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("author-delete", kwargs={"pk": self.object.pk})
            )

# Classes created for the forms challenge


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("book-delete", kwargs={"pk": self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    # fields = "__all__"
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'
