# Spec: Búsqueda y filtros facetados con paginación en UI y API

Modo SDD: tiny
Estado: Cerrado

## Alcance y aceptación

- **Objetivo**: Implementar búsqueda facetada y filtros con paginación fija de 10 elementos en la vista web `/catalog/books/` y en el endpoint público JSON `GET /catalog/api/books/`, manteniendo compatibilidad total y los 43 tests existentes.
- **Query Params y reglas**:
  - `q`: Cadena opcional. Si no está vacía tras `.strip()`, filtra libros donde `title` o `summary` contengan la cadena (`icontains`). Si tras trim queda vacía, se ignora.
  - `status`: Cadena de longitud exacta 1 en `['a', 'r', 'o', 'm']`. Filtra libros con al menos una copia (`BookInstance`) en dicho estado. Si es inválido (longitud != 1 o valor no permitido): API retorna HTTP 400 `{"error": "invalid_query"}`; UI retorna HTTP 200 mostrando mensaje de error sin traceback.
  - `genre`: Entero positivo (> 0). Filtra libros asociados (`Book.genre`). Si no es convertible a entero positivo: API retorna HTTP 400 `{"error": "invalid_query"}`; UI retorna HTTP 200 con mensaje de error sin traceback.
  - `language`: Entero positivo (> 0). Filtra libros por `language_id`. Si no es convertible a entero positivo: API retorna HTTP 400 `{"error": "invalid_query"}`; UI retorna HTTP 200 con mensaje de error sin traceback.
  - `page`: Entero positivo >= 1. 10 elementos por página. Si no es entero >= 1 o está fuera de rango (`page > paginator.num_pages`): API retorna HTTP 400 `{"error": "invalid_query"}`; UI retorna HTTP 200 con mensaje de error o lista vacía sin traceback.
  - Combinación: Lógica AND entre filtros provistos.
  - Ordenamiento determinista: `order_by('title', 'id')` con `.distinct()`.
- **Estructura API JSON (HTTP 200)**:
  - Campos: `count`, `page`, `num_pages`, `results`.
  - Si no hay resultados: `count=0`, `page=1`, `num_pages=1`, `results=[]`.
  - Formato de cada resultado: `id` (int), `title` (str), `author` (`f'{author.last_name}, {author.first_name}'` o null), `isbn` (str), `genre` (lista de nombres str ordenados alfabéticamente).
- **Comportamiento UI (`/catalog/books/`)**:
  - `catalog/book_list.html` con formulario GET conteniendo inputs etiquetados para `q`, `genre`, `language` y `status`.
  - Paginación preservando todos los query params activos.
  - Mensaje visible si no hay resultados coincidentes.
  - Mensaje amigable ante query params inválidos sin 500.
- **Exclusiones**: Sin dependencias externas adicionales, sin commits, sin alterar tests existentes.

## Enfoque técnico y estrategia de pruebas

- **Lógica de filtrado unificada**: Función auxiliar `get_filtered_books_queryset` en `catalog/views.py` para parsear y validar `q`, `status`, `genre`, `language`, retornando un queryset filtrado con orden `('title', 'id')` y `.distinct()`, o indicando error `invalid_query`.
- **API View**: Vista `book_list_api` en `catalog/views.py` expuesta en `catalog/urls.py` como `api/books/`. Maneja serialización JSON, cálculo de páginas y respuestas de error 400 `{"error": "invalid_query"}`.
- **UI View**: Adaptación de `BookListView` en `catalog/views.py` para consultar el queryset filtrado, capturar excepciones de paginación (`Http404`, `EmptyPage`, `PageNotAnInteger`) devolviendo 200 con mensaje explicativo, y alimentando opciones facetadas de géneros, idiomas y estados en el contexto.
- **Template**: Actualización de `catalog/book_list.html` incorporando el formulario GET y preservación de parámetros vía `{% querystring %}` en la paginación heredada de `base_generic.html`.
- **Estrategia de pruebas**:
  - Suite de regresión completa de Django para asegurar que los 43 tests existentes se mantengan en verde.
  - Suite nueva focalizada `BookFacetedSearchAndAPITest` (16 pruebas) cubriendo casos de éxito API, filtros combinados, ordenamiento determinista, autor nulo, géneros ordenados, errores 400 de API, borde sin resultados, renderizado UI de formulario y respuestas UI 200 amigables ante parámetros inválidos y páginas fuera de rango.

## Checklist

- [x] Implementar helper de parseo, validación y filtrado de libros con ordenamiento determinista y `.distinct()`.
- [x] Implementar vista de API JSON pública `GET /catalog/api/books/` y ruta URL asociada.
- [x] Integrar filtros y manejo de errores amigables en `BookListView`.
- [x] Actualizar template `catalog/book_list.html` con formulario de filtros facetados y preservación de parámetros.
- [x] Añadir suite de pruebas automatizadas para endpoint API y vista UI con filtros facetados.
- [x] Ejecutar suite completa (pruebas existentes + nuevas) y verificar que pasen todas al 100%.

## Verificación y cierre

### Registro de fallos locales y reparaciones
- **Fallo inicial observado**: Al invocar `self.client.get(reverse('books'), {'page': '9999'})`, Django `MultipleObjectMixin` lanzaba `Http404` en lugar de responder HTTP 200 con mensaje amigable.
- **Reparación**: Se sobreescribió el método `paginate_queryset` y el método `get` en `BookListView` para interceptar `Http404` / `EmptyPage` / `PageNotAnInteger`, marcando la bandera `page_out_of_range=True` y retornando HTTP 200 con mensaje informativo y lista vacía.

### Comandos de verificación ejecutados
1. Verificación de modelos y configuración de Django:
   ```bash
   /private/var/folders/d7/z7388kp51w532q4c0rj7hqqh0000gn/T/opencode/real-project-gemini-20261104/.venv/bin/python manage.py check
   ```
   *Resultado*: `System check identified no issues (0 silenced).`

2. Ejecución de la suite focalizada:
   ```bash
   /private/var/folders/d7/z7388kp51w532q4c0rj7hqqh0000gn/T/opencode/real-project-gemini-20261104/.venv/bin/python manage.py test catalog.tests.test_views.BookFacetedSearchAndAPITest
   ```
   *Resultado*: `Ran 16 tests in 0.252s - OK`

3. Ejecución de la suite completa del proyecto (43 originales + 16 nuevas = 59 tests):
   ```bash
   /private/var/folders/d7/z7388kp51w532q4c0rj7hqqh0000gn/T/opencode/real-project-gemini-20261104/.venv/bin/python manage.py test
   ```
   *Resultado*:
   ```text
   ...........................................................
   ----------------------------------------------------------------------
   Ran 59 tests in 10.358s

   OK
   Destroying test database for alias 'default'...
   Found 59 test(s).
   System check identified no issues (0 silenced).
   ```

Estado final de la verificación: Exitosa, 100% pruebas pasando, 0 regresiones.
