# Spec SDD-Tiny: Búsqueda y filtros facetados con paginación en Books (UI y API)

Modo SDD: tiny
Estado: Cerrado (Gate 4 aprobado)

## 1. Alcance y aceptación

### Objetivo
Proveer búsqueda textual y filtros facetados combinables (AND) con paginación fija de 10 resultados por página tanto en la vista HTML `/catalog/books/` como en el endpoint público JSON `GET /catalog/api/books/`.

### Comportamientos y contratos
1. **Endpoint API público**: `GET /catalog/api/books/` (no requiere autenticación, retorna `application/json`).
2. **Parámetros de consulta (query params)**:
   - `q`: String. Si tras `.strip()` no está vacía, filtra libros donde `Book.title` o `Book.summary` contenga el texto (`icontains`). Si tras trim queda vacía, se ignora el filtro.
   - `status`: String de exactamente 1 caracter. Valores permitidos: `'a'`, `'r'`, `'o'`, `'m'`. Filtra libros con al menos una copia (`BookInstance`) con dicho status. Si longitud != 1 o valor no permitido: API responde 400 con `{"error": "invalid_query"}`. UI responde 200 con mensaje de error comprensible sin traceback.
   - `genre`: Entero positivo (ID de Genre). Filtra por `Book.genre`. Si no es entero positivo convertible (<=0 o no numérico): API responde 400 con `{"error": "invalid_query"}`. UI responde 200 con mensaje de error comprensible sin traceback.
   - `language`: Entero positivo (ID de Language). Filtra por `Book.language_id`. Si no es entero positivo convertible (<=0 o no numérico): API responde 400 con `{"error": "invalid_query"}`. UI responde 200 con mensaje de error comprensible sin traceback.
   - `page`: Entero positivo >= 1 (10 items por página). Si no es entero >= 1 o excede `num_pages`: API responde 400 con `{"error": "invalid_query"}`. UI responde 200 con mensaje de error sin traceback.
   - Combinación: Lógica AND entre filtros activos.
   - Ordenamiento y unicidad: Orden determinista por `('title', 'id')` ascendente y sin duplicados (`.distinct()`).
3. **Respuesta JSON (200 OK)**:
   ```json
   {
     "count": <int>,
     "page": <int>,
     "num_pages": <int>,
     "results": [
       {
         "id": <int>,
         "title": <str>,
         "author": <str_or_null>,
         "isbn": <str>,
         "genre": [<str_ordenados_alfabeticamente>]
       }
     ]
   }
   ```
   - Si no hay coincidencias (total 0): `count=0`, `page=1`, `num_pages=1`, `results=[]`.
   - `author`: nombre del autor (`str(author)`) o `null`.
   - `genre`: lista de nombres de género ordenados alfabéticamente.
4. **Comportamiento UI (`/catalog/books/`)**:
   - Formulario GET en `catalog/book_list.html` con inputs etiquetados: `q` (text), `genre` (select), `language` (select), `status` (select).
   - Enlaces de paginación preservan query params.
   - Mensaje visible si la lista queda vacía.
   - En caso de parámetros inválidos: HTTP 200 renderizando mensaje amigable sin error 500.

### Criterios de aceptación
- Suite original de 43 pruebas pasa intacta.
- Pruebas exhaustivas para endpoint API y vista UI cubriendo casos válidos, combinaciones, errores 400/200, paginación y ordenamiento.
- Implementación Django nativa sin librerías externas adicionales.

---

## 2. Enfoque técnico y estrategia de pruebas

### Enfoque técnico
- Crear función o método auxiliar reutilizable de validación y filtrado de QuerySet para Book (`filter_books(query_params)`).
- En caso de validación fallida:
  - En API: `JsonResponse({'error': 'invalid_query'}, status=400)`.
  - En UI: `BookListView.paginate_queryset` y `get` capturan la validación fallida, setean `filtered_queryset = Book.objects.none()` y asignan mensaje amigable en `filter_error` para renderizar en el template con status 200.
- Endpoint API `book_api_list(request)` en `views.py`:
  - Valida params, filtra, ordena `order_by('title', 'id').distinct()`.
  - Manejo de paginación con `Paginator(qs, 10)`. Si total count es 0: `{count: 0, page: 1, num_pages: 1, results: []}`.
  - Serialización directa con lista de géneros ordenada alfabéticamente.
- Vista UI `BookListView` en `catalog/views.py`:
  - `paginate_queryset` sobreescrito para tolerar números de página no numéricos, negativos o fuera de rango sin lanzar 404/500, mostrando mensaje de error amigable.
  - Formulario GET con inputs y selects en `catalog/book_list.html`.
- Registro de ruta en `catalog/urls.py`: `path('api/books/', views.book_api_list, name='book-api-list')`.

### Estrategia de pruebas
- 17 nuevos tests en `catalog/tests/test_faceted_search.py` cubriendo:
  1. API pública sin autenticación requerida.
  2. API con base de datos vacía o búsqueda sin coincidencias.
  3. API estructura JSON, autor null y orden alfabético de géneros.
  4. API filtros individuales: `q` (strip, case-insensitive en title/summary), `status` ('a','r','o','m'), `genre` (ID), `language` (ID).
  5. API combinación de filtros con lógica AND y deduplicación con `.distinct()`.
  6. API validación de parámetros inválidos devolviendo status 400 y `{"error": "invalid_query"}`.
  7. UI renderizado de formulario GET con campos `q`, `genre`, `language`, `status`.
  8. UI preservación de query params en paginación.
  9. UI parámetros inválidos devolviendo 200 con mensaje comprensible sin traceback.

---

## 3. Checklist

- [x] Implementar helper de validación y filtrado para `Book` (`filter_books` en `catalog/views.py`)
- [x] Implementar vista API `GET /catalog/api/books/` en `catalog/views.py` y configurar ruta en `catalog/urls.py`
- [x] Actualizar `BookListView` en `catalog/views.py` y template `catalog/book_list.html` con formulario facetado y manejo seguro de errores
- [x] Escribir suite de pruebas para API y UI cubriendo todos los contratos (`catalog/tests/test_faceted_search.py`)
- [x] Ejecutar runner de tests y verificar 43 tests previos + nuevos tests pasando (60 tests en total, 0 fallos)

---

## 4. Verificación y cierre

### Historial de incidencias locales y resolución
1. **Fallo en test de BD vacía (`RestrictedError`)**:
   - *Causa*: `Book.objects.all().delete()` violaba la clave foránea `RESTRICT` de `BookInstance`.
   - *Resolución*: Se ajustó el setup del test para borrar `BookInstance.objects.all().delete()` antes de `Book.objects.all().delete()`.
2. **Fallo en test UI con `page < 1` (404 en lugar de 200)**:
   - *Causa*: `ListView.paginate_queryset` por defecto lanza `Http404` si `page < 1` o `page > num_pages`.
   - *Resolución*: Se sobreescribió `paginate_queryset` en `BookListView` para atrapar `EmptyPage`, `PageNotAnInteger` y enteros `< 1`, seteando `self.filter_error` y devolviendo un queryset vacío con HTTP 200.

### Evidencia de ejecución
Comando ejecutado:
```bash
/private/var/folders/d7/z7388kp51w532q4c0rj7hqqh0000gn/T/opencode/real-project-gemini-20261104/.venv/bin/python manage.py test
```

Salida del comando:
```text
Creating test database for alias 'default'...
............................................................
----------------------------------------------------------------------
Ran 60 tests in 10.447s

OK
Destroying test database for alias 'default'...
Found 60 test(s).
System check identified no issues (0 silenced).
```
Total de tests: 60 (43 originales + 17 nuevos de búsqueda y filtros facetados). 0 fallos, 0 errores.
