from django.test import TestCase
from django.urls import reverse
from catalog.models import Book, Author, Genre, Language, BookInstance
import json


class FacetedSearchAPITests(TestCase):
    @classmethod
    def setUpTestData(cls):
        # Create Authors
        cls.author1 = Author.objects.create(first_name='Arthur', last_name='Conan Doyle')
        cls.author2 = Author.objects.create(first_name='Agatha', last_name='Christie')

        # Create Languages
        cls.lang_en = Language.objects.create(name='English')
        cls.lang_es = Language.objects.create(name='Spanish')

        # Create Genres
        cls.genre_mystery = Genre.objects.create(name='Mystery')
        cls.genre_detective = Genre.objects.create(name='Detective')
        cls.genre_fiction = Genre.objects.create(name='Fiction')

        # Create Books (12 books to test pagination of 10 items)
        cls.books = []
        for i in range(1, 13):
            book = Book.objects.create(
                title=f'Book {i:02d}',
                author=cls.author1 if i % 2 != 0 else cls.author2,
                summary=f'Summary of book {i:02d} special clues',
                isbn=f'9780000000{i:02d}',
                language=cls.lang_en if i <= 6 else cls.lang_es,
            )
            if i % 2 != 0:
                book.genre.add(cls.genre_mystery, cls.genre_detective)
            else:
                book.genre.add(cls.genre_fiction)
            cls.books.append(book)

        # Create BookInstances
        # Book 1 has AVAILABLE
        BookInstance.objects.create(book=cls.books[0], imprint='Pub 1', status=BookInstance.LoanStatus.AVAILABLE)
        # Book 2 has ON_LOAN
        BookInstance.objects.create(book=cls.books[1], imprint='Pub 2', status=BookInstance.LoanStatus.ON_LOAN)
        # Book 3 has RESERVED
        BookInstance.objects.create(book=cls.books[2], imprint='Pub 3', status=BookInstance.LoanStatus.RESERVED)
        # Book 4 has MAINTENANCE
        BookInstance.objects.create(book=cls.books[3], imprint='Pub 4', status=BookInstance.LoanStatus.MAINTENANCE)

    def test_api_public_no_auth_required(self):
        url = reverse('book-api-list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response['Content-Type'], 'application/json')
        data = response.json()
        self.assertEqual(data['count'], 12)
        self.assertEqual(data['page'], 1)
        self.assertEqual(data['num_pages'], 2)
        self.assertEqual(len(data['results']), 10)

    def test_api_empty_database(self):
        BookInstance.objects.all().delete()
        Book.objects.all().delete()
        url = reverse('book-api-list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data, {
            'count': 0,
            'page': 1,
            'num_pages': 1,
            'results': []
        })

    def test_api_empty_results_when_filtered(self):
        url = reverse('book-api-list')
        response = self.client.get(url, {'q': 'nonexistent text string'})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data, {
            'count': 0,
            'page': 1,
            'num_pages': 1,
            'results': []
        })

    def test_api_result_structure_and_sorting(self):
        url = reverse('book-api-list')
        response = self.client.get(url, {'page': 1})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        first_item = data['results'][0]
        self.assertIn('id', first_item)
        self.assertIn('title', first_item)
        self.assertIn('author', first_item)
        self.assertIn('isbn', first_item)
        self.assertIn('genre', first_item)
        self.assertEqual(first_item['author'], 'Conan Doyle, Arthur')
        self.assertEqual(first_item['genre'], ['Detective', 'Mystery'])

    def test_api_book_without_author(self):
        book_no_author = Book.objects.create(
            title='Anonymous Book',
            author=None,
            summary='No author',
            isbn='9781111111111'
        )
        url = reverse('book-api-list')
        response = self.client.get(url, {'q': 'Anonymous'})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 1)
        self.assertIsNone(data['results'][0]['author'])

    def test_api_filter_q(self):
        url = reverse('book-api-list')
        # Title match
        res1 = self.client.get(url, {'q': 'Book 01'})
        self.assertEqual(res1.status_code, 200)
        self.assertEqual(res1.json()['count'], 1)
        self.assertEqual(res1.json()['results'][0]['title'], 'Book 01')

        # Summary match
        res2 = self.client.get(url, {'q': 'special clues'})
        self.assertEqual(res2.status_code, 200)
        self.assertEqual(res2.json()['count'], 12)

        # Whitespace trim
        res3 = self.client.get(url, {'q': '   Book 02   '})
        self.assertEqual(res3.status_code, 200)
        self.assertEqual(res3.json()['count'], 1)

        # Empty string after strip ignored
        res4 = self.client.get(url, {'q': '    '})
        self.assertEqual(res4.status_code, 200)
        self.assertEqual(res4.json()['count'], 12)

    def test_api_filter_status(self):
        url = reverse('book-api-list')
        # 'a' -> Available
        res_a = self.client.get(url, {'status': 'a'})
        self.assertEqual(res_a.status_code, 200)
        self.assertEqual(res_a.json()['count'], 1)
        self.assertEqual(res_a.json()['results'][0]['title'], 'Book 01')

        # 'o' -> On loan
        res_o = self.client.get(url, {'status': 'o'})
        self.assertEqual(res_o.status_code, 200)
        self.assertEqual(res_o.json()['count'], 1)
        self.assertEqual(res_o.json()['results'][0]['title'], 'Book 02')

        # 'r' -> Reserved
        res_r = self.client.get(url, {'status': 'r'})
        self.assertEqual(res_r.status_code, 200)
        self.assertEqual(res_r.json()['count'], 1)
        self.assertEqual(res_r.json()['results'][0]['title'], 'Book 03')

        # 'm' -> Maintenance
        res_m = self.client.get(url, {'status': 'm'})
        self.assertEqual(res_m.status_code, 200)
        self.assertEqual(res_m.json()['count'], 1)
        self.assertEqual(res_m.json()['results'][0]['title'], 'Book 04')

    def test_api_filter_genre(self):
        url = reverse('book-api-list')
        res = self.client.get(url, {'genre': self.genre_mystery.id})
        self.assertEqual(res.status_code, 200)
        # Odd books (6 of 12) have mystery
        self.assertEqual(res.json()['count'], 6)

    def test_api_filter_language(self):
        url = reverse('book-api-list')
        res = self.client.get(url, {'language': self.lang_en.id})
        self.assertEqual(res.status_code, 200)
        # Books 1..6 have lang_en
        self.assertEqual(res.json()['count'], 6)

    def test_api_combined_and_filters(self):
        url = reverse('book-api-list')
        # Books with lang_en AND genre_mystery AND status 'a'
        res = self.client.get(url, {
            'language': self.lang_en.id,
            'genre': self.genre_mystery.id,
            'status': 'a',
            'q': 'Book 01'
        })
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.json()['count'], 1)
        self.assertEqual(res.json()['results'][0]['title'], 'Book 01')

    def test_api_distinct_when_multiple_genres_or_instances(self):
        # Add another instance for book 1
        BookInstance.objects.create(book=self.books[0], imprint='Pub 1 copy 2', status=BookInstance.LoanStatus.AVAILABLE)
        url = reverse('book-api-list')
        res = self.client.get(url, {'status': 'a'})
        self.assertEqual(res.status_code, 200)
        # Book 1 should only appear once
        self.assertEqual(res.json()['count'], 1)
        self.assertEqual(len(res.json()['results']), 1)

    def test_api_invalid_query_parameters(self):
        url = reverse('book-api-list')
        expected_error = {'error': 'invalid_query'}

        # Invalid status
        for bad_status in ['x', 'available', 'ab', '1']:
            res = self.client.get(url, {'status': bad_status})
            self.assertEqual(res.status_code, 400)
            self.assertEqual(res.json(), expected_error)

        # Invalid genre
        for bad_genre in ['abc', '0', '-1', '1.5']:
            res = self.client.get(url, {'genre': bad_genre})
            self.assertEqual(res.status_code, 400)
            self.assertEqual(res.json(), expected_error)

        # Invalid language
        for bad_lang in ['xyz', '-5', '0', ' ']:
            res = self.client.get(url, {'language': bad_lang})
            self.assertEqual(res.status_code, 400)
            self.assertEqual(res.json(), expected_error)

        # Invalid page (out of bounds, 0, negative, non-numeric)
        for bad_page in ['0', '-1', '999', 'abc', '1.2']:
            res = self.client.get(url, {'page': bad_page})
            self.assertEqual(res.status_code, 400)
            self.assertEqual(res.json(), expected_error)


class FacetedSearchUITests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.author = Author.objects.create(first_name='Arthur', last_name='Conan Doyle')
        cls.genre = Genre.objects.create(name='Mystery')
        cls.language = Language.objects.create(name='English')
        cls.book = Book.objects.create(
            title='Sherlock Holmes',
            author=cls.author,
            summary='A consulting detective',
            isbn='9780000000001',
            language=cls.language
        )
        cls.book.genre.add(cls.genre)
        BookInstance.objects.create(book=cls.book, imprint='Test Imprint', status=BookInstance.LoanStatus.AVAILABLE)

    def test_ui_book_list_renders_form_fields(self):
        url = reverse('books')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'name="q"')
        self.assertContains(response, 'name="genre"')
        self.assertContains(response, 'name="language"')
        self.assertContains(response, 'name="status"')

    def test_ui_search_filter_success(self):
        url = reverse('books')
        response = self.client.get(url, {'q': 'Sherlock', 'genre': self.genre.id, 'status': 'a'})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Sherlock Holmes')

    def test_ui_empty_results_message(self):
        url = reverse('books')
        response = self.client.get(url, {'q': 'Nonexistent'})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'There are no books in the library.')

    def test_ui_invalid_parameters_renders_200_with_message(self):
        url = reverse('books')
        # Invalid status
        res1 = self.client.get(url, {'status': 'invalid_status'})
        self.assertEqual(res1.status_code, 200)
        self.assertContains(res1, 'Parámetros de búsqueda o filtro inválidos.')

        # Invalid genre
        res2 = self.client.get(url, {'genre': 'not_an_int'})
        self.assertEqual(res2.status_code, 200)
        self.assertContains(res2, 'Parámetros de búsqueda o filtro inválidos.')

        # Invalid page
        res3 = self.client.get(url, {'page': '-1'})
        self.assertEqual(res3.status_code, 200)
        self.assertContains(res3, 'Número de página inválido.')

    def test_ui_pagination_preserves_querystring(self):
        # Create 12 books to trigger pagination
        for i in range(2, 13):
            b = Book.objects.create(
                title=f'Extra Book {i:02d}',
                summary='Extra summary',
                isbn=f'9780000000{i:02d}',
                language=self.language
            )
            b.genre.add(self.genre)

        url = reverse('books')
        response = self.client.get(url, {'q': 'Book', 'genre': self.genre.id})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.context['is_paginated'])
        # The pagination links should include the querystring with 'q' and 'genre'
        content = response.content.decode('utf-8')
        self.assertIn('q=Book', content)
        self.assertIn(f'genre={self.genre.id}', content)
