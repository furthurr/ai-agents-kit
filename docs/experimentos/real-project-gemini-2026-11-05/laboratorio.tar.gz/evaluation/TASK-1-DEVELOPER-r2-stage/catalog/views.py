from django.shortcuts import render
from django.http import JsonResponse, Http404
from django.db.models import Q
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

# Create your views here.

from .models import Book, Author, BookInstance, Genre, Language


VALID_STATUS_CHOICES = {'a', 'r', 'o', 'm'}


def parse_and_validate_filters(get_params):
    """
    Parses and validates query params for book filtering.
    Returns:
        filters: dict with sanitized values (or None if invalid),
        error: str or None ('invalid_query' if invalid)
    """
    q_raw = get_params.get('q', None)
    status_raw = get_params.get('status', None)
    genre_raw = get_params.get('genre', None)
    language_raw = get_params.get('language', None)

    q = None
    if q_raw is not None:
        trimmed = q_raw.strip()
        if trimmed:
            q = trimmed

    status = None
    if status_raw is not None and status_raw != '':
        if status_raw not in VALID_STATUS_CHOICES:
            return None, 'invalid_query'
        status = status_raw

    genre_id = None
    if genre_raw is not None and genre_raw != '':
        try:
            val = int(genre_raw)
            if val <= 0:
                return None, 'invalid_query'
            genre_id = val
        except (ValueError, TypeError):
            return None, 'invalid_query'

    language_id = None
    if language_raw is not None and language_raw != '':
        try:
            val = int(language_raw)
            if val <= 0:
                return None, 'invalid_query'
            language_id = val
        except (ValueError, TypeError):
            return None, 'invalid_query'

    return {
        'q': q,
        'status': status,
        'genre': genre_id,
        'language': language_id,
        'q_raw': q_raw or '',
        'status_raw': status_raw or '',
        'genre_raw': str(genre_raw) if genre_raw is not None else '',
        'language_raw': str(language_raw) if language_raw is not None else '',
    }, None


def apply_book_filters(queryset, filters):
    """Applies validated filters to a Book queryset."""
    if filters.get('q'):
        q_val = filters['q']
        queryset = queryset.filter(Q(title__icontains=q_val) | Q(summary__icontains=q_val))

    if filters.get('status'):
        queryset = queryset.filter(bookinstance__status=filters['status'])

    if filters.get('genre'):
        queryset = queryset.filter(genre__id=filters['genre'])

    if filters.get('language'):
        queryset = queryset.filter(language_id=filters['language'])

    return queryset.order_by('title', 'id').distinct()


def book_list_api(request):
    """Public JSON API endpoint for books with search, faceted filters and pagination."""
    filters, error = parse_and_validate_filters(request.GET)
    if error:
        return JsonResponse({'error': 'invalid_query'}, status=400)

    # Validate page query param
    page_param = request.GET.get('page', '1')
    try:
        page_num = int(page_param)
        if page_num < 1:
            return JsonResponse({'error': 'invalid_query'}, status=400)
    except (ValueError, TypeError):
        return JsonResponse({'error': 'invalid_query'}, status=400)

    qs = apply_book_filters(
        Book.objects.select_related('author').prefetch_related('genre'),
        filters
    )

    paginator = Paginator(qs, 10)
    count = paginator.count

    if count == 0:
        if page_num != 1:
            return JsonResponse({'error': 'invalid_query'}, status=400)
        return JsonResponse({
            'count': 0,
            'page': 1,
            'num_pages': 1,
            'results': []
        })

    if page_num > paginator.num_pages:
        return JsonResponse({'error': 'invalid_query'}, status=400)

    page_obj = paginator.page(page_num)

    results = []
    for book in page_obj.object_list:
        author_display = None
        if book.author:
            author_display = f'{book.author.last_name}, {book.author.first_name}'
        genre_names = sorted([g.name for g in book.genre.all()])
        results.append({
            'id': book.id,
            'title': book.title,
            'author': author_display,
            'isbn': book.isbn,
            'genre': genre_names,
        })

    return JsonResponse({
        'count': count,
        'page': page_num,
        'num_pages': paginator.num_pages,
        'results': results
    })

def index(request):
    """View function for home page of site."""
    # Generate counts of some of the main objects
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available copies of books
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Number of visits to this view, as counted in the session variable.
    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    # Render the HTML template index.html with the data in the context variable.
    return render(request, 'index.html', context=context)

from django.views import generic


class BookListView(generic.ListView):
    """Generic class-based view for a list of books with search and faceted filters."""
    model = Book
    paginate_by = 10

    def dispatch(self, request, *args, **kwargs):
        filters, error = parse_and_validate_filters(request.GET)
        self.filter_error = error
        self.filters = filters
        try:
            return super().dispatch(request, *args, **kwargs)
        except (PageNotAnInteger, EmptyPage, Http404):
            # En UI: responder 200 con mensaje de error o página vacía sin traceback
            self.filter_error = 'invalid_query'
            self.object_list = Book.objects.none()
            context = self.get_context_data(
                object_list=self.object_list,
                is_paginated=False,
                page_obj=None,
                paginator=None,
            )
            return self.render_to_response(context)

    def get_queryset(self):
        if self.filter_error:
            return Book.objects.none()
        qs = Book.objects.select_related('author').prefetch_related('genre')
        return apply_book_filters(qs, self.filters)

    def paginate_queryset(self, queryset, page_size):
        try:
            return super().paginate_queryset(queryset, page_size)
        except (PageNotAnInteger, EmptyPage, Http404):
            self.filter_error = 'invalid_query'
            paginator = self.get_paginator(
                queryset,
                page_size,
                orphans=self.get_paginate_orphans(),
                allow_empty_first_page=self.get_allow_empty(),
            )
            return (paginator, None, [], False)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['genres'] = Genre.objects.all().order_by('name')
        context['languages'] = Language.objects.all().order_by('name')
        context['status_choices'] = [
            ('a', 'Available'),
            ('r', 'Reserved'),
            ('o', 'On loan'),
            ('m', 'Maintenance'),
        ]
        context['filter_error'] = self.filter_error
        context['current_q'] = self.filters['q_raw'] if self.filters else self.request.GET.get('q', '')
        context['current_status'] = self.filters['status_raw'] if self.filters else self.request.GET.get('status', '')
        context['current_genre'] = self.filters['genre_raw'] if self.filters else self.request.GET.get('genre', '')
        context['current_language'] = self.filters['language_raw'] if self.filters else self.request.GET.get('language', '')
        return context

class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre

class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10

class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language

class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10

class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10

class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance

from django.contrib.auth.mixins import LoginRequiredMixin

class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )

# Added as part of challenge!
from django.contrib.auth.mixins import PermissionRequiredMixin


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')

from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
import datetime
from django.contrib.auth.decorators import login_required, permission_required
from catalog.forms import RenewBookForm


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed'))

    # If this is a GET (or any other method) create the default form
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import RestrictedError
from django.contrib.auth.mixins import PermissionRequiredMixin
from .models import Author


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'

class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    # Not recommended (potential security issue if more fields added)
    fields = '__all__'
    permission_required = 'catalog.change_author'

class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("author-delete", kwargs={"pk": self.object.pk})
            )

# Classes created for the forms challenge


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("book-delete", kwargs={"pk": self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    # fields = "__all__"
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'
