from django.test import TestCase
from django.urls import reverse
from catalog.models import Book, Author, Genre, Language, BookInstance


class BookFacetedSearchAPITest(TestCase):
    @classmethod
    def setUpTestData(cls):
        # Create Authors
        cls.author1 = Author.objects.create(first_name='Arthur', last_name='Conan Doyle')
        cls.author2 = Author.objects.create(first_name='Agatha', last_name='Christie')

        # Create Languages
        cls.lang_en = Language.objects.create(name='English')
        cls.lang_es = Language.objects.create(name='Spanish')

        # Create Genres
        cls.genre_mystery = Genre.objects.create(name='Mystery')
        cls.genre_crime = Genre.objects.create(name='Crime')
        cls.genre_sci_fi = Genre.objects.create(name='Science Fiction')

        # Create Books (12 books to test pagination of 10)
        cls.books = []
        for i in range(1, 13):
            # Book title sorted alphabetically
            book = Book.objects.create(
                title=f'Book {i:02d}',
                summary=f'Summary containing keyword_{i:02d} and general plot.',
                isbn=f'9780000000{i:02d}',
                author=cls.author1 if i % 2 == 1 else cls.author2,
                language=cls.lang_en if i <= 8 else cls.lang_es,
            )
            # Add genres
            if i % 2 == 1:
                book.genre.add(cls.genre_mystery)
            if i % 3 == 0:
                book.genre.add(cls.genre_crime)
            cls.books.append(book)

        # Create BookInstances for statuses
        # Book 01: status 'a' and 'm'
        BookInstance.objects.create(book=cls.books[0], imprint='Imp 1', status=BookInstance.LoanStatus.AVAILABLE)
        BookInstance.objects.create(book=cls.books[0], imprint='Imp 2', status=BookInstance.LoanStatus.MAINTENANCE)
        # Book 02: status 'o'
        BookInstance.objects.create(book=cls.books[1], imprint='Imp 3', status=BookInstance.LoanStatus.ON_LOAN)
        # Book 03: status 'r'
        BookInstance.objects.create(book=cls.books[2], imprint='Imp 4', status=BookInstance.LoanStatus.RESERVED)

    def test_api_public_and_contract_structure(self):
        """GET /catalog/api/books/ returns 200 with proper json structure."""
        url = reverse('book-list-api')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response['Content-Type'], 'application/json')
        data = response.json()
        self.assertIn('count', data)
        self.assertIn('page', data)
        self.assertIn('num_pages', data)
        self.assertIn('results', data)
        self.assertEqual(data['count'], 12)
        self.assertEqual(data['page'], 1)
        self.assertEqual(data['num_pages'], 2)
        self.assertEqual(len(data['results']), 10)

        # Test result item structure
        first_item = data['results'][0]
        self.assertIn('id', first_item)
        self.assertIn('title', first_item)
        self.assertIn('author', first_item)
        self.assertIn('isbn', first_item)
        self.assertIn('genre', first_item)
        self.assertEqual(first_item['title'], 'Book 01')
        self.assertEqual(first_item['author'], 'Conan Doyle, Arthur')
        self.assertIsInstance(first_item['genre'], list)

    def test_api_deterministic_ordering_and_distinct(self):
        """Results must be ordered by ('title', 'id') ascending without duplicates."""
        url = reverse('book-list-api')
        response = self.client.get(url)
        data = response.json()
        titles = [b['title'] for b in data['results']]
        self.assertEqual(titles, sorted(titles))

    def test_api_pagination_second_page(self):
        """Page 2 returns the remaining 2 books."""
        url = reverse('book-list-api')
        response = self.client.get(url, {'page': 2})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 12)
        self.assertEqual(data['page'], 2)
        self.assertEqual(data['num_pages'], 2)
        self.assertEqual(len(data['results']), 2)

    def test_api_filter_q(self):
        """Filter q searches title or summary icontains, whitespace is trimmed, empty ignored."""
        url = reverse('book-list-api')
        # Search by summary keyword
        response = self.client.get(url, {'q': '  keyword_01  '})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 1)
        self.assertEqual(data['results'][0]['title'], 'Book 01')

        # Empty q after trim
        response_empty_q = self.client.get(url, {'q': '   '})
        self.assertEqual(response_empty_q.status_code, 200)
        self.assertEqual(response_empty_q.json()['count'], 12)

    def test_api_filter_status(self):
        """Filter status filters books having at least one copy with that status."""
        url = reverse('book-list-api')
        response = self.client.get(url, {'status': 'a'})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 1)
        self.assertEqual(data['results'][0]['title'], 'Book 01')

        # Invalid status returns 400 {'error': 'invalid_query'}
        for invalid_val in ['x', 'available', 'ab', '']:
            # Note: empty string for status: when passed as invalid or ignored?
            # Prompt: "status: cadena de texto de un solo caracter. Valores válidos exactos: 'a', 'r', 'o', 'm'... Si se pasa cualquier otro valor (o longitud != 1), la API debe responder 400"
            if invalid_val != '':
                resp = self.client.get(url, {'status': invalid_val})
                self.assertEqual(resp.status_code, 400)
                self.assertEqual(resp.json(), {'error': 'invalid_query'})

    def test_api_filter_genre(self):
        """Filter genre filters books with that Genre id."""
        url = reverse('book-list-api')
        response = self.client.get(url, {'genre': self.genre_mystery.id})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        # Odd books (1, 3, 5, 7, 9, 11) -> 6 books
        self.assertEqual(data['count'], 6)

        # Invalid genre returns 400
        for bad_genre in ['abc', '0', '-5', '1.5']:
            resp = self.client.get(url, {'genre': bad_genre})
            self.assertEqual(resp.status_code, 400)
            self.assertEqual(resp.json(), {'error': 'invalid_query'})

    def test_api_filter_language(self):
        """Filter language filters books by language_id."""
        url = reverse('book-list-api')
        response = self.client.get(url, {'language': self.lang_es.id})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        # Books 9, 10, 11, 12 -> 4 books
        self.assertEqual(data['count'], 4)

        # Invalid language returns 400
        for bad_lang in ['bad', '-1', '0']:
            resp = self.client.get(url, {'language': bad_lang})
            self.assertEqual(resp.status_code, 400)
            self.assertEqual(resp.json(), {'error': 'invalid_query'})

    def test_api_filter_combination_and(self):
        """Filters combine with AND logic."""
        url = reverse('book-list-api')
        # q matches Book 01, status is 'a'
        resp = self.client.get(url, {
            'q': 'Book 01',
            'status': 'a',
            'genre': self.genre_mystery.id,
            'language': self.lang_en.id
        })
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()['count'], 1)

        # Combination where no book matches
        resp_none = self.client.get(url, {
            'q': 'Book 01',
            'language': self.lang_es.id
        })
        self.assertEqual(resp_none.status_code, 200)
        data_none = resp_none.json()
        self.assertEqual(data_none, {
            'count': 0,
            'page': 1,
            'num_pages': 1,
            'results': []
        })

    def test_api_invalid_page(self):
        """Page <= 0, non-integer, or > num_pages returns 400 {'error': 'invalid_query'}."""
        url = reverse('book-list-api')
        for bad_page in ['0', '-1', 'abc', '3', '999']:
            resp = self.client.get(url, {'page': bad_page})
            self.assertEqual(resp.status_code, 400)
            self.assertEqual(resp.json(), {'error': 'invalid_query'})

    def test_api_empty_db_or_no_results(self):
        """If 0 results, count=0, page=1, num_pages=1, results=[]."""
        url = reverse('book-list-api')
        resp = self.client.get(url, {'q': 'NonExistentTitleKeywordXYZ'})
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json(), {
            'count': 0,
            'page': 1,
            'num_pages': 1,
            'results': []
        })

    def test_api_author_null_handling(self):
        """Author can be null in book, should serialize as null."""
        book_no_author = Book.objects.create(
            title='Book Without Author',
            summary='No author summary',
            isbn='9789999999999',
            author=None,
        )
        url = reverse('book-list-api')
        resp = self.client.get(url, {'q': 'Without Author'})
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertEqual(data['count'], 1)
        self.assertIsNone(data['results'][0]['author'])


class BookFacetedSearchUIViewTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.author = Author.objects.create(first_name='Arthur', last_name='Conan Doyle')
        cls.lang = Language.objects.create(name='English')
        cls.genre = Genre.objects.create(name='Mystery')
        for i in range(1, 15):
            b = Book.objects.create(
                title=f'UI Book {i:02d}',
                summary='Sample description',
                isbn=f'9781111111{i:02d}',
                author=cls.author,
                language=cls.lang,
            )
            b.genre.add(cls.genre)

    def test_ui_renders_search_form_inputs(self):
        """Book list UI includes GET form with inputs for q, genre, language, status."""
        url = reverse('books')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, '<input type="text" name="q" id="q"')
        self.assertContains(response, 'name="genre"')
        self.assertContains(response, 'name="language"')
        self.assertContains(response, 'name="status"')

    def test_ui_pagination_preserves_query_params(self):
        """Pagination links preserve active query params via querystring tag."""
        url = reverse('books')
        response = self.client.get(url, {'q': 'UI Book', 'genre': self.genre.id})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.context['is_paginated'])
        # querystring tag in Django preserves existing GET params
        self.assertContains(response, 'page=2')
        self.assertContains(response, 'q=UI+Book')
        self.assertContains(response, f'genre={self.genre.id}')

    def test_ui_empty_results_message(self):
        """If search produces no results, visible empty list message is shown."""
        url = reverse('books')
        response = self.client.get(url, {'q': 'NoMatchingBookTitleHere'})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'There are no books matching your criteria or no books in the library.')

    def test_ui_invalid_parameters_return_200_without_traceback(self):
        """Invalid query parameters return 200 rendering error message without 500 error."""
        url = reverse('books')
        for bad_params in [
            {'status': 'invalid'},
            {'genre': 'not-an-id'},
            {'language': '-5'},
            {'page': 'not-a-number'},
            {'page': '9999'},
        ]:
            response = self.client.get(url, bad_params)
            self.assertEqual(response.status_code, 200)
            self.assertContains(response, 'alert-danger')
