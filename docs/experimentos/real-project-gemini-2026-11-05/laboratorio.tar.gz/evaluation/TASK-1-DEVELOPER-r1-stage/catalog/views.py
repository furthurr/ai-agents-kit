from django.shortcuts import render

# Create your views here.

from .models import Book, Author, BookInstance, Genre, Language

def index(request):
    """View function for home page of site."""
    # Generate counts of some of the main objects
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available copies of books
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Number of visits to this view, as counted in the session variable.
    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    # Render the HTML template index.html with the data in the context variable.
    return render(request, 'index.html', context=context)

from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger, InvalidPage
from django.db.models import Q
from django.http import Http404, JsonResponse
from django.views import generic

VALID_STATUSES = {'a', 'r', 'o', 'm'}


def parse_and_filter_books(params):
    """
    Parses query params and filters books according to faceted search criteria.
    Returns:
        (queryset, clean_params, error_msg)
    """
    clean_params = {
        'q': '',
        'status': '',
        'genre': '',
        'language': '',
        'page': '',
    }
    error_msg = None

    # q parameter
    if 'q' in params:
        raw_q = params.get('q', '')
        q_stripped = raw_q.strip()
        clean_params['q'] = q_stripped

    # status parameter
    if 'status' in params:
        raw_status = params.get('status', '')
        if raw_status != '':
            if len(raw_status) == 1 and raw_status in VALID_STATUSES:
                clean_params['status'] = raw_status
            else:
                error_msg = 'Invalid query parameters: status must be one of "a", "r", "o", "m".'

    # genre parameter
    if 'genre' in params:
        raw_genre = params.get('genre', '')
        if raw_genre != '':
            try:
                genre_int = int(raw_genre)
                if genre_int > 0 and str(genre_int) == raw_genre.strip():
                    clean_params['genre'] = genre_int
                else:
                    error_msg = 'Invalid query parameters: genre must be a positive integer.'
            except (ValueError, TypeError):
                error_msg = 'Invalid query parameters: genre must be a positive integer.'

    # language parameter
    if 'language' in params:
        raw_language = params.get('language', '')
        if raw_language != '':
            try:
                lang_int = int(raw_language)
                if lang_int > 0 and str(lang_int) == raw_language.strip():
                    clean_params['language'] = lang_int
                else:
                    error_msg = 'Invalid query parameters: language must be a positive integer.'
            except (ValueError, TypeError):
                error_msg = 'Invalid query parameters: language must be a positive integer.'

    # page parameter
    if 'page' in params:
        raw_page = params.get('page', '')
        if raw_page != '':
            try:
                page_int = int(raw_page)
                if page_int >= 1 and str(page_int) == raw_page.strip():
                    clean_params['page'] = page_int
                else:
                    error_msg = 'Invalid query parameters: page must be an integer >= 1.'
            except (ValueError, TypeError):
                error_msg = 'Invalid query parameters: page must be an integer >= 1.'

    qs = Book.objects.all().select_related('author', 'language').prefetch_related('genre')

    if clean_params['q']:
        qs = qs.filter(Q(title__icontains=clean_params['q']) | Q(summary__icontains=clean_params['q']))

    if clean_params['status']:
        qs = qs.filter(bookinstance__status=clean_params['status'])

    if clean_params['genre']:
        qs = qs.filter(genre=clean_params['genre'])

    if clean_params['language']:
        qs = qs.filter(language_id=clean_params['language'])

    qs = qs.distinct().order_by('title', 'id')

    return qs, clean_params, error_msg


def book_list_api(request):
    """Public JSON API endpoint for faceted book search and pagination."""
    qs, clean_params, error_msg = parse_and_filter_books(request.GET)
    if error_msg:
        return JsonResponse({'error': 'invalid_query'}, status=400)

    paginator = Paginator(qs, 10)
    total_count = paginator.count
    num_pages = paginator.num_pages if paginator.count > 0 else 1

    requested_page = clean_params['page'] if clean_params['page'] != '' else 1

    if requested_page > num_pages:
        return JsonResponse({'error': 'invalid_query'}, status=400)

    if total_count == 0:
        current_page_number = 1
        page_results = []
    else:
        page_obj = paginator.page(requested_page)
        current_page_number = page_obj.number
        page_results = []
        for book in page_obj.object_list:
            author_name = str(book.author) if book.author else None
            genre_names = sorted([g.name for g in book.genre.all()])
            page_results.append({
                'id': book.id,
                'title': book.title,
                'author': author_name,
                'isbn': book.isbn,
                'genre': genre_names,
            })

    return JsonResponse({
        'count': total_count,
        'page': current_page_number,
        'num_pages': num_pages,
        'results': page_results,
    })


class BookListView(generic.ListView):
    """Generic class-based view for a list of books with faceted search."""
    model = Book
    paginate_by = 10
    template_name = 'catalog/book_list.html'

    def get(self, request, *args, **kwargs):
        self.error_msg = None
        self.clean_params = {
            'q': '',
            'status': '',
            'genre': '',
            'language': '',
            'page': '',
        }
        self.qs, self.clean_params, self.error_msg = parse_and_filter_books(request.GET)
        return super().get(request, *args, **kwargs)

    def get_queryset(self):
        if self.error_msg:
            return Book.objects.none()
        return self.qs

    def paginate_queryset(self, queryset, page_size):
        if self.error_msg:
            paginator = self.get_paginator(queryset, page_size)
            page = paginator.get_page(1)
            return (paginator, page, [], False)
        try:
            return super().paginate_queryset(queryset, page_size)
        except (Http404, EmptyPage, PageNotAnInteger, InvalidPage):
            paginator = self.get_paginator(queryset, page_size)
            # Para una página fuera de rango o inválida en UI, responder 200 con mensaje de error o página vacía sin traceback
            page = paginator.get_page(None)
            self.error_msg = 'Invalid page requested.'
            return (paginator, page, [], False)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['error_msg'] = self.error_msg
        context['query_params'] = self.clean_params
        context['genres'] = Genre.objects.all().order_by('name')
        context['languages'] = Language.objects.all().order_by('name')
        context['status_choices'] = BookInstance.LoanStatus.choices
        return context

class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre

class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10

class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language

class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10

class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10

class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance

from django.contrib.auth.mixins import LoginRequiredMixin

class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )

# Added as part of challenge!
from django.contrib.auth.mixins import PermissionRequiredMixin


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')

from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
import datetime
from django.contrib.auth.decorators import login_required, permission_required
from catalog.forms import RenewBookForm


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed'))

    # If this is a GET (or any other method) create the default form
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import RestrictedError
from django.contrib.auth.mixins import PermissionRequiredMixin
from .models import Author


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'

class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    # Not recommended (potential security issue if more fields added)
    fields = '__all__'
    permission_required = 'catalog.change_author'

class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("author-delete", kwargs={"pk": self.object.pk})
            )

# Classes created for the forms challenge


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("book-delete", kwargs={"pk": self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    # fields = "__all__"
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'
