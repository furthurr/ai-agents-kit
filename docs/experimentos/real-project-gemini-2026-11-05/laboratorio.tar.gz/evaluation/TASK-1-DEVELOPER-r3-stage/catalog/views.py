from django.shortcuts import render

# Create your views here.

from .models import Book, Author, BookInstance, Genre, Language

def index(request):
    """View function for home page of site."""
    # Generate counts of some of the main objects
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available copies of books
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Number of visits to this view, as counted in the session variable.
    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    # Render the HTML template index.html with the data in the context variable.
    return render(request, 'index.html', context=context)

from django.http import JsonResponse
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q
from django.views import generic

VALID_STATUSES = {'a', 'r', 'o', 'm'}


def filter_books_queryset(params):
    """
    Parses and validates query parameters.
    Returns (queryset, error_message, cleaned_params).
    If a parameter is invalid, error_message is populated.
    """
    errors = []
    cleaned = {
        'q': '',
        'status': '',
        'genre': '',
        'language': '',
    }

    qs = Book.objects.all().prefetch_related('genre').select_related('author', 'language')

    # 1. q
    q_val = params.get('q')
    if q_val is not None:
        q_val_trimmed = q_val.strip()
        cleaned['q'] = q_val_trimmed
        if q_val_trimmed:
            qs = qs.filter(Q(title__icontains=q_val_trimmed) | Q(summary__icontains=q_val_trimmed))

    # 2. status
    status_val = params.get('status')
    if status_val is not None and status_val != '':
        if len(status_val) != 1 or status_val not in VALID_STATUSES:
            errors.append('Invalid status parameter.')
        else:
            cleaned['status'] = status_val
            qs = qs.filter(bookinstance__status=status_val)

    # 3. genre
    genre_val = params.get('genre')
    if genre_val is not None and genre_val != '':
        try:
            genre_id = int(genre_val)
            if genre_id <= 0:
                raise ValueError()
            cleaned['genre'] = genre_id
            qs = qs.filter(genre__id=genre_id)
        except (ValueError, TypeError):
            errors.append('Invalid genre parameter.')

    # 4. language
    language_val = params.get('language')
    if language_val is not None and language_val != '':
        try:
            language_id = int(language_val)
            if language_id <= 0:
                raise ValueError()
            cleaned['language'] = language_id
            qs = qs.filter(language_id=language_id)
        except (ValueError, TypeError):
            errors.append('Invalid language parameter.')

    qs = qs.order_by('title', 'id').distinct()

    if errors:
        return qs, errors[0], cleaned
    return qs, None, cleaned


def book_list_api(request):
    """Public JSON API endpoint for books with search, faceted filters and pagination."""
    if request.method != 'GET':
        return JsonResponse({'error': 'Method not allowed'}, status=405)

    qs, error, cleaned = filter_books_queryset(request.GET)
    if error:
        return JsonResponse({'error': 'invalid_query'}, status=400)

    page_param = request.GET.get('page', 1)
    try:
        page_num = int(page_param)
        if page_num < 1:
            return JsonResponse({'error': 'invalid_query'}, status=400)
    except (ValueError, TypeError):
        return JsonResponse({'error': 'invalid_query'}, status=400)

    paginator = Paginator(qs, 10)
    total_count = paginator.count

    if total_count == 0:
        if page_num != 1:
            return JsonResponse({'error': 'invalid_query'}, status=400)
        return JsonResponse({
            'count': 0,
            'page': 1,
            'num_pages': 1,
            'results': [],
        })

    if page_num > paginator.num_pages:
        return JsonResponse({'error': 'invalid_query'}, status=400)

    page_obj = paginator.page(page_num)

    results = []
    for book in page_obj.object_list:
        if book.author:
            author_display = f'{book.author.last_name}, {book.author.first_name}'
        else:
            author_display = None

        genre_names = sorted([g.name for g in book.genre.all()])

        results.append({
            'id': book.id,
            'title': book.title,
            'author': author_display,
            'isbn': book.isbn,
            'genre': genre_names,
        })

    return JsonResponse({
        'count': total_count,
        'page': page_num,
        'num_pages': paginator.num_pages,
        'results': results,
    })


class BookListView(generic.ListView):
    """Generic class-based view for a list of books with faceted filters."""
    model = Book
    paginate_by = 10

    def get(self, request, *args, **kwargs):
        self.error_message = None
        self.cleaned_filters = {}
        qs, error, cleaned = filter_books_queryset(request.GET)
        self.cleaned_filters = cleaned
        if error:
            self.error_message = error

        # Validate page parameter if present
        page_param = request.GET.get('page')
        if page_param:
            try:
                page_val = int(page_param)
                if page_val < 1:
                    self.error_message = "Invalid page parameter."
            except (ValueError, TypeError):
                self.error_message = "Invalid page parameter."

        return super().get(request, *args, **kwargs)

    def get_queryset(self):
        if self.error_message:
            return Book.objects.none()
        qs, error, cleaned = filter_books_queryset(self.request.GET)
        return qs

    def paginate_queryset(self, queryset, page_size):
        paginator = self.get_paginator(
            queryset,
            page_size,
            orphans=self.get_paginate_orphans(),
            allow_empty_first_page=self.get_allow_empty(),
        )
        page_kwarg = self.page_kwarg
        page = self.kwargs.get(page_kwarg) or self.request.GET.get(page_kwarg) or 1
        try:
            page_number = int(page)
        except ValueError:
            if page == "last":
                page_number = paginator.num_pages
            else:
                self.error_message = "Requested page is invalid."
                return (paginator, None, [], False)

        try:
            page_obj = paginator.page(page_number)
            return (paginator, page_obj, page_obj.object_list, page_obj.has_other_pages())
        except (EmptyPage, PageNotAnInteger):
            self.error_message = "Requested page is out of range."
            return (paginator, None, [], False)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['error_message'] = self.error_message
        context['current_filters'] = self.cleaned_filters
        context['genres'] = Genre.objects.all().order_by('name')
        context['languages'] = Language.objects.all().order_by('name')
        context['loan_statuses'] = [
            (BookInstance.LoanStatus.AVAILABLE.value, 'Available'),
            (BookInstance.LoanStatus.ON_LOAN.value, 'On loan'),
            (BookInstance.LoanStatus.RESERVED.value, 'Reserved'),
            (BookInstance.LoanStatus.MAINTENANCE.value, 'Maintenance'),
        ]
        return context

class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre

class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10

class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language

class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10

class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10

class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance

from django.contrib.auth.mixins import LoginRequiredMixin

class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )

# Added as part of challenge!
from django.contrib.auth.mixins import PermissionRequiredMixin


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')

from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
import datetime
from django.contrib.auth.decorators import login_required, permission_required
from catalog.forms import RenewBookForm


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed'))

    # If this is a GET (or any other method) create the default form
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import RestrictedError
from django.contrib.auth.mixins import PermissionRequiredMixin
from .models import Author


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'

class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    # Not recommended (potential security issue if more fields added)
    fields = '__all__'
    permission_required = 'catalog.change_author'

class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("author-delete", kwargs={"pk": self.object.pk})
            )

# Classes created for the forms challenge


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("book-delete", kwargs={"pk": self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    # fields = "__all__"
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'
