# Spec: Búsqueda y Filtros Facetados con Paginación en Catálogo (UI y API)

Modo SDD: tiny
Estado: Cerrado (Gate 4 aprobado)

## 1. Alcance y aceptación

### Objetivo
Proveer búsqueda textual y filtros facetados (`q`, `status`, `genre`, `language`) con paginación determinista fija de 10 elementos por página tanto en la vista UI HTML (`/catalog/books/`) como en un endpoint público JSON (`GET /catalog/api/books/`).

### Contratos exactos

#### 1. Endpoint API: `GET /catalog/api/books/`
- Público, no requiere autenticación.
- Parámetros de consulta (query params):
  - `q`: string. Si no está vacía tras `.strip()`, filtrar libros donde `Book.title` o `Book.summary` contenga el texto (`icontains`). Si tras trim queda vacía, ignorar filtro.
  - `status`: string de un solo carácter. Valores válidos exactos: `'a'`, `'r'`, `'o'`, `'m'`. Filtra libros que posean al menos una copia (`BookInstance`) con status igual al valor. Si se pasa cualquier otro valor o longitud != 1, responde HTTP 400 con JSON exacto `{"error": "invalid_query"}`.
  - `genre`: entero positivo (ID de Genre). Filtra libros con `Book.genre = genre`. Si no es entero positivo convertible (texto no numérico, <= 0), responde HTTP 400 con `{"error": "invalid_query"}`.
  - `language`: entero positivo (ID de Language). Filtra libros con `Book.language_id = language`. Si no es entero positivo convertible, responde HTTP 400 con `{"error": "invalid_query"}`.
  - `page`: entero positivo >= 1. Paginación fija de 10 resultados por página. Si `page` no es entero >= 1 o está fuera de rango (excede el total de páginas `num_pages`), responde HTTP 400 con `{"error": "invalid_query"}`.
  - Combinación de filtros: lógica AND.
  - Ordenamiento determinista: `('title', 'id')` ascendente, sin duplicados en resultados (`.distinct()`).
- Estructura de respuesta (200 OK, application/json):
  ```json
  {
    "count": <total_libros_coincidentes_int>,
    "page": <pagina_actual_int>,
    "num_pages": <total_paginas_int>,
    "results": [
      {
        "id": <book_id_int>,
        "title": <book_title_str>,
        "author": <author_display_name_str_o_null>,
        "isbn": <book_isbn_str>,
        "genre": [<lista_de_nombres_de_genero_str_ordenados_alfabeticamente>]
      }
    ]
  }
  ```
  - Si no hay libros en la base o tras filtrar el resultado es 0: `count=0`, `page=1`, `num_pages=1`, `results=[]`.
  - `author`: nombre formateado (`f'{author.last_name}, {author.first_name}'` o `str(author)`) si existe, o `null` si no existe.
  - `genre`: lista de nombres de género ordenados alfabéticamente.

#### 2. Comportamiento UI (`/catalog/books/`):
- Template `catalog/book_list.html` incluye formulario `GET` con inputs etiquetados para:
  - `q` (input text)
  - `genre` (select con opciones de género)
  - `language` (select con opciones de idioma)
  - `status` (select con opciones válidas de disponibilidad)
- Paginación: enlaces anterior/siguiente preservan todos los query params activos (utilizando el tag Django `{% querystring %}`).
- Si la búsqueda no arroja resultados, mostrar mensaje visible de lista vacía.
- Si los parámetros son inválidos (mismas reglas de validación que API), responder HTTP 200 renderizando mensaje de error amigable en HTML sin traceback ni error 500. Si `page` está fuera de rango, responder 200 con mensaje de error o lista vacía sin traceback.

### Invariantes y Exclusiones
- No utilizar librerías externas pesadas (como DRF o Haystack); usar Django nativo, `JsonResponse` y CBV/FBV estándar.
- La suite original de 43 tests debe seguir pasando intacta.

---

## 2. Enfoque técnico y estrategia de pruebas

### Enfoque técnico
1. **Lógica de filtrado y validación común**:
   - `parse_and_filter_books(params)` y `QueryValidationError` en `catalog/views.py`.
   - Consulta ORM eficiente con `prefetch_related('genre')` y `select_related('author')`.
   - Filtro `BookInstance`: `bookinstance__status=status`.
   - Paginador nativo de Django (`Paginator`) con `per_page = 10`.
2. **Endpoint API (`catalog/api/books/`)**:
   - Función de vista `books_api` retornando `JsonResponse`.
   - Manejo exacto de errores 400 con `{"error": "invalid_query"}`.
   - URL registrada en `catalog/urls.py` como `api/books/` con name `api-books`.
3. **Vista UI (`catalog/books/`)**:
   - `BookListView` adaptada para procesar los filtros y query params, manejando excepciones para responder HTTP 200 con mensaje visible amigable (`query_error`).
   - `catalog/book_list.html` actualizado con formulario GET e inputs etiquetados para `q`, `genre`, `language` y `status`.
4. **Estrategia de pruebas**:
   - Suite `catalog/tests/test_search_facets.py` (14 pruebas).
   - Cobertura completa de casos válidos e inválidos de API y UI.
   - Ejecución de la suite completa de 57 tests (43 originales + 14 nuevos).

---

## 3. Checklist

- [x] 1. Definir función de filtrado, validación y paginación en `catalog/views.py`.
- [x] 2. Implementar endpoint público `GET /catalog/api/books/` en `catalog/urls.py` y `catalog/views.py`.
- [x] 3. Actualizar `BookListView` en `catalog/views.py` y el template `catalog/book_list.html` con formulario facetado y manejo amigable de errores.
- [x] 4. Escribir tests exhaustivos para API y UI cubriendo todos los casos de contrato (`catalog/tests/test_search_facets.py`).
- [x] 5. Ejecutar la suite completa (tests nuevos + 43 originales) y verificar que todos pasen limpiamente.

---

## 4. Verificación y cierre

### Comandos ejecutados y resultados observados

1. **Pruebas focalizadas de la nueva funcionalidad:**
   - Comando: `/private/var/folders/d7/z7388kp51w532q4c0rj7hqqh0000gn/T/opencode/real-project-gemini-20261104/.venv/bin/python manage.py test catalog.tests.test_search_facets`
   - Salida:
     ```text
     Creating test database for alias 'default'...
     ..............
     ----------------------------------------------------------------------
     Ran 14 tests in 0.193s

     OK
     Destroying test database for alias 'default'...
     Found 14 test(s).
     ```

2. **Ejecución de la suite completa de regresión:**
   - Comando: `/private/var/folders/d7/z7388kp51w532q4c0rj7hqqh0000gn/T/opencode/real-project-gemini-20261104/.venv/bin/python manage.py test`
   - Salida:
     ```text
     Creating test database for alias 'default'...
     .........................................................
     ----------------------------------------------------------------------
     Ran 57 tests in 9.975s

     OK
     Destroying test database for alias 'default'...
     Found 57 test(s).
     ```

### Registro de fallos locales y reparaciones
- Durante la primera ejecución de tests:
  - Error en `test_api_empty_database_response`: restricción de clave foránea `BookInstance.book` impedía borrar `Book` directamente; corregido borrando instancias antes de libros en el test.
  - Fallo en `test_ui_invalid_parameters_graceful_error`: `paginate_queryset` de Django lanzaba `Http404` ante `page` fuera de rango cuando no se atrapaba antes del dispatch; corregido manejando `EmptyPage` y `PageNotAnInteger` dentro de `paginate_queryset` en `BookListView`, devolviendo HTTP 200 con `query_error=True` sin traceback. Re-ejecución inmediata: 14 de 14 tests aprobados.

### Estado
Completado satisfactoriamente sin violaciones de invariantes ni dependencias adicionales.
