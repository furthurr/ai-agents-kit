from django.http import Http404, JsonResponse
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q
from django.shortcuts import render

# Create your views here.

from .models import Book, Author, BookInstance, Genre, Language


def parse_and_filter_books(params):
    """
    Parses query parameters and filters Book queryset according to contracts:
    - q: string trimmed. If non-empty, icontains on title OR summary. If empty after trim, ignore.
    - status: single char in ('a', 'r', 'o', 'm'). Filters books with >=1 BookInstance with this status.
              Invalid value or len != 1 raises ValueError.
    - genre: positive integer (Genre ID). Filters Book.genre. Non-positive or non-int raises ValueError.
    - language: positive integer (Language ID). Filters Book.language_id. Non-positive or non-int raises ValueError.
    - Combination: AND logic.
    - Deterministic ordering: ('title', 'id') ascending.
    - .distinct() to avoid duplicates.
    """
    qs = Book.objects.all().select_related('author', 'language').prefetch_related('genre')

    cleaned_filters = {}

    if 'q' in params:
        raw_q = params.get('q', '')
        q_stripped = raw_q.strip()
        cleaned_filters['q'] = q_stripped
        if q_stripped:
            qs = qs.filter(Q(title__icontains=q_stripped) | Q(summary__icontains=q_stripped))

    if 'status' in params:
        raw_status = params.get('status')
        if raw_status is not None:
            raw_status = raw_status.strip()
            if raw_status != '':
                valid_statuses = ('a', 'r', 'o', 'm')
                if len(raw_status) != 1 or raw_status not in valid_statuses:
                    raise ValueError("Invalid status")
                cleaned_filters['status'] = raw_status
                qs = qs.filter(bookinstance__status=raw_status)

    if 'genre' in params:
        raw_genre = params.get('genre')
        if raw_genre is not None:
            raw_genre = raw_genre.strip()
            if raw_genre != '':
                try:
                    genre_id = int(raw_genre)
                    if genre_id <= 0:
                        raise ValueError("Genre ID must be positive")
                except (ValueError, TypeError):
                    raise ValueError("Invalid genre")
                cleaned_filters['genre'] = genre_id
                qs = qs.filter(genre__id=genre_id)

    if 'language' in params:
        raw_language = params.get('language')
        if raw_language is not None:
            raw_language = raw_language.strip()
            if raw_language != '':
                try:
                    language_id = int(raw_language)
                    if language_id <= 0:
                        raise ValueError("Language ID must be positive")
                except (ValueError, TypeError):
                    raise ValueError("Invalid language")
                cleaned_filters['language'] = language_id
                qs = qs.filter(language_id=language_id)

    qs = qs.order_by('title', 'id').distinct()
    return qs, cleaned_filters


def book_list_api(request):
    """Public JSON API endpoint for book listing with faceted filters and pagination."""
    try:
        books_qs, _ = parse_and_filter_books(request.GET)
    except ValueError:
        return JsonResponse({'error': 'invalid_query'}, status=400)

    raw_page = request.GET.get('page', '1')
    if raw_page is None or raw_page == '':
        raw_page = '1'
    try:
        page_num = int(raw_page)
        if page_num < 1:
            return JsonResponse({'error': 'invalid_query'}, status=400)
    except (ValueError, TypeError):
        return JsonResponse({'error': 'invalid_query'}, status=400)

    count = books_qs.count()

    if count == 0:
        if page_num != 1:
            return JsonResponse({'error': 'invalid_query'}, status=400)
        return JsonResponse({
            'count': 0,
            'page': 1,
            'num_pages': 1,
            'results': []
        })

    paginator = Paginator(books_qs, 10)
    if page_num > paginator.num_pages:
        return JsonResponse({'error': 'invalid_query'}, status=400)

    page_obj = paginator.page(page_num)

    results = []
    for book in page_obj.object_list:
        results.append({
            'id': book.id,
            'title': book.title,
            'author': str(book.author) if book.author else None,
            'isbn': book.isbn,
            'genre': sorted([g.name for g in book.genre.all()])
        })

    return JsonResponse({
        'count': count,
        'page': page_num,
        'num_pages': paginator.num_pages,
        'results': results
    })


def index(request):
    """View function for home page of site."""
    # Generate counts of some of the main objects
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available copies of books
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Number of visits to this view, as counted in the session variable.
    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    # Render the HTML template index.html with the data in the context variable.
    return render(request, 'index.html', context=context)

from django.views import generic


class BookListView(generic.ListView):
    """Generic class-based view for a list of books with faceted search and filters."""
    model = Book
    paginate_by = 10

    def get(self, request, *args, **kwargs):
        self.error_message = None
        try:
            self.queryset, self.cleaned_filters = parse_and_filter_books(request.GET)
        except ValueError as err:
            self.error_message = "Parámetros de búsqueda o filtros inválidos."
            self.queryset = Book.objects.none()
            self.cleaned_filters = {}
        try:
            return super().get(request, *args, **kwargs)
        except Http404:
            self.error_message = "Página solicitada inválida o fuera de rango."
            self.object_list = Book.objects.none()
            context = self.get_context_data(object_list=self.object_list, is_paginated=False)
            return self.render_to_response(context)

    def paginate_queryset(self, queryset, page_size):
        try:
            return super().paginate_queryset(queryset, page_size)
        except Http404:
            if not self.error_message:
                self.error_message = "Página solicitada inválida o fuera de rango."
            paginator = self.get_paginator(
                queryset, page_size, orphans=self.get_paginate_orphans(),
                allow_empty_first_page=self.get_allow_empty()
            )
            return (paginator, None, [], False)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['genres'] = Genre.objects.all().order_by('name')
        context['languages'] = Language.objects.all().order_by('name')
        context['statuses'] = [
            ('a', 'Available'),
            ('o', 'On loan'),
            ('m', 'Maintenance'),
            ('r', 'Reserved'),
        ]
        context['query_params'] = {
            'q': self.request.GET.get('q', '').strip(),
            'genre': self.request.GET.get('genre', '').strip(),
            'language': self.request.GET.get('language', '').strip(),
            'status': self.request.GET.get('status', '').strip(),
        }
        context['error_message'] = self.error_message
        return context

class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre

class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10

class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language

class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10

class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10

class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance

from django.contrib.auth.mixins import LoginRequiredMixin

class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )

# Added as part of challenge!
from django.contrib.auth.mixins import PermissionRequiredMixin


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')

from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
import datetime
from django.contrib.auth.decorators import login_required, permission_required
from catalog.forms import RenewBookForm


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed'))

    # If this is a GET (or any other method) create the default form
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import RestrictedError
from django.contrib.auth.mixins import PermissionRequiredMixin
from .models import Author


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'

class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    # Not recommended (potential security issue if more fields added)
    fields = '__all__'
    permission_required = 'catalog.change_author'

class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("author-delete", kwargs={"pk": self.object.pk})
            )

# Classes created for the forms challenge


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("book-delete", kwargs={"pk": self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    # fields = "__all__"
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'
