from django.test import TestCase
from django.urls import reverse
from catalog.models import Book, Author, Genre, Language, BookInstance


class BookFilterAndApiTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.author1 = Author.objects.create(first_name='Arthur', last_name='Conan Doyle')
        cls.author2 = Author.objects.create(first_name='Agatha', last_name='Christie')
        cls.genre_mystery = Genre.objects.create(name='Mystery')
        cls.genre_scifi = Genre.objects.create(name='Sci-Fi')
        cls.genre_history = Genre.objects.create(name='History')
        cls.lang_en = Language.objects.create(name='English')
        cls.lang_es = Language.objects.create(name='Spanish')

        cls.book1 = Book.objects.create(
            title='A Study in Scarlet',
            summary='First Sherlock Holmes novel with great investigation',
            isbn='1111111111111',
            author=cls.author1,
            language=cls.lang_en
        )
        cls.book1.genre.add(cls.genre_mystery)

        cls.book2 = Book.objects.create(
            title='The Hound of the Baskervilles',
            summary='Sherlock investigates a hound',
            isbn='2222222222222',
            author=cls.author1,
            language=cls.lang_en
        )
        cls.book2.genre.add(cls.genre_scifi, cls.genre_mystery)

        cls.book3 = Book.objects.create(
            title='Murder on the Orient Express',
            summary='Hercule Poirot investigates murder on a train',
            isbn='3333333333333',
            author=cls.author2,
            language=cls.lang_es
        )
        cls.book3.genre.add(cls.genre_mystery)

        cls.book_no_author = Book.objects.create(
            title='Anonymous Chronicles',
            summary='No author book',
            isbn='4444444444444',
            author=None,
            language=cls.lang_es
        )

        # BookInstances
        BookInstance.objects.create(
            book=cls.book1,
            status=BookInstance.LoanStatus.AVAILABLE,
            imprint='London 1887'
        )
        BookInstance.objects.create(
            book=cls.book1,
            status=BookInstance.LoanStatus.ON_LOAN,
            imprint='London 1890'
        )
        BookInstance.objects.create(
            book=cls.book2,
            status=BookInstance.LoanStatus.MAINTENANCE,
            imprint='London 1902'
        )
        BookInstance.objects.create(
            book=cls.book3,
            status=BookInstance.LoanStatus.RESERVED,
            imprint='London 1934'
        )

    # 1. API Endpoint tests
    def test_api_endpoint_public_access(self):
        response = self.client.get('/catalog/api/books/')
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 4)
        self.assertEqual(data['page'], 1)
        self.assertEqual(data['num_pages'], 1)
        self.assertEqual(len(data['results']), 4)
        # Check ordering ('title', 'id')
        titles = [b['title'] for b in data['results']]
        self.assertEqual(titles, sorted(titles))

    def test_api_result_fields(self):
        response = self.client.get('/catalog/api/books/', {'q': 'Orient Express'})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 1)
        item = data['results'][0]
        self.assertEqual(item['id'], self.book3.id)
        self.assertEqual(item['title'], 'Murder on the Orient Express')
        self.assertEqual(item['author'], 'Christie, Agatha')
        self.assertEqual(item['isbn'], '3333333333333')
        self.assertEqual(item['genre'], ['Mystery'])

    def test_api_null_author_and_sorted_genres(self):
        # book2 has Sci-Fi and Mystery
        response = self.client.get('/catalog/api/books/', {'q': 'Hound'})
        self.assertEqual(response.status_code, 200)
        item = response.json()['results'][0]
        self.assertEqual(item['genre'], ['Mystery', 'Sci-Fi'])

        # book_no_author has author None
        response_no_author = self.client.get('/catalog/api/books/', {'q': 'Anonymous'})
        self.assertEqual(response_no_author.status_code, 200)
        item_no_author = response_no_author.json()['results'][0]
        self.assertIsNone(item_no_author['author'])
        self.assertEqual(item_no_author['genre'], [])

    def test_api_query_q_filter_and_trim(self):
        # Whitespace only q should be ignored
        res_whitespace = self.client.get('/catalog/api/books/', {'q': '   '})
        self.assertEqual(res_whitespace.status_code, 200)
        self.assertEqual(res_whitespace.json()['count'], 4)

        # q matching summary
        res_summary = self.client.get('/catalog/api/books/', {'q': ' Poirot '})
        self.assertEqual(res_summary.status_code, 200)
        self.assertEqual(res_summary.json()['count'], 1)
        self.assertEqual(res_summary.json()['results'][0]['id'], self.book3.id)

        # q matching title
        res_title = self.client.get('/catalog/api/books/', {'q': 'Scarlet'})
        self.assertEqual(res_title.status_code, 200)
        self.assertEqual(res_title.json()['count'], 1)
        self.assertEqual(res_title.json()['results'][0]['id'], self.book1.id)

    def test_api_query_status_filter(self):
        # 'a' -> book1 has available copy
        res_a = self.client.get('/catalog/api/books/', {'status': 'a'})
        self.assertEqual(res_a.status_code, 200)
        self.assertEqual(res_a.json()['count'], 1)
        self.assertEqual(res_a.json()['results'][0]['id'], self.book1.id)

        # 'm' -> book2
        res_m = self.client.get('/catalog/api/books/', {'status': 'm'})
        self.assertEqual(res_m.status_code, 200)
        self.assertEqual(res_m.json()['count'], 1)
        self.assertEqual(res_m.json()['results'][0]['id'], self.book2.id)

    def test_api_query_genre_filter(self):
        res_scifi = self.client.get('/catalog/api/books/', {'genre': self.genre_scifi.id})
        self.assertEqual(res_scifi.status_code, 200)
        self.assertEqual(res_scifi.json()['count'], 1)
        self.assertEqual(res_scifi.json()['results'][0]['id'], self.book2.id)

    def test_api_query_language_filter(self):
        res_lang = self.client.get('/catalog/api/books/', {'language': self.lang_es.id})
        self.assertEqual(res_lang.status_code, 200)
        self.assertEqual(res_lang.json()['count'], 2)

    def test_api_combined_filters_and(self):
        # language=es AND q=train
        res = self.client.get('/catalog/api/books/', {
            'language': self.lang_es.id,
            'q': 'train'
        })
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.json()['count'], 1)
        self.assertEqual(res.json()['results'][0]['id'], self.book3.id)

        # language=en AND q=train -> 0 matches
        res_empty = self.client.get('/catalog/api/books/', {
            'language': self.lang_en.id,
            'q': 'train'
        })
        self.assertEqual(res_empty.status_code, 200)
        self.assertEqual(res_empty.json(), {
            'count': 0,
            'page': 1,
            'num_pages': 1,
            'results': []
        })

    def test_api_invalid_query_cases(self):
        # status invalid value
        res = self.client.get('/catalog/api/books/', {'status': 'x'})
        self.assertEqual(res.status_code, 400)
        self.assertEqual(res.json(), {'error': 'invalid_query'})

        # status invalid length
        res = self.client.get('/catalog/api/books/', {'status': 'ab'})
        self.assertEqual(res.status_code, 400)
        self.assertEqual(res.json(), {'error': 'invalid_query'})

        # genre non-int
        res = self.client.get('/catalog/api/books/', {'genre': 'mystery'})
        self.assertEqual(res.status_code, 400)
        self.assertEqual(res.json(), {'error': 'invalid_query'})

        # genre <= 0
        res = self.client.get('/catalog/api/books/', {'genre': '0'})
        self.assertEqual(res.status_code, 400)
        self.assertEqual(res.json(), {'error': 'invalid_query'})
        res = self.client.get('/catalog/api/books/', {'genre': '-2'})
        self.assertEqual(res.status_code, 400)
        self.assertEqual(res.json(), {'error': 'invalid_query'})

        # language non-int
        res = self.client.get('/catalog/api/books/', {'language': 'english'})
        self.assertEqual(res.status_code, 400)
        self.assertEqual(res.json(), {'error': 'invalid_query'})

        # language <= 0
        res = self.client.get('/catalog/api/books/', {'language': '0'})
        self.assertEqual(res.status_code, 400)
        self.assertEqual(res.json(), {'error': 'invalid_query'})

        # page not int >= 1
        res = self.client.get('/catalog/api/books/', {'page': '0'})
        self.assertEqual(res.status_code, 400)
        self.assertEqual(res.json(), {'error': 'invalid_query'})

        res = self.client.get('/catalog/api/books/', {'page': 'abc'})
        self.assertEqual(res.status_code, 400)
        self.assertEqual(res.json(), {'error': 'invalid_query'})

        # page out of range (> num_pages)
        res = self.client.get('/catalog/api/books/', {'page': '2'})
        self.assertEqual(res.status_code, 400)
        self.assertEqual(res.json(), {'error': 'invalid_query'})

    def test_api_pagination_fixed_ten(self):
        # Create additional books to exceed 10
        for i in range(15):
            Book.objects.create(
                title=f'Extra Book {i:02d}',
                summary='Extra summary',
                isbn=f'99999999999{i:02d}',
                author=self.author1,
                language=self.lang_en
            )
        # Total books = 4 + 15 = 19 -> num_pages = 2
        res_page1 = self.client.get('/catalog/api/books/', {'page': '1'})
        self.assertEqual(res_page1.status_code, 200)
        data1 = res_page1.json()
        self.assertEqual(data1['count'], 19)
        self.assertEqual(data1['page'], 1)
        self.assertEqual(data1['num_pages'], 2)
        self.assertEqual(len(data1['results']), 10)

        res_page2 = self.client.get('/catalog/api/books/', {'page': '2'})
        self.assertEqual(res_page2.status_code, 200)
        data2 = res_page2.json()
        self.assertEqual(data2['count'], 19)
        self.assertEqual(data2['page'], 2)
        self.assertEqual(data2['num_pages'], 2)
        self.assertEqual(len(data2['results']), 9)

        # page 3 out of range
        res_page3 = self.client.get('/catalog/api/books/', {'page': '3'})
        self.assertEqual(res_page3.status_code, 400)
        self.assertEqual(res_page3.json(), {'error': 'invalid_query'})

    # 2. UI Tests (/catalog/books/)
    def test_ui_contains_form_and_labels(self):
        response = self.client.get(reverse('books'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, '<form method="get"')
        self.assertContains(response, 'name="q"')
        self.assertContains(response, 'name="genre"')
        self.assertContains(response, 'name="language"')
        self.assertContains(response, 'name="status"')
        self.assertContains(response, 'Search')
        self.assertContains(response, 'Genre')
        self.assertContains(response, 'Language')
        self.assertContains(response, 'Status')

    def test_ui_filtering_results(self):
        response = self.client.get(reverse('books'), {'q': 'Sherlock'})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'A Study in Scarlet')
        self.assertContains(response, 'The Hound of the Baskervilles')
        self.assertNotContains(response, 'Murder on the Orient Express')

    def test_ui_empty_results_message(self):
        response = self.client.get(reverse('books'), {'q': 'NonExistentStringXYZ'})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'There are no books matching your criteria.')

    def test_ui_invalid_params_handled_with_200_and_no_traceback(self):
        # Invalid status
        res1 = self.client.get(reverse('books'), {'status': 'invalid'})
        self.assertEqual(res1.status_code, 200)
        self.assertContains(res1, 'There are no books matching your criteria.')
        self.assertTrue('error_message' in res1.context)

        # Invalid genre
        res2 = self.client.get(reverse('books'), {'genre': '-5'})
        self.assertEqual(res2.status_code, 200)

        # Invalid language
        res3 = self.client.get(reverse('books'), {'language': 'non_int'})
        self.assertEqual(res3.status_code, 200)

        # Invalid page
        res4 = self.client.get(reverse('books'), {'page': '9999'})
        self.assertEqual(res4.status_code, 200)

    def test_ui_pagination_preserves_query_params(self):
        # Create books so there are 2 pages
        for i in range(12):
            b = Book.objects.create(
                title=f'Z Sherlock Holmes Series {i:02d}',
                summary='Investigating cases',
                isbn=f'88888888888{i:02d}',
                author=self.author1,
                language=self.lang_en
            )
            BookInstance.objects.create(book=b, status=BookInstance.LoanStatus.AVAILABLE)

        response = self.client.get(reverse('books'), {'q': 'Sherlock', 'status': 'a'})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.context['is_paginated'])
        # The pagination links use {% querystring page=... %} which preserves existing query parameters
        content = response.content.decode('utf-8')
        self.assertIn('page=2', content)
        self.assertIn('q=Sherlock', content)
        self.assertIn('status=a', content)
