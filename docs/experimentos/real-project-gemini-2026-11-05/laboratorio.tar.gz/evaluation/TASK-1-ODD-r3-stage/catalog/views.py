from django.shortcuts import render
from django.http import JsonResponse
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q

# Create your views here.

from .models import Book, Author, BookInstance, Genre, Language


VALID_STATUSES = {'a', 'r', 'o', 'm'}


def parse_and_filter_books(params):
    """
    Helper function to validate and filter books query parameters.
    Returns:
        (queryset, clean_params, error_message)
    If error_message is not None, validation failed.
    """
    clean_params = {
        'q': '',
        'status': '',
        'genre': '',
        'language': '',
        'page': '1',
    }
    
    qs = Book.objects.all()

    # 1. q
    raw_q = params.get('q', None)
    if raw_q is not None:
        clean_q = raw_q.strip()
        clean_params['q'] = clean_q
        if clean_q:
            qs = qs.filter(Q(title__icontains=clean_q) | Q(summary__icontains=clean_q))

    # 2. status
    if 'status' in params:
        raw_status = params['status']
        if len(raw_status) != 1 or raw_status not in VALID_STATUSES:
            return None, clean_params, "Invalid status parameter. Must be one of 'a', 'r', 'o', 'm'."
        clean_params['status'] = raw_status
        qs = qs.filter(bookinstance__status=raw_status)

    # 3. genre
    if 'genre' in params:
        raw_genre = params['genre']
        try:
            genre_id = int(raw_genre)
            if genre_id <= 0:
                raise ValueError()
        except (ValueError, TypeError):
            return None, clean_params, "Invalid genre parameter. Must be a positive integer ID."
        clean_params['genre'] = str(genre_id)
        qs = qs.filter(genre__id=genre_id)

    # 4. language
    if 'language' in params:
        raw_lang = params['language']
        try:
            lang_id = int(raw_lang)
            if lang_id <= 0:
                raise ValueError()
        except (ValueError, TypeError):
            return None, clean_params, "Invalid language parameter. Must be a positive integer ID."
        clean_params['language'] = str(lang_id)
        qs = qs.filter(language_id=lang_id)

    # Distinct and deterministic ordering
    qs = qs.distinct().order_by('title', 'id')
    return qs, clean_params, None


def book_list_api(request):
    """Public JSON API endpoint for book listing with search, filtering and pagination."""
    qs, clean_params, error = parse_and_filter_books(request.GET)
    if error is not None:
        return JsonResponse({'error': 'invalid_query'}, status=400)

    raw_page = request.GET.get('page', '1')
    try:
        page_num = int(raw_page)
        if page_num < 1:
            return JsonResponse({'error': 'invalid_query'}, status=400)
    except (ValueError, TypeError):
        return JsonResponse({'error': 'invalid_query'}, status=400)

    count = qs.count()
    if count == 0:
        if page_num != 1:
            return JsonResponse({'error': 'invalid_query'}, status=400)
        return JsonResponse({
            'count': 0,
            'page': 1,
            'num_pages': 1,
            'results': []
        })

    paginator = Paginator(qs, 10)
    if page_num > paginator.num_pages:
        return JsonResponse({'error': 'invalid_query'}, status=400)

    page_obj = paginator.page(page_num)

    results = []
    # Pre-fetch or select related if needed, but for 10 items iterating is standard
    for book in page_obj.object_list.prefetch_related('genre').select_related('author'):
        results.append({
            'id': book.id,
            'title': book.title,
            'author': str(book.author) if book.author else None,
            'isbn': book.isbn,
            'genre': sorted([g.name for g in book.genre.all()]),
        })

    return JsonResponse({
        'count': count,
        'page': page_num,
        'num_pages': paginator.num_pages,
        'results': results,
    })

def index(request):
    """View function for home page of site."""
    # Generate counts of some of the main objects
    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available copies of books
    num_instances_available = BookInstance.objects.filter(
        status__exact=BookInstance.LoanStatus.AVAILABLE).count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Number of visits to this view, as counted in the session variable.
    num_visits = request.session.get('num_visits', 0)
    num_visits += 1
    request.session['num_visits'] = num_visits

    context = {
        'num_books': num_books,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_authors': num_authors,
        'num_visits': num_visits,
    }

    # Render the HTML template index.html with the data in the context variable.
    return render(request, 'index.html', context=context)

from django.views import generic


class BookListView(generic.ListView):
    """Generic class-based view for a list of books with search and faceted filters."""
    model = Book
    paginate_by = 10

    def paginate_queryset(self, queryset, page_size):
        """Override to prevent 404 on invalid/out-of-range page and let get() handle error display."""
        paginator = self.get_paginator(
            queryset,
            page_size,
            orphans=self.get_paginate_orphans(),
            allow_empty_first_page=self.get_allow_empty(),
        )
        page_kwarg = self.page_kwarg
        page = self.kwargs.get(page_kwarg) or self.request.GET.get(page_kwarg) or 1
        try:
            page_number = int(page)
        except ValueError:
            page_number = page
        try:
            page = paginator.page(page_number)
            return (paginator, page, page.object_list, page.has_other_pages())
        except (EmptyPage, PageNotAnInteger):
            return (paginator, None, queryset.none(), False)

    def get(self, request, *args, **kwargs):
        self.filter_error = None
        self.clean_params = {}
        qs, clean_params, error = parse_and_filter_books(request.GET)
        self.clean_params = clean_params
        if error is not None:
            self.filter_error = error
            self.object_list = Book.objects.none()
            context = self.get_context_data(object_list=self.object_list, is_paginated=False)
            return self.render_to_response(context)

        self.object_list = qs
        
        # Check page validity
        if 'page' in request.GET:
            raw_page = request.GET.get('page')
            paginator = self.get_paginator(qs, self.paginate_by)
            try:
                page_num = int(raw_page)
                if page_num < 1:
                    self.filter_error = "Invalid page number. Must be >= 1."
                elif paginator.count > 0 and page_num > paginator.num_pages:
                    self.filter_error = f"Page out of range. Max page is {paginator.num_pages}."
                elif paginator.count == 0 and page_num != 1:
                    self.filter_error = "Page out of range. No results."
            except (ValueError, TypeError):
                self.filter_error = "Invalid page parameter. Must be an integer."

            if self.filter_error:
                self.object_list = Book.objects.none()
                context = self.get_context_data(object_list=self.object_list, is_paginated=False)
                return self.render_to_response(context)

        context = self.get_context_data()
        return self.render_to_response(context)

    def get_queryset(self):
        if hasattr(self, 'object_list') and self.object_list is not None:
            return self.object_list
        qs, _, _ = parse_and_filter_books(self.request.GET)
        return qs

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['filter_error'] = getattr(self, 'filter_error', None)
        context['clean_params'] = getattr(self, 'clean_params', {})
        context['all_genres'] = Genre.objects.all().order_by('name')
        context['all_languages'] = Language.objects.all().order_by('name')
        context['status_choices'] = [
            ('a', 'Available'),
            ('r', 'Reserved'),
            ('o', 'On loan'),
            ('m', 'Maintenance'),
        ]
        return context

class BookDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Book

class AuthorListView(generic.ListView):
    """Generic class-based list view for a list of authors."""
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    """Generic class-based detail view for an author."""
    model = Author


class GenreDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Genre

class GenreListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Genre
    paginate_by = 10

class LanguageDetailView(generic.DetailView):
    """Generic class-based detail view for a genre."""
    model = Language

class LanguageListView(generic.ListView):
    """Generic class-based list view for a list of genres."""
    model = Language
    paginate_by = 10

class BookInstanceListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = BookInstance
    paginate_by = 10

class BookInstanceDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = BookInstance

from django.contrib.auth.mixins import LoginRequiredMixin

class LoanedBooksByUserListView(LoginRequiredMixin, generic.ListView):
    """Generic class-based view listing books on loan to current user."""
    model = BookInstance
    template_name = 'catalog/bookinstance_list_borrowed_user.html'
    paginate_by = 10

    def get_queryset(self):
        return (
            BookInstance.objects.filter(borrower=self.request.user)
            .filter(status__exact=BookInstance.LoanStatus.ON_LOAN)
            .order_by('due_back')
        )

# Added as part of challenge!
from django.contrib.auth.mixins import PermissionRequiredMixin


class LoanedBooksAllListView(PermissionRequiredMixin, generic.ListView):
    """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
    model = BookInstance
    permission_required = 'catalog.can_mark_returned'
    template_name = 'catalog/bookinstance_list_borrowed_all.html'
    paginate_by = 10

    def get_queryset(self):
        return BookInstance.objects.filter(status__exact=BookInstance.LoanStatus.ON_LOAN).order_by('due_back')

from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
import datetime
from django.contrib.auth.decorators import login_required, permission_required
from catalog.forms import RenewBookForm


@login_required
@permission_required('catalog.can_mark_returned', raise_exception=True)
def renew_book_librarian(request, pk):
    """View function for renewing a specific BookInstance by librarian."""
    book_instance = get_object_or_404(BookInstance, pk=pk)

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_instance.due_back = form.cleaned_data['renewal_date']
            book_instance.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed'))

    # If this is a GET (or any other method) create the default form
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date})

    context = {
        'form': form,
        'book_instance': book_instance,
    }

    return render(request, 'catalog/book_renew_librarian.html', context)


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import RestrictedError
from django.contrib.auth.mixins import PermissionRequiredMixin
from .models import Author


class AuthorCreate(PermissionRequiredMixin, CreateView):
    model = Author
    fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death']
    initial = {'date_of_death': datetime.date(2023, 11, 11)}
    permission_required = 'catalog.add_author'

class AuthorUpdate(PermissionRequiredMixin, UpdateView):
    model = Author
    # Not recommended (potential security issue if more fields added)
    fields = '__all__'
    permission_required = 'catalog.change_author'

class AuthorDelete(PermissionRequiredMixin, DeleteView):
    model = Author
    success_url = reverse_lazy('authors')
    permission_required = 'catalog.delete_author'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("author-delete", kwargs={"pk": self.object.pk})
            )

# Classes created for the forms challenge


class BookCreate(PermissionRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.add_book'


class BookUpdate(PermissionRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'author', 'summary', 'isbn', 'genre', 'language']
    permission_required = 'catalog.change_book'


class BookDelete(PermissionRequiredMixin, DeleteView):
    model = Book
    success_url = reverse_lazy('books')
    permission_required = 'catalog.delete_book'

    def form_valid(self, form):
        try:
            self.object.delete()
            return HttpResponseRedirect(self.success_url)
        except RestrictedError:
            return HttpResponseRedirect(
                reverse("book-delete", kwargs={"pk": self.object.pk})
            )


class GenreCreate(PermissionRequiredMixin, CreateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.add_genre'


class GenreUpdate(PermissionRequiredMixin, UpdateView):
    model = Genre
    fields = ['name', ]
    permission_required = 'catalog.change_genre'


class GenreDelete(PermissionRequiredMixin, DeleteView):
    model = Genre
    success_url = reverse_lazy('genres')
    permission_required = 'catalog.delete_genre'


class LanguageCreate(PermissionRequiredMixin, CreateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.add_language'


class LanguageUpdate(PermissionRequiredMixin, UpdateView):
    model = Language
    fields = ['name', ]
    permission_required = 'catalog.change_language'


class LanguageDelete(PermissionRequiredMixin, DeleteView):
    model = Language
    success_url = reverse_lazy('languages')
    permission_required = 'catalog.delete_language'


class BookInstanceCreate(PermissionRequiredMixin, CreateView):
    model = BookInstance
    fields = ['book', 'imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.add_bookinstance'


class BookInstanceUpdate(PermissionRequiredMixin, UpdateView):
    model = BookInstance
    # fields = "__all__"
    fields = ['imprint', 'due_back', 'borrower', 'status']
    permission_required = 'catalog.change_bookinstance'


class BookInstanceDelete(PermissionRequiredMixin, DeleteView):
    model = BookInstance
    success_url = reverse_lazy('bookinstances')
    permission_required = 'catalog.delete_bookinstance'
