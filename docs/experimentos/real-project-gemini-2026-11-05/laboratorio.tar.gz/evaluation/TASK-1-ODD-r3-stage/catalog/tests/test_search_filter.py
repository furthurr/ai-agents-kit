from django.test import TestCase, Client
from django.urls import reverse
from catalog.models import Book, Author, Genre, Language, BookInstance

class BookSearchAndFilterApiTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.author1 = Author.objects.create(first_name='Arthur', last_name='Conan Doyle')
        cls.author2 = Author.objects.create(first_name='Agatha', last_name='Christie')
        
        cls.genre_mys = Genre.objects.create(name='Mystery')
        cls.genre_sci = Genre.objects.create(name='Sci-Fi')
        cls.genre_adv = Genre.objects.create(name='Adventure')
        
        cls.lang_en = Language.objects.create(name='English')
        cls.lang_es = Language.objects.create(name='Spanish')
        
        cls.b1 = Book.objects.create(title='A Study in Scarlet', author=cls.author1, summary='First Holmes adventure', isbn='1111111111111', language=cls.lang_en)
        cls.b1.genre.add(cls.genre_mys, cls.genre_adv)
        
        cls.b2 = Book.objects.create(title='Murder on the Orient Express', author=cls.author2, summary='Hercule Poirot mystery', isbn='2222222222222', language=cls.lang_en)
        cls.b2.genre.add(cls.genre_mys)
        
        cls.b3 = Book.objects.create(title='The Time Machine', author=None, summary='Travel through time', isbn='3333333333333', language=cls.lang_es)
        cls.b3.genre.add(cls.genre_sci)

        # BookInstances
        # b1 has an available instance ('a') and reserved ('r')
        BookInstance.objects.create(book=cls.b1, imprint='Imp1', status=BookInstance.LoanStatus.AVAILABLE)
        BookInstance.objects.create(book=cls.b1, imprint='Imp2', status=BookInstance.LoanStatus.RESERVED)
        
        # b2 has maintenance ('m')
        BookInstance.objects.create(book=cls.b2, imprint='Imp3', status=BookInstance.LoanStatus.MAINTENANCE)
        
        # b3 has on loan ('o')
        BookInstance.objects.create(book=cls.b3, imprint='Imp4', status=BookInstance.LoanStatus.ON_LOAN)

    def test_api_endpoint_exists(self):
        response = self.client.get('/catalog/api/books/')
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 3)
        self.assertEqual(data['page'], 1)
        self.assertEqual(data['num_pages'], 1)
        self.assertEqual(len(data['results']), 3)

    def test_api_results_structure_and_ordering(self):
        response = self.client.get('/catalog/api/books/')
        self.assertEqual(response.status_code, 200)
        data = response.json()
        results = data['results']
        # Ordered by ('title', 'id')
        self.assertEqual(results[0]['title'], 'A Study in Scarlet')
        self.assertEqual(results[0]['author'], 'Conan Doyle, Arthur')
        self.assertEqual(results[0]['genre'], ['Adventure', 'Mystery'])  # alphabetically ordered genres
        self.assertEqual(results[0]['isbn'], '1111111111111')
        
        self.assertEqual(results[1]['title'], 'Murder on the Orient Express')
        self.assertEqual(results[1]['author'], 'Christie, Agatha')
        
        self.assertEqual(results[2]['title'], 'The Time Machine')
        self.assertIsNone(results[2]['author'])

    def test_api_q_filter(self):
        # icontains on title or summary
        response = self.client.get('/catalog/api/books/', {'q': 'holmes'})
        data = response.json()
        self.assertEqual(data['count'], 1)
        self.assertEqual(data['results'][0]['title'], 'A Study in Scarlet')

        # whitespace only q should be ignored
        response = self.client.get('/catalog/api/books/', {'q': '   '})
        data = response.json()
        self.assertEqual(data['count'], 3)

    def test_api_status_filter_and_validation(self):
        # Valid status 'a'
        response = self.client.get('/catalog/api/books/', {'status': 'a'})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 1)
        self.assertEqual(data['results'][0]['title'], 'A Study in Scarlet')

        # Invalid status
        for invalid_status in ['x', 'aa', '']:
            response = self.client.get('/catalog/api/books/', {'status': invalid_status})
            self.assertEqual(response.status_code, 400)
            self.assertEqual(response.json(), {'error': 'invalid_query'})

    def test_api_genre_filter_and_validation(self):
        # Valid genre
        response = self.client.get('/catalog/api/books/', {'genre': self.genre_mys.id})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 2)

        # Invalid genre
        for invalid_genre in ['abc', '0', '-1']:
            response = self.client.get('/catalog/api/books/', {'genre': invalid_genre})
            self.assertEqual(response.status_code, 400)
            self.assertEqual(response.json(), {'error': 'invalid_query'})

    def test_api_language_filter_and_validation(self):
        # Valid language
        response = self.client.get('/catalog/api/books/', {'language': self.lang_es.id})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 1)
        self.assertEqual(data['results'][0]['title'], 'The Time Machine')

        # Invalid language
        for invalid_lang in ['xyz', '-5', '0']:
            response = self.client.get('/catalog/api/books/', {'language': invalid_lang})
            self.assertEqual(response.status_code, 400)
            self.assertEqual(response.json(), {'error': 'invalid_query'})

    def test_api_pagination_and_validation(self):
        # Invalid page
        for invalid_page in ['0', '-1', 'abc', '2']:  # page 2 is out of range since only 3 items (1 page)
            response = self.client.get('/catalog/api/books/', {'page': invalid_page})
            self.assertEqual(response.status_code, 400)
            self.assertEqual(response.json(), {'error': 'invalid_query'})

    def test_api_empty_results_structure(self):
        response = self.client.get('/catalog/api/books/', {'q': 'nonexistentterm'})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {
            'count': 0,
            'page': 1,
            'num_pages': 1,
            'results': []
        })

    def test_ui_search_and_filters(self):
        response = self.client.get(reverse('books'), {'q': 'holmes'})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'A Study in Scarlet')
        self.assertNotContains(response, 'Murder on the Orient Express')

    def test_ui_invalid_params_renders_200_with_error(self):
        for params in [{'status': 'invalid'}, {'genre': 'abc'}, {'language': '-1'}, {'page': 'invalid'}, {'page': '99'}]:
            response = self.client.get(reverse('books'), params)
            self.assertEqual(response.status_code, 200)
            self.assertIn('error', response.content.decode('utf-8').lower())

    def test_combined_filters_and_pagination(self):
        # Create additional books to test pagination (> 10 books)
        for i in range(15):
            b = Book.objects.create(
                title=f'Extra Book {i:02d}',
                summary='Mystery adventure extra',
                isbn=f'99999999999{i:02d}',
                language=self.lang_en
            )
            b.genre.add(self.genre_mys)
            BookInstance.objects.create(book=b, status=BookInstance.LoanStatus.AVAILABLE)

        # Filter combining q, status, genre, language
        params = {
            'q': 'Extra',
            'status': 'a',
            'genre': self.genre_mys.id,
            'language': self.lang_en.id,
            'page': 2
        }
        # 1. API test
        response = self.client.get('/catalog/api/books/', params)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data['count'], 15)
        self.assertEqual(data['page'], 2)
        self.assertEqual(data['num_pages'], 2)
        self.assertEqual(len(data['results']), 5)

        # 2. UI test pagination preserving query params
        ui_response = self.client.get(reverse('books'), params)
        self.assertEqual(ui_response.status_code, 200)
        content = ui_response.content.decode('utf-8')
        # Check querystring helper preserving active filters in previous link
        self.assertIn('q=Extra', content)
        self.assertIn('status=a', content)
        self.assertIn(f'genre={self.genre_mys.id}', content)
        self.assertIn(f'language={self.lang_en.id}', content)
        self.assertIn('page=1', content)
