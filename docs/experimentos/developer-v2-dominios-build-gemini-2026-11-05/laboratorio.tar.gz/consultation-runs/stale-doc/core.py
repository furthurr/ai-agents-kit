def greet():
    return "Hola, mundo"
