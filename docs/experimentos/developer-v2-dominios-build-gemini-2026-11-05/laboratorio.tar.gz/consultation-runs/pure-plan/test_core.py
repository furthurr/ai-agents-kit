import unittest
from core import greet
class T(unittest.TestCase):
 def test_greet(self): self.assertEqual(greet(), "Hola")
