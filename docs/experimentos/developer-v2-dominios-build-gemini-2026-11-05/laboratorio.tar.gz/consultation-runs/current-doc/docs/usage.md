# Contrato de uso
La función pura core.greet() devuelve exactamente Hola.
