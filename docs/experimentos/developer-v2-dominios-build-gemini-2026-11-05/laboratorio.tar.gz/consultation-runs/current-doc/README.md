# Proyecto de saludo
Documentación canónica de uso: docs/usage.md.
Runner: python -m unittest discover.
