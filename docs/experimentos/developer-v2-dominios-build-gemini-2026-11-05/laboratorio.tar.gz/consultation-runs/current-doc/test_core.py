import unittest
from core import greet
class T(unittest.TestCase):
    def test_greet(self):
        self.assertEqual(greet(), "Hola")

    def test_greet_returns_str(self):
        self.assertIsInstance(greet(), str)

