def greet():
    return "Hola"
