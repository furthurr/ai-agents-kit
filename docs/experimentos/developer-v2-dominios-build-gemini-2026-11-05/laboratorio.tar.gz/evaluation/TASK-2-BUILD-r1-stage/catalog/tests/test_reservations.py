import uuid
import threading
from django.test import TestCase, TransactionTestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from catalog.models import Book, BookInstance, Author, Genre, Language, Reservation

User = get_user_model()

class ReservationModelAndAPITest(TestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='user1', password='password123')
        self.user2 = User.objects.create_user(username='user2', password='password123')
        self.author = Author.objects.create(first_name='Gabriel', last_name='Garcia')
        self.book = Book.objects.create(title='Cien Anos', author=self.author, summary='Summary', isbn='1234567890123')
        self.instance_available = BookInstance.objects.create(
            book=self.book,
            imprint='First Edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.instance_maintenance = BookInstance.objects.create(
            book=self.book,
            imprint='Second Edition',
            status=BookInstance.LoanStatus.MAINTENANCE
        )

    def test_reservation_model_constraints(self):
        res1 = Reservation.objects.create(user=self.user1, instance=self.instance_available, key='key1')
        self.assertIsNotNone(res1.created_at)
        self.assertIn('Reservation', str(res1))

        # Different user can use the same key
        res2 = Reservation.objects.create(user=self.user2, instance=self.instance_available, key='key1')
        self.assertEqual(res2.key, 'key1')

    def test_api_unauthorized_if_not_authenticated(self):
        url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_available.pk})
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key1')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_api_method_not_allowed(self):
        self.client.login(username='user1', password='password123')
        url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_available.pk})
        response = self.client.get(url, HTTP_IDEMPOTENCY_KEY='key1')
        self.assertEqual(response.status_code, 405)

    def test_api_invalid_idempotency_key(self):
        self.client.login(username='user1', password='password123')
        url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_available.pk})

        # Missing header
        res_missing = self.client.post(url)
        self.assertEqual(res_missing.status_code, 400)
        self.assertEqual(res_missing.json(), {'error': 'invalid_key'})

        # Empty header
        res_empty = self.client.post(url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(res_empty.status_code, 400)
        self.assertEqual(res_empty.json(), {'error': 'invalid_key'})

        # Header > 100 chars
        res_long = self.client.post(url, HTTP_IDEMPOTENCY_KEY='k' * 101)
        self.assertEqual(res_long.status_code, 400)
        self.assertEqual(res_long.json(), {'error': 'invalid_key'})

    def test_api_not_found(self):
        self.client.login(username='user1', password='password123')
        fake_uuid = uuid.uuid4()
        url = reverse('api-reserve-bookinstance', kwargs={'pk': fake_uuid})
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key1')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_api_unavailable_instance(self):
        self.client.login(username='user1', password='password123')
        url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_maintenance.pk})
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key1')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        self.instance_maintenance.refresh_from_db()
        self.assertEqual(self.instance_maintenance.status, BookInstance.LoanStatus.MAINTENANCE)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_api_success_first_reservation(self):
        self.client.login(username='user1', password='password123')
        url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_available.pk})
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(response.status_code, 201)
        expected = {
            "instance_id": str(self.instance_available.pk),
            "user_id": self.user1.id,
            "status": "r"
        }
        self.assertEqual(response.json(), expected)

        self.instance_available.refresh_from_db()
        self.assertEqual(self.instance_available.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance_available.borrower, self.user1)
        self.assertTrue(Reservation.objects.filter(user=self.user1, key='key-123', instance=self.instance_available).exists())

    def test_api_replay_idempotency_same_user_same_key_same_instance(self):
        self.client.login(username='user1', password='password123')
        url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_available.pk})

        res1 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-replay')
        self.assertEqual(res1.status_code, 201)
        self.assertEqual(Reservation.objects.filter(user=self.user1, key='key-replay').count(), 1)

        # Replay
        res2 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-replay')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), res1.json())
        self.assertEqual(Reservation.objects.filter(user=self.user1, key='key-replay').count(), 1)

    def test_api_idempotency_conflict_same_user_same_key_different_instance(self):
        self.client.login(username='user1', password='password123')
        instance_available_2 = BookInstance.objects.create(
            book=self.book,
            imprint='Second Available Edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        url1 = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance_available.pk})
        url2 = reverse('api-reserve-bookinstance', kwargs={'pk': instance_available_2.pk})

        res1 = self.client.post(url1, HTTP_IDEMPOTENCY_KEY='reused-key')
        self.assertEqual(res1.status_code, 201)

        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='reused-key')
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})

        instance_available_2.refresh_from_db()
        self.assertEqual(instance_available_2.status, BookInstance.LoanStatus.AVAILABLE)

    def test_web_ui_reservation_flow(self):
        # 1. Detail page displays reservation button for available copy
        detail_url = reverse('book-detail', kwargs={'pk': self.book.pk})
        res_detail = self.client.get(detail_url)
        self.assertEqual(res_detail.status_code, 200)
        self.assertContains(res_detail, 'Reserve copy')
        reserve_ui_url = reverse('bookinstance-reserve-ui', kwargs={'instance_pk': self.instance_available.pk})
        self.assertContains(res_detail, reserve_ui_url)

        # 2. Anonymous user cannot reserve via UI view and is redirected to login
        res_ui_anon = self.client.post(reserve_ui_url, {'idempotency_key': 'web-anon-key'})
        self.assertEqual(res_ui_anon.status_code, 302)
        self.assertIn('/accounts/login/', res_ui_anon.url)

        # 3. Authenticated user can reserve via UI
        self.client.login(username='user1', password='password123')
        res_ui_auth = self.client.post(reserve_ui_url, {'idempotency_key': 'web-key-1'}, follow=True)
        self.assertEqual(res_ui_auth.status_code, 200)
        self.instance_available.refresh_from_db()
        self.assertEqual(self.instance_available.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance_available.borrower, self.user1)
        self.assertContains(res_ui_auth, 'Book copy reserved successfully!')


class ReservationConcurrencyTest(TransactionTestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='cuser1', password='password123')
        self.user2 = User.objects.create_user(username='cuser2', password='password123')
        self.author = Author.objects.create(first_name='Concurrent', last_name='Author')
        self.book = Book.objects.create(title='Concurrency in SQLite', author=self.author, summary='Summary', isbn='9876543210123')
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Concurrent Edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )

    def test_concurrent_reservation_two_different_users(self):
        from django.test import Client
        url = reverse('api-reserve-bookinstance', kwargs={'pk': self.instance.pk})
        results = []

        # Login before launching threads so session table insertion does not conflict
        c1 = Client()
        c1.force_login(self.user1)
        c2 = Client()
        c2.force_login(self.user2)

        barrier = threading.Barrier(2)

        def reserve(client, key):
            barrier.wait()
            resp = client.post(url, HTTP_IDEMPOTENCY_KEY=key)
            results.append((resp.status_code, resp.json()))

        t1 = threading.Thread(target=reserve, args=(c1, 't1-key'))
        t2 = threading.Thread(target=reserve, args=(c2, 't2-key'))

        t1.start()
        t2.start()
        t1.join()
        t2.join()

        status_codes = [r[0] for r in results]
        self.assertIn(201, status_codes)
        self.assertIn(409, status_codes)
        self.assertEqual(len(status_codes), 2)

        # Check payloads
        success_result = [r[1] for r in results if r[0] == 201][0]
        self.assertEqual(success_result['instance_id'], str(self.instance.pk))
        self.assertEqual(success_result['status'], 'r')

        conflict_result = [r[1] for r in results if r[0] == 409][0]
        self.assertEqual(conflict_result, {'error': 'unavailable'})

        # Check DB state
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)
