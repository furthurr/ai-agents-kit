import uuid
from django.test import TestCase, TransactionTestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from catalog.models import Book, Author, Genre, Language, BookInstance, Reservation
import threading

User = get_user_model()

class ReservationModelTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user(username='res_user', password='password123')
        cls.author = Author.objects.create(first_name='Arthur', last_name='Conan Doyle')
        cls.book = Book.objects.create(
            title='Sherlock Holmes',
            author=cls.author,
            summary='Detective stories',
            isbn='1234567890123'
        )
        cls.instance = BookInstance.objects.create(
            book=cls.book,
            imprint='Test Pub',
            status=BookInstance.LoanStatus.AVAILABLE
        )

    def test_reservation_creation(self):
        reservation = Reservation.objects.create(
            user=self.user,
            instance=self.instance,
            key='unique-key-1'
        )
        self.assertEqual(reservation.user, self.user)
        self.assertEqual(reservation.instance, self.instance)
        self.assertEqual(reservation.key, 'unique-key-1')
        self.assertIsNotNone(reservation.created_at)
        self.assertIn('unique-key-1', str(reservation))

    def test_unique_user_key_constraint(self):
        Reservation.objects.create(
            user=self.user,
            instance=self.instance,
            key='same-key'
        )
        # Another user can use the same key
        other_user = User.objects.create_user(username='other_user', password='password123')
        res_other = Reservation.objects.create(
            user=other_user,
            instance=self.instance,
            key='same-key'
        )
        self.assertEqual(res_other.key, 'same-key')

        # Same user with same key fails
        with self.assertRaises(Exception):
            Reservation.objects.create(
                user=self.user,
                instance=self.instance,
                key='same-key'
            )


class ReservationAPITest(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user1 = User.objects.create_user(username='user1', password='passuser1')
        cls.user2 = User.objects.create_user(username='user2', password='passuser2')
        cls.author = Author.objects.create(first_name='Jane', last_name='Austen')
        cls.book = Book.objects.create(
            title='Pride and Prejudice',
            author=cls.author,
            summary='Romantic novel',
            isbn='9876543210987'
        )
        cls.instance_avail = BookInstance.objects.create(
            book=cls.book,
            imprint='Penguin',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        cls.instance_loan = BookInstance.objects.create(
            book=cls.book,
            imprint='Penguin',
            status=BookInstance.LoanStatus.ON_LOAN
        )
        cls.instance_maint = BookInstance.objects.create(
            book=cls.book,
            imprint='Penguin',
            status=BookInstance.LoanStatus.MAINTENANCE
        )

    def test_unauthenticated_returns_401(self):
        url = reverse('api-bookinstance-reserve', args=[self.instance_avail.id])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_invalid_http_method_returns_405(self):
        self.client.login(username='user1', password='passuser1')
        url = reverse('api-bookinstance-reserve', args=[self.instance_avail.id])
        response = self.client.get(url, HTTP_IDEMPOTENCY_KEY='key-123')
        self.assertEqual(response.status_code, 405)

    def test_missing_or_invalid_idempotency_key_returns_400(self):
        self.client.login(username='user1', password='passuser1')
        url = reverse('api-bookinstance-reserve', args=[self.instance_avail.id])

        # Missing header
        res1 = self.client.post(url)
        self.assertEqual(res1.status_code, 400)
        self.assertEqual(res1.json(), {'error': 'invalid_key'})

        # Empty or whitespace only
        res2 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(res2.status_code, 400)
        self.assertEqual(res2.json(), {'error': 'invalid_key'})

        # Length > 100
        res3 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='a' * 101)
        self.assertEqual(res3.status_code, 400)
        self.assertEqual(res3.json(), {'error': 'invalid_key'})

    def test_nonexistent_instance_returns_404(self):
        self.client.login(username='user1', password='passuser1')
        random_uuid = uuid.uuid4()
        url = reverse('api-bookinstance-reserve', args=[random_uuid])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='valid-key')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_unavailable_instance_returns_409(self):
        self.client.login(username='user1', password='passuser1')
        # On loan
        url_loan = reverse('api-bookinstance-reserve', args=[self.instance_loan.id])
        res_loan = self.client.post(url_loan, HTTP_IDEMPOTENCY_KEY='key-loan')
        self.assertEqual(res_loan.status_code, 409)
        self.assertEqual(res_loan.json(), {'error': 'unavailable'})

        # Maintenance
        url_maint = reverse('api-bookinstance-reserve', args=[self.instance_maint.id])
        res_maint = self.client.post(url_maint, HTTP_IDEMPOTENCY_KEY='key-maint')
        self.assertEqual(res_maint.status_code, 409)
        self.assertEqual(res_maint.json(), {'error': 'unavailable'})

    def test_successful_reservation(self):
        self.client.login(username='user1', password='passuser1')
        url = reverse('api-bookinstance-reserve', args=[self.instance_avail.id])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='valid-key-1')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), {
            "instance_id": str(self.instance_avail.id),
            "user_id": self.user1.id,
            "status": "r"
        })

        # Check DB state
        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance_avail.borrower, self.user1)

        # Check Reservation record
        res_record = Reservation.objects.get(user=self.user1, key='valid-key-1')
        self.assertEqual(res_record.instance, self.instance_avail)

    def test_replay_idempotency_returns_201_without_duplication(self):
        self.client.login(username='user1', password='passuser1')
        url = reverse('api-bookinstance-reserve', args=[self.instance_avail.id])

        # First attempt
        res1 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='repeat-key')
        self.assertEqual(res1.status_code, 201)

        # Replay with same user, same key, same instance
        res2 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='repeat-key')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), {
            "instance_id": str(self.instance_avail.id),
            "user_id": self.user1.id,
            "status": "r"
        })

        # Verify only 1 reservation record exists
        self.assertEqual(Reservation.objects.filter(user=self.user1, key='repeat-key').count(), 1)

    def test_idempotency_conflict_returns_409(self):
        self.client.login(username='user1', password='passuser1')
        # Create a second available instance
        second_instance = BookInstance.objects.create(
            book=self.book,
            imprint='Second Copy',
            status=BookInstance.LoanStatus.AVAILABLE
        )

        url1 = reverse('api-bookinstance-reserve', args=[self.instance_avail.id])
        res1 = self.client.post(url1, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(res1.status_code, 201)

        # Try to use same key for second_instance
        url2 = reverse('api-bookinstance-reserve', args=[second_instance.id])
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='shared-key')
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})

        # second_instance should remain untouched
        second_instance.refresh_from_db()
        self.assertEqual(second_instance.status, BookInstance.LoanStatus.AVAILABLE)

    def test_independent_keys_between_users(self):
        # User 1 reserves instance_avail with key-xyz
        self.client.login(username='user1', password='passuser1')
        url1 = reverse('api-bookinstance-reserve', args=[self.instance_avail.id])
        res1 = self.client.post(url1, HTTP_IDEMPOTENCY_KEY='key-xyz')
        self.assertEqual(res1.status_code, 201)

        # Another instance for user 2
        second_instance = BookInstance.objects.create(
            book=self.book,
            imprint='Second Copy',
            status=BookInstance.LoanStatus.AVAILABLE
        )

        # User 2 reserves second_instance with same key string key-xyz
        self.client.login(username='user2', password='passuser2')
        url2 = reverse('api-bookinstance-reserve', args=[second_instance.id])
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='key-xyz')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), {
            "instance_id": str(second_instance.id),
            "user_id": self.user2.id,
            "status": "r"
        })


class ReservationConcurrencyTest(TransactionTestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='conc_u1', password='password123')
        self.user2 = User.objects.create_user(username='conc_u2', password='password123')
        self.author = Author.objects.create(first_name='Concurrent', last_name='Author')
        self.book = Book.objects.create(
            title='Concurrency in SQLite',
            author=self.author,
            summary='Testing locks',
            isbn='1112223334445'
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Special Edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )

    def test_two_concurrent_users_single_available_instance(self):
        from django.test import Client
        url = reverse('api-bookinstance-reserve', args=[self.instance.id])
        results = []

        def client_request(username, password, key):
            c = Client()
            c.login(username=username, password=password)
            resp = c.post(url, HTTP_IDEMPOTENCY_KEY=key)
            results.append((resp.status_code, resp.json()))

        t1 = threading.Thread(target=client_request, args=('conc_u1', 'password123', 'k1'))
        t2 = threading.Thread(target=client_request, args=('conc_u2', 'password123', 'k2'))

        t1.start()
        t2.start()
        t1.join()
        t2.join()

        status_codes = sorted([r[0] for r in results])
        self.assertEqual(status_codes, [201, 409])

        success_res = [r[1] for r in results if r[0] == 201][0]
        conflict_res = [r[1] for r in results if r[0] == 409][0]

        self.assertEqual(success_res['status'], 'r')
        self.assertEqual(conflict_res, {'error': 'unavailable'})

        # Verify only 1 reservation in DB
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)


class ReservationUITest(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user(username='ui_user', password='password123')
        cls.author = Author.objects.create(first_name='Leo', last_name='Tolstoy')
        cls.book = Book.objects.create(
            title='War and Peace',
            author=cls.author,
            summary='Epic novel',
            isbn='5556667778889'
        )
        cls.instance_avail = BookInstance.objects.create(
            book=cls.book,
            imprint='Vintage',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        cls.instance_maint = BookInstance.objects.create(
            book=cls.book,
            imprint='Vintage',
            status=BookInstance.LoanStatus.MAINTENANCE
        )

    def test_book_detail_shows_reserve_button_for_available_only(self):
        url = reverse('book-detail', args=[self.book.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

        reserve_url = reverse('bookinstance-reserve-web', args=[self.instance_avail.id])
        self.assertContains(response, reserve_url)
        self.assertContains(response, 'Reserve this copy')
        self.assertContains(response, 'name="idempotency_key"')
        self.assertContains(response, 'csrfmiddlewaretoken')

        # Maintenance copy should not have reserve button
        maint_reserve_url = reverse('bookinstance-reserve-web', args=[self.instance_maint.id])
        self.assertNotContains(response, maint_reserve_url)

    def test_web_reserve_requires_authentication(self):
        url = reverse('bookinstance-reserve-web', args=[self.instance_avail.id])
        response = self.client.post(url, {'idempotency_key': 'web-key-1'})
        self.assertEqual(response.status_code, 302)
        self.assertIn('/accounts/login/', response.url)

    def test_web_reserve_success_and_feedback(self):
        self.client.login(username='ui_user', password='password123')
        url = reverse('bookinstance-reserve-web', args=[self.instance_avail.id])
        response = self.client.post(url, {'idempotency_key': 'web-key-1'}, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Book copy reserved successfully!')

        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance_avail.borrower, self.user)
