import uuid
from concurrent.futures import ThreadPoolExecutor
from django.test import TestCase, TransactionTestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.db import connection
from catalog.models import Book, Author, BookInstance, Genre, Reservation

User = get_user_model()


class ReservationAPITest(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.author = Author.objects.create(first_name='Gabriel', last_name='Garcia Marquez')
        cls.book = Book.objects.create(
            title='Cien Anos de Soledad',
            author=cls.author,
            summary='Realismo magico',
            isbn='1234567890123'
        )
        cls.instance_available = BookInstance.objects.create(
            book=cls.book,
            imprint='Sudamericana, 1967',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        cls.instance_on_loan = BookInstance.objects.create(
            book=cls.book,
            imprint='Sudamericana, 1967',
            status=BookInstance.LoanStatus.ON_LOAN
        )
        cls.user1 = User.objects.create_user(username='user1', password='password123')
        cls.user2 = User.objects.create_user(username='user2', password='password123')

    def test_reserve_requires_authentication(self):
        url = reverse('bookinstance-reserve-api', args=[self.instance_available.id])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_reserve_requires_post_method(self):
        self.client.force_login(self.user1)
        url = reverse('bookinstance-reserve-api', args=[self.instance_available.id])
        response = self.client.get(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 405)

    def test_missing_or_invalid_idempotency_key(self):
        self.client.force_login(self.user1)
        url = reverse('bookinstance-reserve-api', args=[self.instance_available.id])

        # Missing key
        response = self.client.post(url)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

        # Empty or spaces key
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

        # Key longer than 100 chars
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='k' * 101)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json(), {'error': 'invalid_key'})

    def test_instance_not_found(self):
        self.client.force_login(self.user1)
        non_existent_id = uuid.uuid4()
        url = reverse('bookinstance-reserve-api', args=[non_existent_id])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_instance_not_available(self):
        self.client.force_login(self.user1)
        url = reverse('bookinstance-reserve-api', args=[self.instance_on_loan.id])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})

    def test_successful_reservation(self):
        self.client.force_login(self.user1)
        url = reverse('bookinstance-reserve-api', args=[self.instance_available.id])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-success-1')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), {
            "instance_id": str(self.instance_available.id),
            "user_id": self.user1.id,
            "status": "r"
        })

        self.instance_available.refresh_from_db()
        self.assertEqual(self.instance_available.status, 'r')
        self.assertEqual(self.instance_available.borrower, self.user1)

        reservation = Reservation.objects.get(user=self.user1, key='key-success-1')
        self.assertEqual(reservation.instance, self.instance_available)

    def test_replay_idempotency_same_user_same_key_same_instance(self):
        self.client.force_login(self.user1)
        url = reverse('bookinstance-reserve-api', args=[self.instance_available.id])

        # First attempt
        res1 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-replay-1')
        self.assertEqual(res1.status_code, 201)
        self.assertEqual(res1.json(), {
            "instance_id": str(self.instance_available.id),
            "user_id": self.user1.id,
            "status": "r"
        })

        # Replay attempt
        res2 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-replay-1')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), {
            "instance_id": str(self.instance_available.id),
            "user_id": self.user1.id,
            "status": "r"
        })
        self.assertEqual(Reservation.objects.filter(user=self.user1, key='key-replay-1').count(), 1)

    def test_replay_idempotency_persists_across_sessions(self):
        # Initial request with client 1
        self.client.force_login(self.user1)
        url = reverse('bookinstance-reserve-api', args=[self.instance_available.id])
        res1 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-session-persist')
        self.assertEqual(res1.status_code, 201)

        # Fresh client / new session for the same user
        fresh_client = self.client_class()
        fresh_client.force_login(self.user1)
        res2 = fresh_client.post(url, HTTP_IDEMPOTENCY_KEY='key-session-persist')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), {
            "instance_id": str(self.instance_available.id),
            "user_id": self.user1.id,
            "status": "r"
        })

    def test_idempotency_conflict_same_user_same_key_different_instance(self):
        self.client.force_login(self.user1)
        url1 = reverse('bookinstance-reserve-api', args=[self.instance_available.id])
        res1 = self.client.post(url1, HTTP_IDEMPOTENCY_KEY='reuse-key')
        self.assertEqual(res1.status_code, 201)

        another_instance = BookInstance.objects.create(
            book=self.book,
            imprint='Sudamericana, 1967',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        url2 = reverse('bookinstance-reserve-api', args=[another_instance.id])
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='reuse-key')
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})

    def test_different_users_can_use_same_key(self):
        # User 1 reserves instance_available with 'common-key'
        self.client.force_login(self.user1)
        url1 = reverse('bookinstance-reserve-api', args=[self.instance_available.id])
        res1 = self.client.post(url1, HTTP_IDEMPOTENCY_KEY='common-key')
        self.assertEqual(res1.status_code, 201)

        # Another instance for User 2
        copy2 = BookInstance.objects.create(
            book=self.book,
            imprint='Sudamericana, 1967',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.client.force_login(self.user2)
        url2 = reverse('bookinstance-reserve-api', args=[copy2.id])
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='common-key')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(Reservation.objects.filter(key='common-key').count(), 2)

    def test_failed_requests_do_not_mutate_state(self):
        self.client.force_login(self.user1)
        url = reverse('bookinstance-reserve-api', args=[self.instance_available.id])
        res = self.client.post(url, HTTP_IDEMPOTENCY_KEY='')  # 400
        self.assertEqual(res.status_code, 400)

        self.instance_available.refresh_from_db()
        self.assertEqual(self.instance_available.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(self.instance_available.borrower)
        self.assertEqual(Reservation.objects.count(), 0)


class ReservationUITest(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.author = Author.objects.create(first_name='Gabriel', last_name='Garcia Marquez')
        cls.book = Book.objects.create(
            title='Cien Anos de Soledad',
            author=cls.author,
            summary='Realismo magico',
            isbn='1234567890123'
        )
        cls.instance = BookInstance.objects.create(
            book=cls.book,
            imprint='Sudamericana, 1967',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        cls.user = User.objects.create_user(username='uiuser', password='password123')

    def test_book_detail_shows_reserve_form_for_available_instance(self):
        url = reverse('book-detail', args=[self.book.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        reserve_url = reverse('bookinstance-reserve-ui', args=[self.instance.id])
        self.assertContains(response, reserve_url)
        self.assertContains(response, 'idempotency_key')
        self.assertContains(response, 'Reservar ejemplar')

    def test_ui_reserve_requires_login(self):
        url = reverse('bookinstance-reserve-ui', args=[self.instance.id])
        response = self.client.post(url, {'idempotency_key': 'key-ui-1'})
        # Should redirect to login
        self.assertEqual(response.status_code, 302)
        self.assertTrue('/accounts/login/' in response.url or 'login' in response.url)

    def test_ui_reserve_success_and_redirect(self):
        self.client.force_login(self.user)
        url = reverse('bookinstance-reserve-ui', args=[self.instance.id])
        response = self.client.post(url, {'idempotency_key': 'key-ui-1'}, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertRedirects(response, reverse('book-detail', args=[self.book.id]))

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, 'r')
        self.assertEqual(self.instance.borrower, self.user)
        # Check success message appears in response
        self.assertContains(response, 'reservada con éxito')


class ReservationConcurrencyTest(TransactionTestCase):
    """Test real concurrency under SQLite using TransactionTestCase."""

    def test_concurrent_reservation_on_same_instance(self):
        author = Author.objects.create(first_name='Concurrency', last_name='Author')
        book = Book.objects.create(
            title='Concurrent Book',
            author=author,
            summary='Summary',
            isbn='9999999999999'
        )
        instance = BookInstance.objects.create(
            book=book,
            imprint='Imprint 1',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        user1 = User.objects.create_user(username='concur_user1', password='password123')
        user2 = User.objects.create_user(username='concur_user2', password='password123')

        url = reverse('bookinstance-reserve-api', args=[instance.id])

        # Pre-login clients sequentially to populate sessions without concurrency clash on test runner
        client1 = self.client_class()
        client1.force_login(user1)
        client2 = self.client_class()
        client2.force_login(user2)

        def reserve(client, key):
            resp = client.post(url, HTTP_IDEMPOTENCY_KEY=key)
            connection.close()
            return resp.status_code, resp.json()

        with ThreadPoolExecutor(max_workers=2) as executor:
            future1 = executor.submit(reserve, client1, 'key-concur-user1')
            future2 = executor.submit(reserve, client2, 'key-concur-user2')
            result1 = future1.result()
            result2 = future2.result()

        status_codes = sorted([result1[0], result2[0]])
        self.assertEqual(status_codes, [201, 409])

        if result1[0] == 201:
            self.assertEqual(result2[1], {'error': 'unavailable'})
        else:
            self.assertEqual(result1[1], {'error': 'unavailable'})

        instance.refresh_from_db()
        self.assertEqual(instance.status, 'r')
        self.assertIn(instance.borrower, [user1, user2])
        self.assertEqual(Reservation.objects.count(), 1)
