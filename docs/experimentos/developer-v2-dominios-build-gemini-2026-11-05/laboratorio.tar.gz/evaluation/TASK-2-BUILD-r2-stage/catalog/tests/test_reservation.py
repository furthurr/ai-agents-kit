import json
import uuid
from concurrent.futures import ThreadPoolExecutor
from django.contrib.auth import get_user_model
from django.test import TestCase, TransactionTestCase
from django.urls import reverse
from catalog.models import Book, BookInstance, Author, Genre, Language, Reservation

User = get_user_model()


class BookInstanceReservationApiTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user1 = User.objects.create_user(username='user1', password='password123')
        cls.user2 = User.objects.create_user(username='user2', password='password123')
        cls.author = Author.objects.create(first_name='Gabriel', last_name='Garcia Marquez')
        cls.book = Book.objects.create(
            title='Cien Anos de Soledad',
            author=cls.author,
            summary='Realismo magico',
            isbn='1234567890123'
        )
        cls.available_instance = BookInstance.objects.create(
            book=cls.book,
            imprint='Sudamericana, 1967',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        cls.maintenance_instance = BookInstance.objects.create(
            book=cls.book,
            imprint='Sudamericana, 1967',
            status=BookInstance.LoanStatus.MAINTENANCE
        )

    def test_reservation_requires_authentication(self):
        url = reverse('api-bookinstance-reserve', args=[self.available_instance.id])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_reservation_only_allows_post(self):
        self.client.login(username='user1', password='password123')
        url = reverse('api-bookinstance-reserve', args=[self.available_instance.id])
        get_response = self.client.get(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(get_response.status_code, 405)

    def test_reservation_missing_or_invalid_idempotency_key(self):
        self.client.login(username='user1', password='password123')
        url = reverse('api-bookinstance-reserve', args=[self.available_instance.id])

        # Missing header
        res1 = self.client.post(url)
        self.assertEqual(res1.status_code, 400)
        self.assertEqual(res1.json(), {'error': 'invalid_key'})

        # Whitespace header
        res2 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(res2.status_code, 400)
        self.assertEqual(res2.json(), {'error': 'invalid_key'})

        # Key too long (> 100 chars)
        res3 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='k' * 101)
        self.assertEqual(res3.status_code, 400)
        self.assertEqual(res3.json(), {'error': 'invalid_key'})

    def test_reservation_nonexistent_instance(self):
        self.client.login(username='user1', password='password123')
        non_existent_uuid = uuid.uuid4()
        url = reverse('api-bookinstance-reserve', args=[non_existent_uuid])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_reservation_unavailable_instance(self):
        self.client.login(username='user1', password='password123')
        url = reverse('api-bookinstance-reserve', args=[self.maintenance_instance.id])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        # State must remain unchanged
        self.maintenance_instance.refresh_from_db()
        self.assertEqual(self.maintenance_instance.status, BookInstance.LoanStatus.MAINTENANCE)
        self.assertIsNone(self.maintenance_instance.borrower)
        self.assertEqual(Reservation.objects.count(), 0)

    def test_reservation_success_and_replay_idempotency(self):
        self.client.login(username='user1', password='password123')
        url = reverse('api-bookinstance-reserve', args=[self.available_instance.id])
        key = 'unique-key-1'

        # Initial successful reservation
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY=key)
        self.assertEqual(response.status_code, 201)
        expected_json = {
            'instance_id': str(self.available_instance.id),
            'user_id': self.user1.id,
            'status': 'r'
        }
        self.assertEqual(response.json(), expected_json)

        # Check DB mutations
        self.available_instance.refresh_from_db()
        self.assertEqual(self.available_instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.available_instance.borrower, self.user1)
        self.assertEqual(Reservation.objects.count(), 1)
        reservation = Reservation.objects.first()
        self.assertEqual(reservation.user, self.user1)
        self.assertEqual(reservation.instance, self.available_instance)
        self.assertEqual(reservation.key, key)

        # Replay with same user, same key, same instance
        replay_response = self.client.post(url, HTTP_IDEMPOTENCY_KEY=key)
        self.assertEqual(replay_response.status_code, 201)
        self.assertEqual(replay_response.json(), expected_json)
        self.assertEqual(Reservation.objects.count(), 1)

    def test_reservation_idempotency_conflict_different_instance(self):
        self.client.login(username='user1', password='password123')
        instance2 = BookInstance.objects.create(
            book=self.book,
            imprint='Sudamericana, 1967',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        url1 = reverse('api-bookinstance-reserve', args=[self.available_instance.id])
        url2 = reverse('api-bookinstance-reserve', args=[instance2.id])
        key = 'reused-key'

        # Reserve instance 1
        res1 = self.client.post(url1, HTTP_IDEMPOTENCY_KEY=key)
        self.assertEqual(res1.status_code, 201)

        # Try to reserve instance 2 with the same key
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY=key)
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})

        # Verify instance 2 is NOT reserved
        instance2.refresh_from_db()
        self.assertEqual(instance2.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(instance2.borrower)

    def test_reservation_keys_independent_between_users(self):
        # User 1 reserves instance 1 with key 'common-key'
        self.client.login(username='user1', password='password123')
        url1 = reverse('api-bookinstance-reserve', args=[self.available_instance.id])
        res1 = self.client.post(url1, HTTP_IDEMPOTENCY_KEY='common-key')
        self.assertEqual(res1.status_code, 201)
        self.client.logout()

        # Create another available instance
        instance2 = BookInstance.objects.create(
            book=self.book,
            imprint='Sudamericana, 1967',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        url2 = reverse('api-bookinstance-reserve', args=[instance2.id])

        # User 2 uses the SAME key 'common-key' for instance 2
        self.client.login(username='user2', password='password123')
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='common-key')
        self.assertEqual(res2.status_code, 201)

        # Confirm 2 distinct reservations exist
        self.assertEqual(Reservation.objects.filter(key='common-key').count(), 2)


class BookInstanceReservationConcurrencyTests(TransactionTestCase):
    def test_concurrent_reservations_result_in_one_success_one_conflict(self):
        user1 = User.objects.create_user(username='concur_u1', password='password123')
        user2 = User.objects.create_user(username='concur_u2', password='password123')
        author = Author.objects.create(first_name='Jane', last_name='Austen')
        book = Book.objects.create(title='Pride and Prejudice', author=author, summary='Classic', isbn='1112223334445')
        instance = BookInstance.objects.create(book=book, imprint='Penguin', status=BookInstance.LoanStatus.AVAILABLE)

        url = reverse('api-bookinstance-reserve', args=[instance.id])

        from django.test import Client

        def try_reserve(username, key):
            c = Client()
            c.login(username=username, password='password123')
            return c.post(url, HTTP_IDEMPOTENCY_KEY=key)

        with ThreadPoolExecutor(max_workers=2) as executor:
            future1 = executor.submit(try_reserve, 'concur_u1', 'key-user1')
            future2 = executor.submit(try_reserve, 'concur_u2', 'key-user2')
            res1 = future1.result()
            res2 = future2.result()

        status_codes = sorted([res1.status_code, res2.status_code])
        self.assertEqual(status_codes, [201, 409])

        if res1.status_code == 201:
            self.assertEqual(res2.json(), {'error': 'unavailable'})
        else:
            self.assertEqual(res1.json(), {'error': 'unavailable'})

        instance.refresh_from_db()
        self.assertEqual(instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(Reservation.objects.count(), 1)


class BookInstanceReservationUITests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user(username='ui_user', password='password123')
        cls.author = Author.objects.create(first_name='Author', last_name='Tester')
        cls.book = Book.objects.create(title='Test Book UI', author=cls.author, summary='Summary', isbn='9999999999999')
        cls.available_copy = BookInstance.objects.create(
            book=cls.book,
            imprint='First Edition',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        cls.maintenance_copy = BookInstance.objects.create(
            book=cls.book,
            imprint='Second Edition',
            status=BookInstance.LoanStatus.MAINTENANCE
        )

    def test_book_detail_shows_reserve_button_only_for_available_copies(self):
        response = self.client.get(reverse('book-detail', args=[self.book.id]))
        self.assertEqual(response.status_code, 200)
        reserve_url = reverse('bookinstance-reserve', args=[self.available_copy.id])
        self.assertContains(response, f'action="{reserve_url}"')
        self.assertContains(response, 'name="idempotency_key"')
        self.assertContains(response, 'Reserve copy')

        unavail_reserve_url = reverse('bookinstance-reserve', args=[self.maintenance_copy.id])
        self.assertNotContains(response, f'action="{unavail_reserve_url}"')

    def test_reserve_ui_requires_login(self):
        url = reverse('bookinstance-reserve', args=[self.available_copy.id])
        response = self.client.post(url, {'idempotency_key': 'ui-key-1'})
        # Should redirect to login
        self.assertEqual(response.status_code, 302)
        self.assertTrue('/accounts/login/' in response.url or 'login' in response.url)

    def test_reserve_ui_success_and_messages(self):
        self.client.login(username='ui_user', password='password123')
        url = reverse('bookinstance-reserve', args=[self.available_copy.id])
        response = self.client.post(url, {'idempotency_key': 'ui-key-1'}, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'successfully reserved')

        self.available_copy.refresh_from_db()
        self.assertEqual(self.available_copy.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.available_copy.borrower, self.user)
