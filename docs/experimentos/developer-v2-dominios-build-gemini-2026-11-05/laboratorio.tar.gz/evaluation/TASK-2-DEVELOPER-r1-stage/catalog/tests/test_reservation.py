import uuid
import concurrent.futures
from django.test import TestCase, TransactionTestCase, Client
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.db import IntegrityError, connection
from catalog.models import Book, Author, BookInstance, Reservation

User = get_user_model()


class ReservationModelTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user1 = User.objects.create_user(username='user1', password='password123')
        cls.user2 = User.objects.create_user(username='user2', password='password123')
        cls.author = Author.objects.create(first_name='Test', last_name='Author')
        cls.book = Book.objects.create(
            title='Test Book',
            author=cls.author,
            summary='Summary',
            isbn='1234567890123'
        )
        cls.instance1 = BookInstance.objects.create(
            book=cls.book,
            imprint='Test imprint',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        cls.instance2 = BookInstance.objects.create(
            book=cls.book,
            imprint='Test imprint 2',
            status=BookInstance.LoanStatus.AVAILABLE
        )

    def test_reservation_creation_and_str(self):
        res = Reservation.objects.create(
            user=self.user1,
            instance=self.instance1,
            key='key-123'
        )
        self.assertEqual(res.user, self.user1)
        self.assertEqual(res.instance, self.instance1)
        self.assertEqual(res.key, 'key-123')
        self.assertIsNotNone(res.created_at)
        self.assertIn('key-123', str(res))

    def test_reservation_uniqueness_per_user_key(self):
        Reservation.objects.create(
            user=self.user1,
            instance=self.instance1,
            key='shared-key'
        )
        # Same user, same key -> IntegrityError
        from django.db import transaction
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                Reservation.objects.create(
                    user=self.user1,
                    instance=self.instance2,
                    key='shared-key'
                )

        # Different user, same key -> allowed
        res2 = Reservation.objects.create(
            user=self.user2,
            instance=self.instance2,
            key='shared-key'
        )
        self.assertEqual(res2.key, 'shared-key')


class ReservationAPITest(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user1 = User.objects.create_user(username='apiuser1', password='password123')
        cls.user2 = User.objects.create_user(username='apiuser2', password='password123')
        cls.author = Author.objects.create(first_name='Author', last_name='Name')
        cls.book = Book.objects.create(
            title='Sample Book',
            author=cls.author,
            summary='Test summary',
            isbn='9876543210123'
        )
        cls.instance_avail = BookInstance.objects.create(
            book=cls.book,
            imprint='Imprint 1',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        cls.instance_on_loan = BookInstance.objects.create(
            book=cls.book,
            imprint='Imprint 2',
            status=BookInstance.LoanStatus.ON_LOAN
        )
        cls.instance_reserved = BookInstance.objects.create(
            book=cls.book,
            imprint='Imprint 3',
            status=BookInstance.LoanStatus.RESERVED
        )
        cls.instance_maint = BookInstance.objects.create(
            book=cls.book,
            imprint='Imprint 4',
            status=BookInstance.LoanStatus.MAINTENANCE
        )

    def test_unauthenticated_returns_401(self):
        url = reverse('api-reserve-book-instance', args=[self.instance_avail.id])
        res = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(res.status_code, 401)
        self.assertEqual(res.json(), {'error': 'unauthorized'})

    def test_method_not_allowed_for_get_and_others(self):
        self.client.login(username='apiuser1', password='password123')
        url = reverse('api-reserve-book-instance', args=[self.instance_avail.id])
        res_get = self.client.get(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(res_get.status_code, 405)
        self.assertEqual(res_get.json(), {'error': 'method_not_allowed'})

        res_put = self.client.put(url, HTTP_IDEMPOTENCY_KEY='key-1')
        self.assertEqual(res_put.status_code, 405)

    def test_invalid_key_missing_empty_whitespace_or_too_long(self):
        self.client.login(username='apiuser1', password='password123')
        url = reverse('api-reserve-book-instance', args=[self.instance_avail.id])

        # Missing header
        res1 = self.client.post(url)
        self.assertEqual(res1.status_code, 400)
        self.assertEqual(res1.json(), {'error': 'invalid_key'})

        # Empty string
        res2 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='')
        self.assertEqual(res2.status_code, 400)
        self.assertEqual(res2.json(), {'error': 'invalid_key'})

        # Whitespace only
        res3 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(res3.status_code, 400)
        self.assertEqual(res3.json(), {'error': 'invalid_key'})

        # Longer than 100 characters
        res4 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='k' * 101)
        self.assertEqual(res4.status_code, 400)
        self.assertEqual(res4.json(), {'error': 'invalid_key'})

    def test_nonexistent_instance_returns_404(self):
        self.client.login(username='apiuser1', password='password123')
        random_uuid = uuid.uuid4()
        url = reverse('api-reserve-book-instance', args=[random_uuid])
        res = self.client.post(url, HTTP_IDEMPOTENCY_KEY='valid-key-404')
        self.assertEqual(res.status_code, 404)
        self.assertEqual(res.json(), {'error': 'not_found'})

    def test_unavailable_instance_returns_409(self):
        self.client.login(username='apiuser1', password='password123')

        for inst in [self.instance_on_loan, self.instance_reserved, self.instance_maint]:
            url = reverse('api-reserve-book-instance', args=[inst.id])
            res = self.client.post(url, HTTP_IDEMPOTENCY_KEY=f'key-{inst.id}')
            self.assertEqual(res.status_code, 409)
            self.assertEqual(res.json(), {'error': 'unavailable'})
            inst.refresh_from_db()
            self.assertNotEqual(inst.borrower, self.user1)

    def test_successful_first_reservation_and_replay_idempotency(self):
        self.client.login(username='apiuser1', password='password123')
        url = reverse('api-reserve-book-instance', args=[self.instance_avail.id])

        # First reservation (201 Created)
        res1 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='idemp-key-100')
        self.assertEqual(res1.status_code, 201)
        expected_payload = {
            "instance_id": str(self.instance_avail.id),
            "user_id": self.user1.id,
            "status": "r"
        }
        self.assertEqual(res1.json(), expected_payload)

        # Check DB state
        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance_avail.borrower, self.user1)
        self.assertEqual(Reservation.objects.filter(user=self.user1, key='idemp-key-100').count(), 1)

        # Replay with same user, same key, same instance -> 201 Created exact same payload
        res2 = self.client.post(url, HTTP_IDEMPOTENCY_KEY='idemp-key-100')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), expected_payload)
        self.assertEqual(Reservation.objects.filter(user=self.user1, key='idemp-key-100').count(), 1)

        # Replay from a new client/session (new connection)
        new_client = Client()
        new_client.login(username='apiuser1', password='password123')
        res3 = new_client.post(url, HTTP_IDEMPOTENCY_KEY='idemp-key-100')
        self.assertEqual(res3.status_code, 201)
        self.assertEqual(res3.json(), expected_payload)
        self.assertEqual(Reservation.objects.filter(user=self.user1, key='idemp-key-100').count(), 1)

    def test_idempotency_conflict_when_reusing_key_for_different_instance(self):
        self.client.login(username='apiuser1', password='password123')
        inst2 = BookInstance.objects.create(
            book=self.book,
            imprint='Imprint Second',
            status=BookInstance.LoanStatus.AVAILABLE
        )

        url1 = reverse('api-reserve-book-instance', args=[self.instance_avail.id])
        res1 = self.client.post(url1, HTTP_IDEMPOTENCY_KEY='reused-key')
        self.assertEqual(res1.status_code, 201)

        # Try reserving inst2 with the same key
        url2 = reverse('api-reserve-book-instance', args=[inst2.id])
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='reused-key')
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})

        inst2.refresh_from_db()
        self.assertEqual(inst2.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(inst2.borrower)

    def test_failed_requests_do_not_mutate_state(self):
        self.client.login(username='apiuser1', password='password123')
        url = reverse('api-reserve-book-instance', args=[self.instance_avail.id])

        # Failed with 400
        res = self.client.post(url, HTTP_IDEMPOTENCY_KEY='')
        self.assertEqual(res.status_code, 400)

        self.instance_avail.refresh_from_db()
        self.assertEqual(self.instance_avail.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertIsNone(self.instance_avail.borrower)
        self.assertEqual(Reservation.objects.count(), 0)


class ConcurrencyReservationTest(TransactionTestCase):
    """Tests real concurrent requests with SQLite on disk."""

    def setUp(self):
        self.author = Author.objects.create(first_name='Author', last_name='Concurrent')
        self.book = Book.objects.create(
            title='Concurrent Book',
            author=self.author,
            summary='Summary',
            isbn='1112223334445'
        )
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Concurrent Imprint',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.users = [
            User.objects.create_user(username=f'cuser_{i}', password='password123')
            for i in range(5)
        ]

    def test_concurrent_reservations_result_in_one_winner_and_conflicts_no_500(self):
        url = reverse('api-reserve-book-instance', args=[self.instance.id])

        # Pre-authenticate clients sequentially to avoid session table lock during concurrent worker execution
        clients = []
        for user in self.users:
            c = Client()
            c.force_login(user)
            clients.append((c, user))

        def reserve_call(client_user):
            client, user = client_user
            connection.close()  # Ensure independent thread connection
            key = f'concurrency-key-{user.id}'
            response = client.post(url, HTTP_IDEMPOTENCY_KEY=key)
            return response.status_code, response.json()

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(reserve_call, cu) for cu in clients]
            results = [f.result() for f in concurrent.futures.as_completed(futures)]

        status_codes = [status for status, _ in results]
        self.assertEqual(status_codes.count(201), 1)
        self.assertEqual(status_codes.count(409), 4)
        for status, data in results:
            if status == 409:
                self.assertEqual(data, {'error': 'unavailable'})
            elif status == 201:
                self.assertEqual(data['status'], 'r')

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIsNotNone(self.instance.borrower)
        self.assertEqual(Reservation.objects.filter(instance=self.instance).count(), 1)


class ReservationUITest(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user(username='webuser', password='password123')
        cls.author = Author.objects.create(first_name='Web', last_name='Author')
        cls.book = Book.objects.create(
            title='Web Book',
            author=cls.author,
            summary='Web summary',
            isbn='5556667778889'
        )
        cls.avail_copy = BookInstance.objects.create(
            book=cls.book,
            imprint='Available Copy',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        cls.maint_copy = BookInstance.objects.create(
            book=cls.book,
            imprint='Maintenance Copy',
            status=BookInstance.LoanStatus.MAINTENANCE
        )

    def test_book_detail_shows_reserve_form_for_available_copies_only(self):
        url = reverse('book-detail', args=[self.book.id])
        res = self.client.get(url)
        self.assertEqual(res.status_code, 200)

        reserve_url = reverse('reserve-book-instance-web', args=[self.avail_copy.id])
        self.assertContains(res, reserve_url)
        self.assertContains(res, 'Reserve</button>')
        self.assertContains(res, 'name="idempotency_key"')

        # Maintenance copy should not have reserve form
        maint_reserve_url = reverse('reserve-book-instance-web', args=[self.maint_copy.id])
        self.assertNotContains(res, maint_reserve_url)

    def test_web_reserve_unauthenticated_redirects_to_login(self):
        reserve_url = reverse('reserve-book-instance-web', args=[self.avail_copy.id])
        res = self.client.post(reserve_url, {'idempotency_key': 'test-web-key'})
        self.assertEqual(res.status_code, 302)
        self.assertTrue(res.url.startswith('/accounts/login/'))

    def test_web_reserve_success_redirects_and_shows_message(self):
        self.client.login(username='webuser', password='password123')
        reserve_url = reverse('reserve-book-instance-web', args=[self.avail_copy.id])
        res = self.client.post(reserve_url, {'idempotency_key': 'test-web-key-1'}, follow=True)
        self.assertEqual(res.status_code, 200)
        self.assertContains(res, 'Book copy successfully reserved!')

        self.avail_copy.refresh_from_db()
        self.assertEqual(self.avail_copy.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.avail_copy.borrower, self.user)
