import uuid
import json
import threading
from django.test import TestCase, TransactionTestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from catalog.models import Book, Author, BookInstance, Genre, Language, Reservation

User = get_user_model()


class ReservationModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='password123')
        self.user2 = User.objects.create_user(username='testuser2', password='password123')
        self.book = Book.objects.create(title='Test Book', summary='A summary', isbn='1234567890123')
        self.instance = BookInstance.objects.create(book=self.book, imprint='Test Imprint', status=BookInstance.LoanStatus.AVAILABLE)

    def test_reservation_creation_and_uniqueness(self):
        res1 = Reservation.objects.create(user=self.user, instance=self.instance, key='key1')
        self.assertEqual(res1.user, self.user)
        self.assertEqual(res1.instance, self.instance)
        self.assertEqual(res1.key, 'key1')
        self.assertIsNotNone(res1.created_at)

        # Different user with same key should succeed
        res2 = Reservation.objects.create(user=self.user2, instance=self.instance, key='key1')
        self.assertEqual(res2.key, 'key1')

        # Same user with same key should raise IntegrityError
        from django.db import IntegrityError
        with self.assertRaises(IntegrityError):
            Reservation.objects.create(user=self.user, instance=self.instance, key='key1')


class ReservationAPITest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='apiuser', password='password123')
        self.user2 = User.objects.create_user(username='apiuser2', password='password123')
        self.book = Book.objects.create(title='API Book', summary='Summary', isbn='9876543210123')
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Imprint',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.url = reverse('bookinstance-reserve-api', args=[self.instance.id])

    def test_unauthenticated_returns_401(self):
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key123')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})

    def test_method_not_allowed_for_get(self):
        self.client.force_login(self.user)
        response = self.client.get(self.url, HTTP_IDEMPOTENCY_KEY='key123')
        self.assertEqual(response.status_code, 405)
        self.assertEqual(response.json(), {'error': 'method_not_allowed'})

    def test_missing_or_invalid_idempotency_key(self):
        self.client.force_login(self.user)

        # Missing header
        res1 = self.client.post(self.url)
        self.assertEqual(res1.status_code, 400)
        self.assertEqual(res1.json(), {'error': 'invalid_key'})

        # Empty or whitespace header
        res2 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='   ')
        self.assertEqual(res2.status_code, 400)
        self.assertEqual(res2.json(), {'error': 'invalid_key'})

        # Header > 100 chars
        res3 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='x' * 101)
        self.assertEqual(res3.status_code, 400)
        self.assertEqual(res3.json(), {'error': 'invalid_key'})

    def test_nonexistent_instance_returns_404(self):
        self.client.force_login(self.user)
        random_uuid = uuid.uuid4()
        url = reverse('bookinstance-reserve-api', args=[random_uuid])
        response = self.client.post(url, HTTP_IDEMPOTENCY_KEY='key123')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})

    def test_unavailable_instance_returns_409(self):
        self.client.force_login(self.user)
        self.instance.status = BookInstance.LoanStatus.MAINTENANCE
        self.instance.save()

        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key123')
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        self.assertEqual(Reservation.objects.count(), 0)

    def test_successful_reservation(self):
        self.client.force_login(self.user)
        response = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-success-1')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), {
            "instance_id": str(self.instance.id),
            "user_id": self.user.id,
            "status": "r"
        })

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, 'r')
        self.assertEqual(self.instance.borrower, self.user)

        self.assertTrue(Reservation.objects.filter(user=self.user, instance=self.instance, key='key-success-1').exists())

    def test_idempotent_replay_same_user_same_key_same_instance(self):
        self.client.force_login(self.user)
        # First request
        res1 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-replay')
        self.assertEqual(res1.status_code, 201)

        # Replay request
        res2 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-replay')
        self.assertEqual(res2.status_code, 201)
        self.assertEqual(res2.json(), {
            "instance_id": str(self.instance.id),
            "user_id": self.user.id,
            "status": "r"
        })

        # Ensure no duplicates created
        self.assertEqual(Reservation.objects.filter(user=self.user, key='key-replay').count(), 1)

    def test_idempotency_conflict_same_user_same_key_different_instance(self):
        self.client.force_login(self.user)
        # First reservation on self.instance
        res1 = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-conflict')
        self.assertEqual(res1.status_code, 201)

        # Another instance
        instance2 = BookInstance.objects.create(
            book=self.book,
            imprint='Imprint 2',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        url2 = reverse('bookinstance-reserve-api', args=[instance2.id])

        # Attempt to reuse the same key for different instance
        res2 = self.client.post(url2, HTTP_IDEMPOTENCY_KEY='key-conflict')
        self.assertEqual(res2.status_code, 409)
        self.assertEqual(res2.json(), {'error': 'idempotency_conflict'})

        # Instance2 should remain available
        instance2.refresh_from_db()
        self.assertEqual(instance2.status, BookInstance.LoanStatus.AVAILABLE)

    def test_failed_requests_do_not_mutate_state(self):
        self.client.force_login(self.user)
        # Attempt with unavailable instance
        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.save()

        res = self.client.post(self.url, HTTP_IDEMPOTENCY_KEY='key-no-mutation')
        self.assertEqual(res.status_code, 409)

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.ON_LOAN)
        self.assertIsNone(self.instance.borrower)
        self.assertEqual(Reservation.objects.count(), 0)


class ReservationConcurrencyTest(TransactionTestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='conc_user1', password='pwd')
        self.user2 = User.objects.create_user(username='conc_user2', password='pwd')
        self.book = Book.objects.create(title='Concurrency Book', summary='Sum', isbn='1112223334445')
        self.instance = BookInstance.objects.create(
            book=self.book,
            imprint='Imprint Conc',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.url = reverse('bookinstance-reserve-api', args=[self.instance.id])

    def test_concurrent_reservation_results_in_one_success_and_one_conflict(self):
        from django.test import Client

        results = []

        def reserve(user, key):
            c = Client()
            c.force_login(user)
            resp = c.post(self.url, HTTP_IDEMPOTENCY_KEY=key)
            results.append((resp.status_code, resp.json()))

        t1 = threading.Thread(target=reserve, args=(self.user1, 'key-user1'))
        t2 = threading.Thread(target=reserve, args=(self.user2, 'key-user2'))

        t1.start()
        t2.start()
        t1.join()
        t2.join()

        status_codes = [r[0] for r in results]
        self.assertIn(201, status_codes)
        self.assertIn(409, status_codes)

        conflict_resp = [r[1] for r in results if r[0] == 409][0]
        self.assertEqual(conflict_resp, {'error': 'unavailable'})

        success_resp = [r[1] for r in results if r[0] == 201][0]
        self.assertEqual(success_resp["status"], "r")

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(Reservation.objects.count(), 1)


class ReservationUITest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='uiuser', password='password123')
        self.book = Book.objects.create(title='UI Book', summary='Summary', isbn='5556667778889')
        self.available_copy = BookInstance.objects.create(
            book=self.book,
            imprint='Copy 1',
            status=BookInstance.LoanStatus.AVAILABLE
        )
        self.maintenance_copy = BookInstance.objects.create(
            book=self.book,
            imprint='Copy 2',
            status=BookInstance.LoanStatus.MAINTENANCE
        )

    def test_book_detail_shows_reserve_button_only_for_available_copy(self):
        url = reverse('book-detail', args=[self.book.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

        reserve_url = reverse('bookinstance-reserve-web', args=[self.available_copy.id])
        self.assertContains(response, reserve_url)
        self.assertContains(response, 'Reservar')
        self.assertContains(response, 'idempotency_key')

        maint_reserve_url = reverse('bookinstance-reserve-web', args=[self.maintenance_copy.id])
        self.assertNotContains(response, maint_reserve_url)

    def test_web_reserve_anonymous_redirects_to_login(self):
        reserve_url = reverse('bookinstance-reserve-web', args=[self.available_copy.id])
        response = self.client.post(reserve_url, {'idempotency_key': 'key-web'})
        self.assertEqual(response.status_code, 302)
        self.assertIn('/accounts/login/', response.url)

    def test_web_reserve_authenticated_success_and_flash_message(self):
        self.client.force_login(self.user)
        reserve_url = reverse('bookinstance-reserve-web', args=[self.available_copy.id])
        book_detail_url = reverse('book-detail', args=[self.book.id])

        response = self.client.post(reserve_url, {'idempotency_key': 'key-web-1'}, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertRedirects(response, book_detail_url)

        self.assertContains(response, '¡Ejemplar reservado exitosamente!')
        self.available_copy.refresh_from_db()
        self.assertEqual(self.available_copy.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.available_copy.borrower, self.user)
        self.assertEqual(Reservation.objects.count(), 1)
