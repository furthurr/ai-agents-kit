import threading
from concurrent.futures import ThreadPoolExecutor

from django.contrib.auth import get_user_model
from django.db import close_old_connections
from django.test import Client, TestCase, TransactionTestCase

from catalog import models
from catalog.models import Author, Book, BookInstance


User = get_user_model()


class ReservationFixtureMixin:
    def create_catalog(self):
        self.user = User.objects.create_user(username='reader', password='password')
        self.other_user = User.objects.create_user(
            username='other-reader', password='password')
        author = Author.objects.create(first_name='Test', last_name='Author')
        self.book = Book.objects.create(
            title='Reservation test book',
            summary='A book used by reservation tests.',
            isbn='9781234567890',
            author=author,
        )
        self.instance = self.create_instance()

    def create_instance(self):
        return BookInstance.objects.create(
            book=self.book,
            imprint='Test imprint',
            status=BookInstance.LoanStatus.AVAILABLE,
        )

    def api_url(self, instance=None):
        instance = instance or self.instance
        return f'/catalog/api/bookinstance/{instance.pk}/reserve/'

    def web_url(self, instance=None):
        instance = instance or self.instance
        return f'/catalog/book/{instance.pk}/reserve/'

    def reserve(self, instance=None, key='request-1', client=None):
        client = client or self.client
        return client.post(
            self.api_url(instance),
            HTTP_IDEMPOTENCY_KEY=key,
        )


class ReservationModelTests(ReservationFixtureMixin, TestCase):
    def setUp(self):
        self.create_catalog()

    def test_public_reservation_model_has_required_fields_and_user_key_constraint(self):
        reservation_model = getattr(models, 'Reservation', None)
        self.assertIsNotNone(reservation_model)
        self.assertEqual(reservation_model._meta.get_field('key').max_length, 100)
        self.assertTrue(reservation_model._meta.get_field('created_at').auto_now_add)
        self.assertEqual(
            reservation_model._meta.get_field('user').remote_field.model,
            User,
        )
        self.assertEqual(
            reservation_model._meta.get_field('instance').remote_field.model,
            BookInstance,
        )
        self.assertTrue(any(
            set(constraint.fields) == {'user', 'key'}
            for constraint in reservation_model._meta.constraints
        ))


class ReservationAPITests(ReservationFixtureMixin, TestCase):
    def setUp(self):
        self.create_catalog()

    def login(self, client=None, user=None):
        client = client or self.client
        client.force_login(user or self.user)
        return client

    def assert_error(self, response, status, error):
        self.assertEqual(response.status_code, status)
        self.assertEqual(response.json(), {'error': error})

    def test_authentication_and_post_only_contract(self):
        self.assert_error(self.reserve(), 401, 'unauthorized')
        self.assertEqual(self.client.get(self.api_url()).status_code, 405)
        self.assertEqual(self.client.put(self.api_url()).status_code, 405)
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(models.Reservation.objects.count(), 0)

    def test_invalid_keys_do_not_reserve_or_create_records(self):
        client = self.login()
        for key in (None, '', '   ', 'x' * 101):
            with self.subTest(key=key):
                headers = {} if key is None else {'HTTP_IDEMPOTENCY_KEY': key}
                response = client.post(self.api_url(), **headers)
                self.assert_error(response, 400, 'invalid_key')
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(models.Reservation.objects.count(), 0)

    def test_missing_instance_returns_json_404_without_reservation(self):
        client = self.login()
        response = client.post(
            '/catalog/api/bookinstance/00000000-0000-0000-0000-000000000000/reserve/',
            HTTP_IDEMPOTENCY_KEY='missing',
        )
        self.assert_error(response, 404, 'not_found')
        self.assertEqual(models.Reservation.objects.count(), 0)

    def test_first_reservation_and_persistent_replay_have_exact_response(self):
        client = self.login()
        key = 'k' * 100
        response = self.reserve(key=key, client=client)
        expected = {
            'instance_id': str(self.instance.pk),
            'user_id': self.user.pk,
            'status': 'r',
        }
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), expected)

        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.instance.borrower_id, self.user.pk)
        self.assertEqual(models.Reservation.objects.count(), 1)
        record = models.Reservation.objects.get()
        self.assertEqual(record.user_id, self.user.pk)
        self.assertEqual(record.instance_id, self.instance.pk)
        self.assertEqual(record.key, key)

        replay_client = self.login(client=Client())
        replay = self.reserve(key=key, client=replay_client)
        self.assertEqual(replay.status_code, 201)
        self.assertEqual(replay.json(), expected)
        self.assertEqual(models.Reservation.objects.count(), 1)

    def test_reusing_key_for_another_instance_conflicts_without_mutation(self):
        client = self.login()
        self.assertEqual(self.reserve(key='same-key', client=client).status_code, 201)
        other_instance = self.create_instance()

        response = self.reserve(
            instance=other_instance,
            key='same-key',
            client=client,
        )
        self.assert_error(response, 409, 'idempotency_conflict')
        other_instance.refresh_from_db()
        self.assertEqual(other_instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(models.Reservation.objects.count(), 1)

    def test_unavailable_instance_and_independent_users(self):
        client = self.login()
        self.instance.status = BookInstance.LoanStatus.ON_LOAN
        self.instance.save(update_fields=['status'])
        response = self.reserve(key='unavailable', client=client)
        self.assert_error(response, 409, 'unavailable')
        self.assertEqual(models.Reservation.objects.count(), 0)

        other_instance = self.create_instance()
        other_client = self.login(client=Client(), user=self.other_user)
        response = self.reserve(
            instance=other_instance,
            key='same-user-independent-key',
            client=client,
        )
        self.assertEqual(response.status_code, 201)
        response = self.reserve(
            instance=self.create_instance(),
            key='same-user-independent-key',
            client=other_client,
        )
        self.assertEqual(response.status_code, 201)


class ReservationWebTests(ReservationFixtureMixin, TestCase):
    def setUp(self):
        self.create_catalog()

    def test_book_detail_shows_csrf_protected_form_only_for_available_copy(self):
        unavailable = self.create_instance()
        unavailable.status = BookInstance.LoanStatus.ON_LOAN
        unavailable.save(update_fields=['status'])

        response = self.client.get(f'/catalog/book/{self.book.pk}')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, self.web_url())
        self.assertContains(response, 'name="idempotency_key"')
        self.assertContains(response, 'name="csrfmiddlewaretoken"')
        self.assertNotContains(response, self.web_url(unavailable))

    def test_anonymous_web_post_redirects_to_login_without_reserving(self):
        response = self.client.post(
            self.web_url(),
            {'idempotency_key': 'web-key'},
        )
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/'))
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(models.Reservation.objects.count(), 0)

    def test_web_post_requires_csrf_and_shows_success_message(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        page = client.get(f'/catalog/book/{self.book.pk}')
        self.assertEqual(page.status_code, 200)
        csrf_token = client.cookies['csrftoken'].value
        response = client.post(
            self.web_url(),
            {
                'idempotency_key': 'web-success-key',
                'csrfmiddlewaretoken': csrf_token,
            },
            follow=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Reservation confirmed')
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(models.Reservation.objects.count(), 1)


class ReservationConcurrencyTests(ReservationFixtureMixin, TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        self.create_catalog()
        self.clients = []
        for user in (self.user, self.other_user):
            client = Client()
            client.force_login(user)
            self.clients.append(client)

    def test_two_users_racing_for_one_available_copy_have_one_winner(self):
        barrier = threading.Barrier(2)
        url = self.api_url()

        def post_reservation(client, key):
            close_old_connections()
            try:
                barrier.wait(timeout=10)
                return client.post(url, HTTP_IDEMPOTENCY_KEY=key)
            finally:
                close_old_connections()

        with ThreadPoolExecutor(max_workers=2) as executor:
            futures = [
                executor.submit(post_reservation, self.clients[0], 'race-one'),
                executor.submit(post_reservation, self.clients[1], 'race-two'),
            ]
            responses = [future.result(timeout=20) for future in futures]

        self.assertEqual(sorted(response.status_code for response in responses), [201, 409])
        conflict = next(response for response in responses if response.status_code == 409)
        self.assertEqual(conflict.json(), {'error': 'unavailable'})
        self.instance.refresh_from_db()
        self.assertEqual(self.instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertIn(self.instance.borrower_id, (self.user.pk, self.other_user.pk))
        self.assertEqual(models.Reservation.objects.count(), 1)
