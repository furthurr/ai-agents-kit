import re
import uuid
from threading import Barrier, Thread

from django.contrib.auth import get_user_model
from django.db import IntegrityError, close_old_connections, connection, transaction
from django.test import Client, TestCase, TransactionTestCase
from django.urls import reverse

from catalog.models import Author, Book, BookInstance, Reservation


User = get_user_model()


class ReservationTestDataMixin:
    @classmethod
    def setUpTestData(cls):
        cls.create_reservation_test_data()

    @classmethod
    def create_reservation_test_data(cls):
        cls.user = User.objects.create_user(
            username='reservation-user', password='test-password-123')
        cls.other_user = User.objects.create_user(
            username='other-reservation-user', password='test-password-123')
        author = Author.objects.create(first_name='Test', last_name='Author')
        cls.book = Book.objects.create(
            title='Reservable Book',
            summary='A book available for reservation.',
            isbn='9780000000001',
            author=author,
        )
        cls.available_instance = BookInstance.objects.create(
            book=cls.book,
            imprint='Test imprint',
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        cls.second_instance = BookInstance.objects.create(
            book=cls.book,
            imprint='Test imprint',
            status=BookInstance.LoanStatus.AVAILABLE,
        )
        cls.unavailable_instance = BookInstance.objects.create(
            book=cls.book,
            imprint='Test imprint',
            status=BookInstance.LoanStatus.ON_LOAN,
            borrower=cls.other_user,
        )

    def api_url(self, instance=None):
        return reverse(
            'api-reserve-bookinstance',
            kwargs={'pk': instance or self.available_instance.pk},
        )

    def post_reservation(self, client=None, instance=None, key='reserve-key'):
        client = client or self.client
        return client.post(
            self.api_url(instance),
            HTTP_IDEMPOTENCY_KEY=key,
        )


class ReservationModelTests(ReservationTestDataMixin, TestCase):
    def test_key_is_unique_per_user_and_reservations_persist(self):
        first = Reservation.objects.create(
            user=self.user,
            instance=self.available_instance,
            key='same-key',
        )
        other_users_reservation = Reservation.objects.create(
            user=self.other_user,
            instance=self.second_instance,
            key='same-key',
        )

        self.assertEqual(Reservation.objects.get(pk=first.pk).key, 'same-key')
        self.assertEqual(other_users_reservation.user_id, self.other_user.pk)
        with self.assertRaises(IntegrityError), transaction.atomic():
            Reservation.objects.create(
                user=self.user,
                instance=self.second_instance,
                key='same-key',
            )

        self.assertEqual(Reservation.objects.count(), 2)


class ReservationApiTests(ReservationTestDataMixin, TestCase):
    def setUp(self):
        self.client.force_login(self.user)

    def test_anonymous_request_returns_401_json(self):
        response = Client().post(
            self.api_url(), HTTP_IDEMPOTENCY_KEY='anonymous-key')

        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'error': 'unauthorized'})
        self.available_instance.refresh_from_db()
        self.assertEqual(
            self.available_instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertFalse(Reservation.objects.exists())

    def test_non_post_methods_return_405_without_mutation(self):
        get_response = self.client.get(self.api_url())
        put_response = self.client.put(
            self.api_url(), data='{}', content_type='application/json')

        self.assertEqual(get_response.status_code, 405)
        self.assertEqual(put_response.status_code, 405)
        self.available_instance.refresh_from_db()
        self.assertEqual(
            self.available_instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertFalse(Reservation.objects.exists())

    def test_invalid_idempotency_keys_return_400_without_mutation(self):
        invalid_keys = (None, '   ', 'x' * 101)
        for key in invalid_keys:
            with self.subTest(key=key):
                headers = {} if key is None else {'HTTP_IDEMPOTENCY_KEY': key}
                response = self.client.post(self.api_url(), **headers)

                self.assertEqual(response.status_code, 400)
                self.assertEqual(response.json(), {'error': 'invalid_key'})
                self.available_instance.refresh_from_db()
                self.assertEqual(
                    self.available_instance.status,
                    BookInstance.LoanStatus.AVAILABLE,
                )
                self.assertFalse(Reservation.objects.exists())

    def test_missing_instance_returns_404_without_mutation(self):
        response = self.post_reservation(instance=uuid.uuid4(), key='missing')

        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {'error': 'not_found'})
        self.available_instance.refresh_from_db()
        self.assertEqual(
            self.available_instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertFalse(Reservation.objects.exists())

    def test_unavailable_instance_returns_exact_conflict_without_reservation(self):
        response = self.post_reservation(
            instance=self.unavailable_instance.pk, key='unavailable')

        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'unavailable'})
        self.unavailable_instance.refresh_from_db()
        self.assertEqual(
            self.unavailable_instance.status, BookInstance.LoanStatus.ON_LOAN)
        self.assertFalse(Reservation.objects.exists())

    def test_first_reservation_updates_instance_and_returns_exact_payload(self):
        key = 'k' * 100
        response = self.post_reservation(key=key)

        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json(), {
            'instance_id': str(self.available_instance.pk),
            'user_id': self.user.pk,
            'status': 'r',
        })
        self.available_instance.refresh_from_db()
        self.assertEqual(
            self.available_instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.available_instance.borrower, self.user)
        self.assertEqual(Reservation.objects.count(), 1)
        self.assertEqual(Reservation.objects.get().key, key)

    def test_replay_with_new_http_session_returns_the_same_payload(self):
        first_response = self.post_reservation(key='persistent-replay')
        new_client = Client()
        new_client.force_login(self.user)

        replay = self.post_reservation(
            client=new_client, key='persistent-replay')

        self.assertEqual(first_response.status_code, 201)
        self.assertEqual(replay.status_code, 201)
        self.assertEqual(replay.json(), first_response.json())
        self.assertEqual(Reservation.objects.count(), 1)
        self.available_instance.refresh_from_db()
        self.assertEqual(
            self.available_instance.status, BookInstance.LoanStatus.RESERVED)

    def test_reusing_key_for_another_instance_conflicts_without_mutation(self):
        self.post_reservation(instance=self.available_instance.pk, key='one-key')

        response = self.post_reservation(
            instance=self.second_instance.pk, key='one-key')

        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json(), {'error': 'idempotency_conflict'})
        self.second_instance.refresh_from_db()
        self.assertEqual(
            self.second_instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertEqual(Reservation.objects.count(), 1)

    def test_same_key_is_independent_between_users(self):
        self.post_reservation(instance=self.available_instance.pk, key='shared-key')
        other_client = Client()
        other_client.force_login(self.other_user)

        response = self.post_reservation(
            client=other_client,
            instance=self.second_instance.pk,
            key='shared-key',
        )

        self.assertEqual(response.status_code, 201)
        self.assertEqual(Reservation.objects.count(), 2)
        self.assertEqual(
            set(Reservation.objects.values_list('user_id', 'key')),
            {(self.user.pk, 'shared-key'), (self.other_user.pk, 'shared-key')},
        )


class ReservationWebTests(ReservationTestDataMixin, TestCase):
    def setUp(self):
        self.client.force_login(self.user)
        self.detail_url = reverse('book-detail', kwargs={'pk': self.book.pk})
        self.web_reservation_url = reverse(
            'reserve-bookinstance-web',
            kwargs={'pk': self.available_instance.pk},
        )

    def test_detail_renders_csrf_form_only_for_available_instances(self):
        response = self.client.get(self.detail_url)

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, self.web_reservation_url)
        self.assertContains(response, 'name="csrfmiddlewaretoken"')
        self.assertContains(response, 'name="idempotency_key"')
        self.assertNotContains(response, reverse(
            'reserve-bookinstance-web',
            kwargs={'pk': self.unavailable_instance.pk},
        ))
        key_matches = re.findall(
            r'name="idempotency_key" value="([^"]+)"',
            response.content.decode(),
        )
        self.assertEqual(len(key_matches), 2)
        self.assertEqual(len(set(key_matches)), 2)
        self.assertTrue(all(len(key) == 36 for key in key_matches))

    def test_anonymous_web_post_redirects_to_login(self):
        response = Client().post(
            self.web_reservation_url,
            {'idempotency_key': 'anonymous-web-key'},
        )

        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/accounts/login/'))
        self.available_instance.refresh_from_db()
        self.assertEqual(
            self.available_instance.status, BookInstance.LoanStatus.AVAILABLE)
        self.assertFalse(Reservation.objects.exists())

    def test_web_post_requires_csrf_and_shows_success_message(self):
        csrf_client = Client(enforce_csrf_checks=True)
        csrf_client.force_login(self.user)
        detail_response = csrf_client.get(self.detail_url)
        content = detail_response.content.decode()
        csrf_match = re.search(
            r'name="csrfmiddlewaretoken" value="([^"]+)"', content)
        key_match = re.search(
            r'name="idempotency_key" value="([^"]+)"', content)
        self.assertIsNotNone(csrf_match)
        self.assertIsNotNone(key_match)

        csrf_rejected = csrf_client.post(
            self.web_reservation_url,
            {'idempotency_key': key_match.group(1)},
        )
        self.assertEqual(csrf_rejected.status_code, 403)
        self.assertFalse(Reservation.objects.exists())
        self.available_instance.refresh_from_db()
        self.assertEqual(
            self.available_instance.status, BookInstance.LoanStatus.AVAILABLE)

        response = csrf_client.post(
            self.web_reservation_url,
            {
                'csrfmiddlewaretoken': csrf_match.group(1),
                'idempotency_key': key_match.group(1),
            },
            follow=True,
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Reservation confirmed')
        self.assertEqual(response.redirect_chain[-1][0], self.detail_url)
        self.available_instance.refresh_from_db()
        self.assertEqual(
            self.available_instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(Reservation.objects.count(), 1)


class ReservationConcurrencyTests(ReservationTestDataMixin, TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        self.create_reservation_test_data()

    def test_two_users_racing_for_one_instance_get_one_success_and_one_unavailable(self):
        self.assertEqual(connection.vendor, 'sqlite')
        self.assertNotEqual(str(connection.settings_dict['NAME']), ':memory:')
        barrier = Barrier(2)
        results = []
        errors = []
        clients = []
        for user in (self.user, self.other_user):
            client = Client()
            client.force_login(user)
            clients.append((client, user))

        def reserve_concurrently(client, user):
            close_old_connections()
            try:
                barrier.wait(timeout=5)
                response = client.post(
                    self.api_url(),
                    HTTP_IDEMPOTENCY_KEY=f'concurrent-{user.pk}',
                )
                results.append((user.pk, response.status_code, response.json()))
            except BaseException as error:
                errors.append(error)
            finally:
                close_old_connections()

        threads = [
            Thread(target=reserve_concurrently, args=(client, user))
            for client, user in clients
        ]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=15)

        self.assertFalse(any(thread.is_alive() for thread in threads))
        self.assertEqual(errors, [])
        self.assertEqual(sorted(status for _, status, _ in results), [201, 409])
        loser = next(result for result in results if result[1] == 409)
        winner = next(result for result in results if result[1] == 201)
        self.assertEqual(loser[2], {'error': 'unavailable'})
        self.assertEqual(winner[2], {
            'instance_id': str(self.available_instance.pk),
            'user_id': winner[0],
            'status': 'r',
        })
        self.available_instance.refresh_from_db()
        self.assertEqual(
            self.available_instance.status, BookInstance.LoanStatus.RESERVED)
        self.assertEqual(self.available_instance.borrower_id, winner[0])
        self.assertEqual(Reservation.objects.count(), 1)
